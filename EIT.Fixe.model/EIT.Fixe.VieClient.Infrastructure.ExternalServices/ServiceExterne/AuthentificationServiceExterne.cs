﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Algorithmes;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LoginMappers;
using System;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe de Login.
    /// </summary>
    public class AuthentificationServiceExterne : IAuthentificationServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface de la table de paramétrage.
        /// </summary>
        private readonly IParametrage parametrage;

        /// <summary>
        /// Clé d'encryptage.
        /// </summary>
        private const string ENCRYPTION_KEY = "$¤M0t@P@553#L0g!N*%";

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Identite pour l'appel de la brique Login.
        /// </summary>
        private BriqueLogin.Identite IdentiteLogin
        {
            get
            {
                return new BriqueLogin.Identite()
                {
                    ApplicationAppelante = ObjetsCommunsFixe.IdentiteFixeCommune.ApplicationAppelante,
                    Canal = ObjetsCommunsFixe.IdentiteFixeCommune.Canal,
                    Memoid = ObjetsCommunsFixe.IdentiteFixeCommune.Memoid,
                    PointDeVente = ObjetsCommunsFixe.IdentiteFixeCommune.PointDeVente
                };
            }
        }

        #endregion Propriétés

        #region Constructeurs

        /// <summary>
        /// Constructeur d'instanciation.
        /// </summary>
        /// <param name="parametrage">Interface de la table de paramétrage.</param>
        public AuthentificationServiceExterne(IParametrage parametrage)
        {
            //Vérification des entrées.
            parametrage.Valider(nameof(parametrage)).NonNul();

            //Initialisation des champs.
            this.parametrage = parametrage;
        }

        #endregion Constructeurs

        /// <summary>
        /// Permet de récupérer les informations de login d’un compte client, par sa clé.
        /// </summary>
        /// <param name="cleCompteClient">Clé technique du compte client.</param>
        /// <param name="identite">Informations de l’appelant.</param>
        public InformationsLoginCompteClient ObtenirLoginCcParCleCompteClient(Identite identite, int cleCompteClient)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleCompteClient.Valider(nameof(cleCompteClient)).StrictementPositif();

            //Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseLoginDetaille reponse = wsBriqueLogin.ObtenirLoginCCParCleCompteClient(this.IdentiteLogin, cleCompteClient);
                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                return InformationsLoginCompteClientMapper.Convertir(reponse.Login);
            }
        }

        /// <summary>
        /// Permet de récupérer les niveaux d’accès à l’espace client, par la clé ligne.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cleLigne">Clé technique du compte client.</param>
        public string ObtenirLoginLigneParCleLigne(Identite identite, int cleLigne)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            //Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseLoginDetaille reponse = wsBriqueLogin.ObtenirLoginLigneParCleLigne(this.IdentiteLogin, cleLigne);

                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                RoleLogin role;
                switch ((int)reponse.Login.Role)
                {
                    case 1:
                        role = RoleLogin.NonRestreint;
                        break;
                    case 2:
                        role = RoleLogin.GestionnaireCompteClient;
                        break;
                    case 3:
                        role = RoleLogin.Titulaire;
                        break;
                    default:
                        role = RoleLogin.Restreint;
                        break;

                }

                return role.ToString();
            }
        }

        /// <summary>
        /// Permet de changer le mot de passe d'accès au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login associé au mot de passe à modifier.</param>
        /// <param name="ancienMotDePasse">Ancien mot de passe.</param>
        /// <param name="nouveauMotDePasse">Nouveau mot de passe.</param>
        /// <returns>Réponse de la modification de mot de passe.</returns>
        public ReponseModificationMotDePasse ChangerMotDePasseSelfcare(Identite identite, string login, string ancienMotDePasse, string nouveauMotDePasse)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            ancienMotDePasse.Valider(nameof(ancienMotDePasse)).Obligatoire();
            nouveauMotDePasse.Valider(nameof(nouveauMotDePasse)).Obligatoire();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseLogin reponse = wsBriqueLogin.ChangerMotDePasseSFC(this.IdentiteLogin, login, ancienMotDePasse, nouveauMotDePasse);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                return ReponseModificationMotDePasseMapper.Convertir(reponse);
            }
        }

        /// <summary>
        /// Permet d'envoyer un OTP sur l'email du login passé en paramètre.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login sur lequel on doit envoyer un OTP.</param>
        /// <param name="cleMarque">Clé de la marque.</param>
        public void DemanderOtp(Identite identite, string login, int cleMarque)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            cleMarque.Valider(nameof(cleMarque)).StrictementPositif();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseOTP reponse = wsBriqueLogin.DemanderOtpParMailAvecDestinataire(this.IdentiteLogin, login, cleMarque);

                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur}");
                }
            }
        }

        /// <summary>
        /// Permet de vérifier l'exactitude de l'OTP passé en paramètre.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login sur lequel un OTP a été envoyé.</param>
        /// <param name="codeOtp">Code de l'OTP envoyé.</param>
        /// <returns>Résultat du contrôle de validation de l'OTP.</returns>
        public ReponseValidationOtp ValiderOtp(Identite identite, string login, int codeOtp)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            codeOtp.Valider(nameof(codeOtp)).StrictementPositif();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseService reponse = wsBriqueLogin.ValiderOTP(this.IdentiteLogin, login, codeOtp);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                return ReponseValidationOtpMapper.Convertir(reponse);
            }
        }

        /// <summary>
        /// Permet de réinitialiser le mot de passe SFC.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        /// <returns>Le mot de passe temporaire SFC.</returns>
        public string ReinitialiserMotDePasseSfc(Identite identite, string login)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            //Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseStringService reponse = wsBriqueLogin.ReinitialiserMotDePasseSansComClient(this.IdentiteLogin, login);
                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
                return RC4Cryptor.Dechiffrer(ENCRYPTION_KEY, reponse.ResultatAppel);
            }
        }

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        public void ValiderCguFixe(Identite identite, string login)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseBoolService reponse = wsBriqueLogin.ValiderCGUBox(this.IdentiteLogin, login);
                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }
        }

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Mobile.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        public void ValiderCguMobile(Identite identite, string login)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseBoolService reponse = wsBriqueLogin.ValiderCGU(this.IdentiteLogin, login);
                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }
        }

        /// <summary>
        /// Permet de valider le parcours de bienvenue sur le Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        public void ValiderParcoursBienvenue(Identite identite, string login)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            // Appel à la brique Login.
            using (var wsBriqueLogin = new BriqueLogin.Login() { Url = this.parametrage.UrlBriqueLogin })
            {
                BriqueLogin.ReponseLogin reponse = wsBriqueLogin.ValiderInscriptionWeb(this.IdentiteLogin, login);
                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }
        }
    }
}