﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using IHistoriqueServiceExterne = EIT.Fixe.VieClient.Domain.ServiceExterne.IHistoriqueServiceExterne;
using IReferentielServiceExterne = EIT.Fixe.VieClient.Domain.ServiceExterne.IReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ClasseParametres
{
    /// <summary>
    /// Implémente l'interface qui regroupe les interfaces des services externes.
    /// </summary>
    public class ServicesExternes : IServicesExternes
    {
        #region Champs

        /// <summary>
        /// Service externe IHistoriqueServiceExterne.
        /// </summary>
        private readonly IHistoriqueServiceExterne historiqueServiceExterne;

        /// <summary>
        /// Service externe IHistoriqueServiceExterne.
        /// </summary>
        private readonly IReferentielServiceExterne referentielServiceExterne;

        /// <summary>
        /// Service externe ISouscriptionServiceExterne.
        /// </summary>
        private readonly ISouscriptionServiceExterne souscriptionServiceExterne;

        /// <summary>
        /// Service externe IFacturationServiceExterne.
        /// </summary>
        private readonly IFacturationServiceExterne facturationServiceExterne;

        /// <summary>
        /// Service externe ILogistiqueServiceExterne.
        /// </summary>
        private readonly ILogistiqueServiceExterne logistiqueServiceExterne;

        /// <summary>
        /// Service externe ISavServiceExterne.
        /// </summary>
        private readonly ISavServiceExterne savServiceExterne;

        /// <summary>
        /// Service externe ISavServiceExterne.
        /// </summary>
        private readonly ISavEquipementServiceExterne savEquipementServiceExterne;


        /// <summary>
        /// service externe IAnnuaireServiceExterne (Souscription).
        /// </summary>
        private readonly IAnnuaireServiceExterne annuaireServiceExterne;

        /// <summary>
        /// Retourne l'interface de IGBOServiceExterne.
        /// </summary>
        private readonly IGboServiceExterne gboServiceExterne;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur protégé pour les mocks.
        /// </summary>
        protected ServicesExternes()
        {
        }

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="historiqueServiceExterne">Interface du service externe Historique.</param>
        /// <param name="referentielServiceExterne">Interface du service externe Referentiel.</param>
        /// <param name="souscriptionServiceExterne">Interface du service externe Souscription.</param>
        /// <param name="facturationServiceExterne">Interface du service externe Facturation.</param>
        /// <param name="logistiqueServiceExterne">Interface du service externe Logistique.</param>
        /// <param name="savServiceExterne">Interface du service externe SAV.</param>
        /// <param name="savEquipementServiceExterne">Interface du service externe SAV Equipement.</param>
        /// <param name="annuaireServiceExterne">Interface du service externe Annuaire (Souscription).</param>
        /// <param name="gboServiceExterne">Interface du service externe Gbo.</param>
        public ServicesExternes(IHistoriqueServiceExterne historiqueServiceExterne,
            IReferentielServiceExterne referentielServiceExterne,
            ISouscriptionServiceExterne souscriptionServiceExterne,
            IFacturationServiceExterne facturationServiceExterne,
            ILogistiqueServiceExterne logistiqueServiceExterne,
            ISavServiceExterne savServiceExterne,
            ISavEquipementServiceExterne savEquipementServiceExterne,
            IAnnuaireServiceExterne annuaireServiceExterne,
            IGboServiceExterne gboServiceExterne)
        {
            //Vérification des entrées.
            historiqueServiceExterne.Valider(nameof(historiqueServiceExterne)).NonNul();
            referentielServiceExterne.Valider(nameof(referentielServiceExterne)).NonNul();
            souscriptionServiceExterne.Valider(nameof(souscriptionServiceExterne)).NonNul();
            facturationServiceExterne.Valider(nameof(facturationServiceExterne)).NonNul();
            logistiqueServiceExterne.Valider(nameof(logistiqueServiceExterne)).NonNul();
            savServiceExterne.Valider(nameof(savServiceExterne)).NonNul();
            savEquipementServiceExterne.Valider(nameof(savEquipementServiceExterne)).NonNul();
            annuaireServiceExterne.Valider(nameof(annuaireServiceExterne)).NonNul();
            gboServiceExterne.Valider(nameof(gboServiceExterne)).NonNul();

            //Initialisation des champs.
            this.historiqueServiceExterne = historiqueServiceExterne;
            this.referentielServiceExterne = referentielServiceExterne;
            this.souscriptionServiceExterne = souscriptionServiceExterne;
            this.facturationServiceExterne = facturationServiceExterne;
            this.logistiqueServiceExterne = logistiqueServiceExterne;
            this.savServiceExterne = savServiceExterne;
            this.savEquipementServiceExterne = savEquipementServiceExterne;
            this.annuaireServiceExterne = annuaireServiceExterne;
            this.gboServiceExterne = gboServiceExterne;
        }

        #endregion Constructeurs

        #region IServicesExternes

        /// <summary>
        /// Interface de HistoriqueServiceExterne.
        /// </summary>
        public IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get
            {
                return this.historiqueServiceExterne;
            }
        }

        /// <summary>
        /// interface de ReferentielServiceExterne.
        /// </summary>
        public IReferentielServiceExterne ReferentielServiceExterne
        {
            get
            {
                return this.referentielServiceExterne;
            }
        }

        /// <summary>
        /// Interface de ReferentielServiceExterne.
        /// </summary>
        public ISouscriptionServiceExterne SouscriptionServiceExterne
        {
            get
            {
                return this.souscriptionServiceExterne;
            }
        }

        /// <summary>
        /// Interface de FacturationServiceExterne.
        /// </summary>
        public IFacturationServiceExterne FacturationServiceExterne
        {
            get
            {
                return this.facturationServiceExterne;
            }
        }

        /// <summary>
        /// Interface de LogistiqueServiceExterne.
        /// </summary>
        public ILogistiqueServiceExterne LogistiqueServiceExterne
        {
            get
            {
                return this.logistiqueServiceExterne;
            }
        }
        
        /// <summary>
        /// Retourne l'interface de ISavServiceExterne.
        /// </summary>
        public ISavServiceExterne SavServiceExterne
        {
            get
            {
                return this.savServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface de ISavEquipementServiceExterne.
        /// </summary>
        public ISavEquipementServiceExterne SavEquipementServiceExterne
        {
            get
            {
                return this.savEquipementServiceExterne;
            }
        }



        /// <summary>
        /// Retourne l'interface de IAnnuaireServiceExterne (Souscription).
        /// </summary>
        public IAnnuaireServiceExterne AnnuaireServiceExterne
        {
            get
            {
                return this.annuaireServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface de IGboServiceExterne
        /// </summary>
        public IGboServiceExterne GboServiceExterne
        {
            get
            {
                return this.gboServiceExterne;
            }
        }


        #endregion IServicesExternes
    }
}
