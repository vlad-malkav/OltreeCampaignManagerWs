﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Souscription.Domain.ExternalServices;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using IHistoriqueServiceExterne = EIT.Fixe.VieClient.Domain.ServiceExterne.IHistoriqueServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ClasseParametres
{
    /// <summary>
    /// Implementation de l'interface des interfaces des briques externes.
    /// </summary>
    public class BriquesServicesExternes : IBriquesServicesExternes
    {
        #region Champs
        private readonly IComptesClientServiceExterne comptesClientServiceExterne;
        private readonly Fixe.Domain.ExternalServices.IBriqueGboServiceExterne briqueGboServiceExterne;
        private readonly IGestionSurconsommationAboServiceExterne gestionSurconsommationAboServiceExterne;
        private readonly IAuthentificationServiceExterne loginServiceExterne;
        private readonly ITiersServiceExterne tiersServiceExterne;
        private readonly IHistoriqueServiceExterne historiqueServiceExterne;
        private readonly IOptionsServiceExterne optionsServiceExterne;
        private readonly ICommunicationClientServiceExterne communicationClientServiceExterne;
        private readonly IBriqueIcnServiceExterne icnServiceExterne;
        private readonly IInterfaceOperateurServiceExterne interfaceOperateurServiceExterne;
        private readonly IValorisationServiceExterne valorisationServiceExterne;
        private readonly ISfrFixeCompteTvServiceExterne sfrFixeCompteTvServiceExterne;
        private readonly IBriqueDataMartLigneServiceExterne briqueDataMartLigneServiceExterne;
        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur protégé pour les mocks.
        /// </summary>
        protected BriquesServicesExternes()
        {
        }

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="comptesClientServiceExterne">Interface de comptesClientServiceExterne.</param>
        /// <param name="briqueGboServiceExterne">Interface de briqueGboServiceExterne.</param>
        /// <param name="gestionSurconsommationAboServiceExterne">Interface de gestionSurconsommationAboServiceExterne.</param>
        /// <param name="tiersServiceExterne">Interface de tiersServiceExterne.</param>
        /// <param name="loginServiceExterne">Interface de loginServiceExterne.</param>
        /// <param name="historiqueServiceExterne">Interface de historiqueServiceExterne.</param>
        /// <param name="optionsServiceExterne">Interface de optionsServiceExterne</param>
        /// <param name="communicationClientServiceExterne">Interface de communicationClientServiceExterne.</param>
        /// <param name="icnServiceExterne">Interface de icnServiceExterne.</param>
        /// <param name="interfaceOperateurServiceExterne">Interface de interfaceOperateurServiceExterne.</param>
        /// <param name="valorisationServiceExterne">Interface de valorisationServiceExterne.</param>
        /// <param name="sfrFixeCompteTvServiceExterne">Interface de sfrFixeCompteTvServiceExterne.</param>
        /// <param name="briqueDataMartLigneServiceExterne">Interface de briqueDataMartLigneServiceExterne.</param>
        public BriquesServicesExternes(IComptesClientServiceExterne comptesClientServiceExterne,
            Fixe.Domain.ExternalServices.IBriqueGboServiceExterne briqueGboServiceExterne,
            Fixe.Domain.ExternalServices.IGboServiceExterne gboServiceExterne,
            IGestionSurconsommationAboServiceExterne gestionSurconsommationAboServiceExterne,
            ITiersServiceExterne tiersServiceExterne,
            IHistoriqueServiceExterne historiqueServiceExterne,
            IOptionsServiceExterne optionsServiceExterne,
            IAuthentificationServiceExterne loginServiceExterne,
            ICommunicationClientServiceExterne communicationClientServiceExterne,
            IBriqueIcnServiceExterne icnServiceExterne,
            IInterfaceOperateurServiceExterne interfaceOperateurServiceExterne,
            IValorisationServiceExterne valorisationServiceExterne,
            ISfrFixeCompteTvServiceExterne sfrFixeCompteTvServiceExterne,
            IBriqueDataMartLigneServiceExterne briqueDataMartLigneServiceExterne)
        {
            //Vérification des entrées.
            comptesClientServiceExterne.Valider(nameof(comptesClientServiceExterne)).NonNul();
            gboServiceExterne.Valider(nameof(gboServiceExterne)).NonNul();
            briqueGboServiceExterne.Valider(nameof(briqueGboServiceExterne)).NonNul();
            gestionSurconsommationAboServiceExterne.Valider(nameof(gestionSurconsommationAboServiceExterne)).NonNul();
            loginServiceExterne.Valider(nameof(loginServiceExterne)).NonNul();
            tiersServiceExterne.Valider(nameof(tiersServiceExterne)).NonNul();
            historiqueServiceExterne.Valider(nameof(historiqueServiceExterne)).NonNul();
            optionsServiceExterne.Valider(nameof(optionsServiceExterne)).NonNul();
            communicationClientServiceExterne.Valider(nameof(communicationClientServiceExterne)).NonNul();
            icnServiceExterne.Valider(nameof(icnServiceExterne)).NonNul();
            interfaceOperateurServiceExterne.Valider(nameof(interfaceOperateurServiceExterne)).NonNul();
            valorisationServiceExterne.Valider(nameof(valorisationServiceExterne)).NonNul();
            sfrFixeCompteTvServiceExterne.Valider(nameof(sfrFixeCompteTvServiceExterne)).NonNul();
            briqueDataMartLigneServiceExterne.Valider(nameof(briqueDataMartLigneServiceExterne)).NonNul();

            //Initialisation des champs.
            this.comptesClientServiceExterne = comptesClientServiceExterne;
            this.briqueGboServiceExterne = briqueGboServiceExterne;
            this.gestionSurconsommationAboServiceExterne = gestionSurconsommationAboServiceExterne;
            this.loginServiceExterne = loginServiceExterne;
            this.tiersServiceExterne = tiersServiceExterne;
            this.historiqueServiceExterne = historiqueServiceExterne;
            this.optionsServiceExterne = optionsServiceExterne;
            this.communicationClientServiceExterne = communicationClientServiceExterne;
            this.icnServiceExterne = icnServiceExterne;
            this.interfaceOperateurServiceExterne = interfaceOperateurServiceExterne;
            this.valorisationServiceExterne = valorisationServiceExterne;
            this.sfrFixeCompteTvServiceExterne = sfrFixeCompteTvServiceExterne;
            this.briqueDataMartLigneServiceExterne = briqueDataMartLigneServiceExterne;
        }

        #endregion Constructeurs

        #region IBriquesServicesExternes

        /// <summary>
        /// Retourne l'interface ComptesClientServiceExterne.
        /// </summary>
        public IComptesClientServiceExterne ComptesClientServiceExterne
        {
            get
            {
                return this.comptesClientServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface BriqueGboServiceExterne.
        /// </summary>
        public Fixe.Domain.ExternalServices.IBriqueGboServiceExterne BriqueGboServiceExterne
        {
            get
            {
                return this.briqueGboServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface GestionSurconsommationAboServiceExterne.
        /// </summary>
        public IGestionSurconsommationAboServiceExterne GestionSurconsommationAboServiceExterne
        {
            get
            {
                return this.gestionSurconsommationAboServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface LoginServiceExterne.
        /// </summary>
        public IAuthentificationServiceExterne AuthentificationServiceExterne
        {
            get
            {
                return this.loginServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface TiersServiceExterne.
        /// </summary>
        public ITiersServiceExterne TiersServiceExterne
        {
            get
            {
                return this.tiersServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface HistoriqueServiceExterne.
        /// </summary>
        public IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get
            {
                return this.historiqueServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface OptionServiceExterne.
        /// </summary>
        public IOptionsServiceExterne OptionsServiceExterne
        {
            get
            {
                return this.optionsServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface ICommunicationClientServiceExterne.
        /// </summary>
        public ICommunicationClientServiceExterne CommunicationClientServiceExterne
        {
            get
            {
                return this.communicationClientServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface IIcnServiceExterne.
        /// </summary>
        public IBriqueIcnServiceExterne IcnServiceExterne
        {
            get
            {
                return this.icnServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface IInterfaceOperateurServiceExterne.
        /// </summary>
        public IInterfaceOperateurServiceExterne InterfaceOperateurServiceExterne
        {
            get
            {
                return this.interfaceOperateurServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface IValorisationServiceExterne.
        /// </summary>
        public IValorisationServiceExterne ValorisationServiceExterne
        {
            get
            {
                return this.valorisationServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface ISfrFixeCompteTvServiceExterne. 
        /// </summary>
        public ISfrFixeCompteTvServiceExterne SfrFixeCompteTvServiceExterne
        {
            get
            {
                return this.sfrFixeCompteTvServiceExterne;
            }
        }

        /// <summary>
        /// Retourne l'interface IBriqueDataMartLigneServiceExterne. 
        /// </summary>
        public IBriqueDataMartLigneServiceExterne BriqueDataMartLigneServiceExterne
        {
            get
            {
                return this.briqueDataMartLigneServiceExterne;
            }
        }

        #endregion IBriquesServicesExternes
    }
}
