﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Messaging;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ClasseParametres
{
    /// <summary>
    /// Implémentation de l'interface regroupant les interfaces des services techniques internes au domain.
    /// </summary>
    public class ServicesTechniques : IServicesTechniques
    {
        #region Champs

        private readonly IParametrage parametrage;
        private readonly IGenerateurCles generateurCles;
        private readonly IMessagingSystem messagingSystem;
        private readonly IGenerateurSequences generateurSequences;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur protégé pour les mocks.
        /// </summary>
        protected ServicesTechniques()
        {

        }

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="parametrage">Interface de paramétrage.</param>
        /// <param name="generateurCles">Interface de générateur clés.</param>
        /// <param name="messagingSystem">Service d'envoi de message.</param>
        /// <param name="generateurSequences">Service de génération de séquences.</param>
        public ServicesTechniques(IParametrage parametrage, IGenerateurCles generateurCles, IMessagingSystem messagingSystem, IGenerateurSequences generateurSequences)
        {
            //Vérification des entrées.
            parametrage.Valider(nameof(parametrage)).NonNul();
            generateurCles.Valider(nameof(generateurCles)).NonNul();
            messagingSystem.Valider(nameof(messagingSystem)).NonNul();
            generateurSequences.Valider(nameof(generateurSequences)).NonNul();

            //Initialisation des champs.
            this.parametrage = parametrage;
            this.generateurCles = generateurCles;
            this.messagingSystem = messagingSystem;
            this.generateurSequences = generateurSequences;
        }

        #endregion Constructeurs

        #region IServicesTechniques

        /// <summary>
        /// Retourne l'interface de la table de paramétrage.
        /// </summary>
        public IParametrage Parametrage
        {
            get
            {
                return this.parametrage;
            }
        }

        /// <summary>
        /// Retourne l'interface du générateur de Clés.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get
            {
                return this.generateurCles;
            }
        }

        /// <summary>
        /// Service d'envoi de message.
        /// </summary>
        public IMessagingSystem MessagingSystem
        {
            get
            {
                return this.messagingSystem;
            }
        }

        /// <summary>
        /// Service de génération de séquences.
        /// </summary>
        public IGenerateurSequences GenerateurSequences
        {
            get
            {
                return this.generateurSequences;
            }
        }

        #endregion IServicesTechniques
    }
}