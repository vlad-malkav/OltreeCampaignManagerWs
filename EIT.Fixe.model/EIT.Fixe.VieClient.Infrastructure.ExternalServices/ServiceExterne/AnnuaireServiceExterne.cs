﻿using EIT.Composition;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Souscription.Application;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe Icn.
    /// </summary>
    public sealed class AnnuaireServiceExterne : IAnnuaireServiceExterne
    {     
        /// <summary>
        /// Modifie les informations de parution dans l’annuaire universel, en dehors du parcours de souscription.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="parametresDefinitionAnnuaire">Informations de l’annuaire universel.</param>
        public void ModifierParutionAnnuaireUniverselParReferenceExterne(Identite identite, string referenceExterne, ParametresDefinirAnnuaire parametresDefinirAnnuaire)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            parametresDefinirAnnuaire.Valider(nameof(parametresDefinirAnnuaire)).NonNul();

            // Conversion en DTO du domaine Souscription
            ParametresDefinitionAnnuaire parametreDefinitionAnnuaire = ParametresDefinitionAnnuaireMapper.Convertir(parametresDefinirAnnuaire);

            // Appel de la méthode ModifierParutionAnnuaireUniverselParReferenceExterne de AnnuaireServive
            Composer.GetUnique<IAnnuaireService>().ModifierParutionAnnuaireUniverselParReferenceExterne(identite, referenceExterne, parametreDefinitionAnnuaire);
        }

        /// <summary>
        /// Définit le refus du tiers à figurer dans l’annuaire universel, en dehors du parcours de souscription.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        public void DefinirRefusAnnuaireUniverselParReferenceExterne(Identite identite, string referenceExterne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            
            // Appel de la méthode DefinirRefusAnnuaireUniverselParReferenceExterne de AnnuaireServive
            Composer.GetUnique<IAnnuaireService>().DefinirRefusAnnuaireUniverselParReferenceExterne(identite, referenceExterne);
        }


        /// <summary>
        /// Obtient les informations relatives à la parution dans l’annuaire universel associées à une référence externe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Informations relatives à la parution dans l’annuaire universel.</returns>
        public Domain.CommonTypes.DTO.InformationsAnnuaireUniversel ObtenirAnnuaireUniversel(Identite identite, string referenceExterne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();

            // Appeler la méthode ObtenirAnnuaireUniversel du service Annuaire (domaine Souscription)
            Souscription.Application.InformationsAnnuaireUniversel annuaireSouscription = Composer.GetUnique<ICommandeSouscriptionService>().ObtenirAnnuaireUniversel(identite, referenceExterne);

            // Conversion
            Domain.CommonTypes.DTO.InformationsAnnuaireUniversel annuaire = InformationsAnnuaireUniverselMapper.Convertir(annuaireSouscription);

            return annuaire;
        }
    }
}