﻿using EIT.Composition;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations.CommunicationClient;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe CommunicationClient.
    /// </summary>
    public sealed class CommunicationClientServiceExterne : ICommunicationClientServiceExterne
    {
        
        #region Méthodes - ICommunicationClientServiceExterne

        #region Méthodes d'envoi de mail

        /// <summary>
        /// Permet d'envoyer un mail d'annulation de résiliation. VIECLIENT_COM_ANNULRESIL_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailAnnulerResiliation(Identite identite, ParametresEmailAnnulerResiliation parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"numeroLigne", parametres.NumeroLigne },
                {"telLigneTHD", parametres.NumeroLigne },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"nomTitulaire", parametres.NomTitulaire}
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.AnnulerResiliation,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement d'email. VIECLIENT_COM_CONFIRMCHGEMAIL_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailConfirmerChangementEmail(Identite identite, ParametresChangement parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"numeroLigne", parametres.NumeroLigne },
                {"emailContactTitulaire", parametres.EmailContact },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"civiliteTitulaire", parametres.CiviliteTitulaire },
                {"nomTitulaire",parametres.NomTitulaire }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmerChangementEmail,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement d'options. VIECLIENT_COM_CONFIRMCHGTOPTIONS_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailConfirmerChangementOptions(Identite identite, ParametresEmailConfirmerChangementOptions parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"numeroLigne", parametres.NumeroLigne },
                {"emailContact", parametres.EmailContact },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"nomTitulaire", parametres.NomTitulaire}
            };

            for (int i = 0; i < parametres.NomsOptionsSouscrites.Count; i++)
            {
                parametresEmail.Add("nomOptionSouscrite" + (i + 1), parametres.NomsOptionsSouscrites.ElementAt(i));
                parametresEmail.Add("tarifMensuelOption" + (i + 1), parametres.TarifsMensuelOptions.ElementAt(i));
            }

            for (int i = 0; i < parametres.NomsOptionsResiliees.Count; i++)
            {
                parametresEmail.Add("nomOptionResiliee" + (i + 1), parametres.NomsOptionsResiliees.ElementAt(i));
            }

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmerChangementOptions,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement de numéro de téléphone. VIECLIENT_COM_CONFIRMCHGTTEL_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailConfirmerChangementTelephone(Identite identite, ParametresEmailConfirmerChangementTelephone parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telContactMobileTitulaire", parametres.TelephoneMobileContact },
                {"telContactFixeTitulaire", parametres.TelephoneMobileContact },
                {"numeroLigne", parametres.NumeroLigne },
                {"emailContact", parametres.EmailContact },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"civiliteTitulaire", parametres.CiviliteTitulaire },
                {"nomTitulaire", parametres.NomTitulaire }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmerChangementTelephone,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de résiliation avec étiquette. VIECLIENT_COM_CONFIRMRESILAVECETIQ_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailConfirmerResiliationAvecEtiquette(Identite identite, ParametresEmailConfirmerResiliationAvecEtiquette parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"libelleOffre", parametres.LibelleOffre },
                {"dateResiliationEffective", parametres.DateResiliationEffective },
                {"numeroLigne", parametres.NumeroLigne },
                {"emailContact", parametres.EmailContact },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"numeroRetourColis", parametres.NumeroRetourColis},
                {"nomTitulaire", parametres.NomTitulaire },
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"delaiEnvoiMaterielSuiteResiliation", parametres.DelaiEnvoiMaterielSuiteResiliation }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmerResiliationAvecEtiquette,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de résiliation sans étiquette. VIECLIENT_COM_CONFIRMRESILSANSETIQ_MAIL.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerMailConfirmerResiliationSansEtiquette(Identite identite, ParametresEmailConfirmerResiliationSansEtiquette parametres)
        {
            // Création des paramètres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"libelleOffre", parametres.LibelleOffre },
                {"dateResiliationEffective", parametres.DateResiliationEffective },
                {"telLigneTHD", parametres.NumeroLigne },
                {"emailContact", parametres.EmailContact },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"nomTitulaire", parametres.NomTitulaire},
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"delaiEnvoiMaterielSuiteResiliation", parametres.DelaiEnvoiMaterielSuiteResiliation }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmerResiliationSansEtiquette,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un mail avec le RIO. VIECLIENT_COM_CONFIRMRIO_MAIL.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        public void EnvoyerEmailRio(Identite identite, ParametresEmailRio parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            //Création des parametres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"emailContact", parametres.EmailContact },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"telContactFixeTitulaire", parametres.TelephoneFixeContact },
                {"codeRIO", parametres.Rio },
                {"dateFinEngagement", parametres.DateFinEngagement.ToShortDateString() },
                {"telephoneMobileSc", parametres.TelephoneMobileSc },
                {"telephoneFixeSc", parametres.TelephoneFixeSc },
                {"heureOuvertureSc", parametres.HeureOuvertureSc },
                {"heureFermetureSc", parametres.HeureFermetureSc },
                {"urlAssistance", parametres.UrlAssistance },
                {"libelleMarque", parametres.LibelleMarque},
                {"nomTitulaire", parametres.NomTitulaire},
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"mentionsLegalesMarque", parametres.MentionsLegalesMarque}
            };

            //Envoi du mail.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.EnvoiRio,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Envoi un email de confirmation de réinitialisation du code Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du mail.</param>
        public void EnvoyerEmailConfirmationReinitialisationCodeSelfCare(Identite identite, ParametreEmailConfirmationReinitialisationCodeSelfCare parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            //Création des parametres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"emailContact", parametres.EmailContact },
                {"telephoneMobileSc", parametres.TelephoneMobileSc },
                {"telephoneFixeSc", parametres.TelephoneFixeSc },
                {"heureOuvertureSc", parametres.HeureOuvertureSc },
                {"heureFermetureSc", parametres.HeureFermetureSc },
                {"urlAssistance", parametres.UrlAssistance },
                {"libelleMarque", parametres.LibelleMarque},
                {"motDePasseProvisoire", parametres.MotDePasseTemporaire},
                {"civiliteTitulaire", parametres.CiviliteTitulaire},
                {"nomTitulaire", parametres.NomTitulaire},
                {"mentionsLegalesMarque", parametres.MentionsLegalesMarque}
            };

            //Envoi du mail.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ReinitialiserCodeSelfcare,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailContact,
                parametres.CleMarque);
        }

        /// <summary>
        /// Envoi un email pour confirmation de la demande de résiliation.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du mail.</param>
        public void EnvoyerMailConfirmationDemandeResiliation(Identite identite, ParametresEmailConfirmerDemandeResiliation parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            //Création des parametres du mail.
            Dictionary<string, string> parametresEmail = new Dictionary<string, string>
            {
                {"dateDemandeResiliation", parametres.DateDemandeResiliation.ToShortDateString() },
                {"dateResiliationEffective", parametres.DateResiliationEffective.ToShortDateString() },
                {"heureFermetureSc", parametres.HeureFermetureSC},
                {"heureOuvertureSc", parametres.HeureOuvertureSC},
                {"identifiantThd", parametres.ReferenceExterne },
                {"libelleMarque", parametres.LibelleMarque },
                {"numeroFixeSc", parametres.TelephoneFixeSC },
                {"numeroMobileSc", parametres.TelephoneMobileSC },
                {"numeroTelephoneLigne", parametres.NumeroLigne},
                {"numeroMobileContact", parametres.TelephoneMobileContact},
                {"urlBoxAssistance", parametres.UrlAssistance},
                {"nomTitulaire", parametres.NomTitulaire },
                {"civiliteTitulaire",parametres.CiviliteTitulaire },
                {"telLigneTHD",parametres.NumeroLigne }
            };

            //Envoi du mail.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerMailEtAjouterHistorique(identite,
                TypeEmailVieClient.ConfirmationDemandeResiliation,
                parametresEmail,
                parametres.ReferenceExterne,
                parametres.EmailDestinataire,
                parametres.CleMarque);
        }

        #endregion Méthodes d'envoi de mail

        #region Méthodes d'envoi de courrier

        /// <summary>
        /// Permet d'envoyer un courrier de confirmation de résiliation sans étiquette.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du courrier.</param>
        public void EnvoyerCourrierConfirmerResiliationSansEtiquette(Identite identite, ParametresCourrierConfirmerResiliationSansEtiquette parametres)
        {
            // Création des paramètres du courrier.
            Dictionary<string, string> parametresCourrier = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"libelleOffre", parametres.LibelleOffre },
                {"dateResiliationEffective", parametres.DateResiliationEffective },
                {"numeroLigne", parametres.NumeroLigne },
                {"telephoneFixeSC", parametres.TelephoneFixeSC},
                {"telephoneMobileSC", parametres.TelephoneMobileSC},
                {"heureOuvertureSC", parametres.HeureOuvertureSC},
                {"heureFermetureSC", parametres.HeureFermetureSC},
                {"urlAssistance", parametres.UrlAssistance},
                {"libelleMarque", parametres.LibelleMarque},
                {"delaiEnvoiMaterielSuiteResiliation", parametres.DelaiEnvoiMaterielSuiteResiliation }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerCourrierEtAjouterHistorique(identite,
                parametres.ReferenceExterne,
                TypeCourrierVieClient.ConfirmerResiliationSansEtiquette,
                parametresCourrier,
                parametres.AdresseCourrier,
                parametres.CleMarque);
        }

        /// <summary>
        /// Permet d'envoyer un courrier avec le RIO.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du courrier.</param>
        public void EnvoyerCourrierRio(Identite identite, ParametresCourrierRio parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            // Création des paramètres du courrier.
            Dictionary<string, string> parametresCourrier = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"telephoneFixeContact", parametres.TelephoneFixeContact },
                {"codeRioPortaSortante", parametres.Rio },
                {"dateFinEngagement", parametres.DateFinEngagement.ToShortDateString() },
                {"telephoneFixeSC", parametres.TelephoneFixeSc },
                {"heureOuvertureSC", parametres.HeureOuvertureSc },
                {"heureFermetureSC", parametres.HeureFermetureSc },
                {"urlAssistance", parametres.UrlAssistance },
                {"mentionsLegalesMarque", parametres.MentionsLegalesMarque }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerCourrierEtAjouterHistorique(identite,
                parametres.ReferenceExterne,
                TypeCourrierVieClient.ConfirmerRio,
                parametresCourrier,
                new Fixe.Domain.CommonTypes.AdresseCourrier()
                {
                    Civilite = parametres.CiviliteTiers,
                    CodePostal = parametres.CodePostalTiers,
                    Complement = parametres.AdresseTiers2,
                    Nom = parametres.NomTiers,
                    Pays = "France",
                    Prenom = parametres.PrenomTiers,
                    Ville = parametres.VilleTiers,
                    Voie = parametres.AdresseTiers1
                },
                parametres.CleMarque);
        }
      
        #endregion Méthodes d'envoi de courrier

        #region Méthodes d'envoi de SMS

        /// <summary>
        /// Permet d'envoyer une confirmation par SMS pour la réinitialisation du code du SelfCare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètre du SMS.</param>
        public void EnvoyerSmsConfirmationReinitialisationCodeSelfCare(Identite identite, ParametreSMSConfirmationReinitialisationCodeSelfCare parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            // Création des paramètres du SMS.
            Dictionary<string, string> parametresSms = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"motDePasseTemporaire", parametres.MotDePasseTemporaire}
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerSmsEtAjouterHistorique(identite,
            TypeSmsVieClient.ConfirmationReinitialisationCodeSelfcare,
            parametresSms,
            parametres.ReferenceExterne,
            parametres.TelephoneMobileContact,
            parametres.CleMarque);

            // On vide le champ MDP.
            parametresSms["motDePasseTemporaire"] = string.Empty;

            // Historisation du message.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>().HistoriserEnvoiSms(identite,
                parametres.ReferenceExterne,
                TypeSmsVieClient.ConfirmationReinitialisationCodeSelfcare,
                parametres.CleMarque,
                parametresSms,
                parametres.TelephoneMobileContact);
        }

        /// <summary>
        /// Permet d'envoyer un SMS à un client pour la confirmation du RIO.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametres">Paramètres pour l'envoi du SMS.</param>
        public void EnvoyerSmsConfirmationRio(Identite identite, ParametresSmsRio parametres)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();

            // Création des paramètres du SMS.
            Dictionary<string, string> parametresSms = new Dictionary<string, string>
            {
                { "libelleMarque", parametres.LibelleMarque },
                { "codeRIO", parametres.Rio },
                { "libelleFinEngagement", parametres.DateFinEngagement.ToShortDateString() }
            };

            Composer.GetUnique<Fixe.Domain.ExternalServices.IBriqueCommunicationClientServiceExterne>().EnvoyerSmsEtAjouterHistorique(identite,
                TypeSmsVieClient.ConfirmationRio,
                parametresSms,
                parametres.ReferenceExterne,
                parametres.TelephoneMobileContact,
                parametres.CleMarque,
                parametres.TelephoneMobileContact);
        }

        /// <summary>
        /// Permet d'envoyer une confirmation par SMS pour la remise en service.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètre du SMS.</param>
        public void EnvoyerSmsRemiseEnService(Identite identite, ParametreSmsRemiseEnService parametres)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametres.Valider(nameof(parametres)).NonNul();
            // Création des paramètres du SMS.
            Dictionary<string, string> parametresSms = new Dictionary<string, string>
            {
                {"referenceExterne", parametres.ReferenceExterne },
                {"telephoneMobileContact", parametres.TelephoneMobileContact },
                {"libelleMarque", parametres.LibelleMarque},
                {"numeroLigne", parametres.TelephoneFixeLigne}
            };

            // Historisation du message.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>().HistoriserEnvoiSms(identite,
                parametres.ReferenceExterne,
                TypeSmsVieClient.RemiseEnService,
                parametres.CleMarque,
                parametresSms,
                parametres.TelephoneMobileContact);
        }

        #endregion Méthodes d'envoi de SMS

        #endregion Méthodes - ICommunicationClientServiceExterne
    }
}