﻿using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.Systeme.Identification;
using System;
using EIT.Fixe.Systeme.Communication;
using EIT.Messaging;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers;
using EIT.Composition;
using EIT.Fixe.Sav.Application.Interface;
using EIT.Fixe.Sav.Application;
using System.Linq;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe SAV.
    /// </summary>
    public sealed class SavServiceExterne : ISavServiceExterne
    {


        #region Méthodes - ISavServiceExterne

        /// <summary>
        /// Retourne la liste des clés des "SAV équipement" associés à la ligne depuis sa référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        public List<long> ListerClesSavEquipementParReferenceExterne(Identite identite, string referenceExterne)
        {
            // Vérification des entrants
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            List<long> listeCles;

            // Appel au domaine externe SAV
            ListeSavPourDetail listeSavPourDetail = Composer.GetUnique<ISavService>().ListerSavParReferenceExterne(identite, referenceExterne);
            
            // Extraction de la liste de clés des "SAV Equipement".
            if (listeSavPourDetail != null && listeSavPourDetail.ListeSavEquipement != null)
            {
                listeCles = listeSavPourDetail.ListeSavEquipement.Select(x => x.Cle).ToList();
            }
            else
            {
                listeCles = new List<long>();
            }

            return listeCles;
        }
        
        /// <summary>
        /// Indique si un SAV technicien est en cours sur une ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Présence d'un SAV technicien en cours sur la ligne.</returns>
        public bool VerifierSavTechnicienEnCoursParReferenceExterne(Identite identite, string referenceExterne)
        {
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            
            return Composer.GetUnique<ISavService>().VerifierSavTechnicienEnCoursParReferenceExterne(identite, referenceExterne);
        }
        
        #endregion Méthodes - ISavServiceExterne
    }
}