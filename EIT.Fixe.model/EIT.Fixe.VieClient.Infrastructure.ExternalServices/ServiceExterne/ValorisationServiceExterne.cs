﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ValorisationMappers;
using System;
using System.Collections.Generic;
using System.Linq;
using VLO2_LIBFIX;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe Valorisation.
    /// </summary>
    public sealed class ValorisationServiceExterne : IValorisationServiceExterne
    {
        #region Méthodes - IValorisationServiceExterne

        /// <summary>
        /// Permet de résilier la ligne au sens valorisation : Positionner une date de résiliation sur le contrat.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="dateResiliation">Date de la résiliation programée.</param>
        /// <param name="estFraisResiliationAppliques">Indique si des frais de résiliation sont appliqués.</param>
        /// <param name="montantHtFraisResiliation">Montant HT des frais de résiliation.</param>
        /// <param name="tvaFraisResiliation">TVA sur les frais de résiliation.</param>
        public void ResilierLigne(
            Identite identite,
            string referenceExterne,
            DateTime dateResiliation,
            bool estFraisResiliationAppliques,
            decimal montantHtFraisResiliation,
            decimal tvaFraisResiliation)
        {
            // Création de la factory Valorisation.
            VLO2Factory factoryValorisation = VLO2Factory.CreerFactory();
            factoryValorisation.Valider(nameof(factoryValorisation)).NonNul();

            // Création de l'objet Valorisation.
            IVLO2LibFix valorisation = factoryValorisation.CreerVLO2LibFix();
            valorisation.Valider(nameof(valorisation)).NonNul();

            // Résiliation.
            valorisation.Resilier(
                    referenceExterne,
                    dateResiliation,
                    estFraisResiliationAppliques,
                    montantHtFraisResiliation,
                    tvaFraisResiliation,
                    identite.ApplicationAppelante);
        }

        /// <summary>
        /// Permet d’ajouter, de mettre à jour ou de supprimer des remises dans la brique Valorisation.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="remises">Liste des remises à transmettre à la Valorisation.</param>
        public void ChangerRemise(Identite identite, string referenceExterne, List<RemisePourValorisation> remises)
        {
            // Vérification des entrées.
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            remises.Valider(nameof(remises)).NonNul();

            // Création de la factory Valorisation.
            VLO2Factory factoryValorisation = VLO2Factory.CreerFactory();
            factoryValorisation.Valider(nameof(factoryValorisation)).NonNul();

            // Création de l'objet Valorisation.
            IVLO2LibFix valorisation = factoryValorisation.CreerVLO2LibFix();
            valorisation.Valider(nameof(valorisation)).NonNul();

            // Convertir listeRemises en une liste d’objets de type Remise (paquet Nugget).
            List<VLO2_LIBFIX.Remise> listeRemisesValorisation = remises.Select(x => RemiseMapper.Convertir(x)).ToList();

            // Appeler la méthode ChangerRemise (DTI Valorisation).
            ReponseVLO2 reponse = valorisation.ChangerRemises(referenceExterne, listeRemisesValorisation, identite.Canal.ToString());

            if (!reponse.EstOk)
            {
                throw new Exception($"Message d'erreur: {reponse.MessageErreur}, code erreur: {reponse.CodeRetour}, avertissement: {reponse.MessageWarning}");
            }
        }

        #endregion Méthodes - IValorisationServiceExterne
    }
}