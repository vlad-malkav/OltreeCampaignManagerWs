﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Helpers;
using EIT.Fixe.Systeme.Communication;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Messaging;
using System;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe InterfaceOperateur.
    /// </summary>
    public sealed class InterfaceOperateurServiceExterne : IInterfaceOperateurServiceExterne
    {
        #region Propriétés

        /// <summary>
        /// Interface du paramétrage pour la récupération des Urls.
        /// </summary>
        private readonly IParametrage parametrage;

        /// <summary>
        /// Système de gestion des messages.
        /// </summary>
        private readonly IMessagingSystem messagingSystem;

        #endregion Propriétés

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="clientFactory">Fabrique de clients WCF.</param>
        /// <param name="messagingSystem">Système de gestion des messages.</param>
        /// <param name="parametrage">Paramétrage.</param>
        public InterfaceOperateurServiceExterne(IClientFactory clientFactory, IMessagingSystem messagingSystem, IParametrage parametrage)
        {
            // Validation des entrées.
            clientFactory.Valider(nameof(clientFactory)).NonNul();
            messagingSystem.Valider(nameof(messagingSystem)).NonNul();
            parametrage.Valider(nameof(parametrage)).NonNul();

            this.messagingSystem = messagingSystem;
            this.parametrage = parametrage;
        }

        #endregion Constructeurs

        #region Méthodes privées

        /// <summary>
        /// Permet de valider une demande.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        private void ValiderDemande(Identite identite, int identifiantTransactionOperateur)
        {
            //Validation des entrées.
            identifiantTransactionOperateur.Valider(nameof(identifiantTransactionOperateur)).StrictementPositif();
            // Instanciation du message ValiderDemande.
            NrjMobile.InterfaceOperateur.Evenements.Fixe.Commandes.ValiderDemande validerDemande = new NrjMobile.InterfaceOperateur.Evenements.Fixe.Commandes.ValiderDemande()
            {
                IdentifiantTransaction = identifiantTransactionOperateur,
                Headers = EventHelper.InitialiserHeadersEvenementAvecIdentite(identite)
            };

            // Envoi du message ValiderDemande.
            this.messagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), validerDemande);
        }

        #endregion Méthodes privées

        #region Méthodes - IInterfaceOperateurServiceExterne

        /// <summary>
        /// Permet de créer une demande de résiliation auprès de l'opérateur.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        public void CreerDemandeResiliation(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            identifiantTransactionOperateur.Valider(nameof(identifiantTransactionOperateur)).StrictementPositif();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            using (BriqueInterfaceOperateur.InterfaceOperateurFixe interfaceOperateur =
                     new BriqueInterfaceOperateur.InterfaceOperateurFixe() { Url = this.parametrage.UrlBriqueInterfaceOperateur })
            {
                BriqueInterfaceOperateur.ReponseService reponse = interfaceOperateur
                    .CreerDemandeResiliation(identifiantTransactionOperateur, numeroContratOperateur);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }

            this.ValiderDemande(identite, identifiantTransactionOperateur);
        }

        /// <summary>
        /// Permet de créer une demande de suspension de ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        public void CreerDemandeSuspension(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            identifiantTransactionOperateur.Valider(nameof(identifiantTransactionOperateur)).StrictementPositif();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            BriqueInterfaceOperateur.TypeService[] typeServices = { BriqueInterfaceOperateur.TypeService.Data, BriqueInterfaceOperateur.TypeService.TV, BriqueInterfaceOperateur.TypeService.Voip };

            using (BriqueInterfaceOperateur.InterfaceOperateurFixe interfaceOperateur =
                     new BriqueInterfaceOperateur.InterfaceOperateurFixe() { Url = this.parametrage.UrlBriqueInterfaceOperateur })
            {
                BriqueInterfaceOperateur.ReponseService reponse = interfaceOperateur.CreerDemandeSuspension(identifiantTransactionOperateur, numeroContratOperateur, typeServices);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }

            this.ValiderDemande(identite, identifiantTransactionOperateur);
        }

        /// <summary>
        /// Permet de créer une demande de remise en service.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        public void CreerDemandeRemiseEnService(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            identifiantTransactionOperateur.Valider(nameof(identifiantTransactionOperateur)).StrictementPositif();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            BriqueInterfaceOperateur.TypeService[] typeServices = { BriqueInterfaceOperateur.TypeService.Data, BriqueInterfaceOperateur.TypeService.TV, BriqueInterfaceOperateur.TypeService.Voip };

            using (BriqueInterfaceOperateur.InterfaceOperateurFixe interfaceOperateur =
                     new BriqueInterfaceOperateur.InterfaceOperateurFixe() { Url = this.parametrage.UrlBriqueInterfaceOperateur })
            {
                BriqueInterfaceOperateur.ReponseService reponse = interfaceOperateur
                    .CreerDemandeRemiseEnService(identifiantTransactionOperateur, numeroContratOperateur, typeServices);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }

            this.ValiderDemande(identite, identifiantTransactionOperateur);
        }

        /// <summary>
        /// Permet de créer une demande de rétractation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        public void CreerDemandeRetractation(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            identifiantTransactionOperateur.Valider(nameof(identifiantTransactionOperateur)).StrictementPositif();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            using (BriqueInterfaceOperateur.InterfaceOperateurFixe interfaceOperateur =
                   new BriqueInterfaceOperateur.InterfaceOperateurFixe() { Url = this.parametrage.UrlBriqueInterfaceOperateur })
            {
                BriqueInterfaceOperateur.ReponseService reponse = interfaceOperateur
                    .CreerDemandeRetractation(identifiantTransactionOperateur, numeroContratOperateur);

                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }
            }

            this.ValiderDemande(identite, identifiantTransactionOperateur);
        }

        #endregion Méthodes - IInterfaceOperateurServiceExterne
    }
}