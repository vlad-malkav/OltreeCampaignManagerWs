﻿using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.Systeme.Identification;
using System;
using EIT.Fixe.Systeme.Communication;
using EIT.Messaging;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers;
using EIT.Composition;
using EIT.Fixe.Sav.Application.Interface;
using EIT.Fixe.Sav.Application;
using System.Linq;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Interactions avec le service externe SAV Equipement.
    /// </summary>
    public sealed class SavEquipementServiceExterne : ISavEquipementServiceExterne
    {

        #region Méthodes - ISavEquipementServiceExterne
        

        /// <summary>
        /// Retourne le numéro de retour colis associé à un "SAV équipement".
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cleSavEquipement">Clé du SAV Equipement.</param>
        public string ObtenirNumeroRetourColisDepuisCleSavEquipement(Identite identite, long cleSavEquipement)
        {
            // Vérification des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleSavEquipement.Valider(nameof(cleSavEquipement)).StrictementPositif();
            
            // Appel au domaine externe SAV Equipement
            SavEquipementPourConsultation savEquipement = Composer.GetUnique<ISavEquipementService>().ObtenirSavEquipementPourConsultationOuConfirmationDepuisCle(identite, cleSavEquipement);

            // Verification du retour
            savEquipement.Valider(nameof(savEquipement)).NonNul();
                        
            // Retourner le numéro retour colis
            return savEquipement.NumeroRetourColis;
        }


        #endregion Méthodes - ISavEquipementServiceExterne
    }
}