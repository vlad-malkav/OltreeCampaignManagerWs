﻿using EIT.DataAccess.EntityFramework;
using EIT.Fixe.Systeme.Parametrage.Oracle;
using EIT.Fixe.VieClient.Domain.ServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Paramétrage spécifique au domaine Vie client.
    /// </summary>
    public sealed class Parametrage : TableParametrage, IParametrage
    {
        #region Champs

        /// <summary>
        /// Nom de la table en base de données.
        /// </summary>
        private const string nomTable = "T_VIECLI_PAR";

        /// <summary>
        /// Nombre maximum d’historiques à afficher sur la fiche de synthèse de la ligne fixe.
        /// </summary>
        private const string nombreHistoriquesFicheSyntheseLigne = "NombreHistoriquesFicheSyntheseLigne";

        /// <summary>
        /// Nombre maximum de dossier GBO à afficher sur la fiche de synthèse de ligne fixe.
        /// </summary>
        private const string nombreDossierFicheSyntheseLigne = "NombreDossierFicheSyntheseLigne";

        /// <summary>
        /// Code opérateur d'un réseau full. Les autres codes opérateur offrent une réseau light.
        /// </summary>
        private const string codeOperateurReseauFull = "CodeOperateurReseauFull";

        /// <summary>
        /// Clé de la valeur de durée de validité des pannes collectives, en minutes.
        /// </summary>
        private const string dureeValiditeDonneesPannesCollectives = "DureeValiditeDonneesPannesCollectives";

        /// <summary>
        /// Clé du delai (en heures) affiché sur la page de transfert des appels.
        /// </summary>
        private const string delaiTransfertAppel = "DelaiTransfertAppel";

        /// <summary>
        /// Clé du libellé de l’activité affiché sur la page de transfert des appels.
        /// </summary>
        private const string libelleActiviteTransfertAppel = "LibelleActiviteTransfertAppel";

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="connectionProvider">Interface du fournisseur de connexion.</param>
        public Parametrage(IConnectionProvider connectionProvider)
            : base(nomTable, connectionProvider)
        {
        }

        #endregion Constructeurs

        #region Propriétés

        /// <summary>
        /// Nombre maximum d’historiques à afficher sur la fiche de synthèse de la ligne fixe.
        /// </summary>
        public int NombreHistoriquesFicheSyntheseLigne
        {
            get
            {
                return base.ObtenirParametreEntier(nombreHistoriquesFicheSyntheseLigne);
            }
        }

        /// <summary>
        /// Nombre maximum de dossier GBO à afficher sur la fiche de synthèse de ligne fixe.
        /// </summary>
        public int NombreDossierFicheSyntheseLigne
        {
            get
            {
                return base.ObtenirParametreEntier(nombreDossierFicheSyntheseLigne);
            }
        }

        /// <summary>
        /// Code opérateur d'un réseau full. Les autres codes opérateur offrent une réseau light.
        /// </summary>
        public string CodeOperateurReseauFull
        {
            get
            {
                return base.ObtenirParametre(codeOperateurReseauFull);
            }
        }

        /// <summary>
        /// Durée de validité des données concernant les pannes collectives, en minutes.
        /// </summary>
        /// <remarks>Passé ce délai en minutes, les données ne sont plus exploitables.</remarks>
        public int DureeValiditeDonneesPannesCollectives
        {
            get
            {
                return this.ObtenirParametreEntier(dureeValiditeDonneesPannesCollectives);
            }
        }

        /// <summary>
        /// Libellé des frais fixes de résiliation.
        /// </summary>
        public string LibelleFraisResiliation
        {
            get
            {
                return this.ObtenirParametre("LibelleFraisResiliation");
            }
        }

        /// <summary>
        /// Montant Ht des frais de résiliation.
        /// </summary>
        public decimal MontantHtFraisResiliation
        {
            get
            {
                return this.ObtenirParametreDecimal("MontantHtFraisResiliation");
            }
        }

        /// <summary>
        /// Tva des frais de résiliation.
        /// </summary>
        public decimal TvaFraisResiliation
        {
            get
            {
                return this.ObtenirParametreDecimal("TvaFraisResiliation");
            }
        }

        /// <summary>
        ///  Clé du motif de résiliation "Portabilité Sortante".
        /// </summary>
        public long CleMotifResiliationPortabiliteSortante
        {
            get
            {
                return this.ObtenirParametreEntier("CleMotifResiliationPortabiliteSortante");
            }
        }

        /// <summary>
        /// Delai (en heures) affiché sur la page de transfert des appels.
        /// </summary>
        public int DelaiTransfertAppel
        {
            get
            {
                return this.ObtenirParametreEntier(delaiTransfertAppel);
            }
        }

        /// <summary>
        /// Libellé de l’activité affiché sur la page de transfert des appels.
        /// </summary>
        public string LibelleActiviteTransfertAppel
        {
            get
            {
                return this.ObtenirParametre(libelleActiviteTransfertAppel);
            }
        }

        /// <summary>
        /// Clé du motif de résiliation "Impayés".
        /// </summary>
        public long CleMotifResiliationImpayes
        {
            get
            {
                return this.ObtenirParametreEntier("CleMotifResiliationImpayes");
            }
        }


        /// <summary>
        /// Clé du motif de résiliation "Rétractation".
        /// </summary>
        public long CleMotifResiliationRetractation
        {
            get
            {
                return this.ObtenirParametreEntier("CleMotifResiliationRetractation");
            }
        }

        #region Urls

        /// <summary>
        /// Web service de la brique Tiers.
        /// </summary>
        public string UrlBriqueTiers
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueTiers");
            }
        }

        /// <summary>
        /// Web service de la brique Historique.
        /// </summary>
        public string UrlBriqueHistorique
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueHistorique");
            }
        }

        /// <summary>
        /// Web service de la brique CompteClient.
        /// </summary>
        public string UrlBriqueComptesClient
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueComptesClient");
            }
        }

        /// <summary>
        /// Web service de la brique GestionSurconsommationAbo.
        /// </summary>
        public string UrlBriqueGestionSurconsommationAbo
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueGestionSurconsommationAbo");
            }
        }

        /// <summary>
        /// Web service de la brique Login.
        /// </summary>
        public string UrlBriqueLogin
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueLogin");
            }
        }

        /// <summary>
        /// Web service de Options.
        /// </summary>
        public string UrlBriqueOptions
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueOptions");
            }
        }

        /// <summary>
        /// Web service de Valorisation.
        /// </summary>
        public string UrlBriqueValorisation
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueValorisation");
            }
        }

        /// <summary>
        /// Web service InterfaceOperateur.
        /// </summary>
        public string UrlBriqueInterfaceOperateur
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueInterfaceOperateur");
            }
        }

        /// <summary>
        /// Web service Icn.
        /// </summary>
        public string UrlBriqueIcn
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueIcn");
            }
        }


        /// <summary>
        /// URL du web service Compte TV.
        /// </summary>
        public string UrlBriqueCompteTV
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueCompteTV");
            }
        }


        /// <summary>
        /// URL du web service DataMart Ligne.
        /// </summary>
        public string UrlBriqueDataMartLigne
        {
            get
            {
                return this.ObtenirParametre("UrlBriqueDataMartLigne");
            }
        }

        #endregion Urls

        #endregion Propriétés
    }
}