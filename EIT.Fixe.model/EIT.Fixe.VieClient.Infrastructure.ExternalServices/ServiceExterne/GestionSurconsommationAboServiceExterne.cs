﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using System;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe de gestion de surconsommation abo.
    /// </summary>
    public sealed class GestionSurconsommationAboServiceExterne : IGestionSurconsommationAboServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface de la table de paramétrage.
        /// </summary>
        private readonly IParametrage parametrage;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Identite pour l'appel de la brique externe de gestion de surconsommation abo.
        /// </summary>
        private BriqueGestionSurconsommationAbo.Identite IdentiteGestionSurConso
        {
            get
            {
                return new BriqueGestionSurconsommationAbo.Identite()
                {
                    ApplicationAppelante = ObjetsCommunsFixe.IdentiteFixeCommune.ApplicationAppelante,
                    Canal = ObjetsCommunsFixe.IdentiteFixeCommune.Canal,
                    Memoid = ObjetsCommunsFixe.IdentiteFixeCommune.Memoid,
                    PointDeVente = ObjetsCommunsFixe.IdentiteFixeCommune.PointDeVente
                };
            }
        }

        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametrage">Service de paramétrage.</param>
        public GestionSurconsommationAboServiceExterne(IParametrage parametrage)
        {
            parametrage.Valider(nameof(parametrage)).NonNul();

            this.parametrage = parametrage;
        }

        #endregion Constructeur

        /// <summary>
        /// Récupération du seuil de surconsommation d’une ligne mobile par sa clé.
        /// </summary>
        /// <param name="cleLigne">Clé technique de la ligne mobile.</param>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <returns>Le seuil de surconsommation de la ligne.</returns>
        public decimal ObtenirSeuilParCleLigne(Identite identite, int cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Appel à la brique ComptesClient.
            using (BriqueGestionSurconsommationAbo.GestionSurconsommationAbo wsBriqueGSC =
                new BriqueGestionSurconsommationAbo.GestionSurconsommationAbo() { Url = this.parametrage.UrlBriqueGestionSurconsommationAbo })
            {
                BriqueGestionSurconsommationAbo.ReponseDecimalService reponse = wsBriqueGSC.ObtenirSeuil(this.IdentiteGestionSurConso, cleLigne);

                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                return reponse.ResultatAppel;
            }
        }
    }
}