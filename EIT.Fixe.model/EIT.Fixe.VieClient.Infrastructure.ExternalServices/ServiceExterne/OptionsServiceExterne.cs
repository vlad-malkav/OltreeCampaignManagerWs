﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Communication;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers;
using EIT.Options.Application.Interface.Param;
using EIT.Options.Application.Interface.Service;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe des options.
    /// </summary>
    public sealed class OptionsServiceExterne : IOptionsServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface du client WCF pour appel de service externes.
        /// </summary>
        private readonly IClientFactory clientFactory;

        /// <summary>
        /// Interface du paramétrage pour la récupération des Urls.
        /// </summary>
        private readonly IParametrage parametrage;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Identité pour l'appel de la brique Options.
        /// </summary>
        private Options.Application.Interface.Presentation.Identite IdentiteOptions
        {
            get
            {
                return new Options.Application.Interface.Presentation.Identite()
                {
                    Canal = ObjetsCommunsFixe.IdentiteFixeCommune.Canal,
                    Memoid = ObjetsCommunsFixe.IdentiteFixeCommune.Memoid,
                    PointDeVente = ObjetsCommunsFixe.IdentiteFixeCommune.PointDeVente
                };
            }
        }

        #endregion Propriétés

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="clientFactory">Client factory.</param>
        /// <param name="parametrage">Service de paramétrage.</param>
        public OptionsServiceExterne(IClientFactory clientFactory, IParametrage parametrage)
        {
            this.clientFactory = clientFactory;
            this.parametrage = parametrage;
        }

        #endregion Constructeurs

        #region Méthodes - IOptionsServiceExterne

        /// <summary>
        /// Permet de récupérer les informations d'une location de box par clé du gestionnaire d'option.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaire">Clé du gestionnaire.</param>
        /// <returns>InformationLocationBoxPourDetail.</returns>
        public InformationsLocationBoxPourDetail ObtenirLocationBoxParCleGestionnaire(Identite identite, string cleGestionnaire)
        {
            using (IClient<IOptionsXML> optionClient = this.clientFactory.CreateClient<IOptionsXML>(this.parametrage.UrlBriqueOptions))
            {
                ParamObtenirLocationBox parametreOption = new ParamObtenirLocationBox()
                {
                    CleGestionnaire = cleGestionnaire
                };
                Options.Application.Interface.Presentation.Option option = optionClient.Service.ObtenirLocationBox(this.IdentiteOptions, parametreOption);
                return InformationsLocationBoxPourDetailMapper.Convertir(option);
            }
        }

        /// <summary>
        /// Permet d'enregistrer des modifications d'options (souscription/résiliation) sur le gestionnaire.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        /// <param name="clesOptionsAAjouter">Liste des clés des options à ajouter.</param>
        /// <param name="clesOptionsASupprimer">Liste des clés des options à supprimer.</param>
        public void ModifierOptionsGestionnaire(Identite identite, string cleGestionnaireOptions, List<int> clesOptionsAAjouter, List<int> clesOptionsASupprimer)
        {
            using (IClient<IOptionsXML> optionClient = this.clientFactory.CreateClient<IOptionsXML>(this.parametrage.UrlBriqueOptions))
            {
                // Initialisation de la liste des ActionOption.
                List<Options.Application.Interface.Presentation.ActionOption> actionsOptions = new List<Options.Application.Interface.Presentation.ActionOption>();

                // Ajout des options de type Ajout dans la liste des ActionOption.
                clesOptionsAAjouter.ForEach(x => actionsOptions.Add(new Options.Application.Interface.Presentation.ActionOption()
                {
                    Action = Options.Application.Interface.Commun.Enum.TypeAction.Ajout,
                    CleOption = x
                }));

                // Ajout des options de type Suppression dans la liste des ActionOption.
                clesOptionsASupprimer.ForEach(x => actionsOptions.Add(new Options.Application.Interface.Presentation.ActionOption()
                {
                    Action = Options.Application.Interface.Commun.Enum.TypeAction.Suppression,
                    CleOption = x
                }));

                // Création de l'objet qui sera passé à la brique option.
                ParamModifierOptions paramModifierOptions = new ParamModifierOptions()
                {
                    CleGestionnaire = cleGestionnaireOptions,
                    Demandes = actionsOptions.ToArray()
                };

                // Appel à la web methode ModifierOptions de la brique options.
                optionClient.Service.ModifierOptions(IdentiteOptions, paramModifierOptions);
            }
        }

        /// <summary>
        /// Permet de lister les options associées au gestionnaire.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        /// <param name="clesOptions">Liste des clés d'options à retourner.</param>
        /// <returns>Liste des options.</returns>
        public ReponseListeOptions RechercherOptionsParCleGestionnaire(Identite identite, string cleGestionnaireOptions, int[] clesOptions)
        {
            using (IClient<IOptionsXML> optionClient = this.clientFactory.CreateClient<IOptionsXML>(this.parametrage.UrlBriqueOptions))
            {
                // Création de l'objet qui sera passé à la brique Options.
                ParamListerOptions paramListerOptions = new ParamListerOptions()
                {
                    CleGestionnaire = cleGestionnaireOptions,
                    ClesOptions = clesOptions,
                    InfosPack = new Options.Application.Interface.Presentation.InfosPack()
                };

                // Appel à la web méthode ListerOptions de la brique Options et conversion de l'objet de retour.
                Options.Application.Interface.Reponse.ReponseListeOptions reponseListeOptions =
                    optionClient.Service.ListerOptions(IdentiteOptions, paramListerOptions);

                // Conversion pour retour.
                if (reponseListeOptions == null)
                {
                    return null;
                }
                return reponseListeOptions.Convertir();
            }
        }

        /// <summary>
        /// Permet de résilier le gestionnaire d'options.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        public void ResilierGestionnaireOptions(Identite identite, string cleGestionnaireOptions)
        {
            using (IClient<IOptionsXML> optionClient = this.clientFactory.CreateClient<IOptionsXML>(this.parametrage.UrlBriqueOptions))
            {
                // Création de l'objet qui sera passé à la brique option.
                ParamResilierGestionnaire paramResilierGestionnaire = new ParamResilierGestionnaire()
                {
                    CleGestionnaire = cleGestionnaireOptions
                };

                // Appel à la web methode de la brique options.
                optionClient.Service.ResilierGestionnaire(IdentiteOptions, paramResilierGestionnaire);
            }
        }

        #endregion Méthodes - IOptionsServiceExterne
    }
}