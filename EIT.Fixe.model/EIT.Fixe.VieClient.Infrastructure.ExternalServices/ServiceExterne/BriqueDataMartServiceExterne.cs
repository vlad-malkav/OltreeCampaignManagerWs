﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Souscription.Domain.CommonTypes;
using EIT.Fixe.Souscription.Domain.ExternalServices;
using EIT.Fixe.Systeme.Communication;
using EIT.Fixe.Systeme.Identification;
using System.Linq;
using EIT.Fixe.VieClient.Domain.ServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Classe pour l'utilisation du service externe de la brique DataMart.
    /// </summary>
    public class BriqueDataMartLigneServiceExterne : IBriqueDataMartLigneServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface du client WCF pour appel de service externes.
        /// </summary>
        private readonly IClientFactory clientFactory;

        /// <summary>
        /// Interface du parametrage de la briqueTiers.
        /// </summary>
        private readonly IParametrage parametrage;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'instanciation.
        /// </summary>
        /// <param name="clientFactory">Interface du client WCF.</param>
        /// <param name="parametrage">Interface du parametrage.</param>
        public BriqueDataMartLigneServiceExterne(IClientFactory clientFactory, IParametrage parametrage)
        {
            //Vérification des entrées.
            clientFactory.Valider(nameof(clientFactory)).NonNull();
            parametrage.Valider(nameof(parametrage)).NonNull();

            //Initialisation.
            this.clientFactory = clientFactory;
            this.parametrage = parametrage;
        }

        #endregion Constructeurs

        #region IBriqueDataMartServiceExterne

        /// <summary>
        /// Permet de vérifier l'existence d'une Référence Externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="referenceExterne">La Référence Externe à vérifier.</param>
        /// <returns>Résultat de la vérification.</returns>
        public bool EstReferenceExterneExistante(Identite identite, string referenceExterne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Création de l'objet de retour.
            bool estReferenceExterneExistante = false;

            // Appel au service.
            using (IClient<BriqueDataMartLigne.ILigneService> clientDataMart = 
                this.clientFactory.CreateClient<BriqueDataMartLigne.ILigneService>(this.parametrage.UrlBriqueCompteTV))
            {
                estReferenceExterneExistante = clientDataMart.Service.EstReferenceExterneExistante(identite, referenceExterne);
            }

            return estReferenceExterneExistante;
        }

        #endregion IBriqueDataMartServiceExterne
    }
}