﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Communication;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.SystemesExternes.SfrFixe.TV.Application;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéraction avec la brique externe SfrFixeCompteTv.
    /// </summary>
    public class SfrFixeCompteTvServiceExterne : ISfrFixeCompteTvServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface du client WCF pour appel de service externes.
        /// </summary>
        private readonly IClientFactory clientFactory;

        /// <summary>
        /// Interface de la table de paramètrage.
        /// </summary>
        private readonly IParametrage parametrage;

        #endregion Champs

        #region Constructeur

        /// <summary>
        /// Constructeur du service externe.
        /// </summary>
        /// <param name="clientFactory">Interface du client WCF.</param>
        /// <param name="parametrage">Interface parametrage.</param>
        public SfrFixeCompteTvServiceExterne(IClientFactory clientFactory, IParametrage parametrage)
        {
            //Vérification des entrées.
            clientFactory.Valider(nameof(clientFactory)).NonNul();
            parametrage.Valider(nameof(parametrage)).NonNul();

            //Initialisation.
            this.clientFactory = clientFactory;
            this.parametrage = parametrage;
        }

        #endregion Constructeur

        #region Méthodes

        /// <summary>
        /// Permet de débloquer le compte MyPartnerTV.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        public void Debloquer(Identite identite, string referenceExterne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            // Appel au service externe.
            using (IClient<ICompteTVService> compteTVService = this.clientFactory.CreateClient<ICompteTVService>(this.parametrage.UrlBriqueCompteTV))
            {
                compteTVService.Service.Debloquer(referenceExterne);
            }
        }

        /// <summary>
        /// Permet de de modifier le mot de passe du compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        public void ModifierMotDePasseMyPartnerTv(Identite identite, string referenceExterne, string motDePasse)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            motDePasse.Valider(nameof(motDePasse)).Obligatoire();

            // Appel au service externe.
            using (IClient<ICompteTVService> compteTVService = this.clientFactory.CreateClient<ICompteTVService>(this.parametrage.UrlBriqueCompteTV))
            {
                compteTVService.Service.ModifierMotDePasse(referenceExterne, motDePasse);
            }
        }

        /// <summary>
        /// Permet de créer un compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        /// <param name="identifiant">Identifiant du compte My Partner TV.</param>
        public void CreerCompteMyPartnerTv(Identite identite, string referenceExterne, string identifiant)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            identifiant.Valider(nameof(identifiant)).Obligatoire();

            // Appel au service externe.
            using (IClient<ICompteTVService> compteTVService = this.clientFactory.CreateClient<ICompteTVService>(this.parametrage.UrlBriqueCompteTV))
            {
                compteTVService.Service.AjouterIdentifiant(referenceExterne, identifiant);
            }
        }

        #endregion Méthodes
    }
}