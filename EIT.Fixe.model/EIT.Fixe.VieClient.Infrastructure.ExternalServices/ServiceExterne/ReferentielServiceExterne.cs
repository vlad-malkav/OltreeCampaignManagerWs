﻿using EIT.Composition;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Referentiel.Application.DTO;
using EIT.Fixe.Referentiel.Application.Interfaces;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ReferentielMappers;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe Référentiel.
    /// </summary>
    public sealed class ReferentielServiceExterne : IReferentielServiceExterne
    {
        /// <summary>
        /// Récupère les informations de la technologie de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTechnologie">Clé de la technologie.</param>
        /// <returns>Technologie correspondante à la clé.</returns>
        public TechnologiePourDetail ObtenirTechnologieParCle(Identite identite, int cleTechnologie)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTechnologie.Valider(nameof(cleTechnologie)).StrictementPositif();

            Technologie technologie = Composer.GetUnique<ITechnologieService>().ObtenirTechnologie(identite, cleTechnologie);
            technologie.Valider(nameof(technologie)).NonNul();

            return TechnologiePourDetailMapper.Convertir(technologie);
        }

        /// <summary>
        /// Permet de récupérer l'ensemble des informations d'une offre par sa clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Offre correspondante à la clé.</returns>
        public OffrePourDetail ObtenirOffreParCle(Identite identite, int cleOffre)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

            Offre offre = Composer.GetUnique<IOffreService>().RechercherOffreDepuisCle(identite, cleOffre);
            offre.Valider(nameof(offre)).NonNul();

            return OffrePourDetailMapper.Convertir(offre);
        }

        /// <summary>
        /// Permet de récupérer le libellé d'une marque par sa clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleMarque">Clé de la marque.</param>
        /// <returns>Libellé de la marque correspondante.</returns>
        public string ObtenirLibelleMarqueParCle(Identite identite, int cleMarque)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleMarque.Valider(nameof(cleMarque)).StrictementPositif();

            Referentiel.Application.DTO.Marque marque = Composer.GetUnique<IMarqueService>().RechercherMarqueDepuisCle(identite, cleMarque);
            marque.Valider(nameof(marque)).NonNul();

            return marque.Libelle;
        }

        /// <summary>
        /// Permet de récupérer une promotion par sa clé.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="clePromotion">Clé unique de la promotion.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Ensemble des informations d'une promotion.</returns>
        public PromotionPourDetail ObtenirPromotionParCle(Identite identite, int clePromotion, int cleOffre)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            clePromotion.Valider(nameof(clePromotion)).StrictementPositif();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

            // Appel à la méthode RechercherPromotionDepuisCle (DTI Referentiel)
            Promotion promotion = Composer.GetUnique<IPromotionService>().RechercherPromotionDepuisCle(identite, clePromotion, cleOffre, null);

            // Vérification du retour.
            promotion.Valider(nameof(promotion)).NonNul();

            // Conversion en objet de présentation de service externe.
            return PromotionPourDetailMapper.Convertir(promotion);
        }

        /// <summary>
        /// Recherche une liste de promotions par leurs clés.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="listeClesPromotion">Liste de clés uniques de promotions.</param>
        /// <returns>Tableau de promotions.</returns>
        public PromotionPourDetail[] RechercherPromotionsDepuisListeCles(Identite identite, int[] listeClesPromotion)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            listeClesPromotion.Valider(nameof(listeClesPromotion)).NonNul();

            // Appel à la méthode RechercherPromotions (DTI Referentiel).
            Promotion[] promotions = Composer.GetUnique<IPromotionService>().RechercherPromotions(identite, listeClesPromotion);

            // Vérification du retour.
            promotions.Valider(nameof(promotions)).NonNul();

            // Conversion en tableau d'objets de présentation de service externe.
            return promotions.Select(x => PromotionPourDetailMapper.Convertir(x)).ToArray();
        }

        /// <summary>
        /// Fournit la liste des promotions éligibles pour l'offre.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Liste des promotions éligibles.</returns>
        public PromotionPourDetail[] ObtenirPromotionsEligiblesParCleOffre(Identite identite, int cleOffre)
        {
            ///Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

            // Appel à la méthode RechercherCatalogueDesPromotions (DTI Referentiel). 
            Promotion[] promotions = Composer.GetUnique<IPromotionService>().RechercherCatalogueDesPromotions(identite, cleOffre, null);

            // Vérification du retour
            promotions.Valider(nameof(promotions)).NonNul();

            // Conversion en tableau d'objets de présentation de service externe.
            return promotions.Select(x => PromotionPourDetailMapper.Convertir(x)).ToArray();
        }

        /// <summary>
        /// Teste l’éligibilité d’un code promo par rapport à une ligne.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <param name="clePromo">Clé unique de la promotion.</param>
        /// <returns></returns>
        public bool TesterEligibiliteCodePromo(Identite identite, int cleOffre, int clePromo)
        {
            ///Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();
            clePromo.Valider(nameof(clePromo)).StrictementPositif();

            // Parse de la clé de promotion

            // Appel à la méthode de la brique externe.
            return Composer.GetUnique<IPromotionService>()
                .TesterEligibiliteCodePromo(identite, clePromo, cleOffre);
        }

        /// <summary>
        /// Retourne les informations du kit de la box.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleKitBox">Clé du KitBox.</param>
        /// <returns>Informations du KitBox.</returns>
        public Domain.CommonTypes.DTO.RefComKitBox ObtenirRefComKitBox(Identite identite, int cleKitBox)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleKitBox.Valider(nameof(cleKitBox)).StrictementPositif();

            // Appel à la méthode ObtenirRefComKitBox (DTI Referentiel).
            Referentiel.Application.DTO.RefComKitBox refComKitBox = Composer.GetUnique<IRefComKitBoxService>()
                .ObtenirRefComKitBox(identite, cleKitBox);

            // Vérification du retour.
            refComKitBox.Valider(nameof(refComKitBox)).NonNul();

            // Conversion en objet de présentation de service externe.
            return RefComKitBoxMapper.Convertir(refComKitBox);
        }

        /// <summary>
        /// Retourne les informations de la "référence commerciale".
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="codeRefCom">Code de la "référence commerciale".</param>
        /// <returns>Informations de la référence commerciale sérialisée.</returns>
        public Domain.CommonTypes.DTO.RefComSerialisee ObtenirRefComSerialiseeDepuisCodeRefCom(Identite identite, string codeRefCom)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            codeRefCom.Valider(nameof(codeRefCom)).Obligatoire();

            // Appel à la méthode RechercherRefComDepuisCodeRefCom (DTI Referentiel).
            Referentiel.Application.DTO.RefComSerialisee refComSerialisee = Composer.GetUnique<IRefComService>()
                .RechercherRefComDepuisCodeRefCom(identite, codeRefCom);

            // Vérification du retour.
            refComSerialisee.Valider(nameof(refComSerialisee)).NonNul();

            // Conversion en objet de présentation de service externe.
            return RefComSerialiseeMapper.Convertir(refComSerialisee);
        }

        /// <summary>
        /// Permet d'obtenir une marque.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleMarque">Clé de la marque.</param>
        /// <returns>Informations sur la marque.</returns>
        public Domain.CommonTypes.DTO.Marque ObtenirMarqueParCle(Identite identite, int cleMarque)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleMarque.Valider(nameof(cleMarque)).StrictementPositif();

            return Composer.GetUnique<IMarqueService>().RechercherMarqueDepuisCle(identite, cleMarque).Convertir();
        }

        /// <summary>
        /// Recherche une liste de promotions par leurs clés.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="listeClesPromotion">Liste de clés uniques de promotions.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Tableau de promotions.</returns>
        public PromotionPourDetail[] RechercherPromotionsDepuisListeClesEtCleOffre(Identite identite, int cleOffre, int[] listeClesPromotion)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            listeClesPromotion.Valider(nameof(listeClesPromotion)).NonNul();

            // Appel à la méthode RechercherPromotionsAvecCleOffre (DTI Referentiel).
            Promotion[] promotions = Composer.GetUnique<IPromotionService>().RechercherPromotionsAvecCleOffre(identite, cleOffre, listeClesPromotion);

            // Vérification du retour.
            promotions.Valider(nameof(promotions)).NonNul();

            // Conversion en tableau d'objets de présentation de service externe.
            return promotions.Select(x => PromotionPourDetailMapper.Convertir(x)).ToArray();
        }
    }
}