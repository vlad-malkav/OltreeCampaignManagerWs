﻿using EIT.Composition;
using EIT.Fixe.Facturation.Application;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe Facturation.
    /// </summary>
    public sealed class FacturationServiceExterne : IFacturationServiceExterne
    {
        /// <summary>
        /// Obtenir la date de la dernière facture par clé de ligne.
        /// </summary>
        /// <param name="identite">Identité.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Date de la dernière facture.</returns>
        public DateTime? RechercherDateDerniereFactureParCleLigne(Identite identite, long cleLigne)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            return Composer.GetUnique<IGoFacturationService>()
                .RechercherDateDerniereFactureParCleLigne(identite, cleLigne);
        }
        
        /// <summary>
        /// Retourne la liste des motifs de suspension de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns></returns>
        public List<string> ObtenirListeMotifsSuspensionParReferenceExterne(Identite identite, string referenceExterne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Appel service CompteFacturationLigneService
            LignePourDetails detail = Composer.GetUnique<ICompteFacturationLigneService>().ObtenirDetailsLigneParIdentifiantThd(identite, referenceExterne);
            detail.Valider(nameof(detail)).NonNul();
            detail.ListeMotifsSuspension.Valider(nameof(detail.ListeMotifsSuspension)).NonNul();

            // Extraction de la liste des motifs de suspension
            List<string> listeMotifsSuspension = detail.ListeMotifsSuspension.Select(x => x.Libelle).ToList();
            
            return listeMotifsSuspension;
        }
        
        /// <summary>
        ///  Retourne les informations des seuils de surconsommation  de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Informations des seuils de surconsommation.</returns>
        public InformationsSeuilsSurconsommation ObtenirInformationsSeuilsSurconsommationParReferenceExterne(Identite identite, string referenceExterne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Appel service CompteFacturationLigneService
            LignePourDetails detail = Composer.GetUnique<ICompteFacturationLigneService>().ObtenirDetailsLigneParIdentifiantThd(identite, referenceExterne);
            detail.Valider(nameof(detail)).NonNul();

            // construction de l'objet de retour
            InformationsSeuilsSurconsommation informationsSeuils = new InformationsSeuilsSurconsommation()
            {
                SeuilSurconsommationTelephonie = detail.SeuilSurconsommationVoix,
                SeuilSurconsommationVod = detail.SeuilSurconsommationVod
            };

            return informationsSeuils;
        }
    }
}