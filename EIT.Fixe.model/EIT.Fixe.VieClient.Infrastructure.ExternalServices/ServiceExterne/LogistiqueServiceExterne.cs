﻿using EIT.Composition;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Logistique.Application;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le domaine externe Logistique.
    /// </summary>
    public sealed class LogistiqueServiceExterne : ILogistiqueServiceExterne
    {
        /// <summary>
        /// Retourne les informations décrivant l'équipement.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleEquipement">Clé unique de l'équipement.</param>
        /// <returns></returns>
        public Domain.CommonTypes.DTO.Equipement ObtenirEquipementDepuisCle(Identite identite, long cleEquipement)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleEquipement.Valider(nameof(cleEquipement)).StrictementPositif();

            // Appel à la méthode ObtenirEquipementDepuisCle (domaine Logistique).
            Logistique.Application.Equipement equipement = Composer.GetUnique<IEquipementService>().ObtenirEquipementDepuisCle(identite, cleEquipement);
            equipement.Valider(nameof(equipement)).NonNul();

            // Conversion en objet de présentation de service externe.
            return EquipementMapper.Convertir(equipement);
        }
        
        /// <summary>
        /// Permet de créer une demande de retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Une demande de retour équipement correspodant à la référence externe donnée en paramètre.</returns>
        public Domain.CommonTypes.DTO.DemandeRetourEquipement CreerDemandeRetourEquipement(Identite identite, string referenceExterne)
        {
            return Composer.GetUnique<IDemandeRetourEquipementService>().CreerDemandeRetourEquipement(
                identite,
                referenceExterne,
                TypeDemandeRetourEquipement.RetractationResiliation).Convertir();
        }

        /// <summary>
        /// Permet de gérer les traitements liés à la commande de retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="informationsCommandeRetourEquipement">Informations de la commande de retour équipement à créer.</param>
        public void GererCommandeRetourEquipement(Identite identite, string referenceExterne, CommandeRetourEquipementPourCreation informationsCommandeRetourEquipement)
        {
            // Vérification des paramètres entrants.
            informationsCommandeRetourEquipement.Valider(nameof(informationsCommandeRetourEquipement)).NonNul();
            informationsCommandeRetourEquipement.CodeArticleCourrierResiliationRetourColis
                .Valider(nameof(informationsCommandeRetourEquipement.CodeArticleCourrierResiliationRetourColis)).Obligatoire();
            informationsCommandeRetourEquipement.CleImprimeCourrierResiliationRetourColis
                .Valider(nameof(informationsCommandeRetourEquipement.CleImprimeCourrierResiliationRetourColis)).StrictementPositif();

            // Création de l'objet qui défini l'adresse de livraison.
            ParametresDefinitionAdresseLivraison parametresDefinitionAdresseLivraison = new ParametresDefinitionAdresseLivraison()
            {
                Destinataire = string.Format("{0} {1} {2}",
                                            informationsCommandeRetourEquipement.Tiers.Civilite,
                                            informationsCommandeRetourEquipement.Tiers.Nom,
                                            informationsCommandeRetourEquipement.Tiers.Prenom),
                ComplementDestinataire = null,
                ComplementIdentification = null,
                ComplementPointRemise = null,
                Voie = informationsCommandeRetourEquipement.Tiers.Adresse.Voie,
                ServiceParticulier = null,
                CodePostal = informationsCommandeRetourEquipement.Tiers.Adresse.CodePostal,
                Ville = informationsCommandeRetourEquipement.Tiers.Adresse.Ville,
                NumeroTelephone = informationsCommandeRetourEquipement.Tiers.TelephoneMobileTiers,
                Email = informationsCommandeRetourEquipement.Tiers.EmailTiers
            };

            // Initialisation de la liste des paramètres du courrier.
            List<string> parametres = new List<string>()
            {
                informationsCommandeRetourEquipement.CleMarque.ToString(),
                string.Empty,
                informationsCommandeRetourEquipement.LibelleOffre,
                string.Empty,
                string.Empty,
                informationsCommandeRetourEquipement.Tiers.TelephoneMobileTiers,
                informationsCommandeRetourEquipement.NumeroRetourEquipement,
                informationsCommandeRetourEquipement.DateResiliation.ToString(),
                referenceExterne,
                informationsCommandeRetourEquipement.TelephoneFixeSc,
                string.Empty,
                string.Empty,
                string.Empty,
                string.Empty,
                string.Empty
            };

            // Instanciation des paramètres du courrier.
            List<ParametresCourrier> listeParametresCourrier = new List<ParametresCourrier>();
            listeParametresCourrier.Add(new ParametresCourrier()
            {
                CodeArticle = informationsCommandeRetourEquipement.CodeArticleCourrierResiliationRetourColis,
                CleImprimeCourrier = informationsCommandeRetourEquipement.CleImprimeCourrierResiliationRetourColis,
                Parametres = parametres
            });

            // Création de la commande d'expédition.
            Composer.GetUnique<ICommandeExpeditionService>().CreerCommandeExpeditionComplete(
                                                identite,
                                                referenceExterne,
                                                TypeOrigine.ResilRetract,
                                                parametresDefinitionAdresseLivraison,
                                                TypeLivraison.Domicile,
                                                null,
                                                listeParametresCourrier,
                                                true,
                                                true);
        }

        /// <summary>
        /// Permet d'obtenir une liste de commande d'expédition reférence commerciale pour lister.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleCommandeExpedition">Clé de la commande d'expédition.</param>
        /// <returns>Une liste CommandeExpeditionReferenceCommercialePourLister.</returns>
        public List<Domain.CommonTypes.DTO.CommandeExpeditionReferenceCommercialePourLister> ObtenirCommandeExpeditionParCle(Identite identite, long cleCommandeExpedition)
        {
            CommandeExpeditionPourDetail commmandeExpeditionPourDetail =
                Composer.GetUnique<ICommandeExpeditionService>().ObtenirDetailCommandeExpeditionParCle(identite, cleCommandeExpedition);

            return commmandeExpeditionPourDetail.ListeReferenceCommerciale.Select(x => x.Convertir()).ToList();
        }
    }
}