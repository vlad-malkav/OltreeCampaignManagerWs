﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Helpers;
using EIT.Fixe.Systeme.Communication;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Mappers.TiersMapper;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Messaging;
using EIT.Tiers.Application.Tiers;
using System;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe Tiers.
    /// </summary>
    public sealed class TiersServiceExterne : ITiersServiceExterne
    {
        #region Champs

        /// <summary>
        /// Interface du client WCF pour appel de service externes.
        /// </summary>
        private readonly IClientFactory clientFactory;

        /// <summary>
        /// Interface du paramétrage pour la récupération des Urls.
        /// </summary>
        private readonly IParametrage parametrage;

        /// <summary>
        /// Interface du service d'envoi de message.
        /// </summary>
        private readonly IMessagingSystem messagingSystem;

        #endregion Champs

        #region Constructeur

        /// <summary>
        /// Constructeur d'instanciation.
        /// </summary>
        /// <param name="clientFactory">Client factory.</param>
        /// <param name="parametrage">Service de paramétrage.</param>
        /// <param name="messagingSystem">Service d'envoi de message.</param>
        public TiersServiceExterne(IClientFactory clientFactory, IParametrage parametrage, IMessagingSystem messagingSystem)
        {
            this.clientFactory = clientFactory;
            this.parametrage = parametrage;
            this.messagingSystem = messagingSystem;
        }

        #endregion Constructeur

        #region Méthodes - ITiersServiceExterne

        /// <summary>
        /// Obtient le login SFC du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Email/LoginSFC du tiers.</returns>
        public string ObtenirLoginSfcParCleTiers(Identite identite, long cleTiers)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            // Appel au service externe.
            using (IClient<ITiersService> clientTiers = this.clientFactory.CreateClient<ITiersService>(this.parametrage.UrlBriqueTiers))
            {
                TiersPhysique tiersPhysique = clientTiers.Service.RechercherTiersParCleTiers(identite, (int)cleTiers);
                return tiersPhysique.Tiers.Email;
            }
        }

        /// <summary>
        /// Obtient le tiers par clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Ensemble des informations du tiers.</returns>
        public TiersPourDetail ObtenirParCle(Identite identite, long cleTiers)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            // Appel au service externe.
            using (IClient<ITiersService> clientTiers = this.clientFactory.CreateClient<ITiersService>(this.parametrage.UrlBriqueTiers))
            {
                TiersPhysique tiersPhysique = clientTiers.Service.RechercherTiersParCleTiers(identite, (int)cleTiers);
                return TiersPourDetailMapper.Convertir(tiersPhysique);
            }
        }

        /// <summary>
        /// Obtient la clé mobile d'un tiers via la clé fixe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiersFixe">Clé fixe du tiers.</param>
        /// <returns>Informations du tiers associé.</returns>
        public TiersAssociePourDetail ObtenirCleTiersMobileParCleTiersFixe(Identite identite, int cleTiersFixe)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiersFixe.Valider(nameof(cleTiersFixe)).StrictementPositif();

            // Appel au service externe.
            using (IClient<ITiersService> clientTiers = this.clientFactory.CreateClient<ITiersService>(this.parametrage.UrlBriqueTiers))
            {
                // Récupération des informations.
                TiersAssocie tiersAssocie = clientTiers.Service.EstTiersAssocie(identite, cleTiersFixe);
                tiersAssocie.Valider(nameof(tiersAssocie)).NonNul();

                // Construction de l'objet de retour, et retour de ce dernier.
                return new TiersAssociePourDetail()
                {
                    CleTiers = tiersAssocie.CleTiers,
                    EstAssocie = tiersAssocie.TiersEstAssocie
                };
            }
        }

        /// <summary>
        /// Permet de modifier l'email de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <param name="email">Email de contact du tiers.</param>
        public void ModifierEmailContactTiers(Identite identite, long cleTiers, string email)
        {
            using (IClient<ITiersService> clientTiers = this.clientFactory.CreateClient<ITiersService>(this.parametrage.UrlBriqueTiers))
            {
                // Appel de la méthode ModifierEmailTiers de la brique Tier.
                clientTiers.Service.ModifierEmailTiers(identite, email, (int)cleTiers);
            }
        }

        /// <summary>
        /// Permet de modifier les numéros de téléphones de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <param name="numeroMobile">Téléphone mobile de contact du tiers.</param>
        /// <param name="numeroFixe">Téléphone fixe de contact du tiers.</param>
        public void ModifierTelephonesContactTiers(Identite identite, long cleTiers, string numeroMobile, string numeroFixe)
        {
            // Instanciation du message.
            Tiers.Domain.SharedKernel.Event.Tiers.ModifierNumerosTiersEvent modifierNumeroTiersEvent = new Tiers.Domain.SharedKernel.Event.Tiers.ModifierNumerosTiersEvent()
            {
                CleTiers = (int)cleTiers,
                NumeroMobile = numeroMobile,
                NumeroFixe = numeroFixe,
                Headers = EventHelper.InitialiserHeadersEvenementAvecIdentite(identite)
            };

            // Envoi d'un message ModifierNumerosTiersEvent à la brique Tier.
            messagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), modifierNumeroTiersEvent);
        }

        /// <summary>
        /// Permet de modifier les préférences de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="preferences">Préférences de contact.</param>
        public void ModifierPreferenceDeContactTiers(Identite identite, ParametrePreferencesContactTiers preferences)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            preferences.Valider(nameof(preferences)).NonNul();
            // Instanciation du message.
            Tiers.Domain.SharedKernel.Event.Tiers.ModifierPreferencesDeContactTiersEvent modifierPreferencesDeContactTiersEvent
                = new Tiers.Domain.SharedKernel.Event.Tiers.ModifierPreferencesDeContactTiersEvent()
                {
                    CleTiers = (int)preferences.CleTiers,
                    ContactCourrier = preferences.ContactCourrier,
                    ContactEmail = preferences.ContactEmail,
                    ContactMessageVocal = preferences.ContactMessageVocal,
                    ContactSMS = preferences.ContactSms,
                    ContactTelevente = preferences.ContactTelevente,
                    Headers = EventHelper.InitialiserHeadersEvenementAvecIdentite(identite)
                };

            // Envoi d'un message ModifierPreferencesDeContactTiersEvent à la brique Tiers.
            messagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), modifierPreferencesDeContactTiersEvent);
        }

        #endregion Méthodes - ITiersServiceExterne
    }
}