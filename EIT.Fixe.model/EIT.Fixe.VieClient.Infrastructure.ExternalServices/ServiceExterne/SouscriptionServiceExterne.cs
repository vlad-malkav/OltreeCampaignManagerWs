﻿using EIT.Composition;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Souscription.Application;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec le service externe Souscription.
    /// </summary>
    public sealed class SouscriptionServiceExterne : ISouscriptionServiceExterne
    {
        /// <summary>
        /// Récupération d'une commande de souscription depuis sa référence externe.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Informations de la commande de souscription.</returns>
        public Domain.CommonTypes.DTO.CommandeSouscriptionPourDetail RechercherCommandeSouscriptionParReferenceExterne(Identite identite, string referenceExterne)
        {
            // Vérification des paramètrs entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul().LongueurMax(30);

            // Récupération des éléments techniques.
            ElementsTechniquesCommande elementsTechniques = Composer.GetUnique<Souscription.Application.ICommandeSouscriptionService>()
                .ObtenirElementsTechniquesCommande(identite, referenceExterne);

            // On teste les informations récupérées.
            if (elementsTechniques == null)
            {
                throw new Exception
                    ($"Aucune commande de souscription n'a pu étre récupérée depuis l'identifiant THD '{ referenceExterne}'");
            }

            // Construction de l'objet de retour.
            Domain.CommonTypes.DTO.CommandeSouscriptionPourDetail commandeSouscription = new Domain.CommonTypes.DTO.CommandeSouscriptionPourDetail()
            {
                Cle = elementsTechniques.CleCommande,
                Numero = elementsTechniques.NumeroCommande,
                DateCreation = elementsTechniques.DateCommande,
                Etat = elementsTechniques.EtatCommande,
                DateConfirmation = elementsTechniques.DateConfirmation,
                CleTiers = elementsTechniques.CleTiers
            };

            // Retour.
            return commandeSouscription;
        }

        /// <summary>
        /// Permet de récupérer l'adresseInstallation depuis la ref externe.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleAdresseInstallation">Cle d'adresse installation.</param>
        /// <returns>AdresseInstallation.</returns>
        public AdresseInstallationPourDetail ObtenirAdresseInstallationParCleEligibilite(Identite identite, long cleAdresseInstallation)
        {
            // Vérification des paramètrs entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleAdresseInstallation.Valider(nameof(cleAdresseInstallation)).StrictementPositif();

            AdresseInstallation informations = Composer.GetUnique<Souscription.Application.ICommandeSouscriptionService>()
                .ObtenirAdresseInstallationDepuisCle(identite, cleAdresseInstallation);

            return new AdresseInstallationPourDetail()
            {
                Cle = cleAdresseInstallation,
                CodePostal = informations.CodePostal,
                Numero = informations.NumeroVoie,
                Rue = informations.NomVoie,
                Ville = informations.Ville,
                Complement = informations.ComplementNumeroVoie,
                Batiment = informations.Batiment,
                Escalier = informations.Escalier,
                Etage = informations.Etage
            };
        }

        /// <summary>
        /// Liste les professions disponibles pour l’annuaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <returns>Liste des professions disponibles dans l’annuaire.</returns>
        public List<ParamProfession> ListerProfessionAnnuaire(Identite identite)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();

            // Appeler la méthode ListerProfessionAnnuaire du domaine Souscription            
            Profession[] listeProfessions = Composer.GetUnique<IProfessionService>().ListerProfessionsAnnuaire(identite);
            List<ParamProfession> listeParamProfessions = listeProfessions.Select(x => ParamProfessionMapper.Convertir(x)).ToList();

            return listeParamProfessions;
        }
    }
}