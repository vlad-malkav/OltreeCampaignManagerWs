﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ComptesClientMappers;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe Comptes clients.
    /// </summary>
    public sealed class ComptesClientServiceExterne : IComptesClientServiceExterne
    {
        #region Champs

        /// <summary>
        /// Service de paramétrage.
        /// </summary>
        private readonly IParametrage parametrage;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Identite pour l'appel de la brique externe Comptes Clients.
        /// </summary>
        private BriqueComptesClient.Identite IdentiteComptesClient
        {
            get
            {
                return new BriqueComptesClient.Identite()
                {
                    ApplicationAppelante = ObjetsCommunsFixe.IdentiteFixeCommune.ApplicationAppelante,
                    Canal = ObjetsCommunsFixe.IdentiteFixeCommune.Canal,
                    Memoid = ObjetsCommunsFixe.IdentiteFixeCommune.Memoid
                };
            }
        }

        #endregion Propriétés

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametrage">Service de paramétrage;</param>
        public ComptesClientServiceExterne(IParametrage parametrage)
        {
            parametrage.Valider(nameof(parametrage)).NonNul();

            this.parametrage = parametrage;
        }

        #endregion Constructeurs

        /// <summary>
        /// Permet de récupérer l’ensemble des comptes clients d’un tiers, par sa clé.
        /// Remarque : il s’agit de la clé tiers dans le SI Mobile.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cleTiersMobile">Clé unique du tiers au sein du SI Mobile.</param>
        /// <returns>La liste des comptes clients.</returns>
        public CompteClientPourLister[] RechercherComptesClientParCleTiersTitulaireLight(Identite identite, int cleTiersMobile)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleTiersMobile.Valider(nameof(cleTiersMobile)).StrictementPositif();

            //Appel à la brique ComptesClient.
            using (BriqueComptesClient.ComptesClient wsBriqueCC = new BriqueComptesClient.ComptesClient() { Url = this.parametrage.UrlBriqueComptesClient })
            {
                BriqueComptesClient.ReponseRechercherListeComptesClientLight reponse = wsBriqueCC.RechercherComptesClientParCleTiersTitulaireLight(this.IdentiteComptesClient, cleTiersMobile);
                
                return reponse.ComptesClient.Select(c => CompteClientPourListerMapper.Convertir(c)).ToArray();
            }
        }

        /// <summary>
        /// Permet de récupérer l’ensemble des informations d’un compte client, par sa clé.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cleCompteClient">Clé technique du compte client.</param>
        /// <returns>Le compte client correspondant.</returns>
        public CompteClientPourDetail ObtenirCompteClientParCle(Identite identite, long cleCompteClient)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleCompteClient.Valider(nameof(cleCompteClient)).StrictementPositif();

            //Appel à la brique ComptesClient.
            using (BriqueComptesClient.ComptesClient wsBriqueCC = new BriqueComptesClient.ComptesClient() { Url = this.parametrage.UrlBriqueComptesClient })
            {
                BriqueComptesClient.ReponseRechercherCompteClient reponse = wsBriqueCC.RechercherCompteClient(this.IdentiteComptesClient, (int)cleCompteClient);

                // Vérification de la réponse obtenue.
                if (reponse.ErreurSurvenue)
                {
                    throw new Exception($"{reponse.MessageErreur} code erreur : {reponse.CodeErreur}");
                }

                return CompteClientPourDetailMapper.Convertir(reponse.CompteClient);
            }
        }
    }
}