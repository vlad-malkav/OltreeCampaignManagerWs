﻿using EIT.Composition;
using EIT.Fixe.Historique.Application.Interface;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe des historiques.
    /// </summary>
    public sealed class HistoriqueServiceExterne : IHistoriqueServiceExterne
    {
        #region Méthodes - IHistoriqueServiceExterne

        /// <summary>
        /// Obtient la liste des historiques correspondant à la référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe sur laquelle effectuer la recherche.</param>
        /// <returns>Liste des historiques.</returns>
        public HistoriquePourLister[] RechercherHistoriquesParReferenceExterne(Identite identite, string referenceExterne)
        {
            // Validation des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();

            // Initialisation des critères de recherche.
            ParametresRechercheHistoriqueFonctionnel parametresRecherche = new ParametresRechercheHistoriqueFonctionnel
            {
                RefExterne = referenceExterne
            };

            // Recherche des historique.
            HistoriqueFonctionnel[] historiquesFonctionnels = Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>()
                .RechercheHistoriqueFonctionnelMulticriteres(identite, parametresRecherche);

            // Réponse.
            return historiquesFonctionnels.Select(h => HistoriquePourListerMapper.Convertir(h)).ToArray();
        }

        /// <summary>
        /// Obtient la liste des historiques correspondant à la référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe sur laquelle effectuer la recherche.</param>
        /// <param name="indexPage">Index de la page.</param>
        /// <param name="nombreResultats">Nombre de résultats maximum à retourner.</param>
        /// <returns>Liste des historiques.</returns>
        public HistoriquePourLister[] RechercherHistoriquesParReferenceExterne(Identite identite, string referenceExterne, int indexPage, int nombreResultats)
        {
            // Validation des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();

            // Initialisation des critères de recherche.
            ParametresRechercheHistoriqueFonctionnel parametresRecherche = new ParametresRechercheHistoriqueFonctionnel
            {
                RefExterne = referenceExterne,
                Canal = identite.Canal.ToString(),
                MemoID = null //Paramètre null, car l'historique n'est pas obligatoirement fait à partir de son MEMOID.
            };

            // Recherche des historique.
            HistoriqueFonctionnel[] historiquesFonctionnels = Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>()
                .RechercheHistoriqueFonctionnelMulticriteresAvecPagination(identite, parametresRecherche, indexPage, nombreResultats);

            // Si aucun historique, on retourne null.
            if (historiquesFonctionnels == null || !historiquesFonctionnels.Any())
            {
                return null;
            }

            // Réponse.
            return historiquesFonctionnels.Select(h => HistoriquePourListerMapper.Convertir(h)).ToArray();
        }

        /// <summary>
        /// Permet de créer un historique appel dans la brique externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="informationsHistorique">Informations de l'historique à créer.</param>
        /// <returns>Clé de l'Historique Appel créé.</returns>
        /// <remarks>Les numéros de téléphone appelés et appelants ne sont pas obligatoires.</remarks>
        public long CreerHistoriqueAppel(Identite identite, HistoriqueAppelPourCreation informationsHistorique)
        {
            // Validation des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            informationsHistorique.Valider(nameof(informationsHistorique)).NonNul();

            // Vérification des paramètres entrants, historique fonctionnel.
            informationsHistorique.HistoriqueFonctionnel.Valider(nameof(informationsHistorique.HistoriqueFonctionnel)).NonNul();
            informationsHistorique.HistoriqueFonctionnel.CleMetier1.Valider(nameof(informationsHistorique.HistoriqueFonctionnel.CleMetier1)).NonNul();
            informationsHistorique.HistoriqueFonctionnel.CleMetier2.Valider(nameof(informationsHistorique.HistoriqueFonctionnel.CleMetier2)).NonNul();
            informationsHistorique.HistoriqueFonctionnel.Commentaire.Valider(nameof(informationsHistorique.HistoriqueFonctionnel.Commentaire))
                .Si(string.IsNullOrWhiteSpace(informationsHistorique.HistoriqueFonctionnel.Commentaire));
            if (informationsHistorique.HistoriqueFonctionnel.CleOrigine.HasValue)
            {
                int cleOrigine = informationsHistorique.HistoriqueFonctionnel.CleOrigine.GetValueOrDefault();
                cleOrigine.Valider(nameof(cleOrigine)).StrictementPositif();
            }

            // Vérification des paramètres entrants, historique appel.
            informationsHistorique.DateAppel.Valider(nameof(informationsHistorique.DateAppel)).NonNul();
            informationsHistorique.DureeAppel.Valider(nameof(informationsHistorique.DureeAppel)).Positif();

            // Création de l'objet de paramètres de l'historique Fonctionnel.
            ParametresCreationHistoriqueFonctionnel parametresCreationHistoriqueFonctionnel = new ParametresCreationHistoriqueFonctionnel()
            {
                CleOrigine = informationsHistorique.HistoriqueFonctionnel.CleOrigine,
                CleTypeMetierNv1 = (int)informationsHistorique.HistoriqueFonctionnel.CleMetier1,
                CleTypeMetierNv2 = (int)informationsHistorique.HistoriqueFonctionnel.CleMetier2,
                Commentaire = informationsHistorique.HistoriqueFonctionnel.Commentaire,
                RefExterne = informationsHistorique.HistoriqueFonctionnel.ReferenceExterne
            };

            // Création de l'objet de paramètres de l'historique appel.
            ParametresCreationHistoriqueAppel parametresCreationHistoriqueAppel = new ParametresCreationHistoriqueAppel()
            {
                ParametresHistoriqueFonctionnel = parametresCreationHistoriqueFonctionnel,
                NomTiers = informationsHistorique.NomTiers,
                PrenomTiers = informationsHistorique.PrenomTiers,
                TelAppelant = informationsHistorique.NumeroTelephoneAppelant,
                TelAppele = informationsHistorique.NumeroTelephoneAppele,
                DateAppel = informationsHistorique.DateAppel,
                DureeAppel = informationsHistorique.DureeAppel,
                PointDeVenteCmi = informationsHistorique.PointDeVenteCmi,
                CleCanalMedia = informationsHistorique.CleCanalMedia,
                CleQualificationAppelNv1 = informationsHistorique.CleQualificationAppelNiveau1,
                CleQualificationAppelNv2 = informationsHistorique.CleQualificationAppelNiveau2
            };

            // Création de l'historique.
            long cleHistoriqueAppel = Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>()
                .CreerHistoriqueAppel(identite, parametresCreationHistoriqueAppel);
            cleHistoriqueAppel.Valider(nameof(cleHistoriqueAppel)).StrictementPositif();

            // On retourne la clé de l'historique créé.
            return cleHistoriqueAppel;
        }

        /// <summary>
        /// Obtention de la liste des thèmes pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'iden,tification de l'appelant.</param>
        /// <returns>Tableau de thèmes pour le transfert des appels.</returns>
        public ThemeQualificationAppel[] ObtenirThemesTransfertAppel(Identite identite)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();

            TypeMetierNv2[] reponse = Composer.GetUnique<IHistoriqueService>().ObtenirTypesMetierNv2(identite);

            //Vérification du résultat obtenu.
            if (reponse == null)
            {
                return null;
            }

            return reponse.Select(c => ThemeQualificationAppelMapper.Convertir(c)).ToArray();
        }

        /// <summary>
        /// Obtention de la liste des types de "Niveau1" associés à un Thème pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleTheme">Clé du thème.</param>
        /// <returns>Liste des "Niveau1" associés à un thème pour le transfert des appels</returns>
        public Niveau1QualificationAppel[] ObtenirNiveau1TransfertAppelParCleTheme(Identite identite, int cleTheme)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTheme.Valider(nameof(cleTheme)).StrictementPositif();

            QualificationAppelNv1[] reponse = Composer.GetUnique<IHistoriqueService>().ObtenirQualificationsAppelNv1ParCleTypeMetierNv2(identite, cleTheme);

            //Vérification du résultat obtenu.
            if (reponse == null)
            {
                return null;
            }

            return reponse.Select(x => Niveau1QualificationAppelMapper.Convertir(x)).ToArray();
        }

        /// <summary>
        /// Obtention de la liste des types de "Niveau1" associés à un Thème pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleNiveau1">Clé du Niveau1.</param>
        /// <returns>Liste des "Niveau2" associés à un "Niveau1" pour le transfert des appels</returns>
        public Niveau2QualificationAppel[] ObtenirNiveau2TransfertAppelParCleNiveau1(Identite identite, int cleNiveau1)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleNiveau1.Valider(nameof(cleNiveau1)).StrictementPositif();

            QualificationAppelNv2[] reponse = Composer.GetUnique<IHistoriqueService>().ObtenirQualificationsAppelNv2ParCleNv1(identite, cleNiveau1);

            //Vérification du résultat obtenu.
            if (reponse == null)
            {
                return null;
            }

            return reponse.Select(l => Niveau2QualificationAppelMapper.Convertir(l)).ToArray();
        }

        /// <summary>
        /// Obtention des informations d'un média à partir de sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleMedia">Clé technique d'un média.</param>
        /// <returns>Objet de présentation de type MediaHistorique.</returns>
        public MediaHistorique ObtenirMediaParCle(Identite identite, int cleMedia)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleMedia.Valider(nameof(cleMedia)).StrictementPositif();

            Media[] reponse = Composer.GetUnique<IHistoriqueService>().ObtenirMedias(identite);

            reponse.Valider(nameof(reponse)).NonNul();

            Media media = reponse.FirstOrDefault(x => x.Cle == cleMedia);

            return MediaHistoriqueMapper.Convertir(media);
        }

        /// <summary>
        /// Permet de créer un historique fonctionnel dans la brique externe et stocker la liaison historique/ligne dans le SI Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne cncernés par l'historique.</param>
        /// <param name="informationsHistorique">Informations de l'ihstorique à créer.</param>
        /// <returns>Cle de l'HistoriqueFonctionnel créé.</returns>
        public long CreerHistoriqueFonctionnelPourLigne(Identite identite, long cleLigne, HistoriquePourCreation informationsHistorique)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            informationsHistorique.Valider(nameof(informationsHistorique)).NonNul();

            informationsHistorique.CleMetier1.Valider(nameof(informationsHistorique.CleMetier1)).NonNul();
            informationsHistorique.CleMetier2.Valider(nameof(informationsHistorique.CleMetier2)).NonNul();
            informationsHistorique.Commentaire.Valider(nameof(informationsHistorique.Commentaire)).Si(string.IsNullOrWhiteSpace(informationsHistorique.Commentaire));

            if (informationsHistorique.CleOrigine.HasValue)
            {
                int cleOrigine = informationsHistorique.CleOrigine.GetValueOrDefault();
                cleOrigine.Valider(nameof(cleOrigine)).StrictementPositif();
            }
            ParametresCreationHistoriqueFonctionnel parametresCreationHistoriqueFonctionnel = new ParametresCreationHistoriqueFonctionnel()
            {
                CleOrigine = informationsHistorique.CleOrigine,
                CleTypeMetierNv1 = (int)informationsHistorique.CleMetier1,
                CleTypeMetierNv2 = (int)informationsHistorique.CleMetier2,
                Commentaire = informationsHistorique.Commentaire,
                RefExterne = informationsHistorique.ReferenceExterne
            };
            long cleHistoriqueFonctionnel = Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>()
                .CreerHistoriqueFonctionnelAvecRetourCleDossier(identite, parametresCreationHistoriqueFonctionnel);
            cleHistoriqueFonctionnel.Valider(nameof(cleHistoriqueFonctionnel)).StrictementPositif();

            return cleHistoriqueFonctionnel;
        }

        /// <summary>
        /// Obtention d'une liste d'historiques d'appels depuis une liste de clés.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="listeCles">Liste de clés techniques des historiques à rechercher.</param>
        /// <returns>Liste des historiques d'appel correspondant aux clés techniques fournies.</returns>
        public HistoriqueAppelPourLister[] ListerHistoriquesAppelsParListeCles(Identite identite, long[] listeCles)
        {
            if (listeCles == null || !listeCles.Any())
            {
                return null;
            }

            HistoriqueAppel[] historiques = Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>()
                .ObtenirHistoriquesAppelsDepuisListeCles(identite, listeCles);

            return HistoriquePourListerMapper.ConvertirListeHistoriquesAppels(historiques);
        }

        /// <summary>
        /// Création de l'historique fonctionnel pour une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="informationsHistorique">Informations nécessaire à la création d'un historique.</param>
        public void CreerHistoriquePourDemandeResiliation(Identite identite, HistoriqueFonctionnelPourCreation informationsHistorique)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            informationsHistorique.Valider(nameof(informationsHistorique)).NonNul();

            //Appel au service historique.
            Composer.GetUnique<Fixe.Domain.ExternalServices.IHistoriqueServiceExterne>().CreerHistoriqueFonctionnel(identite, informationsHistorique.CleMetier1,
                informationsHistorique.CleMetier2, informationsHistorique.ReferenceExterne, informationsHistorique.Commentaire, informationsHistorique.CleOrigine);
        }

        #endregion Méthodes - IHistoriqueServiceExterne
    }
}