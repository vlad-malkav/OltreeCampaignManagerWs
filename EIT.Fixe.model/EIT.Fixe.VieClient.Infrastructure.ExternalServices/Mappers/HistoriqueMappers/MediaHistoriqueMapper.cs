﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des medias historique.
    /// </summary>
    internal static class MediaHistoriqueMapper
    {
        /// <summary>
        /// Conversion d'une media historique du historique en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="mediaAConvertir">Media  à convertir, provenant du historique.</param>
        /// <returns>Media historique, interne au domaine Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        public static MediaHistorique Convertir(Historique.Application.Interface.Media mediaAConvertir)
        {
            if (mediaAConvertir == null)
            {
                return null;
            }

            return new MediaHistorique()
            {
                Cle = mediaAConvertir.Cle,
                Libelle = mediaAConvertir.Libelle,
                LibelleCourt = mediaAConvertir.LibelleCourt
            };
        }
    }
}
