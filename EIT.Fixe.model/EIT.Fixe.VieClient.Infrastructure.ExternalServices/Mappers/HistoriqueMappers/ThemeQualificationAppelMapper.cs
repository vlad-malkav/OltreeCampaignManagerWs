﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des thèmes de qualification appel.
    /// </summary>
    internal static class ThemeQualificationAppelMapper
    {
        /// <summary>
        /// Conversion d'un thèm de qualification appel du historique en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="qualificationAConvertir">Thème qualification appel à convertir, provenant du historique.</param>
        /// <returns>Thème qualification appel, interne au domaine Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        public static ThemeQualificationAppel Convertir(Historique.Application.Interface.TypeMetierNv2 qualificationAConvertir)
        {
            if (qualificationAConvertir == null)
            {
                return null;
            }

            return new ThemeQualificationAppel()
            {
                Cle = qualificationAConvertir.Cle,
                Libelle = qualificationAConvertir.Libelle
            };
        }

    }
}
