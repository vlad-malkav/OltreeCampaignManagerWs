﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des Niveau1 de qualification appel.
    /// </summary>
    internal static class Niveau1QualificationAppelMapper
    {
        /// <summary>
        /// Conversion d'un Niveau1 de qualification appel du historique en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="niveau1AConvertir">Niveau1 de qualification appel à convertir, provenant du historique.</param>
        /// <returns>Niveau1 associés à un thème pour le transfert des appels, interne au domaine Vie Client.</returns>    
        public static Niveau1QualificationAppel Convertir(Historique.Application.Interface.QualificationAppelNv1 niveau1AConvertir)
        {
            if (niveau1AConvertir == null)
            {
                return null;
            }

            return new Niveau1QualificationAppel()
            {
                Cle = niveau1AConvertir.Cle,
                Libelle = niveau1AConvertir.Libelle
            };
        }
    }
}
