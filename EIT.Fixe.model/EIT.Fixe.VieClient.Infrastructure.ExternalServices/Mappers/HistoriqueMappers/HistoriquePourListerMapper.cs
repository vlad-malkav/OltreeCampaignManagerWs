﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers
{
    /// <summary>
    /// Méthodes génériques dde conversion des historiques.
    /// </summary>
    internal static class HistoriquePourListerMapper
    {
        /// <summary>
        /// Conversion d'un historique externe en historique Vie Client, pour lister.
        /// </summary>
        /// <param name="historiqueAConvertir">Informations à convertir.</param>
        /// <returns>Historique pour lister dans Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        internal static HistoriquePourLister Convertir(Historique.Application.Interface.HistoriqueFonctionnel historiqueAConvertir)
        {
            if (historiqueAConvertir == null)
            {
                return null;
            }

            return new HistoriquePourLister()
            {
                Agent = historiqueAConvertir.MemoId,
                Cle = historiqueAConvertir.Cle,
                DateCreation = historiqueAConvertir.DateCreation,
                Historique = historiqueAConvertir.TypeMetierNv2.Libelle,
                Type = historiqueAConvertir.TypeMetierNv1.Libelle,
                Canal = historiqueAConvertir.Canal
            };
        }

        /// <summary>
        /// Conversion d'une liste d'historiques d'appel.
        /// </summary>
        /// <param name="historiques">Liste des historiques à convertir.</param>
        /// <returns>Objets de présentation Vie Client pour lister.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        internal static HistoriqueAppelPourLister[] ConvertirListeHistoriquesAppels(Historique.Application.Interface.HistoriqueAppel[] historiques)
        {
            if (historiques == null)
            {
                return null;
            }

            IList<HistoriqueAppelPourLister> ret = new List<HistoriqueAppelPourLister>();

            foreach (var historique in historiques)
            {
                if (historique != null)
                {
                    ret.Add(ConvertirHistoriqueAppel(historique));
                }
            }

            return ret.ToArray();
        }

        /// <summary>
        /// Convertion d'un historique d'appel.
        /// </summary>
        /// <param name="historique">Historique source.</param>
        /// <returns>Informations principales de l'historique d'appel.</returns>
        internal static HistoriqueAppelPourLister ConvertirHistoriqueAppel(Historique.Application.Interface.HistoriqueAppel historique)
        {
            if (historique == null)
            {
                return null;
            }

            return new HistoriqueAppelPourLister()
            {
                Cle = historique.Cle,

                CleTypeMetierNiveau1 = historique.TypeMetierNv1.Cle,
                LibelleTypeMetierNiveau1 = historique.TypeMetierNv1.Libelle,
                CleTypeMetierNiveau2 = historique.TypeMetierNv2.Cle,
                LibelleTypeMetierNiveau2 = historique.TypeMetierNv2.Libelle,

                Commentaire = historique.Commentaire,
                QualificationAppelNiveau1 = new Domain.CommonTypes.DTO.HistoriquesServiceExterne.Niveau1QualificationAppel
                {
                    Cle = historique.QualificationAppelNv1.Cle,
                    Libelle = historique.QualificationAppelNv1.Libelle
                },
                QualificationAppelNiveau2 = new Domain.CommonTypes.DTO.HistoriquesServiceExterne.Niveau2QualificationAppel
                {
                    Cle = historique.QualificationAppelNv2.Cle,
                    Libelle = historique.QualificationAppelNv2.Libelle
                }
            };
        }
    }
}