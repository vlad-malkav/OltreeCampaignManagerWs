﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.HistoriqueMappers
{ /// <summary>
  /// Méthodes génériques de conversion des Niveau2 de qualification appel.
  /// </summary>
    internal static class Niveau2QualificationAppelMapper
    {
        /// <summary>
        /// Conversion d'un Niveau2 de qualification appel du historique en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="niveau2AConvertir">Niveau2 de qualification appel à convertir, provenant du historique.</param>
        /// <returns>Niveau2 associés à un Niveau1 pour le transfert des appels, interne au domaine Vie Client.</returns>    
        public static Niveau2QualificationAppel Convertir(Historique.Application.Interface.QualificationAppelNv2 niveau2AConvertir)
        {
            if (niveau2AConvertir == null)
            {
                return null;
            }

            return new Niveau2QualificationAppel()
            {
                Cle = niveau2AConvertir.Cle,
                Libelle = niveau2AConvertir.Libelle
            };
        }
    }
}
