﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LoginMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des comptes clients.
    /// </summary>
    internal static class InformationsLoginCompteClientMapper
    {
        /// <summary>
        /// Conversion d'un compte client provenant de la brique Login, en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="informationsAConvertir">Login à convertir.</param>
        /// <returns>Informations login compte client, interne au domaine Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        internal static InformationsLoginCompteClient Convertir(BriqueLogin.LoginDetaille informationsAConvertir)
        {
            if (informationsAConvertir == null)
            {
                return new InformationsLoginCompteClient()
                {
                    AAccesSpecifiqueEspaceClientMobile = false,
                    LoginGestionnaire = string.Empty
                };
            }
            else
            {
                return new InformationsLoginCompteClient()
                {
                    AAccesSpecifiqueEspaceClientMobile = true,
                    LoginGestionnaire = informationsAConvertir.Id
                };
            }
            
        }
    }
}