﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LoginMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des réponses de validation OTP.
    /// </summary>
    internal static class ReponseValidationOtpMapper
    {
        /// <summary>
        /// Conversion d'une réponse de validation OTP provenant de la brique Authentification en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="reponseValidationOtpAConvertir">Validation OTP à convertir.</param>
        /// <returns>Validation OTP convertie.</returns>
        internal static ReponseValidationOtp Convertir(BriqueLogin.ReponseService reponseValidationOtpAConvertir)
        {
            if (reponseValidationOtpAConvertir == null)
            {
                return null;
            }

            return new ReponseValidationOtp()
            {
                EstValide = !reponseValidationOtpAConvertir.ErreurSurvenue,
                MessageErreur = reponseValidationOtpAConvertir.MessageErreur
            };
        }
    }
}
