﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LoginMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des réponses de modification de mot de passe.
    /// </summary>
    internal static class ReponseModificationMotDePasseMapper
    {
        /// <summary>
        /// Conversion d'une réponse de validation OTP provenant de la brique Authentification en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="reponseModificationMotDePasseAConvertir">Validation OTP à convertir.</param>
        /// <returns>Validation OTP convertie.</returns>
        internal static ReponseModificationMotDePasse Convertir(BriqueLogin.ReponseLogin reponseModificationMotDePasseAConvertir)
        {
            if (reponseModificationMotDePasseAConvertir == null)
            {
                return null;
            }

            return new ReponseModificationMotDePasse()
            {
                CodeErreur = reponseModificationMotDePasseAConvertir.CodeErreur,
                EstModifie = !reponseModificationMotDePasseAConvertir.ErreurSurvenue,
                MessageErreur = reponseModificationMotDePasseAConvertir.MessageErreur
            };
        }
    }
}

