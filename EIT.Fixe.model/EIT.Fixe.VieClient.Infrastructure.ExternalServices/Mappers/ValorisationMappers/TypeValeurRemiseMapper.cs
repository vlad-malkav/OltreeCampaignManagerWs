﻿using System;
using VLO2_LIBFIX;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ValorisationMappers
{
    /// <summary>
    /// Classe de conversion vers l'énumération de service externe Valorisation TypeValeurRemise.
    /// </summary>
    public static class TypeValeurRemiseMapper
    {
        /// <summary>
        /// Convertit l'énumération de présentation 'TypeValeurRemise' en énumération de service externe Valorisation 'TypeValeurRemise'.
        /// </summary>
        /// <param name="typeValeurRemise">Objet à convertir.</param>
        /// <returns></returns>
        public static TypeValeurRemise Convertir(Domain.CommonTypes.Enumerations.TypeValeurRemise typeValeurRemise)
        {
            switch (typeValeurRemise)
            {
                case Domain.CommonTypes.Enumerations.TypeValeurRemise.NA:
                    return TypeValeurRemise.Indefini;
                case Domain.CommonTypes.Enumerations.TypeValeurRemise.EnMontant:
                    return TypeValeurRemise.Montant;
                case Domain.CommonTypes.Enumerations.TypeValeurRemise.EnPourcentage:
                    return TypeValeurRemise.Proportionnel;
                default:
                    throw new InvalidOperationException($"Impossible de convertir la valeur Domain.CommonTypes.Enumerations.TypeValeurRemise.{typeValeurRemise} " +
                                                            "en une valeur d'énumération VLO2_LIBFIX.TypeApplicationPromotion");
            }

        }
    }
}