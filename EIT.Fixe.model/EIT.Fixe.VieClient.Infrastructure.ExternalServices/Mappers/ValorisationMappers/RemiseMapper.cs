﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ValorisationMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des remises pour Valorisation.
    /// </summary>
    internal static class RemiseMapper
    {
        /// <summary>
        /// Conversion d'un objet de présentation RemisePourValorisation en objet interne au domaine Valorisation.
        /// </summary>
        /// <param name="remiseAConvertir">Objet à convertir.</param>
        /// <returns>Objet interne au domaine Valorisation.</returns>
        public static VLO2_LIBFIX.Remise Convertir(RemisePourValorisation remiseAConvertir)
        {
            if (remiseAConvertir == null)
            {
                return null;
            }

            return new VLO2_LIBFIX.Remise()
            {
                DateDebut = remiseAConvertir.DateDebut,
                DateFin = remiseAConvertir.DateFin,
                MontantHT = remiseAConvertir.MontantHT,
                Pourcentage = remiseAConvertir.Pourcentage,
                ReferenceRemise = remiseAConvertir.ReferenceRemise,
                TypeValeurRemise = TypeValeurRemiseMapper.Convertir(remiseAConvertir.TypeValeur)
            };
        }
    }
}