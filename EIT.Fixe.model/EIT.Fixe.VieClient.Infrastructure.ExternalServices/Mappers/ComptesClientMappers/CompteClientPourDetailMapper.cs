﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ComptesClientMappers
{
    /// <summary>
    /// Contient les méthodes pour convertir les détailles du compte client du service externe.
    /// </summary>
    public static class CompteClientPourDetailMapper
    {
        /// <summary>
        ///  Convertit un entite en DTO.
        /// </summary>
        /// <param name="comtpeAConvertir">Objet à convertir.</param>
        /// <returns>CompteClientPourDetail.</returns>
        public static CompteClientPourDetail Convertir(BriqueComptesClient.CompteClient comtpeAConvertir)
        {
            if (comtpeAConvertir == null)
            {
                return null;
            }

            CompteClientPourDetail compteARetourner = new CompteClientPourDetail()
            {
                Cle = comtpeAConvertir.Cle,
                Numero = comtpeAConvertir.NumeroClient,
                Titulaire = TiersPourDetailMapper.Convertir(comtpeAConvertir.TiersTitulaire.TiersPhysique),
            };

            List<LigneMobilePourLister> listeLignesMobile = new List<LigneMobilePourLister>();
            foreach (BriqueComptesClient.LigneLightPourRecherche ligne in comtpeAConvertir.Lignes)
            {
                if (ligne != null)
                {
                    listeLignesMobile.Add(LigneMobilePourListerMapper.Convertir(ligne));
                }
            }
            compteARetourner.ListeLignes = listeLignesMobile;

            return compteARetourner;
        }
    }
}