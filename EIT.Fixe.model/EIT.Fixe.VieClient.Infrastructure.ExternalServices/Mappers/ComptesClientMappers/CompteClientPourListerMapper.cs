﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ComptesClientMappers
{
    /// <summary>
    /// Méthodes générique de conversion des comptes clients.
    /// </summary>
    internal static class CompteClientPourListerMapper
    {
        /// <summary>
        /// Conversion d'un compte client distant en compte client local (Vie Client).
        /// </summary>
        /// <param name="compteAConvertir">Informations à convertir.</param>
        /// <returns>Compte client local (Vie Client).</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        internal static CompteClientPourLister Convertir(BriqueComptesClient.CompteClientPourListerLight compteAConvertir)
        {
            if (compteAConvertir == null)
            {
                return null;
            }

            return new CompteClientPourLister()
            {
                Cle = compteAConvertir.Cle,
                Numero = compteAConvertir.NumeroClient,
                Titulaire = TiersPourDetailMapper.Convertir(compteAConvertir.Titulaire)
            };
        }
    }
}