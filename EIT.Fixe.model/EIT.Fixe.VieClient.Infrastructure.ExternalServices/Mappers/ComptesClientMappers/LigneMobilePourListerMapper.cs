﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ComptesClientMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de lignes mobiles.
    /// </summary>
    internal static class LigneMobilePourListerMapper
    {
        /// <summary>
        /// Conversion de ligne de la brique comptes client en ligne mobile Vie Client.
        /// </summary>
        /// <param name="ligneAConvertir">Informations de la ligne à convertir.</param>
        /// <returns>Ligne mobile, utilisable dans Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas d'erreur.</remarks>
        internal static LigneMobilePourLister Convertir(BriqueComptesClient.LigneLightPourRecherche ligneAConvertir)
        {
            if(ligneAConvertir == null)
            {
                return null;
            }

            return new LigneMobilePourLister()
            {
                Tiers = TiersPourDetailMapper.Convertir(ligneAConvertir.Titulaire.TiersPhysique),
                Cle = ligneAConvertir.Cle,
                LibelleOffre = ligneAConvertir.NomOffre,
                Numero = ligneAConvertir.Msisdn,
                CodeOperateur = ligneAConvertir.CodeOperateur,
                EstReseauFull = false, 
                ScoreChurn = ligneAConvertir.ScoreChurn.Score,
                SeuilSurconsommationTelephonie = ligneAConvertir.SeuilSurconsommation,
                Statut = ConvertirEtat(ligneAConvertir.Etat)
            };
        }

        /// <summary>
        /// Conversion de l'état d'une ligne mobile.
        /// </summary>
        /// <param name="etatDossier">Etat du dossier, au sein de la brique externe.</param>
        /// <returns>Etat du dossier utilisable dans le domaine Vie Client.</returns>
        private static EtatLigneMobile ConvertirEtat(BriqueComptesClient.EtatLigne etatLigne)
        {
            return ConvertisseurEnum<BriqueComptesClient.EtatLigne, EtatLigneMobile>.Convertir(etatLigne);
        }
    }
}