﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ComptesClientMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de tiers.
    /// </summary>
    internal static class TiersPourDetailMapper
    {
        /// <summary>
        /// Conversion d'un tiers de la brique externe Comptes Client en tiers Vie Client.
        /// </summary>
        /// <param name="tiersAconvertir">Tiers à convertir.</param>
        /// <returns>Informations du tiers, utilisable dans Vie Client.</returns>
        internal static TiersPourDetail Convertir(BriqueComptesClient.TiersPhysique tiersAconvertir)
        {
            return new TiersPourDetail()
            {
                Civilite = Convertir(tiersAconvertir.Civilite),
                Cle = tiersAconvertir.CleTiers,
                DateNaissance = tiersAconvertir.DateNaissance,
                EmailContact = tiersAconvertir.Email,
                Nom = tiersAconvertir.Nom,
                NomNaissance = tiersAconvertir.NomNaissance,
                NumeroMobileDeContact = tiersAconvertir.TelephoneMobile,
                NumeroDepartementNaissance = tiersAconvertir.DptNaissance,
                NumeroFixeDeContact = tiersAconvertir.TelephoneFixe,
                NumeroTiersBancaire = tiersAconvertir.NumeroTiersBancaire,
                Prenom = tiersAconvertir.Prenom,
                VilleNaissance = tiersAconvertir.VilleNaissance
            };
        }

        /// <summary>
        /// Conversion d'un tiers de la brique externe Comptes Client en tiers Vie Client.
        /// </summary>
        /// <param name="tiersAconvertir">Tiers à convertir.</param>
        /// <returns>Informations du tiers, utilisable dans Vie Client.</returns>
        internal static TiersPourDetail Convertir(BriqueComptesClient.TiersPourCompteClientPourLister tiersAconvertir)
        {
           

            return new TiersPourDetail()
            {
                Civilite = Convertir(tiersAconvertir.Civilite),
                Cle = tiersAconvertir.CleTiers,
                DateNaissance = tiersAconvertir.DateNaissance,
                EmailContact = tiersAconvertir.Email,
                Nom = tiersAconvertir.Nom,
                NomNaissance = tiersAconvertir.NomNaissance,
                NumeroMobileDeContact = tiersAconvertir.TelephoneMobile,
                NumeroDepartementNaissance = tiersAconvertir.DptNaissance,
                NumeroFixeDeContact = tiersAconvertir.TelephoneFixe,
                Prenom = tiersAconvertir.Prenom,
                VilleNaissance = tiersAconvertir.VilleNaissance
            };
        }

        /// <summary>
        /// Conversion d'une chaîne de caractère en civilité.
        /// </summary>
        /// <param name="civilite">Chaîne de caractère à convertir.</param>
        /// <returns>Civilité.</returns>
        private static Civilite Convertir(string civilite)
        {
            if (string.IsNullOrWhiteSpace(civilite))
            {
                return Civilite.NA;
            }

            switch (civilite.Trim().ToLower())
            {
                case "me":
                case "mme":
                case "madame":
                    return Civilite.Mme;
                case "m":
                case "mr":
                case "monsieur":
                    return Civilite.M;
                case "melle":
                case "mll":
                case "mlle":
                case "mle":
                case "ml":
                case "mademoiselle":
                    return Civilite.Melle;
                default:
                    return Civilite.NA;
            }
        }

        /// <summary>
        /// Conversion de la civilité de la brique compte client en civilité du SI Fixe.
        /// </summary>
        /// <param name="civilite">Civilité de la brique compte client.</param>
        /// <returns>Civilité du SI Fixe.</returns>
        private static Civilite Convertir(BriqueComptesClient.TypeCivilite3 civilite)
        {
            switch (civilite)
            {
                case BriqueComptesClient.TypeCivilite3.Madame:
                    return Civilite.Mme;
                case BriqueComptesClient.TypeCivilite3.Mademoiselle:
                    return Civilite.Melle;
                case BriqueComptesClient.TypeCivilite3.Monsieur:
                    return Civilite.M;
                default:
                    return Civilite.NA;
            }
        }
    }
}