﻿

using EIT.Fixe.Souscription.Application;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de Profession (DTO Souscription).
    /// </summary>
    internal static class ProfessionMapper
    {
        /// <summary>
        /// Conversion d'un objet de présentation de service externe Profession en objet interne au domaine Souscription.
        /// </summary>
        /// <param name="professionAConvertir">Objet à convertir.</param>
        /// <returns>Objet interne au domaine Souscription.</returns>
        public static Souscription.Application.Profession Convertir(Domain.CommonTypes.DTO.ParamProfession professionAConvertir)
        {
            if (professionAConvertir == null)
            {
                return null;
            }

            return new Souscription.Application.Profession()
            {
                Cle = professionAConvertir.Cle,
                Libelle = professionAConvertir.Libelle               
            };
        }
    }
}