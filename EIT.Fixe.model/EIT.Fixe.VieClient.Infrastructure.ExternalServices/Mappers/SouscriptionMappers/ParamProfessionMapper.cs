﻿

using EIT.Fixe.Souscription.Application;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de ParamProfession (service externe Souscription).
    /// </summary>
    internal static class ParamProfessionMapper
    {
        /// <summary>
        /// Conversion d'un objet de type Profession (DTO domaine Souscription) en objet de présentation de service externe ParamProfession.
        /// </summary>
        /// <param name="professionAConvertir">Objet à convertir.</param>
        /// <returns>de présentation de service externe Souscription.</returns>
        public static Domain.CommonTypes.DTO.ParamProfession Convertir(Souscription.Application.Profession professionAConvertir)
        {
            if (professionAConvertir == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.ParamProfession()
            {
                Cle = professionAConvertir.Cle,
                Libelle = professionAConvertir.Libelle               
            };
        }
    }
}