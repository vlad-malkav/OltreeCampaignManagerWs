﻿using EIT.Fixe.Souscription.Application;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion en ParametresDefinitionAnnuaire pour Souscription.
    /// </summary>
    internal static class ParametresDefinitionAnnuaireMapper
    {
        /// <summary>
        /// Conversion d'un objet de présentation ParametresDefinirAnnuaire en objet interne au domaine Valorisation ParametresDefinitionAnnuaire.
        /// </summary>
        /// <param name="remiseAConvertir">Objet à convertir.</param>
        /// <returns>Objet interne au domaine Valorisation.</returns>
        public static ParametresDefinitionAnnuaire Convertir(ParametresDefinirAnnuaire parametresAConvertir)
        {
            if (parametresAConvertir == null)
            {
                return null;
            }

            return new ParametresDefinitionAnnuaire()
            {
                CleTiers = parametresAConvertir.CleTiers,
                DiffusionEmail = parametresAConvertir.DiffusionEmail,
                DiffusionPrenom = parametresAConvertir.DiffusionPrenom,
                DiffusionProfession = parametresAConvertir.DiffusionProfession,
                InscriptionAnnuaireInverse = parametresAConvertir.InscriptionAnnuaireInverse,
                LimiterDiffusionAdresseVille = parametresAConvertir.LimiterDiffusionAdresseVille,
                Profession = ProfessionMapper.Convertir(parametresAConvertir.Profession),
                UtilisationMarketing = parametresAConvertir.UtilisationMarketing
            };
        }
    }
}