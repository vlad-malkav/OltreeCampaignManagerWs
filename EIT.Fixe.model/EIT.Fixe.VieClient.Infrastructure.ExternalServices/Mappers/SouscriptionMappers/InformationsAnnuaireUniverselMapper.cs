﻿using EIT.Fixe.Souscription.Application;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion en ParametresDefinitionAnnuaire pour Souscription.
    /// </summary>
    internal static class InformationsAnnuaireUniverselMapper
    {
        /// <summary>
        /// Conversion d'un objet de présentation ParametresDefinirAnnuaire en objet interne au domaine Valorisation ParametresDefinitionAnnuaire.
        /// </summary>
        /// <param name="remiseAConvertir">Objet à convertir.</param>
        /// <returns>Objet interne au domaine Valorisation.</returns>
        public static Domain.CommonTypes.DTO.InformationsAnnuaireUniversel Convertir(Souscription.Application.InformationsAnnuaireUniversel annuaireAConvertir)
        {
            if (annuaireAConvertir == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.InformationsAnnuaireUniversel()
            {
                CleTiers = annuaireAConvertir.CleTiers,
                DiffusionEmail = annuaireAConvertir.DiffusionEmail,
                DiffusionPrenom = annuaireAConvertir.DiffusionPrenom,
                DiffusionProfession = annuaireAConvertir.DiffusionProfession,
                InscriptionAnnuaireInverse = annuaireAConvertir.InscriptionAnnuaireInverse,
                LimiterDiffusionAdresseVille = annuaireAConvertir.LimiterDiffusionAdresseVille,
                Profession = ParamProfessionMapper.Convertir(annuaireAConvertir.Profession),
                UtilisationMarketing = annuaireAConvertir.UtilisationMarketing,
                DiffusionAnnuaireUniversel = annuaireAConvertir.DiffusionAnnuaireUniversel,
                ReferenceExterne = annuaireAConvertir.ReferenceExterne                
            };
        }
    }
}