﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet DemandeRetourEquipement.
    /// </summary>
    internal static class DemandeRetourEquipementMapper
    {
        /// <summary>
        /// Conversion de l'objet DemandeRetourEquipement de la brique Logistique vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="demandeAConvertir">Demande à convertir.</param>
        /// <returns>Demande convertie.</returns>
        public static DemandeRetourEquipement Convertir(this Logistique.Application.DemandeRetourEquipement demandeAConvertir)
        {
            if(demandeAConvertir == null)
            {
                return null;
            }
            return new DemandeRetourEquipement()
            {
                Cle = demandeAConvertir.CleDemande,
                Numero = demandeAConvertir.NumeroRetour
            };
        }
    }
}