﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet CommandeExpeditionReferenceCommercialePourListerMapper.
    /// </summary>
    internal static class CommandeExpeditionReferenceCommercialePourListerMapper
    {
        /// <summary>
        /// Conversion de l'objet CommandeExpeditionReferenceCommercialePourLister de la brique Logistique vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="commandeAConvertir">Commande à convertir.</param>
        /// <returns>Commande convertie.</returns>
        internal static CommandeExpeditionReferenceCommercialePourLister Convertir(this Logistique.Application.CommandeExpeditionReferenceCommercialePourLister commandeAConvertir)
        {
            if (commandeAConvertir == null)
            {
                return null;
            }

            CommandeExpeditionReferenceCommercialePourLister referenceCommercialePourLister = new CommandeExpeditionReferenceCommercialePourLister()
            {
                CodeRefCom = commandeAConvertir.CodeRefCom,
                CleEquipement = commandeAConvertir.Equipement.Cle
            };

            if (commandeAConvertir.Equipement != null)
            {
                referenceCommercialePourLister.CleEquipement = commandeAConvertir.Equipement.Cle;
            }

            return referenceCommercialePourLister;
        }
    }
}