﻿using EIT.Fixe.Souscription.Application;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.SouscriptionMappers;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet ParametresDefinitionAnnuaire.
    /// </summary>
    internal static class ParametresDefinitionAnnuaireMapper
    {
        /// <summary>
        /// Conversion de l'objet de paramètres ParametresDefinirAnnuaire du domaine Vie Client vers le DTO ParametresDefinitionAnnuaire du domaine Souscription.
        /// </summary>
        /// <param name="parametresDefinirAnnuaire">Demande à convertir.</param>
        /// <returns>Demande convertie.</returns>
        public static ParametresDefinitionAnnuaire Convertir(ParametresDefinirAnnuaire parametresDefinirAnnuaire)
        {
            if(parametresDefinirAnnuaire == null)
            {
                return null;
            }
            return new ParametresDefinitionAnnuaire()
            {
                CleTiers = parametresDefinirAnnuaire.CleTiers,
                DiffusionEmail = parametresDefinirAnnuaire.DiffusionEmail,
                DiffusionPrenom = parametresDefinirAnnuaire.DiffusionPrenom,
                DiffusionProfession = parametresDefinirAnnuaire.DiffusionProfession,
                InscriptionAnnuaireInverse = parametresDefinirAnnuaire.InscriptionAnnuaireInverse,
                LimiterDiffusionAdresseVille = parametresDefinirAnnuaire.LimiterDiffusionAdresseVille,
                Profession = ProfessionMapper.Convertir(parametresDefinirAnnuaire.Profession),
                UtilisationMarketing = parametresDefinirAnnuaire.UtilisationMarketing
            };
        }
    }
}