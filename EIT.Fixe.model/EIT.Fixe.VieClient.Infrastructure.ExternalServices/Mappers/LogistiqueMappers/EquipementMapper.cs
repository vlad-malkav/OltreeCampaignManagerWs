﻿namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers
{
    /// <summary>
    /// Méthodes générique de conversion des équipements du domaine Logistique.
    /// </summary>
    internal static class EquipementMapper
    {
        /// <summary>
        /// Conversion d'un équipement du domaine Logistique en équipement du domaine Vie Client.
        /// </summary>
        /// <param name="equipement">Objet équipement du domaine Logistique à convertir.</param>
        /// <returns>Objet équipement du domaine Vie Client.</returns>
        internal static Domain.CommonTypes.DTO.Equipement Convertir(Logistique.Application.Equipement equipement)
        {
            if (equipement == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.Equipement
            {
                Cle = equipement.Cle,
                AdresseMac = equipement.AdresseMac,
                NumeroCarteTv = equipement.NumeroCarteTv,
                NumeroSerie = equipement.NumeroSerie,
                Etat = equipement.Etat
            };
        }
    }
}