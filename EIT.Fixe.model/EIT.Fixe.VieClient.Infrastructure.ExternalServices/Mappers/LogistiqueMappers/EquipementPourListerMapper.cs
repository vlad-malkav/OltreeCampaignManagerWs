﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.LogistiqueMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet EquipementPourLister.
    /// </summary>
    internal static class EquipementPourListerMapper
    {
        /// <summary>
        /// Conversion de l'objet EquipementPourLister de la brique Logistique vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="equipementAConvertir">Equipement à convertir.</param>
        /// <returns>Equipement convertie.</returns>
        public static EquipementPourLister Convertir(this Logistique.Application.EquipementPourLister equipementAConvertir)
        {
            if(equipementAConvertir == null)
            {
                return null;
            }
            return new EquipementPourLister()
            {
                NumeroSerie = equipementAConvertir.NumeroSerie,
                Type = (TypeEquipement)equipementAConvertir.Etat
            };
        }
    }
}