﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ReferentielMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des offres.
    /// </summary>
    internal static class OffrePourDetailMapper
    {
        /// <summary>
        /// Conversion d'un offre du référentiel en offre locale (Vie Client).
        /// </summary>
        /// <param name="offreAConverir">Offre du référentiel à convertir.</param>
        /// <returns>Offre pour détail, dans Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        public static OffrePourDetail Convertir(Referentiel.Application.DTO.Offre offreAConverir)
        {
            if (offreAConverir == null)
            {
                return null;
            }

            return new OffrePourDetail()
            {
                Cle = offreAConverir.Cle,
                Descriptif = offreAConverir.Descriptif,
                MontantPromosIllimitees = offreAConverir.MontantTtcPromosIllimitees,
                MontantPromosLimitees = offreAConverir.MontantTtcPromosLimitees,
                Nom = offreAConverir.Nom,
                PrixCommercialisationTtc = offreAConverir.PrixCommercialisationTtc,
                MontantRemiseAutoTtc = offreAConverir.MontantRemiseAutoTtc,
                LibelleRemiseAuto = offreAConverir.LibelleRemiseAuto,
                MontantRemiseAutoHt = offreAConverir.MontantRemiseAutoHt
            };
        }
    }
}