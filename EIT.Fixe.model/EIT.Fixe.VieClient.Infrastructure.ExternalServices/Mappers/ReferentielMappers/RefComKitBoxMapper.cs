﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers
{
    /// <summary>
    /// Mapper permettant de convertir un objet RefComKitBox du Referentiel en un objet de présentation du domaine.
    /// </summary>
    public static class RefComKitBoxMapper
    {
        /// <summary>
        /// Méthode qui converti un objet RefComKitBox du Referentiel en un objet de présentation du domaine.
        /// </summary>
        /// <param name="refComKitBox">RefComKitBox à convertir.</param>
        /// <returns>Objet RefComKitBox du domaine VieClient.</returns>
        public static RefComKitBox Convertir (Referentiel.Application.DTO.RefComKitBox refComKitBox)
        {
            if (refComKitBox == null)
            {
                return null;
            }

            return new RefComKitBox()
            {
                Cle = refComKitBox.Cle,
                Description = refComKitBox.Descriptif,
                Libelle = refComKitBox.Libelle,
                MontantDepotGarantie = refComKitBox.MontantDepotGarantie
            };
        }
    }
}
