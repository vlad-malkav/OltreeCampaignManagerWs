﻿using System;
using EIT.Fixe.Referentiel.Application.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ReferentielMappers
{
    /// <summary>
    /// Classe de conversion en PromotionPourDetail.
    /// </summary>
    public static class PromotionPourDetailMapper
    {
        public static PromotionPourDetail Convertir(Promotion promotionAConvertir)
        {
            if (promotionAConvertir == null)
            {
                return null;
            }

            return new PromotionPourDetail()
            {

                Cle = promotionAConvertir.Cle,
                CodePromo = promotionAConvertir.CodePromo,
                Descriptif = promotionAConvertir.Descriptif,
                MontantHT = promotionAConvertir.MontantHt,
                MontantTtc = promotionAConvertir.MontantTtc,
                EffetPromotion = promotionAConvertir.EffetPromotion,
                OrdreAffichage = promotionAConvertir.OrdreAffichage,
                DateOuverture = promotionAConvertir.DateOuverture.GetValueOrDefault(),
                DateFermeture = promotionAConvertir.DateFermeture,
                Duree = promotionAConvertir.Duree,
                EstAutomatique = promotionAConvertir.EstAutomatique

            };
        }

        
    }
   
}
