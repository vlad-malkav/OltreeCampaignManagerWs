﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers
{
    /// <summary>
    /// Mapper permettant de convertir un objet RefComSerialisee du Referentiel en un objet de présentation du domaine.
    /// </summary>
    public static class RefComSerialiseeMapper
    {
        /// <summary>
        /// Méthode qui converti un objet RefComSerialisee du Referentiel en un objet de présentation du domaine.
        /// </summary>
        /// <param name="refComSerialisee">RefComSerialisee à convertir.</param>
        /// <returns>Objet RefComSerialisee du domaine VieClient.</returns>
        public static RefComSerialisee Convertir (Referentiel.Application.DTO.RefComSerialisee refComSerialisee)
        {
            if (refComSerialisee == null)
            {
                return null;
            }

            return new RefComSerialisee()
            {
                Cle = refComSerialisee.Cle,
                Libelle = refComSerialisee.Libelle,
                Type = refComSerialisee.TypeRefCom
            };
        }
    }
}
