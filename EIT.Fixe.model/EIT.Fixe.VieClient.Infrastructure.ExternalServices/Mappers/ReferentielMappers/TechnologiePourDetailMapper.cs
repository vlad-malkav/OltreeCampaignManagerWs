﻿using EIT.Fixe.VieClient.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ReferentielMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des technologies de ligne.
    /// </summary>
    internal static class TechnologiePourDetailMapper
    {
        /// <summary>
        /// Conversion d'une technologie du référentiel en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="technologieAConvertir">Technologie à convertir, provenant du référentiel.</param>
        /// <returns>Technologie pour détail, interne au domaine Vie Client.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        public static TechnologiePourDetail Convertir(Referentiel.Application.DTO.Technologie technologieAConvertir)
        {
            if (technologieAConvertir == null)
            {
                return null;
            }

            return new TechnologiePourDetail()
            {
                Cle = technologieAConvertir.Cle,
                Libelle = technologieAConvertir.Libelle
            };
        }
    }
}