﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.ReferentielMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des marques.
    /// </summary>
    internal static class MarqueMapper
    {
        /// <summary>
        /// Conversion d'une marque du référentiel en marque locale (Vie Client).
        /// </summary>
        /// <param name="marqueAConvertir">Marque du référentiel à convertir.</param>
        /// <returns>Marque convertie.</returns>
        public static Marque Convertir(this Referentiel.Application.DTO.Marque marqueAConvertir)
        {
            if (marqueAConvertir == null)
            {
                return null;
            }

            return new Marque()
            {
                CleImprimeCourrierResiliationRetourColis = marqueAConvertir.CleImprimeCourrierResiliationRetourColis.Value,
                TelephoneFixeSc = marqueAConvertir.TelephoneFixeSc,
                HeureFermetureSc = marqueAConvertir.HeureFermetureSc,
                HeureOuvertureSc = marqueAConvertir.HeureOuvertureSc,
                Libelle = marqueAConvertir.Libelle,
                SiteWeb = marqueAConvertir.SiteWeb,
                TelephoneMobileSc = marqueAConvertir.TelephoneMobileSc,
                UrlAssistance = marqueAConvertir.UrlAssistance,
                MentionLegales = marqueAConvertir.MentionLegale
            };
        }
    }
}