﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet Modification.
    /// </summary>
    internal static class ModificationMapper
    {
        /// <summary>
        /// Conversion de l'objet Modification de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="modificationAConvertir">Modification à convertir.</param>
        /// <returns>Modification convertie.</returns>
        public static Modification Convertir(this Options.Application.Interface.Presentation.Modification modificationAConvertir)
        {
            if (modificationAConvertir == null)
            {
                return null;
            }
            return new Modification()
            {
                Canal = modificationAConvertir.Canal,
                DateCreation = modificationAConvertir.DateCreation,
                DateTraitement = modificationAConvertir.DateTraitement,
                EstEnCours = modificationAConvertir.EstEnCours,
                Utilisateur = modificationAConvertir.Utilisateur
            };
        }
    }
}