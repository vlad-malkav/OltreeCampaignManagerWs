﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet Option.
    /// </summary>
    internal static class OptionMapper
    {
        /// <summary>
        /// Conversion de l'objet Option de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="optionAConvertir">Option à convertir.</param>
        /// <returns>Option converti.</returns>
        public static Option Convertir(this Options.Application.Interface.Presentation.Option optionAConvertir)
        {
            if(optionAConvertir == null)
            {
                return null;
            }

            return new Option()
            {
                Cle = optionAConvertir.Cle,
                CleRegroupement = optionAConvertir.CleRegroupement,
                Cout = optionAConvertir.Cout.Convertir(),
                DerniereModification = optionAConvertir.DerniereModification == null ? null : optionAConvertir.DerniereModification.Convertir(),
                EstModifiable = optionAConvertir.EstModifiable,
                EstSouscrite = optionAConvertir.EstSouscrite,
                EstFct = optionAConvertir.EstFCT,
                Libelle = optionAConvertir.Libelle,
                Ordre = optionAConvertir.Ordre,
                Descriptif = optionAConvertir.Description,
                ModeFacturation = optionAConvertir.ModeFacturation.Convertir()
            };
        }

        /// <summary>
        /// Conversion de l'énumération ModeFacturation de la brique Option vers l'énumération ModeFacturation du domaine Vie Client.
        /// </summary>
        /// <param name="modeFacturationAConvertir">Mode de facturation à convertir.</param>
        /// <returns>Mode de facturation converti.</returns>
        public static Domain.CommonTypes.Enumerations.ModeFacturation Convertir(this Options.Application.Interface.Commun.Enum.ModeFacturation? modeFacturationAConvertir)
        {
            if (modeFacturationAConvertir == null)
            {
                return ModeFacturation.NA;
            }
            switch (modeFacturationAConvertir)
            {
                case Options.Application.Interface.Commun.Enum.ModeFacturation.Ponctuel:
                    return Domain.CommonTypes.Enumerations.ModeFacturation.Ponctuel;
                case Options.Application.Interface.Commun.Enum.ModeFacturation.Recurrent:
                    return Domain.CommonTypes.Enumerations.ModeFacturation.Recurrent;
            }
            return Domain.CommonTypes.Enumerations.ModeFacturation.NA;
        }
    }
}