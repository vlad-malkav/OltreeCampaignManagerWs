﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet Categorie.
    /// </summary>
    internal static class CategorieMapper
    {
        /// <summary>
        /// Conversion de l'objet Categorie de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="categorieAConvertir">Catégorie à convertir.</param>
        /// <returns>Catégorie convertie.</returns>
        public static Categorie Convertir(this Options.Application.Interface.Presentation.Categorie categorieAConvertir)
        {
            if(categorieAConvertir == null)
            {
                return null;
            }
            return new Categorie()
            {
                Cle = categorieAConvertir.Cle.Value,
                Libelle = categorieAConvertir.Libelle,
                Ordre = categorieAConvertir.Ordre
            };
        }
    }
}