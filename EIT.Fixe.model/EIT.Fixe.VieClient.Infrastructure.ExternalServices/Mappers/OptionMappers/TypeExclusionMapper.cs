﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'énumération TypeExclusion.
    /// </summary>
    internal static class TypeExclusionMapper
    {
        /// <summary>
        /// Conversion de l'énumération Option de la brique Options vers l'énumération du domaine Vie Client.
        /// </summary>
        /// <param name="typeExclusionAConvertir">Type exclusion à convertir.</param>
        /// <returns>Type exclusion converti.</returns>
        public static TypeExclusion Convertir(this Options.Application.Interface.Commun.Enum.TypeExclusion? typeExclusionAConvertir)
        {
            if(typeExclusionAConvertir == null)
            {
                return TypeExclusion.NA;
            }
            switch (typeExclusionAConvertir)
            {
                case Options.Application.Interface.Commun.Enum.TypeExclusion.UneParmiPlusieurs:
                    return TypeExclusion.UneParmiPlusieursFacultative;
                case Options.Application.Interface.Commun.Enum.TypeExclusion.UneParmiPlusieursObligatoire:
                    return TypeExclusion.UneParmiPlusieursObligatoire;
                default:
                    return TypeExclusion.NA;
            }
        }
    }
}