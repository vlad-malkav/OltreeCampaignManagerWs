﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet Cout.
    /// </summary>
    internal static class CoutMapper
    {
        /// <summary>
        /// Conversion de l'objet Cout de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="coutAConvertir">Coût à convertir.</param>
        /// <returns>Coût converti.</returns>
        public static Cout Convertir(this Options.Application.Interface.Presentation.Cout coutAConvertir)
        {
            if(coutAConvertir == null)
            {
                return null;
            }
            return new Cout()
            {
                MontantHt = coutAConvertir.MontantHT,
                MontantTtc = coutAConvertir.MontantTTC,
                TauxTva = coutAConvertir.TauxTVA
            };
        }
    }
}