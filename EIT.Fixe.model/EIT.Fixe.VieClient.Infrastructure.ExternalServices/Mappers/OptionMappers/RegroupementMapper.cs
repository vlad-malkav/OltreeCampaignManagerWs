﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet Regroupement.
    /// </summary>
    internal static class RegroupementMapper
    {
        /// <summary>
        /// Conversion de l'objet Regroupement de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="regroupementAConvertir">Regroupement à convertir.</param>
        /// <returns>Regroupement converti.</returns>
        public static Regroupement Convertir(this Options.Application.Interface.Presentation.Regroupement regroupementAConvertir)
        {
            if(regroupementAConvertir == null)
            {
                return null;
            }
            return new Regroupement()
            {
                Cle = regroupementAConvertir.Cle.Value,
                CleCategorie = regroupementAConvertir.CleCategorie,
                Libelle = regroupementAConvertir.Libelle,
                Ordre = regroupementAConvertir.Ordre,
                TypeExclusion = regroupementAConvertir.TypeExclusion.Convertir()
            };
        }
    }
}