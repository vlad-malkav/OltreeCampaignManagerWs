﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion des informations de location de box.
    /// </summary>
    internal static class InformationsLocationBoxPourDetailMapper
    {
        /// <summary>
        /// Conversion d'une option de la brique Options en objet interne au domaine Vie Client.
        /// </summary>
        /// <param name="optionAConvertir">Option à convertir.</param>
        /// <returns>Informations location box pour détail, interne au domaine Vie Client.</returns>
        public static InformationsLocationBoxPourDetail Convertir(
            Options.Application.Interface.Presentation.Option optionAConvertir)
        {
            if (optionAConvertir == null)
            {
                return null;
            }

            return new InformationsLocationBoxPourDetail()
            {
                Cle = optionAConvertir.Cle,
                MontantTtc = optionAConvertir.Cout.MontantTTC.HasValue ? optionAConvertir.Cout.MontantTTC.Value : 0
            };
        }
    }
}