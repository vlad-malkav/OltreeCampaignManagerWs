﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Linq;

namespace EIT.Fixe.VieClient.Infrastructure.ExternalServices.Mappers.OptionMappers
{
    /// <summary>
    /// Méthodes génériques de conversion de l'objet ReponseListeOptions.
    /// </summary>
    internal static class ReponseListeOptionsMapper
    {
        /// <summary>
        /// Conversion de l'objet ReponseListeOptions de la brique Options vers l'objet de paramètre du domaine Vie Client.
        /// </summary>
        /// <param name="reponseAConvertir">Réponse à convertir.</param>
        /// <returns>Réponse convertie.</returns>
        public static ReponseListeOptions Convertir(this Options.Application.Interface.Reponse.ReponseListeOptions reponseAConvertir)
        {
            if(reponseAConvertir == null)
            {
                return null;
            }
            return new ReponseListeOptions()
            {
               Categories = reponseAConvertir.Categories.Select(x => x.Convertir()).ToList(),
               Options = reponseAConvertir.Options.Select(x => x.Convertir()).ToList(),
               Regroupements = reponseAConvertir.Regroupements.Select(x => x.Convertir()).ToList()
            };
        }
    }
}