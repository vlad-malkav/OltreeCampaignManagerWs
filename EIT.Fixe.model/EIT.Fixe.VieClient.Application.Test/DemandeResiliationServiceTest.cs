﻿using System;
using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Classe de test du service DemandeResiliation.
    /// </summary>
    [TestFixture]
    public class DemandeResiliationRepositoryTest
    {
        #region Propriétés 

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private Mock<IServicesTechniques> servicesTechniques { get; set; }

        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Mock de l'objet DemandeResiliation. Est renvoyé par les repositories.
        /// </summary>
        private Mock<DemandeResiliation> demandeResiliation { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Clé de demande de résiliation valide.
        /// </summary>
        private long CleDemandeResiliationValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Clé de motif de résiliation valide.
        /// </summary>
        private long CleMotifResiliationValide
        {
            get
            {
                return 10;
            }
        }

        /// <summary>
        /// Clé de mode de retour équipement.
        /// </summary>
        private long CleModeRetourEquipementValide
        {
            get
            {
                return 100;
            }
        }

        /// <summary>
        /// Clé d'adresse installation valide.
        /// </summary>
        private long CleAdresseInstallationValide
        {
            get
            {
                return 1000;
            }
        }

        /// <summary>
        /// Clé de ligne valide.
        /// </summary>
        private long CleLigneValide
        {
            get
            {
                return 10000;
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identiteValide = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserDemandeResiliation();
            this.InitialiserRepositories();
        }

        /// <summary>
        /// Initialise la demande de résiliation.
        /// </summary>
        private void InitialiserDemandeResiliation()
        {
            this.demandeResiliation = new Mock<DemandeResiliation>();
            this.demandeResiliation.Setup(x => x.Cle).Returns(this.CleDemandeResiliationValide);
            this.demandeResiliation.Setup(x => x.CleMotifResiliation).Returns(this.CleMotifResiliationValide);
            this.demandeResiliation.Setup(x => x.CleModeRetourEquipement).Returns(this.CleModeRetourEquipementValide);
            this.demandeResiliation.Setup(x => x.Ligne).Returns(new Ligne(this.identiteValide,
                new DetailLignePourCreation()
                {
                    Cle = this.CleLigneValide,
                    CleOffre = 1,
                    CleTechnologie = 1,
                    CleTiers = 1,
                    ReferenceExterne = "123456789",
                    CleCompteFacturation = 1,
                    CleAdresseInstallation = 1,
                    CleGestionnaireOptions = "1",
                    CleIcn = 1,
                    CleMarque = 1,
                    DateFinEngagement = new DateTime(2018, 12, 31),
                    IdentifiantTransactionOperateur = 1,
                    Numero = "0123456789",
                    NumeroContratOperateur = "0123",
                    Rio = "rio",
                    CleCommandeExpedition = 1,
                    CleKitBox = 1
                },
                this.servicesTechniques.Object,
                new Mock<IServicesExternes>().Object,
                new Mock<IBriquesServicesExternes>().Object,
                new Mock<IRepositories>().Object));
            this.demandeResiliation.Setup(x => x.DateResiliationProgrammee).Returns(DateTime.Today);
        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();

            Mock<DemandeResiliation> demandeResiliation2 = new Mock<DemandeResiliation>();
            demandeResiliation2.Setup(x => x.Cle).Returns(2);

            Mock<IDemandeResiliationRepository> mockDemandeResiliationRepository = new Mock<IDemandeResiliationRepository>();
            mockDemandeResiliationRepository.Setup(x => x.ObtenirDepuisCle(this.CleDemandeResiliationValide)).Returns(this.demandeResiliation.Object);
            mockDemandeResiliationRepository.Setup(x => x.RechercherDemandesResiliationATraiter()).Returns(new List<DemandeResiliation>()
            {
                this.demandeResiliation.Object,
                demandeResiliation2.Object
            });

            Mock<IMotifResiliationRepository> mockMotifResiliationRepository = new Mock<IMotifResiliationRepository>();
            Mock<MotifResiliation> mockMotifResiliation = new Mock<MotifResiliation>();
            mockMotifResiliationRepository.Setup(x => x.ObtenirDepuisCle(this.CleMotifResiliationValide)).Returns(mockMotifResiliation.Object);

            Mock<IModeRetourEquipementRepository> mockModeRetourEquipementRepository = new Mock<IModeRetourEquipementRepository>();
            Mock<ModeRetourEquipement> mockModeRetourEquipement = new Mock<ModeRetourEquipement>();
            mockModeRetourEquipementRepository.Setup(x => x.ObtenirDepuisCle(this.CleModeRetourEquipementValide)).Returns(mockModeRetourEquipement.Object);

            DetailLignePourCreation detailLigne = new DetailLignePourCreation()
            {
                Cle = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                ReferenceExterne = "123456789",
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                DateFinEngagement = new DateTime(2018, 12, 31),
                IdentifiantTransactionOperateur = 1,
                Numero = "0123456789",
                NumeroContratOperateur = "0123",
                Rio = "rio",
                CleCommandeExpedition = 1,
                CleKitBox = 1
            };

            Mock<ILigneRepository> mockLigneRepository = new Mock<ILigneRepository>();
            Ligne ligne = new Ligne(this.identiteValide, detailLigne, this.servicesTechniques.Object, this.servicesExternes.Object, this.briquesExternes.Object, this.repositories.Object);
            mockLigneRepository.Setup(x => x.ObtenirDepuisCle(this.CleLigneValide)).Returns(ligne);

            this.repositories.Setup(x => x.DemandeResiliationRepository).Returns(mockDemandeResiliationRepository.Object);
            this.repositories.Setup(x => x.ModeRetourEquipementRepository).Returns(mockModeRetourEquipementRepository.Object);
            this.repositories.Setup(x => x.LigneRepository).Returns(mockLigneRepository.Object);
            this.repositories.Setup(x => x.MotifResiliationRepository).Returns(mockMotifResiliationRepository.Object);
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();

            Mock<ISouscriptionServiceExterne> mockSouscriptionServiceExterne = new Mock<ISouscriptionServiceExterne>();
            mockSouscriptionServiceExterne.Setup(x => x.ObtenirAdresseInstallationParCleEligibilite(this.identiteValide, this.CleAdresseInstallationValide)).Returns(new Mock<Domain.CommonTypes.DTO.AdresseInstallationPourDetail>().Object);
            this.servicesExternes.Setup(x => x.SouscriptionServiceExterne).Returns(mockSouscriptionServiceExterne.Object);
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();

            Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers adressePrincipale = new Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers()
            {
                CodePostal = "123",
                ComplementIdentification = "123",
                Ville = "Lomme",
                Voie = "13 rue de la Chance",
                EstPrincipale = true
            };
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
            {
                Civilite = Fixe.Domain.CommonTypes.Civilite.M,
                Nom = "Bonheur",
                Prenom = "Gontran",
                ListeAdresses = new List<Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers>() { adressePrincipale }            
            };
            this.briquesExternes.Setup(x => x.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(tiers);        
        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
            this.servicesTechniques.Setup(x => x.GenerateurCles.ObtenirCleLongue<KitBox>()).Returns(1); 
            this.servicesTechniques.Setup(x => x.GenerateurCles.ObtenirCleLongue<GestionnaireDemandeRemises>()).Returns(1);
            this.servicesTechniques.Setup(x => x.GenerateurCles.ObtenirCle<HistoriqueEtatLigne>()).Returns(1);
        }

        #endregion Méthodes d'initialisation et de vérification

        #region Tests de l'initialisation du service

        /// <summary>
        /// Test du constructeur de DemandeResiliationService dans le cas ou l'interface des repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void DemandeResiliationService_RepositoriesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new DemandeResiliationService(null, this.servicesExternes.Object, this.briquesExternes.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de DemandeResiliationService dans le cas ou l'interface des services externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void DemandeResiliationService_ServicesExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new DemandeResiliationService(this.repositories.Object, null, this.briquesExternes.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de DemandeResiliationService dans le cas ou l'interface des briques externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void DemandeResiliationService_BriquesExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de DemandeResiliationService dans le cas ou le repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void DemandeResiliationService_ParametresOK_OK()
        {
            // Act.
            TestDelegate action = () => new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, this.briquesExternes.Object);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de l'initialisation du service

        #region Tests de la méthode AnnulerDemandeResiliation

        /// <summary>
        /// Test de la méthode AnnulerDemandeResiliation dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void AnnulerDemandeResiliation_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.AnnulerDemandeResiliation(null, this.CleDemandeResiliationValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode AnnulerDemandeResiliation dans le cas où la clé de demande de résiliation est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void AnnulerDemandeResiliation_CleDemandeResiliationAZero_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.AnnulerDemandeResiliation(this.identiteValide, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode AnnulerDemandeResiliation dans le cas où la clé de demande de résiliation est négative. Lève une exception.
        /// </summary>
        [Test]
        public void AnnulerDemandeResiliation_CleDemandeResiliationNegative_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.AnnulerDemandeResiliation(this.identiteValide, -123);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode AnnulerDemandeResiliation dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void AnnulerDemandeResiliation_ParametresOK_OK()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            demandeResiliationService.AnnulerDemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide);

            // Assert.
            this.demandeResiliation.Verify(x => x.Annuler(this.identiteValide));
        }

        #endregion Tests de la méthode AnnulerDemandeResiliation

        #region Tests de la méthode ListerDemandesResiliationATraiter

        /// <summary>
        /// Test de la méthode ListerDemandesResiliationATraiter dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ListerDemandesResiliationATraiter_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.ListerDemandesResiliationATraiter(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ListerDemandesResiliationATraiter dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ListerDemandesResiliationATraiter_ParametresOK_OK()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object,  this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            long[] demandesResiliationATraiter = demandeResiliationService.ListerDemandesResiliationATraiter(this.identiteValide);

            // Assert.
            Assert.AreEqual(new long[2] { 1, 2 }, demandesResiliationATraiter);
        }

        #endregion Tests de la méthode ListerDemandesResiliationATraiter

        #region Tests de la méthode ObtenirDetailDemandeResiliationParCle

        /// <summary>
        /// Test de la méthode ObtenirDetailDemandeResiliationParCle dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailDemandeResiliationParCle_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.ObtenirDetailDemandeResiliationParCle(null, this.CleDemandeResiliationValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailDemandeResiliationParCle dans le cas où la clé de demande de résiliation est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailDemandeResiliationParCle_CleDemandeResiliationAZero_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.ObtenirDetailDemandeResiliationParCle(this.identiteValide, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailDemandeResiliationParCle dans le cas où la clé de demande de résiliation est négative. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailDemandeResiliationParCle_CleDemandeResiliationNegative_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.ObtenirDetailDemandeResiliationParCle(this.identiteValide, -123);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailDemandeResiliationParCle dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirDetailDemandeResiliationParCle_ParametresOK_OK()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            DemandeResiliationPourDetail demandeResiliationPourDetail = demandeResiliationService.ObtenirDetailDemandeResiliationParCle(this.identiteValide, this.CleDemandeResiliationValide);

            // Assert.
            Assert.NotNull(demandeResiliationPourDetail);
        }

        #endregion Tests de la méthode ObtenirDetailDemandeResiliationParCle

        #region Tests de la méthode TraiterDemandeResiliationDifferee

        /// <summary>
        /// Test de la méthode TraiterDemandeResiliationDifferee dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void TraiterDemandeResiliationDifferee_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.TraiterDemandeResiliationDifferee(null, this.CleDemandeResiliationValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode TraiterDemandeResiliationDifferee dans le cas où la clé de demande de résiliation est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void TraiterDemandeResiliationDifferee_CleDemandeResiliationAZero_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.TraiterDemandeResiliationDifferee(this.identiteValide, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode AnnulerDemandeResiliation dans le cas où la clé de demande de résiliation est négative. Lève une exception.
        /// </summary>
        [Test]
        public void TraiterDemandeResiliationDifferee_CleDemandeResiliationNegative_LeveException()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            TestDelegate action = () => demandeResiliationService.TraiterDemandeResiliationDifferee(this.identiteValide, -123);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode TraiterDemandeResiliationDifferee dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void TraiterDemandeResiliationDifferee_ParametresOK_OK()
        {
            // Arrange.
            DemandeResiliationService demandeResiliationService = new DemandeResiliationService(this.repositories.Object, this.servicesExternes.Object, this.briquesExternes.Object);

            // Act.
            demandeResiliationService.TraiterDemandeResiliationDifferee(this.identiteValide, this.CleDemandeResiliationValide);

            // Assert.
            this.demandeResiliation.Verify(x => x.Traiter(this.identiteValide));
        }

        #endregion Tests de la méthode TraiterDemandeResiliationDifferee
    }
}
