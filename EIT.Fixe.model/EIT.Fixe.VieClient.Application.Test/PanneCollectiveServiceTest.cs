﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Tests de la classe LigneService
    /// </summary>
    [TestFixture]
    public class PanneCollectiveServiceTest
    {

        private Identite identite;
        private PanneCollective panne;
        private IPanneCollectiveService service;
        private Mock<IServicesTechniques> servicesTechniques;
        private Mock<IRepositories> repositories;
        private Mock<ILigneService> ligneService;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        private long cle;
        private long cleLigne;
        private int dureeValidite;
        private DetailLignePourCreation detailLignePourCreation;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();
            this.InitialiserBriqueServiceExterne();
            this.ligneService = new Mock<ILigneService>();
            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();
            this.servicesExternes = new Mock<IServicesExternes>();
            this.cle = 1;
            this.cleLigne = 2;
            this.dureeValidite = 3;

            this.detailLignePourCreation = new DetailLignePourCreation()
            {
                Cle = this.cle,
                CleCompteFacturation = 1,

                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                CleCommandeExpedition = 1,
                DateFinEngagement = new DateTime(2020, 12, 1),
                Numero = "0102030405",
                NumeroContratOperateur = "NumeroContratOperateur",
                ReferenceExterne = "refext",
                IdentifiantTransactionOperateur = 1,
                Rio = "rio",
                CleKitBox = 1
            };


            // Initialisation de l'entite PanneCollective
            this.panne = new PanneCollective(this.identite, this.cle, DateTime.Now);
            this.InitialiserRepositorie(this.panne);

            this.service = new PanneCollectiveService(this.repositories.Object, this.servicesTechniques.Object, this.ligneService.Object);

        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            IGenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);

            this.servicesTechniques.Setup(t => t.Parametrage.DureeValiditeDonneesPannesCollectives).Returns(5);
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            Ligne entite1 = new Ligne(this.identite, this.detailLignePourCreation, this.servicesTechniques.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            entite1.Numero = "0102030405";
            this.detailLignePourCreation.Cle = 2;
            Ligne entite2 = new Ligne(this.identite, this.detailLignePourCreation, this.servicesTechniques.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            entite2.Numero = "0203040506";
            this.detailLignePourCreation.Cle = 3;
            Ligne entite3 = new Ligne(this.identite, this.detailLignePourCreation, this.servicesTechniques.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            entite3.Numero = "0304050607";
            sourceDonnees.Add(entite1);
            sourceDonnees.Add(entite2);
            sourceDonnees.Add(entite3);
            return sourceDonnees;
        }

        /// <summary>
        /// Initialisation du Repositorie
        /// </summary>
        private void InitialiserRepositorie(PanneCollective entite)
        {
            Mock<IPanneCollectiveRepository> panneRepository = new Mock<IPanneCollectiveRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.PanneCollectiveRepository).Returns(panneRepository.Object);

            this.repositories.Setup(s => s.PanneCollectiveRepository.ListerPannesCollectivesParCleLigne(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<int>())).Returns(new List<PanneCollective>()
            {
                entite
            });

            
            ILigneRepository lignerepository = new LigneRepository(this.CreerSourceDonnees());
            this.repositories.Setup(r => r.LigneRepository).Returns(lignerepository);

            //  Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            //this.repositories.Setup(r => r.LigneRepository).Returns(ligneRepository.Object);

        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
        }

        #region Test Constructeurs
        /// <summary>
        /// Creation du service avec repositories null.
        /// </summary>
        [Test]
        public void ConstruirePanneCollectiveService_RepositoriesNull_LeveException()
        {

            TestDelegate action = () => new PanneCollectiveService(null, this.servicesTechniques.Object, this.ligneService.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation du service avec service technique null.
        /// </summary>
        [Test]
        public void ConstruirePanneCollectiveService_ServicesTechniquesNull_LeveException()
        {

            TestDelegate action = () => new PanneCollectiveService(this.repositories.Object, null, this.ligneService.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation du service avec service ligne null.
        /// </summary>
        [Test]
        public void ConstruirePanneCollectiveService_LigneServiceNull_LeveException()
        {

            TestDelegate action = () => new PanneCollectiveService(this.repositories.Object, this.servicesTechniques.Object, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation du service.
        /// </summary>
        [Test]
        public void ConstruirePanneCollectiveService_ParametresValide_OK()
        {
            TestDelegate action = () => new PanneCollectiveService(this.repositories.Object, this.servicesTechniques.Object, this.ligneService.Object);

            Assert.That(action, Throws.Nothing);
        }

        #endregion Test Constructeurs

        #region Test CreerPanneCollective
        /// <summary>
        /// Créer une panne collective avec identite nulle.
        /// </summary>
        [Test]
        public void CreerPanneCollective_IdentiteNull_LeveException()
        {
            Interface.DTO.InformationsPanneCollectivePourCreation informationsPanneCollective = new Interface.DTO.InformationsPanneCollectivePourCreation()
            {
                CleLigne = 2,
                DateDebut = DateTime.Now
            };
            TestDelegate action = () => service.CreerPanneCollective(null, informationsPanneCollective);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une panne collective avec informations PanneCollective null.
        /// </summary>
        [Test]
        public void CreerPanneCollective_informationsPanneCollectiveNull_LeveException()
        {
            Interface.DTO.InformationsPanneCollectivePourCreation informationsPanneCollective = null;

            TestDelegate action = () => service.CreerPanneCollective(this.identite, informationsPanneCollective);

            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Créer une panne collective avec Paramètres OK.
        /// </summary>
        [Test]
        public void CreerPanneCollective_informationsPanneCollectiveValide_OK()
        {
            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(l => l.Cle).Returns(2);
            ligne.Setup(l => l.ListePannesCollectives).Returns(new List<PanneCollective>());
            Interface.DTO.InformationsPanneCollectivePourCreation informationsPanneCollective = new Interface.DTO.InformationsPanneCollectivePourCreation()
            {
                CleLigne = 2,
                DateDebut = DateTime.Now
            };
            this.ligneService.Setup(c => c.EstLigneExistanteParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(true);
            this.repositories.Setup(s => s.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligne.Object);
            this.ligneService.Setup(x => x.ObtenirLigneParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new LignePourDetail());

            TestDelegate action = () => this.service.CreerPanneCollective(this.identite, informationsPanneCollective);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Verifier la création d'une panne collective avec Paramètres OK.
        /// </summary>
        [Test]
        public void VerifierCreerPanneCollective_informationsPanneCollectiveValide_OK()
        {
            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(l => l.Cle).Returns(2);
            ligne.Setup(l => l.ListePannesCollectives).Returns(new List<PanneCollective>());
            Interface.DTO.InformationsPanneCollectivePourCreation informationsPanneCollective = new Interface.DTO.InformationsPanneCollectivePourCreation()
            {
                CleLigne = 2,
                DateDebut = DateTime.Now
            };
             this.repositories.Setup(s => s.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligne.Object);
            this.ligneService.Setup(x => x.ObtenirLigneParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new LignePourDetail());


            bool resultat = this.service.CreerPanneCollective(this.identite, informationsPanneCollective);


            Assert.AreNotEqual(0, resultat);
            Assert.AreNotEqual(-1, resultat);
            this.repositories.Verify(r => r.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
        }

        /// <summary>
        /// Test de CreerPanneCollective avec levée d'une exception pour une ligne inexistante.
        /// </summary>
        [Test]
        public void CreerPanneCollective_LigneInexistante_Exception()
        {
            Interface.DTO.InformationsPanneCollectivePourCreation informationsPanneCollective = new Interface.DTO.InformationsPanneCollectivePourCreation()
            {
                CleLigne = 9999,
                DateDebut = DateTime.Now               
            };

            TestDelegate action = () => this.service.CreerPanneCollective(this.identite, informationsPanneCollective);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test CreerPanneCollective

        #region Test EstLigneAffecteeParPanneCollective

        /// <summary>
        /// EstLigneAffecteeParPanneCollective avec identite null.
        /// </summary>
        [Test]
        public void EstLigneAffecteeParPanneCollective_IdentiteNull_LeveException()
        {
            TestDelegate action = () => service.EstLigneAffecteeParPanneCollective(null, this.cleLigne);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// EstLigneAffecteeParPanneCollective avec clé de la ligne null.
        /// </summary>
        [Test]
        public void EstLigneAffecteeParPanneCollective_CleLigneNull_LeveException()
        {
            long cleLigne = 0;
            TestDelegate action = () => service.EstLigneAffecteeParPanneCollective(this.identite, cleLigne);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// EstLigneAffecteeParPanneCollective avec clé de la ligne invalide.
        /// </summary>
        [Test]
        public void EstLigneAffecteeParPanneCollective_CleLigneInvalide_LeveException()
        {
            long cleLigneInvalide = -1;
            TestDelegate action = () => service.EstLigneAffecteeParPanneCollective(this.identite, cleLigneInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// EstLigneAffecteeParPanneCollective avec Paramètres OK.
        /// </summary>
        [Test]
        public void EstLigneAffecteeParPanneCollective_ParametresValide_OK()
        {
            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(x => x.Cle).Returns(this.cleLigne);

            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.cleLigne)).Returns(ligne.Object);

            TestDelegate action = () => this.service.EstLigneAffecteeParPanneCollective(this.identite, this.cleLigne);

            Assert.That(action, Throws.Nothing);
        }

       
        
        /// <summary>
        /// Verifier EstLigneAffecteeParPanneCollective avec Paramètres OK.
        /// </summary>
        [Test]
        public void VerifierEstLigneAffecteeParPanneCollective_ParametresValide_OK()
        {
            bool estLigneAffectee = this.service.EstLigneAffecteeParPanneCollective(this.identite, 1);

            Assert.IsTrue(estLigneAffectee);
            this.servicesTechniques.Verify(t => t.Parametrage.DureeValiditeDonneesPannesCollectives);
            this.repositories.Verify(r => r.PanneCollectiveRepository.ListerPannesCollectivesParCleLigne(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<int>()));
        }
        

        /// <summary>
        /// Verifier EstLigneAffecteeParPanneCollective avec clé inexistante.
        /// </summary>
        [Test]
        public void VerifierEstLigneAffecteeParPanneCollective_CleInexistante_exception()
        {
            long cleLigne = 99999;


            // ==> configurer le DataSource : IDataSource CreerSourceDonnees() (voir LigneRepositoryTest)

            
            TestDelegate action = () => this.service.EstLigneAffecteeParPanneCollective(this.identite, cleLigne);

            Assert.Throws<ArgumentException>(action);
        }
        

        #endregion Test EstLigneAffecteeParPanneCollective

        #region Test ListerPannesCollectivesParClesLigne
        /// <summary>
        /// Lister les pannes collectives avec l'identite null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParClesLigne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerPannesCollectivesParCleLigne(null, this.cleLigne, this.dureeValidite);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives avec la cle null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParClesLigne_CleNull_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ListerPannesCollectivesParCleLigne(null, cle, this.dureeValidite);

            Assert.Throws<ArgumentException>(action);
        }
        /// <summary>
        /// Lister les pannes collectives avec la cle invalide.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParClesLigne_CleInvalide_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ListerPannesCollectivesParCleLigne(null, cleInvalide, this.dureeValidite);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives avec la dureeValidite null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParClesLigne_DureeValiditeNull_LeveException()
        {
            int dureeValidite = 0;
            TestDelegate action = () => this.service.ListerPannesCollectivesParCleLigne(null, this.cleLigne, dureeValidite);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParClesLigne_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ListerPannesCollectivesParCleLigne(this.identite, this.cleLigne, this.dureeValidite);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Lister les pannes collectives sans le delegate action.
        /// </summary>
        [Test]
        public void VerifieristerPannesCollectivesParClesLigne_ParametreValide_OK()
        {
            PanneCollectivePourLister[] list = this.service.ListerPannesCollectivesParCleLigne(this.identite, this.cleLigne, this.dureeValidite);

            this.repositories.Verify(c => c.PanneCollectiveRepository.ListerPannesCollectivesParCleLigne(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<int>()));
            Assert.AreEqual(list.Length, 1);
            PanneCollectivePourLister pannes = list[0];
            Assert.AreEqual(pannes.Cle, this.panne.Cle);
            Assert.AreEqual(pannes.DateDebut, this.panne.DateDebut);
           
        }
        #endregion Test ListerPannesCollectivesParClesLigne

    }
}
