﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.Entities;
using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Domain.Gbo;
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Facturation.Domain.CommonTypes.Event;
using EIT.Fixe.Souscription.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Messaging;
using EIT.Tiers.Domain.SharedKernel.Event.Tiers;
using Moq;
using NrjMobile.InterfaceOperateur.Evenements.Fixe;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Tests de la classe LigneService.
    /// </summary>
    [TestFixture]
    public class LigneServiceTest
    {
        #region Propriétés

        private long cle;
        private long cleLigne;
        private int clePromo;
        private long cleDemandeRemisePromotion;
        private string numero;
        private string referenceExterne;
        private string referenceExterneInvalide;
        private Ligne ligne;
        private CompteClientPourDetail compte;
        private DemandesRemisesLignePourExpiration demande;
        private Identite identite;
        private ILigneService service;
        private InformationsLignePourCreationEtActivation informationLigne;
        private DossierGBOPourCreation informationsDossierGBO;
        private TiersAssociePourDetail tiersAssociePourDetail;
        private HistoriquePourCreation historiqueDossierGBO;
        private LigneCompteClientMobilePourLister ligneCompteClientMobilePourLister;
        private DetailLigneFixeTitulairePourVue360 detailLigneFixeTitulairePourVue360;
        private CompteClientMobilePourLister compteClientMobilePourLister;
        private Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiersPourDetail;
        private Marque marque;
        private DocumentLigne[] documentsLigne;
        private HistoriqueReinitialiserLogin historiqueReinitialiserLogin;
        private PromotionPourDetail promotions;
        private ReponseValidationOtp reponseValidationOtp;
        private ReponseModificationMotDePasse reponseModificationMotDePasse;

        private Mock<IServicesExternes> servicesExternes;
        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IRepositories> repositories;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        Mock<Ligne> ligneMock;
        Mock<GestionnaireDemandeRemises> gestionnaireMock;
        private long[] tableauCle;


        private Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository;

        /// <summary>
        /// Clé de demande de résiliation valide.
        /// </summary>
        private long CleDemandeResiliationValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Clé de motif de résiliation valide.
        /// </summary>
        private long CleMotifResiliationValide
        {
            get
            {
                return 10;
            }
        }

        /// <summary>
        /// Clé de mode de retour équipement.
        /// </summary>
        private long CleModeRetourEquipementValide
        {
            get
            {
                return 100;
            }
        }

        /// <summary>
        /// Clé d'adresse installation valide.
        /// </summary>
        private long CleAdresseInstallationValide
        {
            get
            {
                return 1000;
            }
        }

        /// <summary>
        /// Clé de ligne valide.
        /// </summary>
        private long CleLigneValide
        {
            get
            {
                return 10000;
            }
        }

        /// <summary>
        /// Clé tiers valide.
        /// </summary>
        private long CleTiersValide
        {
            get
            {
                return 100000;
            }
        }

        /// <summary>
        /// Clé de contrat valide.
        /// </summary>
        private string CleContratValide
        {
            get
            {
                return "CleContratValide";
            }
        }

        /// <summary>
        /// Retourne une date de reception courrier ar valide.
        /// </summary>
        private DateTime DateReceptionCourrierArValide
        {
            get
            {
                return new DateTime(2018, 2, 5);
            }
        }

        /// <summary>
        /// Retourne une date de résiliation programmée valide.
        /// </summary>
        private DateTime DateResiliationProgrammeeValide
        {
            get
            {
                return DateTime.Today.AddMonths(1);
            }
        }

        /// <summary>
        /// Retourne un email valide
        /// </summary>
        private string EmailValide
        {
            get
            {
                return "bonjour@mail.com";
            }
        }

        /// <summary>
        /// Retourne une valeur de seuil de surconsommation voix
        /// </summary>
        private decimal SeuilSurconsommationVoix
        {
            get
            {
                return 12.5M;
            }
        }

        /// <summary>
        /// Retourne une valeur de seuil de surconsommation VOD
        /// </summary>
        private decimal SeuilSurconsommationVod
        {
            get
            {
                return 5.3M;
            }
        }


        private int CleDossierGboValide => 42;
        private int CleDossierGboSansLigne => 666;

        #endregion Propriétés

        #region Initialisateurs

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite()
            {
                Memoid = "MemoId",
                ApplicationAppelante = "EIT.Fixe.VieClient",
                Canal = Canal.NonDefini
            };

            this.tiersPourDetail = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
            {
                Cle = 1,
                CiviliteEnum = Fixe.Domain.CommonTypes.Civilite.M,
                Nom = "Nom",
                Prenom = "Prenom",
                NumeroDepartementNaissance = "50",
                DateNaissance = new DateTime(2010, 11, 12),
                NumeroMobileDeContact = "0123456789",
                NumeroFixeDeContact = "0123456789",
                EmailContact = "test@test.fr",
                ListeAdresses = new List<AdresseTiers>()
                {
                    new AdresseTiers()
                    {
                        CodePostal = "CodePostal",
                        ComplementIdentification = "ComplementIdentification",
                        Ville = "Ville",
                        Voie = "Voie",
                        EstPrincipale = true
                    }
                }
            };

            this.marque = new Marque()
            {
                SiteWeb = "SiteWeb"
            };

            this.InitialiserServiceExterne();
            this.InitialiserServiceTechnique();
            this.InitialiserBriqueServiceExterne();

            this.cle = 1;
            this.cleLigne = 2;
            this.clePromo = 3;
            this.cleDemandeRemisePromotion = 5;
            this.numero = "0123456789";
            this.referenceExterne = "123456789";
            this.referenceExterneInvalide = "referenceInvalide";
            DetailLignePourCreation detailLigne = new DetailLignePourCreation()
            {
                Cle = 1,
                CleOffre = this.clePromo,
                CleTechnologie = 1,
                CleTiers = this.CleTiersValide,
                ReferenceExterne = "123456789",
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                DateFinEngagement = new DateTime(2018, 12, 31),
                IdentifiantTransactionOperateur = 1,
                Numero = "0123456789",
                NumeroContratOperateur = "0123",
                Rio = "rio",
                ListeDemandeRemisePourCreation = new List<DemandeRemisePourCreation>()
                {
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemiseSurForfait,
                        DetailRemiseForfaitPourCreation = new DemandeRemiseForfaitPourCreation()
                        {
                            MontantHT = 1
                        },

                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Descriptif = "RemiseSurForfait"
                        }
                    },
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurOffre,
                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Cle = 1,
                            MontantHT = 1,
                            Duree = 1,
                            Descriptif = "RemisePromotionSurOffre"
                        }
                    },
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurFrais,
                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Cle = 1,
                            MontantHT = 1,
                            Duree = 1,
                            Descriptif = "RemisePromotionSurFrais"
                        }
                    }
                },
                CleKitBox = 1,
                CleCommandeExpedition = 1
            };

            CommandePourLister commande = new CommandePourLister()
            {
                Cle = 1,
                Numero = "numero",
                TypeCommande = TypeCommande.Souscription,
                Date = new DateTime(2018, 10, 21),
                Etat = EtatCommande.EnCours,
                EstSyntheseOsafAccessible = true

            };
            this.informationLigne = new InformationsLignePourCreationEtActivation()
            {
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                CleCommandeExpedition = 1,
                DateFinEngagement = new DateTime(2018, 12, 31),
                Numero = "0123456789",
                NumeroContratOperateur = "0123",
                ReferenceExterne = "123456789",
                IdentifiantTransactionOperateur = 1,
                Rio = "rio",
                ListeClesPromotions = new List<long>(),
                CleKitBox = 1
            };

            this.informationsDossierGBO = new DossierGBOPourCreation()
            {
                AgentProprietaire = "agent",
                CleActivite = 3,
                Delai = 1,
                Commentaire = "Commentaire",
                EstConfidentiel = true

            };

            this.historiqueDossierGBO = new Interface.DTO.HistoriquePourCreation()
            {
                CleOrigine = 1,
                CleMetier1 = 1,
                CleMetier2 = 1,
                Commentaire = "Commentaire"
            };

            this.compte = new CompteClientPourDetail()
            {
                Cle = 1,
                Numero = this.numero,
                ListeLignes = new List<LigneMobilePourLister>()
                {

                }
                //Titulaire = new Domain.CommonTypes.DTO.TiersPourDetail()
                //{
                //    Civilite = "Civilité"

                //}
            };

            this.tiersAssociePourDetail = new TiersAssociePourDetail()
            {
                CleTiers = 1,
                EstAssocie = true
            };

            this.ligneCompteClientMobilePourLister = new LigneCompteClientMobilePourLister()
            {
                Cle = 1,
                EstReseauFull = true,
                EstSyntheseCrmMobileAccessible = true,
                NiveauAccessEspaceClientMobile = "niveau d'accès à l'espace mobile du client",
                Numero = "Numero",
                Offre = "Offre",
                ScoreChurn = 1,
                SeuilSurconsommation = 1,
                Statut = EtatLigneMobile.Active,
                Utilisateur = "Utilisateur"
            };

            this.detailLigneFixeTitulairePourVue360 = new DetailLigneFixeTitulairePourVue360()
            {
                //AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                CleLigne = 1,
                EstReinitialisationCodeConfidentielPossible = true,
                Numero = "Numero",
                SeuilSurconsommationTelephonie = this.SeuilSurconsommationVoix,
                SeuilSurconsommationVod = SeuilSurconsommationVod,
                Etat = EtatLigne.Activee,
                Technologie = "TechnologiePourDetail"
            };

            this.compteClientMobilePourLister = new CompteClientMobilePourLister()
            {
                Cle = 1,
                AccesSpecifiqueEspaceClient = true,
                LoginGestionnaire = "LoginGestionnaire",
                Numero = "Numero",
                Titulaire = "Titulaire",
                ListeLignes = new List<LigneCompteClientMobilePourLister>(),
                NombreLignes = 1
            };

            this.tiersPourDetail = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
            {
                Cle = 1,
                CiviliteEnum = Fixe.Domain.CommonTypes.Civilite.M,
                Nom = "Nom",
                Prenom = "Prenom",
                NumeroDepartementNaissance = "50",
                DateNaissance = new DateTime(2010, 11, 12),
                NumeroMobileDeContact = "0123456789",
                NumeroFixeDeContact = "0123456789",
                EmailContact = "test@test.fr",
                ListeAdresses = new List<AdresseTiers>()
                {
                    new AdresseTiers()
                    {
                        CodePostal = "CodePostal",
                        ComplementIdentification = "ComplementIdentification",
                        Ville = "Ville",
                        Voie = "Voie",
                        EstPrincipale = true
                    }
                }
            };

            this.marque = new Marque()
            {
                SiteWeb = "SiteWeb"
            };

            Mock<DocumentLigne> doc = new Mock<DocumentLigne>();
            doc.Setup(d => d.Libelle).Returns("Libelle");
            doc.Setup(d => d.RefDoc).Returns("RefDoc");
            this.documentsLigne = new DocumentLigne[] { doc.Object };

            this.promotions = new PromotionPourDetail()
            {
                Cle = 1,
                Descriptif = "Descriptif",
                MontantTtc = 12,
                Duree = 30
            };



            this.demande = new DemandesRemisesLignePourExpiration()
            {
                CleLigne = 1,
                ListeClesDemandeRemise = new List<long>() { 1, 2, 3 }

            };

            this.InitialiserRepositories();
            ParametreHistoriqueReinitialiserLoginPourCreation param = new ParametreHistoriqueReinitialiserLoginPourCreation()
            {
                CanalDemande = "CanalDemande",
                Cle = 1,
                CleLigne = 1,
                Destinataire = "Destinataire",
                Identifiant = "Identifiant",
                ModeEnvoi = CanalCommunication.Email
            };
            this.historiqueReinitialiserLogin = new HistoriqueReinitialiserLogin(this.identite, param);

            // Initialisation de l'entite Ligne.
            ligneMock = new Mock<Ligne>();
            this.ligne = new Ligne(this.identite, detailLigne, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            ligneMock.SetReturnsDefault(ligne);
            gestionnaireMock = new Mock<GestionnaireDemandeRemises>();
            gestionnaireMock.Setup(g => g.CreerEtActiverDemandeRemisePromotion(identite, It.IsAny<DemandeRemisePourCreation>(), this.cleLigne, detailLigne.CleOffre));
            gestionnaireMock.Setup(g => g.ResilierDemandeRemiseParCle(identite, It.IsAny<long>(), this.cleLigne, It.IsAny<int>()));
            gestionnaireMock.Setup(g => g.ExpirerDemandeRemiseParCle(It.IsAny<Identite>(), It.IsAny<long>()));

            ligneMock.Setup(l => l.GestionnaireDemandeRemises).Returns(gestionnaireMock.Object);

            this.InitialiserRepositories(this.ligne);
            this.tableauCle = new long[] { 1 };
            this.service = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<Domain.ServiceExterne.IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<Domain.ServiceExterne.IHistoriqueServiceExterne>();
            Mock<Domain.ServiceExterne.IReferentielServiceExterne> referentielService = new Mock<Domain.ServiceExterne.IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();
            Mock<ILogistiqueServiceExterne> logistiqueServiceExterne = new Mock<ILogistiqueServiceExterne>();
            Mock<IFacturationServiceExterne> facturationServiceExterne = new Mock<IFacturationServiceExterne>();
            Mock<IGboServiceExterne> gboServiceExterne = new Mock<IGboServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
            this.servicesExternes.Setup(s => s.LogistiqueServiceExterne).Returns(logistiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.FacturationServiceExterne).Returns(facturationServiceExterne.Object);
            this.servicesExternes.Setup(s => s.GboServiceExterne).Returns(gboServiceExterne.Object);

            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>())).Returns(new CommandeSouscriptionPourDetail()
            {
                Cle = 1,

                DateCreation = new DateTime(2018, 12, 31),

                Numero = "0123456789",

            });
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new Domain.CommonTypes.DTO.AdresseInstallationPourDetail()
            {
                Cle = 1,
                CodePostal = "59000",
                Numero = "11",
                Rue = "test",
                Ville = "test"
            });

            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne.CreerHistoriqueAppel(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.HistoriqueAppelPourCreation>())).Returns(1);
            this.servicesExternes.Setup(l => l.LogistiqueServiceExterne.ObtenirCommandeExpeditionParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new List<CommandeExpeditionReferenceCommercialePourLister>());

            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne.CreerHistoriqueAppel(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.HistoriqueAppelPourCreation>())).Returns(1);

            HistoriquePourLister[] listeHistoriquePourLister = new HistoriquePourLister[] { new HistoriquePourLister() { } };
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne.RechercherHistoriquesParReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(listeHistoriquePourLister);



            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new TechnologiePourDetail()
            {
                Libelle = "technologie"
            });

            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new TechnologiePourDetail()
            {
                Libelle = "technologie"
            });

            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new OffrePourDetail()
            {
                Cle = 1,
                Descriptif = "Descriptif",
                MontantPromosIllimitees = 1,
                MontantPromosLimitees = 1,
                MontantRemiseAutoTtc = 1,
                Nom = "Nom",
                PrixCommercialisationTtc = 1,
                MontantRemiseAutoHt = 55
            });
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                Cle = 1,
                Descriptif = "Descriptif",
                MontantTtc = 12,
                Duree = 30,
                EffetPromotion = Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurOffre

            });
            this.servicesExternes.Setup(x => x.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<long>()));

            this.servicesExternes.Setup(x => x.GboServiceExterne.CreerHistoriqueDossierGboLigne(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>())).Returns(1);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.RechercherPromotionsDepuisListeCles(It.IsAny<Identite>(), It.IsAny<int[]>()))
                .Returns(new PromotionPourDetail[]
                {
                    new PromotionPourDetail()
                    {
                        EffetPromotion = Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurOffre,
                        Descriptif = "test"
                    }
                });

            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.RechercherPromotionsDepuisListeClesEtCleOffre(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int[]>()))
              .Returns(new PromotionPourDetail[]
              {
                    new PromotionPourDetail()
                    {
                        EffetPromotion = Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurOffre,
                        Descriptif = "test"
                    }
              });

            this.servicesExternes.Setup(l => l.ReferentielServiceExterne.TesterEligibiliteCodePromo(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(true);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(this.marque);


            this.servicesExternes.Setup(c => c.GboServiceExterne.ListerClesDossiersDepuisReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>())).Returns(new List<int>() { 1, 2, 3 });


            // service externe SAV            
            List<long> listeClesSavEquipement = new List<long> { 1 };
            this.servicesExternes.Setup(x => x.SavServiceExterne.ListerClesSavEquipementParReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>())).Returns(listeClesSavEquipement);

            // service externe SAV Equipement
            string numeroRetourColisSavEquipement = "123456789";
            this.servicesExternes.Setup(x => x.SavEquipementServiceExterne.ObtenirNumeroRetourColisDepuisCleSavEquipement(It.IsAny<Identite>(), It.IsAny<long>())).Returns(numeroRetourColisSavEquipement);

            // service externe Facturation
            InformationsSeuilsSurconsommation infoSeuilsSurconsommation = new InformationsSeuilsSurconsommation() { SeuilSurconsommationTelephonie = this.SeuilSurconsommationVoix, SeuilSurconsommationVod = this.SeuilSurconsommationVod };
            this.servicesExternes.Setup(x=>x.FacturationServiceExterne.ObtenirInformationsSeuilsSurconsommationParReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>())).Returns(infoSeuilsSurconsommation);

        }

        /// <summary>
        /// Initialisation du serviceTechniques.
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IGenerateurSequences> generateurSequence = new Mock<IGenerateurSequences>();
            generateurSequence.Setup(x => x.ObtenirEntier(It.IsAny<string>())).Returns(1);
            Mock<Domain.ServiceExterne.IParametrage> parametrage = new Mock<Domain.ServiceExterne.IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(x => x.MessagingSystem).Returns(new Mock<IMessagingSystem>().Object);
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.serviceTechnique.Setup(s => s.GenerateurSequences).Returns(generateurSequence.Object);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
            this.serviceTechnique.Setup(t => t.Parametrage.NombreHistoriquesFicheSyntheseLigne).Returns(3);
            this.serviceTechnique.Setup(t => t.Parametrage.CleMotifResiliationImpayes).Returns(this.CleMotifResiliationValide);


            this.serviceTechnique.Setup(t => t.GenerateurCles.ObtenirCleLongue<Entity>()).Returns(2);
            this.serviceTechnique.Setup(t => t.GenerateurCles.ObtenirCle<Entity>()).Returns(1);
            this.serviceTechnique.Setup(t => t.Parametrage.CleMotifResiliationPortabiliteSortante).Returns(this.CleMotifResiliationValide);
            this.serviceTechnique.Setup(x => x.MessagingSystem.Publish(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ModifierPreferencesDeContactTiersEvent>()));
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();
            Mock<IOptionsServiceExterne> optionsServiceExterne = new Mock<IOptionsServiceExterne>();
            Mock<IInterfaceOperateurServiceExterne> interfaceOperateurServiceExterne = new Mock<IInterfaceOperateurServiceExterne>();
            Mock<ISfrFixeCompteTvServiceExterne> sfrFixeCompteTvServiceExterne = new Mock<ISfrFixeCompteTvServiceExterne>();

            Mock<ICommunicationClientServiceExterne> communicationClientService = new Mock<ICommunicationClientServiceExterne>();

            Mock<IBriqueIcnServiceExterne> icnServiceExterne = new Mock<IBriqueIcnServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.CommunicationClientServiceExterne).Returns(communicationClientService.Object);
            this.briquesServicesExterne.Setup(s => s.OptionsServiceExterne).Returns(optionsServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.InterfaceOperateurServiceExterne).Returns(interfaceOperateurServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.SfrFixeCompteTvServiceExterne).Returns(sfrFixeCompteTvServiceExterne.Object);
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new Fixe.Domain.Gbo.ReponseCreationDossierGbo { CleDossierGbo = 1, CleHistoriqueAssociationDossierGboLigne = 1 });

            // Setup des méthodes des différents services externes.
            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne.ObtenirCompteClientParCle(identite, It.IsAny<int>())).Returns(new CompteClientPourDetail()
            {
                Cle = 1,
                ListeLignes = new List<LigneMobilePourLister>(),
                Numero = "0123456789",
                Titulaire = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
                {
                    Nom = "Anne",
                    Prenom = "Onyme"
                }
            });
            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne.ObtenirCompteClientParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new CompteClientPourDetail()
            {
                Cle = 1,
                Numero = "0102030405",
                Titulaire = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
                {
                    Nom = "Anne",
                    Prenom = "Onyme"
                },
                ListeLignes = new List<LigneMobilePourLister>()
                {
                    new LigneMobilePourLister()
                    {
                        Cle = 1,
                        ScoreChurn = 1,
                        Statut =EtatLigneMobile.Active,
                        Numero = "0102030405",
                        LibelleOffre = "offre"
                    }
                }
            });

            this.briquesServicesExterne.Setup(s => s.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            List<AssociationHistoriqueDossierGboPourLister> listeAssociationHistorique = new List<AssociationHistoriqueDossierGboPourLister>()
            {
                new AssociationHistoriqueDossierGboPourLister (1 , 1 , new HistoriqueDossierGboPourDetail(1,1,"reference",DateTime.Now),DateTime.Now)

            };


            this.servicesExternes.Setup(s => s.GboServiceExterne.ListerAssociationsHistoriquesDossiersGboParListeClesDossiersGbo(It.IsAny<Identite>(), It.IsAny<int[]>())).Returns(listeAssociationHistorique.ToArray());
            this.servicesExternes.Setup(s => s.GboServiceExterne.ListerClesDossiersDepuisReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>())).Returns(new List<int>() { 1 });

            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne.ObtenirSeuilParCleLigne(It.IsAny<Identite>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ObtenirLoginLigneParCleLigne(It.IsAny<Identite>(), It.IsAny<int>())).Returns("login");

            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(this.tiersPourDetail);
            this.briquesServicesExterne.Setup(s => s.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(It.IsAny<Identite>(), It.IsAny<string>())).Returns(new Domain.CommonTypes.DTO.InformationsLocationBoxPourDetail()
            {
                Cle = 1,
                MontantTtc = 50
            });
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne.ObtenirLoginSfcParCleTiers(It.IsAny<Identite>(), It.IsAny<long>())).Returns("test@test.fr");
            this.briquesServicesExterne.Setup(s => s.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(It.IsAny<Identite>(), It.IsAny<string>())).Returns(new Domain.CommonTypes.DTO.InformationsLocationBoxPourDetail()
            {
                Cle = 1,
                MontantTtc = 1
            });

            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne.ObtenirCleTiersMobileParCleTiersFixe(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new TiersAssociePourDetail()
            {
                CleTiers = 1,
                EstAssocie = true
            });

            string loginSfc = "test@test.fr";
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne.ObtenirLoginSfcParCleTiers(It.IsAny<Identite>(), It.IsAny<long>())).Returns(loginSfc);

            this.briquesServicesExterne.Setup(c => c.AuthentificationServiceExterne.ObtenirLoginCcParCleCompteClient(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new InformationsLoginCompteClient()
            {
                AAccesSpecifiqueEspaceClientMobile = true,
                LoginGestionnaire = "login"
            });

            //this.briquesServicesExterne.Setup(c => c.LoginServiceExterne.ObtenirLoginCcParCleCompteClient(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new InformationsLoginCompteClient()
            //{
            //    AAccesSpecifiqueEspaceClientMobile = true,
            //    LoginGestionnaire = "login"
            //});

            Fixe.Domain.Gbo.DossierGboPourLister[] listeDossier = new Fixe.Domain.Gbo.DossierGboPourLister[] { new Fixe.Domain.Gbo.DossierGboPourLister() };
            this.briquesServicesExterne.Setup(c => c.BriqueGboServiceExterne.RechercherDossiersParListeClesDossiers(It.IsAny<Identite>(), It.IsAny<List<int>>())).Returns(listeDossier);


            this.briquesServicesExterne.Setup(s => s.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementOptions(It.IsAny<Identite>(), It.IsAny<ParametresEmailConfirmerChangementOptions>()));
            this.briquesServicesExterne.Setup(s => s.CommunicationClientServiceExterne.EnvoyerSmsConfirmationRio(It.IsAny<Identite>(), It.IsAny<ParametresSmsRio>()));

            ReponseListeOptions reponseListeOptions = new ReponseListeOptions()
            {
                Categories = new List<Categorie>(),
                Options = new List<Option>(),
                Regroupements = new List<Regroupement>()
            };


            this.reponseValidationOtp = new ReponseValidationOtp()
            {
                EstValide = true,
                MessageErreur = "Erreur"
            };

            this.reponseModificationMotDePasse = new ReponseModificationMotDePasse()
            {
                CodeErreur = 1,
                MessageErreur = "MessageErreur",
                EstModifie = true
            };



            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ValiderOtp(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>())).Returns(this.reponseValidationOtp);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ValiderCguFixe(It.IsAny<Identite>(), It.IsAny<string>()));
            this.briquesServicesExterne.Setup(s => s.SfrFixeCompteTvServiceExterne.ModifierMotDePasseMyPartnerTv(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>()));


            this.briquesServicesExterne.Setup(s => s.OptionsServiceExterne.RechercherOptionsParCleGestionnaire(identite, It.IsAny<string>(), It.IsAny<int[]>())).Returns(reponseListeOptions);
            this.briquesServicesExterne.Setup(s => s.SfrFixeCompteTvServiceExterne.Debloquer(It.IsAny<Identite>(), this.referenceExterne));


            // Service Externe ICN
            Icn icn = new Icn()
            {
                TiersBanque = "Code01",
                TiersBureau = "Code02",
                TiersCaisse = "Code03"
            };
            this.briquesServicesExterne.Setup(s => s.IcnServiceExterne.RechercherIcnParCle(It.IsAny<int>())).Returns(icn);


        }

        /// <summary>
        /// Initialisation du Repositories.
        /// </summary>
        private void InitialiserRepositories(Ligne ligne)
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();
            Mock<IDemandeRemiseRepository> demandeRemiseRepository = new Mock<IDemandeRemiseRepository>();
            Mock<IMotifResiliationRepository> motifResiliationRepository = new Mock<IMotifResiliationRepository>();
            Mock<IDocumentLigneRepository> documentLigneRepository = new Mock<IDocumentLigneRepository>();
            Mock<IHistoriqueReinitialiserLoginRepository> historiqueReinitialiserLoginRepository = new Mock<IHistoriqueReinitialiserLoginRepository>();
            Mock<IHistoriqueDossierGboLigneRepository> historiqueDossierGboLigneRepository = new Mock<IHistoriqueDossierGboLigneRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);
            this.repositories.Setup(s => s.MotifResiliationRepository).Returns(motifResiliationRepository.Object);
            this.repositories.Setup(s => s.DocumentLigneRepository).Returns(documentLigneRepository.Object);
            this.repositories.Setup(x => x.HistoriqueReinitialiserLoginRepository).Returns(historiqueReinitialiserLoginRepository.Object);
            this.repositories.Setup(s => s.DemandeRemiseRepository).Returns(demandeRemiseRepository.Object);
            this.repositories.Setup(repos => repos.HistoriqueDossierGboLigneRepository).Returns(historiqueDossierGboLigneRepository.Object);

            // Setup des méthodes du repository
            this.repositories.Setup(mock => mock.LigneRepository.AjouterLigne(It.IsAny<Ligne>())).Callback<Ligne>(lignetemp => this.ligne = lignetemp);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirReferenceExterneDepuisCle(It.IsAny<long>())).Returns("123456");
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisNumero(It.IsAny<string>())).Returns(this.ligne);
            this.repositories.Setup(s => s.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisNumero(It.IsAny<string>())).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirReferenceExterneDepuisCle(this.cle)).Returns(this.referenceExterne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(this.cle)).Returns(this.ligne);

            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirReferenceExterneDepuisCle(It.IsAny<long>())).Returns("123456");
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisNumero(It.IsAny<string>())).Returns(this.ligne);

            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCleTiers(It.IsAny<long>())).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisReferenceExterne(this.referenceExterne)).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.RechercherParReferenceExterne(this.referenceExterne)).Returns(this.ligne);
            this.repositories.Setup(mock => mock.LigneRepository.RechercherParReferenceExterne(this.referenceExterneInvalide)).Returns<Ligne>(null);
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(this.ligne);

            List<int> listeCles = new List<int>() { 1, 2, 3 };
            this.repositories.Setup(mock => mock.MotifResiliationRepository.ListerMotifsResiliation()).Returns(new List<MotifResiliation>());

            this.repositories.Setup(mock => mock.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliationValide)).Returns(new Mock<MotifResiliation>().Object);

            this.repositories.Setup(mock => mock.DocumentLigneRepository.Lister()).Returns(this.documentsLigne);

            Dictionary<long, List<long>> dictionnaire = new Dictionary<long, List<long>>();
            dictionnaire.Add(1, new List<long>() { 1, 2 });
            dictionnaire.Add(2, new List<long>() { 1, 2 });
            this.repositories.Setup(mock => mock.DemandeRemiseRepository.ListerPromotionsAExpirer()).Returns(dictionnaire);

            this.repositories.Setup(mock => mock.HistoriqueReinitialiserLoginRepository.Ajouter(It.IsAny<HistoriqueReinitialiserLogin>())).Callback<HistoriqueReinitialiserLogin>(histotemp => this.historiqueReinitialiserLogin = histotemp);

            this.repositories
                .Setup(repos =>repos.HistoriqueDossierGboLigneRepository.RechercherParCleDossier(this.CleDossierGboValide))
                .Returns(new HistoriqueDossierGboLigne(this.identite, 1L, this.referenceExterne, this.CleDossierGboValide));
            this.repositories
                .Setup(repos =>repos.HistoriqueDossierGboLigneRepository.RechercherParCleDossier(this.CleDossierGboSansLigne))
                .Returns(new HistoriqueDossierGboLigne(this.identite, 2L, this.referenceExterneInvalide, this.CleDossierGboSansLigne));
        }


        /// <summary>
        /// Initialisation du Repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();
            Mock<IMotifResiliationRepository> motifResiliationRepository = new Mock<IMotifResiliationRepository>();

            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();
            List<ModeRetourEquipement> listeModeRetourEquipement = new List<ModeRetourEquipement>()
            {
                new ModeRetourEquipement()
                {
                    Cle = 1,
                    EstCocheParDefaut =true
                }
            };

            Mock<MotifResiliation> motifResiliation = new Mock<MotifResiliation>();
            motifResiliation.Setup(x => x.DelaiResiliation).Returns(50);
            motifResiliation.Setup(x => x.ListeModeRetourEquipement).Returns(listeModeRetourEquipement);
            motifResiliationRepository.Setup(x => x.ObtenirDepuisCle(It.IsAny<long>())).Returns(motifResiliation.Object);

            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(x => x.Cle).Returns(1);
            ligne.Setup(x => x.ReferenceExterne).Returns("referenceexterne");
            ligneRepository.Setup(x => x.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(ligne.Object);

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);
            this.repositories.Setup(s => s.MotifResiliationRepository).Returns(motifResiliationRepository.Object);
        }

        #endregion Initialisateurs

        #region Constructeur

        /// <summary>
        /// Création du service LigneService sans erreur.
        /// </summary>
        [Test]
        public void ConstruireLigneService_ParametresValides_OK()
        {

            // Arrange

            // Act
            TestDelegate action = () => new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Assert
            Assert.That(action, Throws.Nothing);
        }


        /// <summary>
        /// Création du service LigneService avec l'interface brique services externe null.
        /// </summary>
        [Test]
        public void ConstruireLigneService_BriqueServicesExterneNull_LeveException()
        {
            TestDelegate action = () => new LigneService(null, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Création du service LigneService avec l'interface services externe null.
        /// </summary>
        [Test]
        public void ConstruireLigneService_ServicesExternesNull_LeveException()
        {

            // Arrange

            // Act
            TestDelegate action = () => new LigneService(this.briquesServicesExterne.Object, null, this.repositories.Object, this.serviceTechnique.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Création du service LigneService avec l'interface de repositories null.
        /// </summary>
        [Test]
        public void ConstruireLigneService_RepositoriesNull_LeveException()
        {

            // Arrange

            // Act
            TestDelegate action = () => new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, null, this.serviceTechnique.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création du service LigneService avec l'interface du service technique null.
        /// </summary>
        [Test]
        public void ConstruireLigneService_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, null);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Constructeur


        #region Test ListerLignesCompteClientMobileParCle

        /// <summary>
        /// Test de ListerLignesCompteClientMobileParCle avec les paramètres valides.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_ParametreValides_OK()
        {
            // Act
            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ListerLignesCompteClientMobileParCle avec identité null.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(null, this.cle);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ListerLignesCompteClientMobileParCle avec informationLigne null.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_CleInvalide_ExceptionLevee()
        {
            // Arrange.
            long cleInvalide = -1;

            // Act.
            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(identite, cleInvalide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile sans le delegate action.
        /// </summary>
        [Test]
        public void VerifierListerLignesCompteClientMobileParCle_ParametreValide_OK()
        {
            LigneCompteClientMobilePourLister[] reponse = this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            this.briquesServicesExterne.Verify(s => s.ComptesClientServiceExterne.ObtenirCompteClientParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(s => s.GestionSurconsommationAboServiceExterne.ObtenirSeuilParCleLigne(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(s => s.AuthentificationServiceExterne.ObtenirLoginLigneParCleLigne(It.IsAny<Identite>(), It.IsAny<int>()));

            Assert.AreEqual(reponse.Length, 1, "erreur count");
            LigneCompteClientMobilePourLister ligne = reponse.First();
            Assert.AreEqual(ligne.Cle, 1, "erreur cle");
            Assert.AreEqual(ligne.ScoreChurn, 1, "erreur ScoreChurn");
            Assert.AreEqual(ligne.LibelleStatut, "Active", "erreur Statut");
            Assert.AreEqual(ligne.Numero, "0102030405", "erreur Numero");
            Assert.AreEqual(ligne.Offre, "offre", "erreur LibelleOffre");

            Assert.AreEqual(ligne.SeuilSurconsommation, 1, "erreur SeuilSurconsommation");
            Assert.AreEqual(ligne.Utilisateur, "login", "erreur Utilisateur");

            Assert.AreEqual(ligne.EstReseauFull, true, "erreur EstReseauFull");
            Assert.AreEqual(ligne.NiveauAccessEspaceClientMobile, "login", "erreur NiveauAccessEspaceClientMobile");
            Assert.AreEqual(ligne.EstSyntheseCrmMobileAccessible, true, "erreur EstSyntheseCRMMobileAccessible");

            Assert.AreEqual(compte.Numero, "0123456789");
        }
        #endregion Test ListerLignesCompteClientMobileParCle

        #region Test ObtenirVue360TitulaireParCle

        /// <summary>
        /// Test de ObtenirVue360TitulaireParCle avec identité null.
        /// </summary>
        [Test]
        public void ObtenirVue360TitulaireParCle_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirVue360TitulaireParCle(null, this.cle);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ObtenirVue360TitulaireParCle avec une clé invalide.
        /// </summary>
        [Test]
        public void ObtenirVue360TitulaireParCle_CleInvalide_ExceptionLevee()
        {
            // Arrange.
            this.cle = -1;

            // Act.
            TestDelegate action = () => this.service.ObtenirVue360TitulaireParCle(this.identite, this.cle);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ObtenirVue360TitulaireParCle paramètres ok.
        /// </summary>
        [Test]
        public void ObtenirVue360TitulaireParCle_OK()
        {
            // Act.
            DetailTitulairePourVue360 detail360 = this.service.ObtenirVue360TitulaireParCle(this.identite, this.CleTiersValide);

            this.repositories.Verify(c => c.LigneRepository.ObtenirDepuisCleTiers(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(c => c.TiersServiceExterne.ObtenirLoginSfcParCleTiers(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(c => c.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(c => c.TiersServiceExterne.ObtenirCleTiersMobileParCleTiersFixe(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(c => c.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(c => c.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(c => c.ComptesClientServiceExterne.RechercherComptesClientParCleTiersTitulaireLight(It.IsAny<Identite>(), It.IsAny<int>()));

            // Assert.
            Assert.IsNotNull(detail360);
            Assert.AreEqual(detail360.Email, "test@test.fr");
            Assert.IsNotNull(detail360.LigneFixe);
            Assert.AreEqual(detail360.LigneFixe.CleLigne, 1);
            Assert.IsTrue(detail360.LigneFixe.EstReinitialisationCodeConfidentielPossible);
            Assert.AreEqual(detail360.LigneFixe.Numero, this.ligne.Numero);
            Assert.AreEqual(detail360.LigneFixe.SeuilSurconsommationTelephonie, this.SeuilSurconsommationVoix);
            Assert.AreEqual(detail360.LigneFixe.SeuilSurconsommationVod, this.SeuilSurconsommationVod);
            Assert.AreEqual(detail360.LigneFixe.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(detail360.LigneFixe.Technologie, "technologie");
            Assert.IsNotNull(detail360.LigneFixe.AdresseInstallation);
            Assert.AreEqual(detail360.LigneFixe.AdresseInstallation.Cle, 1);
            Assert.AreEqual(detail360.LigneFixe.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(detail360.LigneFixe.AdresseInstallation.Numero, "11");
            Assert.AreEqual(detail360.LigneFixe.AdresseInstallation.Rue, "test");
            Assert.AreEqual(detail360.LigneFixe.AdresseInstallation.Ville, "test");
            Assert.AreEqual(detail360.ListeComptesClientMobile.Length, 0);


        }

        #endregion Test ObtenirVue360TitulaireParCle

        #region Test ObtenirInformationsLignePourFicheSyntheseParNumero

        /// <summary>
        /// Test de ObtenirInformationsLignePourFicheSyntheseParNumero avec identité null.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourFicheSyntheseParNumero_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourFicheSyntheseParNumero(null, this.numero);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ObtenirInformationsLignePourFicheSyntheseParNumero avec identité null.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourFicheSyntheseParNumero_ParametresOK()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourFicheSyntheseParNumero(this.identite, this.numero);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ObtenirInformationsLignePourFicheSyntheseParNumero avec identité null.
        /// </summary>
        [Test]
        public void VerifierObtenirInformationsLignePourFicheSyntheseParNumero_ParametresValides_OK()
        {
            // Act.
            DetailLignePourFicheSynthese detailLignePourFicheSynthese = this.service.ObtenirInformationsLignePourFicheSyntheseParNumero(this.identite, this.numero);

            // Assert.

            this.servicesExternes.Verify(s => s.GboServiceExterne.ListerAssociationsHistoriquesDossiersGboParListeClesDossiersGbo(It.IsAny<Identite>(), It.IsAny<int[]>()));

            this.repositories.Verify(r => r.LigneRepository.ObtenirDepuisNumero(It.IsAny<string>()));

            Assert.IsNotNull(detailLignePourFicheSynthese.AdresseInstallation);
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Cle, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Numero, "11");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Rue, "test");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Ville, "test");
            Assert.AreEqual(detailLignePourFicheSynthese.CanalVente, "NonDefini");
            Assert.AreEqual(detailLignePourFicheSynthese.Cle, this.cle);
            Assert.AreEqual(detailLignePourFicheSynthese.DateActivation, this.ligne.SuiviDateCreation);
            Assert.AreEqual(detailLignePourFicheSynthese.DateFinEngagement, new DateTime(2018, 12, 31));
            Assert.AreEqual(detailLignePourFicheSynthese.EstLienListeCommandesAccessible, true);
            Assert.AreEqual(detailLignePourFicheSynthese.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(detailLignePourFicheSynthese.LibelleOffre, "Nom");
            Assert.AreEqual(detailLignePourFicheSynthese.ListeDossiersBackOffice.Count(), 1);
            Assert.AreEqual(detailLignePourFicheSynthese.ListeHistoriques.Count(), 1);
            Assert.IsEmpty(detailLignePourFicheSynthese.ListeMotifsResiliation);
            Assert.IsEmpty(detailLignePourFicheSynthese.ListeMotifsSuspension);
            Assert.AreEqual(detailLignePourFicheSynthese.Numero, this.ligne.Numero);
            Assert.AreEqual(detailLignePourFicheSynthese.Offre, "Nom");
            Assert.AreEqual(detailLignePourFicheSynthese.PrixLocationBox, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PrixOffre, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PrixRemise, 1);

            Assert.IsNotNull(detailLignePourFicheSynthese.PromotionsOffre);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre.Count(), 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Duree, 30);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].EstAutomatique, false);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Libelle, "Descriptif");
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Montant, 12);

            Assert.AreEqual(detailLignePourFicheSynthese.ReferenceExterne, this.ligne.ReferenceExterne);
            Assert.AreEqual(detailLignePourFicheSynthese.StatutSurconsommation, this.ligne.StatutSurconsommation);
            Assert.AreEqual(detailLignePourFicheSynthese.Technologie, "technologie");
            Assert.IsNotNull(detailLignePourFicheSynthese.Tiers);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.AgeCalcule, 7);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Civilite, Civilite.M);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.DateNaissance, new DateTime(2010, 11, 12));
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Email, "test@test.fr");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Nom, "Nom");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Prenom, "Prenom");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.NumeroTelephoneFixeContact, "0123456789");

            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeBanque, "Code01");
            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeBureau, "Code02");
            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeGuichet, "Code03");

            Assert.AreEqual(detailLignePourFicheSynthese.EstGestionRetourColisAccessible, true);
            Assert.AreEqual(detailLignePourFicheSynthese.NumeroRetourColis, "123456789");
        }

        #endregion Test ObtenirInformationsLignePourFicheSyntheseParNumero

        #region Test CreerEtActiverLigne

        /// <summary>
        /// Test de CreerEtActiverLigne avec les paramètres valides.
        /// </summary>
        [Test]
        public void CreerEtActiverLigne_ParametreValides_OK()
        {
            // Act
            TestDelegate action = () => this.service.CreerEtActiverLigne(this.identite, this.informationLigne);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de CreerEtActiverLigne avec identité null.
        /// </summary>
        [Test]
        public void CreerEtActiverLigne_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.CreerEtActiverLigne(null, this.informationLigne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de CreerEtActiverLigne avec informationLigne null.
        /// </summary>
        [Test]
        public void CreerEtActiverLigne_InformationLigneNull_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.CreerEtActiverLigne(identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerEtActiverLigne dans le cas ou les paramètres sont valide.
        /// </summary>
        [Test]
        public void CreerEtActiverLigne_AjouterLigne_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.CreerEtActiverLigne(this.identite, this.informationLigne);

            // Assert.
            this.serviceTechnique.Verify(x => x.GenerateurCles.ObtenirCleLongue<Ligne>());
            this.repositories.Verify(x => x.LigneRepository.AjouterLigne(It.IsAny<Ligne>()));
            this.servicesExternes.Verify(x => x.LogistiqueServiceExterne.ObtenirCommandeExpeditionParCle(this.identite, It.IsAny<long>()));
        }

        #endregion Test CreerEtActiverLigne

        #region Test ObtenirListeCommandesParCleLigne

        /// <summary>
        /// Obtenir une liste de commande avec les paramètres valides.
        /// </summary>
        [Test]
        public void ObtenirListeCommandesParCleLigne_ParametreValides_OK()
        {
            // Act
            TestDelegate action = () => this.service.ObtenirListeCommandesParCleLigne(this.identite, this.ligne.Cle);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ObtenirListeCommandesParCleLigne.
        /// Identite nulle.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirListeCommandesParCleLigne_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirListeCommandesParCleLigne(null, this.ligne.Cle);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        /// <summary>
        /// Test ObtenirListeCommandesParCleLigne cle de la ligne null.
        /// </summary>
        [Test]
        public void ObtenirListeCommandesParCleLigne_CleLigneNull_LeveException()
        {
            long cleLigne = 0;
            // Act.
            TestDelegate action = () => this.service.ObtenirListeCommandesParCleLigne(identite, cleLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ObtenirListeCommandesParCleLigne.
        /// Clé invalide.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirListeCommandesParCleLigne_CleInvalide_LeveeException()
        {
            long cleLigneInvalide = -1;
            // Act.
            TestDelegate action = () => this.service.ObtenirListeCommandesParCleLigne(identite, cleLigneInvalide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir une liste de commande avec les paramètres valides.
        /// </summary>
        [Test]
        public void VerifierObtenirListeCommandesParCleLigne_ParametreValides_OK()
        {
            CommandePourLister[] reponse = this.service.ObtenirListeCommandesParCleLigne(this.identite, this.cle);
            this.servicesExternes.Verify(s => s.SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(It.IsAny<Identite>(), It.IsAny<string>()));

            Assert.AreEqual(reponse.Length, 1, "erreur count");
            CommandePourLister commande = reponse.First();
            // Assert.AreEqual(commande.Cle, 1, "erreur cle");
            // Assert.AreEqual(commande.Numero, "numero", "erreur Numero");
            // Assert.AreEqual(commande.LibelleType, "libelle", "erreur LibelleType");
            // Assert.AreEqual(commande.TypeCommande, "typeCommande", "erreur TypeCommande");
            // Assert.AreEqual(commande.Date, DateTime.Now, "erreur Date");
            // Assert.AreEqual(commande.Etat, "etat", "erreur Etat");
            // Assert.AreEqual(commande.EstSyntheseOSAFAccessible, true, "erreur EstSyntheseOSAFAccessible");

        }

        #endregion Test ObtenirListeCommandesParCleLigne

        #region Test ListerLignesCompteClientMobileParCle

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile avec l'identite null.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(null, this.cle);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile avec la cle null.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_CleNull_LeveException()
        {
            this.cle = 0;

            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile avec la cle negative.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_CleNegatif_LeveException()
        {
            this.cle = -1;

            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile.
        /// </summary>
        [Test]
        public void ListerLignesCompteClientMobileParCle_ParametresValide_OK()
        {
            TestDelegate action = () => this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            Assert.That(action, Throws.Nothing);
        }

        #endregion Test ListerLignesCompteClientMobileParCle

        #region Test VerifierListerLignesCompteClientMobileParCle

        /// <summary>
        /// Obtenir une liste de lignes compte client mobile sans le delegate action.
        /// </summary>
        [Test]
        public void VerifierListerLignesCompteClientMobileParCle_ParametresValide_OK()
        {
            LigneCompteClientMobilePourLister[] reponse = this.service.ListerLignesCompteClientMobileParCle(this.identite, this.cle);

            this.briquesServicesExterne.Verify(s => s.ComptesClientServiceExterne.ObtenirCompteClientParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(s => s.GestionSurconsommationAboServiceExterne.ObtenirSeuilParCleLigne(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(s => s.AuthentificationServiceExterne.ObtenirLoginLigneParCleLigne(It.IsAny<Identite>(), It.IsAny<int>()));

            Assert.AreEqual(reponse.Length, 1, "erreur count");
            LigneCompteClientMobilePourLister ligne = reponse.First();
            Assert.AreEqual(ligne.Cle, 1, "erreur cle");
            Assert.AreEqual(ligne.ScoreChurn, 1, "erreur ScoreChurn");
            Assert.AreEqual(ligne.Statut, EtatLigneMobile.Active);
            Assert.AreEqual(ligne.Numero, "0102030405", "erreur Numero");
            Assert.AreEqual(ligne.Offre, "offre", "erreur LibelleOffre");

            Assert.AreEqual(ligne.SeuilSurconsommation, 1, "erreur SeuilSurconsommation");
            Assert.AreEqual(ligne.Utilisateur, "login", "erreur Utilisateur");

            Assert.AreEqual(ligne.EstReseauFull, true, "erreur EstReseauFull");
            Assert.AreEqual(ligne.NiveauAccessEspaceClientMobile, "login", "erreur NiveauAccessEspaceClientMobile");
            Assert.AreEqual(ligne.EstSyntheseCrmMobileAccessible, true, "erreur EstSyntheseCRMMobileAccessible");
        }

        #endregion Test VerifierListerLignesCompteClientMobileParCle

        #region Test ObtenirInformationsLignePourFicheSyntheseParCle

        /// <summary>
        /// Test de ObtenirInformationsLignePourFicheSyntheseParNumero avec identité null.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourFicheSyntheseParCle_ParametreValide_OK()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourFicheSyntheseParCle(this.identite, this.cle);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ObtenirPourFicheSyntheseParCle.
        /// Parametre valide.
        /// Retour OK.
        /// </summary>
        [Test]
        public void VerifierObtenirInformationsLignePourFicheSyntheseParCle_ParametreValide_OK()
        {
            // Arrange.

            // Act.
            DetailLignePourFicheSynthese detailLignePourFicheSynthese = this.service.ObtenirInformationsLignePourFicheSyntheseParCle(this.identite, this.cle);

            // Assert.
            this.repositories.Verify(r => r.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(b => b.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.briquesServicesExterne.Verify(b => b.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(It.IsAny<Identite>(), ligne.CleGestionnaireOptions));
            this.serviceTechnique.Verify(t => t.Parametrage.NombreHistoriquesFicheSyntheseLigne);
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirLibelleMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(s => s.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>()));


            Assert.IsNotNull(detailLignePourFicheSynthese.AdresseInstallation);
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Cle, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Numero, "11");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Rue, "test");
            Assert.AreEqual(detailLignePourFicheSynthese.AdresseInstallation.Ville, "test");
            Assert.AreEqual(detailLignePourFicheSynthese.CanalVente, "NonDefini");
            Assert.AreEqual(detailLignePourFicheSynthese.Cle, this.cle);
            Assert.AreEqual(detailLignePourFicheSynthese.DateActivation, this.ligne.SuiviDateCreation);
            Assert.AreEqual(detailLignePourFicheSynthese.DateFinEngagement, new DateTime(2018, 12, 31));
            Assert.AreEqual(detailLignePourFicheSynthese.EstLienListeCommandesAccessible, true);
            Assert.AreEqual(detailLignePourFicheSynthese.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(detailLignePourFicheSynthese.LibelleOffre, "Nom");

            Assert.IsNotNull(detailLignePourFicheSynthese.ListeDossiersBackOffice);
            Assert.AreEqual(detailLignePourFicheSynthese.ListeDossiersBackOffice.Count(), 1);

            Assert.IsNotNull(detailLignePourFicheSynthese.ListeHistoriques);
            Assert.AreEqual(detailLignePourFicheSynthese.ListeHistoriques.Count(), 1);
            Assert.IsEmpty(detailLignePourFicheSynthese.ListeMotifsResiliation);
            Assert.IsEmpty(detailLignePourFicheSynthese.ListeMotifsSuspension);
            Assert.AreEqual(detailLignePourFicheSynthese.Numero, this.ligne.Numero);
            Assert.AreEqual(detailLignePourFicheSynthese.Offre, "Nom");
            Assert.AreEqual(detailLignePourFicheSynthese.PrixLocationBox, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PrixOffre, 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PrixRemise, 1);

            Assert.IsNotNull(detailLignePourFicheSynthese.PromotionsOffre);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre.Count(), 1);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Duree, 30);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].EstAutomatique, false);
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Libelle, "Descriptif");
            Assert.AreEqual(detailLignePourFicheSynthese.PromotionsOffre[0].Montant, 12);

            Assert.AreEqual(detailLignePourFicheSynthese.ReferenceExterne, this.ligne.ReferenceExterne);
            Assert.AreEqual(detailLignePourFicheSynthese.StatutSurconsommation, this.ligne.StatutSurconsommation);
            Assert.AreEqual(detailLignePourFicheSynthese.Technologie, "technologie");
            Assert.IsNotNull(detailLignePourFicheSynthese.Tiers);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.AgeCalcule, 7);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Civilite, Civilite.M);
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.DateNaissance, new DateTime(2010, 11, 12));
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Email, "test@test.fr");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Nom, "Nom");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.Prenom, "Prenom");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(detailLignePourFicheSynthese.Tiers.NumeroTelephoneFixeContact, "0123456789");

            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeBanque, "Code01");
            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeBureau, "Code02");
            Assert.AreEqual(detailLignePourFicheSynthese.IcnTiers.CodeGuichet, "Code03");
        }

        /// <summary>
        /// Test de ObtenirPourFicheSyntheseParCle.
        /// Identite nulle.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourFicheSyntheseParCle_IdentiteNulle_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourFicheSyntheseParCle(null, this.cle);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ObtenirPourFicheSyntheseParCle.
        /// Clé invalide.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourFicheSyntheseParCle_CleInvalide_ExceptionLevee()
        {
            // Arrange.
            long cleInvalide = -1;

            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourFicheSyntheseParCle(this.identite, cleInvalide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }
        #endregion Test ObtenirInformationsLignePourFicheSyntheseParCle

        #region Test ObtenirLigneParCle

        /// <summary>
        /// Test de ObtenirLigneParCle.
        /// Parametre valide.
        /// Retour OK.
        /// </summary>
        [Test]
        public void ObtenirLigneParCle_ParametreValide_Ok()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirLigneParCle(this.identite, this.cle);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ObtenirLigneParCle.
        /// Parametre valide.
        /// Retour OK.
        /// </summary>
        [Test]
        public void VerifierObtenirLigneParCle_ParametreValide_Ok()
        {
            // Act.
            LignePourDetail lignePourDetail = this.service.ObtenirLigneParCle(this.identite, this.cle);

            // Assert.
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>()));

            briquesServicesExterne.Verify(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>()));

            Assert.AreEqual(lignePourDetail.AdresseInstallation.Cle, 1);
            Assert.AreEqual(lignePourDetail.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Numero, "11");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Rue, "test");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Ville, "test");

            Assert.AreEqual(lignePourDetail.Cle, this.ligne.Cle);
            Assert.AreEqual(lignePourDetail.DateFinEngagement, this.ligne.DateFinEngagement);
            Assert.AreEqual(lignePourDetail.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(lignePourDetail.Numero, this.ligne.Numero);
            Assert.AreEqual(lignePourDetail.Offre, "Nom");
            Assert.AreEqual(lignePourDetail.ReferenceExterne, this.ligne.ReferenceExterne);
            Assert.AreEqual(lignePourDetail.Technologie, "technologie");

            Assert.AreEqual(lignePourDetail.Tiers.Civilite, Civilite.M);
            Assert.AreEqual(lignePourDetail.Tiers.Cle, 1);
            Assert.AreEqual(lignePourDetail.Tiers.DateNaissance, new DateTime(2010, 11, 12));
            Assert.AreEqual(lignePourDetail.Tiers.DepartementNaissance, "50");
            Assert.AreEqual(lignePourDetail.Tiers.Email, "test@test.fr");
            Assert.AreEqual(lignePourDetail.Tiers.Nom, "Nom");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneFixeContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.Prenom, "Prenom");
        }

        /// <summary>
        /// Test de ObtenirLigneParCle.
        /// Identite nulle.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirLigneParCle_IdentiteNulle_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirLigneParCle(null, this.cle);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ObtenirLigneParCle.
        /// Clé invalide.
        /// Exception levée.
        /// </summary>
        [Test]
        public void ObtenirLigneParCle_CleInvalide_ExceptionLevee()
        {
            // Arrange.
            long cleInvalide = -1;

            // Act.
            TestDelegate action = () => this.service.ObtenirLigneParCle(this.identite, cleInvalide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }
        #endregion Test ObtenirLigneParCle

        #region Test EstLigneExistanteParNumero 
        /// <summary>
        /// Test EstLigneExistanteParNumero Identité null.
        /// </summary>
        [Test]
        public void EstLigneExistanteParNumero_IdentiteNull_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.EstLigneExistanteParNumero(null, "0123456789");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test EstLigneExistanteParNumero Identité null.
        /// </summary>
        [Test]
        public void EstLigneExistanteParNumero_NumeroNull_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.EstLigneExistanteParNumero(identite, string.Empty);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        /// <summary>
        /// Test EstLigneExistanteParNumero parametres ok.
        /// </summary>
        [Test]
        public void EstLigneExistanteParNumero_ParametresValide_OK()
        {
            // Act.
            this.service.EstLigneExistanteParNumero(this.identite, this.numero);

            repositories.Verify(c => c.LigneRepository.ObtenirDepuisNumero(It.IsAny<string>()));

            // Assert.
            Assert.AreEqual(ligne.Numero, "0123456789");
        }

        #endregion Test EstLigneExistanteParNumero

        #region Test EstLigneExistanteParCle
        /// <summary>
        /// Test EstLigneExistanteParCle Identité null.
        /// </summary>
        [Test]
        public void EstLigneExistanteParCle_IdentiteNull_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.EstLigneExistanteParCle(null, 1);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test EstLigneExistanteParCle cle ligne null.
        /// </summary>
        [Test]
        public void EstLigneExistanteParCle_CleLigneNull_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.EstLigneExistanteParCle(identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test EstLigneExistanteParCle cle ligne négatif.
        /// </summary>
        [Test]
        public void EstLigneExistanteParCle_CleLigneNegatif_LeveException()
        {
            // Act.
            TestDelegate action = () => this.service.EstLigneExistanteParCle(identite, -1);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test EstLigneExistanteParNumero parametres ok.
        /// </summary>
        [Test]
        public void EstLigneExistanteParCle_ParametresValide_OK()
        {
            // Act.
            this.service.EstLigneExistanteParCle(this.identite, this.cle);

            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));

            // Assert.
            Assert.AreEqual(ligne.Cle, 1);
        }
        #endregion Test EstLigneExistanteParCle

        #region Test CreerQualificiationAppel

        /// <summary>
        /// Test CreerQualificationAppel paramètres valides.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_ParametresValide_OK()
        {
            // Act
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, this.referenceExterne, this.informationsDossierGBO, this.historiqueDossierGBO);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test et vérification de la méthode CreerQualificationAppel.
        /// </summary>
        [Test]
        public void VerifierCreerQualificationAppel_ParametresValide_OK()
        {
            // Act
            this.service.CreerQualificationAppel(this.identite, this.referenceExterne, this.informationsDossierGBO, this.historiqueDossierGBO);

            // Assert
            this.briquesServicesExterne.Verify(s => s.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>()));
            this.servicesExternes.Verify(s => s.HistoriqueServiceExterne.CreerHistoriqueAppel(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.HistoriqueAppelPourCreation>()));
            this.servicesExternes.Verify(s => s.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<long>()));
        }

        /// <summary>
        /// Test des webs méthodes des services externes appelées dans CreerQualificationAppel.
        /// </summary> 
        [Test]
        public void VerifierCreerQualificationAppel_CreerDossierGboPourLigne_et_CreerHistoriquePourLigne_OK()
        {
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new Fixe.Domain.Gbo.ReponseCreationDossierGbo { CleDossierGbo = 1, CleHistoriqueAssociationDossierGboLigne = 1 });


            this.service.CreerQualificationAppel(this.identite, this.referenceExterne, informationsDossierGBO, historiqueDossierGBO);

            servicesExternes.Verify(c => c.HistoriqueServiceExterne.CreerHistoriqueAppel(It.IsAny<Identite>(), It.IsAny<HistoriqueAppelPourCreation>()));
        }

        /// <summary>
        /// Test CreerQualificationAppel identité nulle.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_IdentiteNulle_ExceptionLevee()
        {
            // Act
            TestDelegate action = () => this.service.CreerQualificationAppel(null, this.referenceExterne, informationsDossierGBO, historiqueDossierGBO);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel référence externe null.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_ReferenceExterneNull_LeveException()
        {
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, null, informationsDossierGBO, historiqueDossierGBO);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel référence externe vide.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_ReferenceExterneVide_LeveException()
        {
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, string.Empty, informationsDossierGBO, historiqueDossierGBO);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel référence externe espaces.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_ReferenceExterneVideEspaces_LeveException()
        {
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, "      ", informationsDossierGBO, historiqueDossierGBO);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel DossierGBO null.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_InformationDossierGBONull_LeveException()
        {
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, this.referenceExterne, null, historiqueDossierGBO);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test CreerQualificationAppel historique null.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_HistoriqueDossierGBONull_LeveException()
        {
            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, this.referenceExterne, informationsDossierGBO, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel commentaire du dossier GBO vide.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_InformationsDossierGBOCommentaireVide_LeveException()
        {
            this.informationsDossierGBO.Commentaire = "";

            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, this.referenceExterne, informationsDossierGBO, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test CreerQualificationAppel commantaire de l'historique vide.
        /// </summary>
        [Test]
        public void CreerQualificationAppel_HistoriqueDossierGBOCommentaireVide_LeveException()
        {
            this.historiqueDossierGBO.Commentaire = "";

            TestDelegate action = () => this.service.CreerQualificationAppel(this.identite, this.referenceExterne, null, historiqueDossierGBO);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test CreerQualificiationAppel

        #region Test ModifierStatutSurconsommationLigne

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec identite null, Lever une exception.
        /// </summary>
        [Test]
        public void ModifierStatutSurconsommationLigne_IdentiteNulle_LeveeException()
        {
            // Act.
            TestDelegate action = () => this.service.ModifierStatutSurconsommationLigne(null, this.cle, ProfilSurconsommation.NouveauClient);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec clé null, Lever une exception.
        /// </summary>
        [Test]
        public void ModifierStatutSurconsommationLigne_CleNulle_LeveeException()
        {
            long cleLigne = 0;
            // Act.
            TestDelegate action = () => this.service.ModifierStatutSurconsommationLigne(this.identite, cleLigne, ProfilSurconsommation.NouveauClient);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec clé invalide, Lever une exception.
        /// </summary>
        [Test]
        public void ModifierStatutSurconsommationLigne_CleInvalide_LeveeException()
        {
            long cleLigneInvalide = 0;
            // Act.
            TestDelegate action = () => this.service.ModifierStatutSurconsommationLigne(this.identite, cleLigneInvalide, ProfilSurconsommation.NouveauClient);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec paramètres Ok.
        /// </summary>
        [Test]
        public void ModifierStatutSurconsommationLigne_ParametresValide_OK()
        {

            // Act.
            TestDelegate action = () => this.service.ModifierStatutSurconsommationLigne(this.identite, this.cle, ProfilSurconsommation.NouveauClient);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec paramètres Ok.
        /// </summary>
        [Test]
        public void VerifierModifierStatutSurconsommationLigne_ParametresValide_OK()
        {
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(1)).Returns(this.ligne);
            this.service.ModifierStatutSurconsommationLigne(this.identite, this.cle, ProfilSurconsommation.NouveauClient);

            this.repositories.Verify(e => e.LigneRepository.ObtenirDepuisCle(1));

        }

        #endregion Test ModifierStatutSurconsommationLigne

        #region Test AppliquerPromotionSurLigne

        /// <summary>
        /// Appliquer promotion sur une ligne avec identite null.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_IdentiteNull_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.AppliquerPromotionSurLigne(null, this.clePromo, this.cleLigne);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Appliquer promotion sur une ligne avec cle promo null.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_ClePromoNull_LeveException()
        {
            // Arrange
            int clePromo = 0;

            // Act
            TestDelegate action = () => this.service.AppliquerPromotionSurLigne(this.identite, clePromo, this.cleLigne);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Appliquer promotion sur une ligne avec cle promo invalide.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_ClePromoInvalide_LeveException()
        {
            // Arrange
            int clePromoInvalide = -1;

            // Act
            TestDelegate action = () => this.service.AppliquerPromotionSurLigne(this.identite, clePromoInvalide, this.cleLigne);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Appliquer promotion sur une ligne avec cle ligne null.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_CleLigneNull_LeveException()
        {
            // Arrange
            long cleLigne = 0;

            // Act
            TestDelegate action = () => this.service.AppliquerPromotionSurLigne(this.identite, this.clePromo, cleLigne);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Appliquer promotion sur une ligne avec cle ligne invalide.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_CleLigneInvalide_LeveException()
        {
            // Arrange
            long cleLigneInvalide = -1;

            // Act
            TestDelegate action = () => this.service.AppliquerPromotionSurLigne(this.identite, this.clePromo, cleLigneInvalide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Appliquer promotion sur une ligne avec paramètres OK.
        /// </summary>
        [Test]
        public void AppliquerPromotionSurLigne_ParametresValide_OK()
        {
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligneMock.Object);

            // Act.
            this.service.AppliquerPromotionSurLigne(this.identite, this.clePromo, this.cleLigne);

            // Assert
            this.repositories.Verify(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.TesterEligibiliteCodePromo(identite, It.IsAny<int>(), this.clePromo));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(identite, this.clePromo, It.IsAny<int>()));
            this.gestionnaireMock.Verify(g => g.CreerEtActiverDemandeRemisePromotion(identite, It.IsAny<DemandeRemisePourCreation>(), It.IsAny<long>(), It.IsAny<int>()));

        }

        #endregion Test AppliquerPromotionSurLigne

        #region Test ObtenirPromotionsLignePourDetailParCleLigne

        /// <summary>
        /// Obtenir détail des promotions associées à une ligne avec identite null.
        /// </summary>
        [Test]
        public void ObtenirPromotionsLignePourDetailParCleLigne_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsLignePourDetailParCleLigne(null, this.cleLigne);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Obtenir détail des promotions associées à une ligne avec cle ligne null.
        /// </summary>
        [Test]
        public void ObtenirPromotionsLignePourDetailParCleLigne_CleLigneNull_LeveException()
        {
            // Arrange
            long cleLigne = 0;

            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsLignePourDetailParCleLigne(this.identite, cleLigne);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir détail des promotions associées à une ligne avec cle ligne invalide.
        /// </summary>
        [Test]
        public void ObtenirPromotionsLignePourDetailParCleLigne_CleLigneInvalide_LeveException()
        {
            // Arrange
            long cleLigneInvalide = -1;

            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsLignePourDetailParCleLigne(this.identite, cleLigneInvalide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir détail des promotions associées à une lignee avec paramètres OK.
        /// </summary>
        [Test]
        public void ObtenirPromotionsLignePourDetailParCleLigne_ParametresValide_OK()
        {
            // Arrange.
            this.ligneMock.Setup(l => l.Cle).Returns(this.cleLigne);
            this.ligneMock.Setup(l => l.Numero).Returns(this.numero);
            this.ligneMock.Setup(l => l.ReferenceExterne).Returns(this.ligne.ReferenceExterne);
            Mock<HistoriqueEtatLigne> mockHistorique1 = new Mock<HistoriqueEtatLigne>();
            mockHistorique1.Setup(h => h.DateChangementEtat).Returns(DateTime.Now.AddHours(1));
            mockHistorique1.Setup(h => h.NouvelEtat).Returns(EtatLigne.Activee);
            Mock<HistoriqueEtatLigne> mockHistorique2 = new Mock<HistoriqueEtatLigne>();
            mockHistorique2.Setup(h => h.DateChangementEtat).Returns(DateTime.Now.AddHours(2));
            mockHistorique2.Setup(h => h.NouvelEtat).Returns(EtatLigne.Activee);
            Mock<HistoriqueEtatLigne> mockHistorique3 = new Mock<HistoriqueEtatLigne>();
            mockHistorique3.Setup(h => h.DateChangementEtat).Returns(DateTime.Now.AddHours(3));
            mockHistorique3.Setup(h => h.NouvelEtat).Returns(EtatLigne.Activee);
            List<HistoriqueEtatLigne> listeHistorique = new List<HistoriqueEtatLigne>() { mockHistorique1.Object, mockHistorique2.Object, mockHistorique3.Object };
            this.ligneMock.Setup(l => l.ListeHistoriqueEtats).Returns(listeHistorique);
            Mock<DemandeRemisePromotion> promoActive1 = new Mock<DemandeRemisePromotion>();
            promoActive1.Setup(p => p.ClePromotionInterne).Returns(1);
            promoActive1.Setup(p => p.ClePromotion()).Returns(1);
            promoActive1.Setup(p => p.Cle).Returns(1);
            promoActive1.Setup(p => p.DureeValidite).Returns(1);
            promoActive1.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });

            promoActive1.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Activee);
            Mock<DemandeRemisePromotion> promoActive2 = new Mock<DemandeRemisePromotion>();
            promoActive2.Setup(p => p.ClePromotionInterne).Returns(1);
            promoActive2.Setup(p => p.ClePromotion()).Returns(2);
            promoActive2.Setup(p => p.DureeValidite).Returns(2);
            promoActive2.Setup(p => p.Cle).Returns(2);
            promoActive2.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });
            promoActive2.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Activee);
            Mock<DemandeRemisePromotion> promoActive3 = new Mock<DemandeRemisePromotion>();
            promoActive3.Setup(p => p.ClePromotionInterne).Returns(1);
            promoActive3.Setup(p => p.ClePromotion()).Returns(3);
            promoActive3.Setup(p => p.DureeValidite).Returns(3);
            promoActive3.Setup(p => p.Cle).Returns(3);
            promoActive3.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });
            promoActive3.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Activee);
            List<DemandeRemisePromotion> listePromoActives = new List<DemandeRemisePromotion>() { promoActive1.Object, promoActive2.Object, promoActive3.Object };
            Mock<DemandeRemisePromotion> promoObso1 = new Mock<DemandeRemisePromotion>();
            promoObso1.Setup(p => p.ClePromotionInterne).Returns(1);
            promoObso1.Setup(p => p.ClePromotion()).Returns(4);
            promoObso1.Setup(p => p.DureeValidite).Returns(4);
            promoObso1.Setup(p => p.Cle).Returns(4);
            promoObso1.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });
            promoObso1.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Expiree);
            Mock<DemandeRemisePromotion> promoObso2 = new Mock<DemandeRemisePromotion>();
            promoObso2.Setup(p => p.ClePromotionInterne).Returns(1);
            promoObso2.Setup(p => p.ClePromotion()).Returns(5);
            promoObso2.Setup(p => p.DureeValidite).Returns(5);
            promoObso2.Setup(p => p.Cle).Returns(5);
            promoObso2.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });
            promoObso2.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Expiree);

            Mock<DemandeRemisePromotion> promoObso3 = new Mock<DemandeRemisePromotion>();
            promoObso3.Setup(p => p.ClePromotionInterne).Returns(1);
            promoObso3.Setup(p => p.ClePromotion()).Returns(6);
            promoObso3.Setup(p => p.DureeValidite).Returns(1);
            promoObso3.Setup(p => p.Cle).Returns(6);
            promoObso3.Setup(p => p.ListeHistoriquesEtats).Returns(new List<HistoriqueEtatDemandeRemise>() { new HistoriqueEtatDemandeRemise(identite, 6, EtatDemandeRemise.Expiree) });
            promoObso3.Setup(p => p.ValeurEtat).Returns(EtatDemandeRemise.Expiree);
            List<DemandeRemisePromotion> listePromoObso = new List<DemandeRemisePromotion>() { promoObso1.Object, promoObso2.Object, promoObso3.Object };

            gestionnaireMock.Setup(g => g.ListerPromotionsActives()).Returns(listePromoActives);
            gestionnaireMock.Setup(g => g.ListerPromotionsObsoletes()).Returns(listePromoObso);

            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligneMock.Object);

            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(identite, this.ligne.ReferenceExterne)).Returns(new CommandeSouscriptionPourDetail());
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.RechercherPromotionsDepuisListeCles(identite, It.IsAny<int[]>())).Returns(new PromotionPourDetail[] {
                new PromotionPourDetail() { Cle = 1, Descriptif = "Des", CodePromo="Code" },
                new PromotionPourDetail() { Cle = 2, Descriptif = "Des", CodePromo = "Code" },
                new PromotionPourDetail() { Cle = 3, Descriptif = "Des", CodePromo = "Code" },
                new PromotionPourDetail() { Cle = 4, Descriptif = "Des", CodePromo = "Code" },
                new PromotionPourDetail() { Cle = 5, Descriptif = "Des", CodePromo = "Code" },
                new PromotionPourDetail() { Cle = 6, Descriptif = "Des", CodePromo = "Code" }
            });

            // Act
            PromotionsLignePourDetail resultat = this.service.ObtenirPromotionsLignePourDetailParCleLigne(this.identite, this.cleLigne);

            // Assert
            Assert.That(resultat.CleLigne, Is.EqualTo(this.cleLigne));
            this.repositories.Verify(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(identite, this.ligne.ReferenceExterne));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.RechercherPromotionsDepuisListeCles(identite, It.IsAny<int[]>()));


        }
        #endregion Test ObtenirPromotionsLignePourDetailParCleLigne

        #region Test ResilierPromotion

        /// <summary>
        /// Test de ResilierPromotion avec identite null, Lever une exception.
        /// </summary>
        [Test]
        public void ResilierPromotion__IdentiteNulle_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.ResilierPromotion(null, this.cleLigne, this.cleDemandeRemisePromotion);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ResilierPromotion avec cle de la ligne null, Lever une exception.
        /// </summary>
        [Test]
        public void ResilierPromotion__CleLigneNulle_LeveeException()
        {
            // Arrange
            long cleLigne = 0;

            // Act
            TestDelegate action = () => this.service.ResilierPromotion(this.identite, cleLigne, this.cleDemandeRemisePromotion);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ResilierPromotion avec clé de ligne invalide, Lever une exception.
        /// </summary>
        [Test]
        public void ResilierPromotion__CleLigneInvalide_LeveeException()
        {
            // Arrange
            long cleLigneInvalide = -1;

            // Act
            TestDelegate action = () => this.service.ResilierPromotion(this.identite, cleLigneInvalide, this.cleDemandeRemisePromotion);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ResilierPromotion avec cle de demande remise promotion null, Lever une exception.
        /// </summary>
        [Test]
        public void ResilierPromotion__CleDemandeRemiseNulle_LeveeException()
        {
            // Arrange
            long cleDemandeRemise = 0;

            // Act
            TestDelegate action = () => this.service.ResilierPromotion(this.identite, this.cleLigne, cleDemandeRemise);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ResilierPromotion avec clédemande remise promotion invalide, Lever une exception.
        /// </summary>
        [Test]
        public void ResilierPromotion__CleDemandeRemiseInvalide_LeveeException()
        {
            // Arrange
            long cleDemandeRemiseInvalide = -1;

            // Act
            TestDelegate action = () => this.service.ResilierPromotion(this.identite, this.cleLigne, cleDemandeRemiseInvalide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }
        /// <summary>
        /// Test de ResilierPromotion avec paramètres OK.
        /// </summary>
        [Test]
        public void ResilierPromotion_ParametresValide_OK()
        {
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligneMock.Object);

            // Act.
            this.service.ResilierPromotion(this.identite, this.cleLigne, this.cleDemandeRemisePromotion);

            // Assert.
            this.repositories.Verify(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.gestionnaireMock.Verify(g => g.ResilierDemandeRemiseParCle(identite, It.IsAny<long>(), this.cleLigne, It.IsAny<int>()));

        }
        #endregion Test ResilierPromotion

        #region Test ObtenirPromotionsEligiblesParCleLigne

        /// <summary>
        /// Obtenir promotion éligible par cle de ligne avec identite null.
        /// </summary>
        [Test]
        public void ObtenirPromotionsEligiblesParCleLigne_IdentiteNull_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsEligiblesParCleLigne(null, this.cleLigne);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        ///  Obtenir promotion éligible par cle de ligne avec cle ligne null.
        /// </summary>
        [Test]
        public void ObtenirPromotionsEligiblesParCleLigne_CleLigneNull_LeveException()
        {
            // Arrange
            long cleLigne = 0;

            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsEligiblesParCleLigne(this.identite, cleLigne);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        ///  Obtenir promotion éligible par cle de ligne avec cle ligne invalide.
        /// </summary>
        [Test]
        public void ObtenirPromotionsEligiblesParCleLigne_CleLigneInvalide_LeveException()
        {
            // Arrange
            long cleLigneInvalide = -1;

            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsEligiblesParCleLigne(this.identite, cleLigneInvalide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtenir promotion éligible par cle de ligne avec paramètres OK.
        /// </summary>
        [Test]
        public void ObtenirPromotionsEligiblesParCleLigne_ParametresValide_OK()
        {
            // Act
            TestDelegate action = () => this.service.ObtenirPromotionsEligiblesParCleLigne(this.identite, this.cleLigne);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de ModifierStatutSurconsommationLigne avec paramètres Ok.
        /// </summary>
        [Test]
        public void VerifierObtenirPromotionsEligiblesParCleLigne_ParametresValide_OK()
        {
            // Arrange
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.cleLigne)).Returns(this.ligne);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirPromotionsEligiblesParCleOffre(this.identite, this.clePromo)).Returns(new PromotionPourDetail[] {
                new PromotionPourDetail()
                {
                    Cle = 1,
                    Descriptif = "Descriptif",
                    MontantTtc = 12,
                    Duree = 30
                },
                new PromotionPourDetail()
                {
                     Cle = 2,
                    Descriptif = "Des",
                    MontantTtc = 10,
                    Duree = 50
                }
                });

            //this.repositories.Verify(e => e.LigneRepository.ObtenirLigneParCle(1));

            PromotionPourLister[] list = this.service.ObtenirPromotionsEligiblesParCleLigne(this.identite, this.cleLigne);

            // Assert
            Assert.AreEqual(list.Length, 2);
            PromotionPourLister promo = list[0];
            Assert.AreEqual(promo.Cle, this.promotions.Cle);
            Assert.AreEqual(promo.Descriptif, this.promotions.Descriptif);
            Assert.AreEqual(promo.PrixTtc, this.promotions.MontantTtc);
            Assert.AreEqual(promo.DureeValiditeEnMois, this.promotions.Duree);
        }
        #endregion Test ObtenirPromotionsEligiblesParCleLigne

        #region Test ListerPromotionsAExpirer
        /// <summary>
        /// Test de ListerPromotionsAExpirer avec identite null, Lever une exception.
        /// </summary>
        [Test]
        public void ListerPromotionsAExpirer__IdentiteNulle_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.ListerPromotionsAExpirer(null);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }
        /// <summary>
        /// Test de ListerPromotionsAExpirer parametres ok.
        /// </summary>
        [Test]
        public void ListerPromotionsAExpirer_ParametresValide_OK()
        {

            // Act.
            TestDelegate action = () => this.service.ListerPromotionsAExpirer(this.identite);

            // Assert.
            Assert.That(action, Throws.Nothing);

        }

        /// <summary>
        /// Test de ListerPromotionsAExpirer parametres ok.
        /// </summary>
        [Test]
        public void VerifierListerPromotionsAExpirer_ParametresValide_OK()
        {
            // Act.
            DemandesRemisesLignePourExpiration[] reponse = this.service.ListerPromotionsAExpirer(this.identite);

            repositories.Verify(c => c.DemandeRemiseRepository.ListerPromotionsAExpirer());

            // Assert.
            Assert.AreEqual(reponse.Length, 2, "erreur count");
            DemandesRemisesLignePourExpiration demande = reponse.First();
            Assert.AreEqual(demande.CleLigne, 1, "erreur cleLigne.");
            Assert.AreEqual(demande.ListeClesDemandeRemise.Count, 2, "erreur ListClesDemandeRemise");
            Assert.IsTrue(demande.ListeClesDemandeRemise.Contains(1));
            Assert.IsTrue(demande.ListeClesDemandeRemise.Contains(2));

        }

        #endregion Test ListerPromotionsAExpirer

        #region Test TraiterExpirationDemandeRemiseParCle
        /// <summary>
        /// Test de TraiterExpirationDemandeRemiseParCle avec identite null, Lever une exception.
        /// </summary>
        [Test]
        public void TraiterExpirationDemandeRemiseParCle__IdentiteNulle_LeveException()
        {
            // Act
            TestDelegate action = () => this.service.TraiterExpirationDemandeRemiseParCle(null, this.demande);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de TraiterExpirationDemandeRemiseParCle avec demendeRemiseLignePourExpiration null, Lever une exception.
        /// </summary>
        [Test]
        public void TraiterExpirationDemandeRemiseParCle__ParametresNulle_LeveException()
        {
            DemandesRemisesLignePourExpiration demande = null;
            // Act
            TestDelegate action = () => this.service.TraiterExpirationDemandeRemiseParCle(this.identite, demande);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ResilierPromotion avec paramètres OK.
        /// </summary>
        [Test]
        public void VerifierTraiterExpirationDemandeRemiseParCle_ParametresValide_OK()
        {
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(ligneMock.Object);
            this.service.TraiterExpirationDemandeRemiseParCle(this.identite, this.demande);

            // Assert.
            this.gestionnaireMock.Verify(g => g.ExpirerDemandeRemiseParCle(identite, It.IsAny<long>()));

        }
        #endregion Test TraiterExpirationDemandeRemiseParCle

        #region Test CreerDemandeResiliation

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new Interface.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                CleMotifResiliation = this.CleMotifResiliationValide,
                DateReceptionCourrierAr = this.DateReceptionCourrierArValide,
                DateResiliationProgrammee = this.DateResiliationProgrammeeValide,
                Email = this.EmailValide,
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = new Mock<Interface.DTO.TiersPourEnvoiBonRetour>().Object
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeResiliation(null, this.CleLigneValide, demandeResiliationPourCreation);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans le cas où la clé de demande de résiliation est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_CleDemandeResiliationAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new Interface.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                CleMotifResiliation = this.CleMotifResiliationValide,
                DateReceptionCourrierAr = this.DateReceptionCourrierArValide,
                DateResiliationProgrammee = this.DateResiliationProgrammeeValide,
                Email = this.EmailValide,
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = new Mock<Interface.DTO.TiersPourEnvoiBonRetour>().Object
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeResiliation(this.identite, 0, demandeResiliationPourCreation);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans le cas où la clé de demande de résiliation est négative. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_CleDemandeResiliationNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new Interface.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                CleMotifResiliation = this.CleMotifResiliationValide,
                DateReceptionCourrierAr = this.DateReceptionCourrierArValide,
                DateResiliationProgrammee = this.DateResiliationProgrammeeValide,
                Email = this.EmailValide,
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = new Mock<Interface.DTO.TiersPourEnvoiBonRetour>().Object
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeResiliation(identite, -150, demandeResiliationPourCreation);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans le cas où la demande de résiliation pour création est à null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_DemandeResiliationANull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeResiliation(identite, this.CleLigneValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new Interface.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                CleMotifResiliation = this.CleMotifResiliationValide,
                DateReceptionCourrierAr = this.DateReceptionCourrierArValide,
                DateResiliationProgrammee = this.DateResiliationProgrammeeValide,
                Email = this.EmailValide,
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = new Mock<Interface.DTO.TiersPourEnvoiBonRetour>().Object
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeResiliation(identite, this.CleLigneValide, demandeResiliationPourCreation);

            // Assert.
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
        }

        #endregion Test CreerDemandeResiliation

        #region Test EnregistrerOptionsLigne

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsAAjouter = new int[3] { 1, 2, 3 };
            int[] clesOptionsASupprimer = new int[3] { 7, 8, 9 };

            // Act.
            TestDelegate action = () => ligneService.EnregistrerOptionsLigne(null, this.CleLigneValide, clesOptionsAAjouter, clesOptionsASupprimer);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsAAjouter = new int[3] { 1, 2, 3 };
            int[] clesOptionsASupprimer = new int[3] { 7, 8, 9 };

            // Act.
            TestDelegate action = () => ligneService.EnregistrerOptionsLigne(this.identite, 0, clesOptionsAAjouter, clesOptionsASupprimer);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsAAjouter = new int[3] { 1, 2, 3 };
            int[] clesOptionsASupprimer = new int[3] { 7, 8, 9 };

            // Act.
            TestDelegate action = () => ligneService.EnregistrerOptionsLigne(this.identite, -400, clesOptionsAAjouter, clesOptionsASupprimer);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où le tableau des clés à ajouter est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_clesOptionsAAjouterNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsASupprimer = new int[3] { 7, 8, 9 };

            // Act.
            TestDelegate action = () => ligneService.EnregistrerOptionsLigne(this.identite, this.CleLigneValide, null, clesOptionsASupprimer);

            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où le tableau des clés à supprimer est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_clesOptionsASupprimerNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsAAjouter = new int[3] { 1, 2, 3 };

            // Act.
            TestDelegate action = () => ligneService.EnregistrerOptionsLigne(this.identite, this.CleLigneValide, clesOptionsAAjouter, null);

            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerOptionsLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void EnregistrerOptionsLigne_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            int[] clesOptionsAAjouter = new int[3] { 1, 2, 3 };
            int[] clesOptionsASupprimer = new int[3] { 7, 8, 9 };

            // Act.
            ligneService.EnregistrerOptionsLigne(this.identite, this.CleLigneValide, clesOptionsAAjouter, clesOptionsASupprimer);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesServicesExterne.Verify(x => x.OptionsServiceExterne.ModifierOptionsGestionnaire(It.IsAny<Identite>(), ligne.CleGestionnaireOptions, It.IsAny<List<int>>(), It.IsAny<List<int>>()));
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identite, It.IsAny<long>(), It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            this.briquesServicesExterne.Verify(x => x.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementOptions(It.IsAny<Identite>(), It.IsAny<ParametresEmailConfirmerChangementOptions>()));
        }

        #endregion Test EnregistrerOptionsLigne

        #region Test ObtenirDetailLigneParCle

        /// <summary>
        /// Test de la méthode ObtenirDetailLigneParCle dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailLigneParCle_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailLigneParCle(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailLigneParCle dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailLigneParCle_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailLigneParCle(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailLigneParCle dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailLigneParCle_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailLigneParCle(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailLigneParCle dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirDetailLigneParCle_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.ObtenirDetailLigneParCle(this.identite, this.CleLigneValide);

            // Assert.
            this.servicesExternes.Verify(x => x.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(this.identite, It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirTechnologieParCle(this.identite, It.IsAny<int>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirOffreParCle(this.identite, It.IsAny<int>()));
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identite, It.IsAny<long>()));
        }

        #endregion Test ObtenirDetailLigneParCle

        #region Test ObtenirDetailOptionsLigneParCleLigne

        /// <summary>
        /// Test de la méthode ObtenirDetailOptionsLigneParCleLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailOptionsLigneParCleLigne_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailOptionsLigneParCleLigne(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailOptionsLigneParCleLigne dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailOptionsLigneParCleLigne_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailOptionsLigneParCleLigne(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailOptionsLigneParCleLigne dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailOptionsLigneParCleLigne_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirDetailOptionsLigneParCleLigne(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailOptionsLigneParCleLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirDetailOptionsLigneParCleLigne_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.ObtenirDetailOptionsLigneParCleLigne(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirOffreParCle(this.identite, It.IsAny<int>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirTechnologieParCle(this.identite, It.IsAny<int>()));
        }

        #endregion Test ObtenirDetailOptionsLigneParCleLigne

        #region Test ObtenirInformationsPourSaisieDemandeResiliation

        /// <summary>
        /// Test de la méthode ObtenirInformationsPourSaisieDemandeResiliation dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsPourSaisieDemandeResiliation_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsPourSaisieDemandeResiliation(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsPourSaisieDemandeResiliation dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsPourSaisieDemandeResiliation_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsPourSaisieDemandeResiliation(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsPourSaisieDemandeResiliation dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsPourSaisieDemandeResiliation_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsPourSaisieDemandeResiliation(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsPourSaisieDemandeResiliation dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirInformationsPourSaisieDemandeResiliation_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.ObtenirInformationsPourSaisieDemandeResiliation(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.MotifResiliationRepository.ListerMotifsResiliation());
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identite, It.IsAny<long>()));
        }

        #endregion Test ObtenirInformationsPourSaisieDemandeResiliation

        #region Test ResilierLigneSurImpayes

        /// <summary>
        /// Test de la méthode ResilierLigneSurImpayes dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ResilierLigneSurImpayes_eventImpayesNull_LeveException()
        {
            // Arrange.
            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            ResilierLigneEvent eventImpayes = null;

            // Act.
            TestDelegate action = () => ligneEventService.ResilierLigneSurImpayes(eventImpayes);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ResilierLigneSurImpayes  avec clé ligne est vide. Lève une exception.
        /// </summary>
        [Test]
        public void ResilierLigneSurImpayes_CleLigneVide_LeveException()
        {
            // Arrange.
            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            ResilierLigneEvent eventImpayes = new ResilierLigneEvent()
            {
                CleLigne = 0,
                Motif = "Modif"
            };

            // Act.
            TestDelegate action = () => ligneEventService.ResilierLigneSurImpayes(eventImpayes);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ResilierLigneSurImpayes  avec clé ligne est négative. Lève une exception.
        /// </summary>
        [Test]
        public void ResilierLigneSurImpayes_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            ResilierLigneEvent eventImpayes = new ResilierLigneEvent()
            {
                CleLigne = -1,
                Motif = "Modif"
            };

            // Act.
            TestDelegate action = () => ligneEventService.ResilierLigneSurImpayes(eventImpayes);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ResilierLigneSurImpayes dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ResilierLigneSurImpayes_ParametresOK_OK()
        {
            // Arrange. 
            Mock<Ligne> mockLigne = new Mock<Ligne>();
            mockLigne.Setup(x => x.CreerDemandeResiliation(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.DemandeResiliationPourCreation>()));
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns((mockLigne.Object));

            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            ResilierLigneEvent eventImpayes = new ResilierLigneEvent()
            {
                CleLigne = 1,
                Motif = "Modif",
                Headers = new Dictionary<string, string>()
            };

            // Act.
            ligneEventService.ResilierLigneSurImpayes(eventImpayes);


            // Assert.
            this.repositories.Verify(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.repositories.Verify(x => x.MotifResiliationRepository.ObtenirDepuisCle(It.IsAny<long>()));
        }

        #endregion Test ResilierLigneSurImpayes

        #region Test SurPortabiliteSortante


        /// <summary>
        /// Test de la méthode SurPortabiliteSortante dans le cas où l'événement PortabiliteSortante est null. Lève une exception.
        /// </summary>
        [Test]
        public void SurPortabiliteSortante_PortabiliteSortanteNull_LeveException()
        {
            // Arrange.
            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            PortabiliteSortante eventPortabiliteSortante = null;

            // Act.
            TestDelegate action = () => ligneEventService.SurPortabiliteSortante(eventPortabiliteSortante);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode SurPortabiliteSortante dans le cas où la clé de contrat est vide. Lève une exception.
        /// </summary>
        [Test]
        public void SurPortabiliteSortante_CleContratVide_LeveException()
        {
            // Arrange.
            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            PortabiliteSortante eventPortabiliteSortante = new PortabiliteSortante()
            {
                CleContrat = "",
                Date = DateTime.Now
            };

            // Act.
            TestDelegate action = () => ligneEventService.SurPortabiliteSortante(eventPortabiliteSortante);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode SurPortabiliteSortante dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void SurPortabiliteSortante_ParametresOK_OK()
        {
            // Arrange.
            Mock<Ligne> mockLigne = new Mock<Ligne>();
            mockLigne.Setup(x => x.CreerDemandeResiliation(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.DemandeResiliationPourCreation>()));
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisNumeroContrat(this.CleContratValide)).Returns(mockLigne.Object);
            mockLigne.Setup(x => x.CreerDemandeResiliation(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.DemandeResiliationPourCreation>()));

            LigneEventService ligneEventService = new LigneEventService(this.repositories.Object, this.serviceTechnique.Object, this.servicesExternes.Object);
            PortabiliteSortante eventPortabiliteSortante = new PortabiliteSortante()
            {
                CleContrat = this.CleContratValide,
                Date = DateTime.Now
            };

            // Act.
            ligneEventService.SurPortabiliteSortante(eventPortabiliteSortante);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisNumeroContrat(this.CleContratValide));
            this.serviceTechnique.Verify(x => x.Parametrage.CleMotifResiliationPortabiliteSortante);
            this.repositories.Verify(x => x.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliationValide));
            mockLigne.Verify(x => x.CreerDemandeResiliation(It.IsAny<Identite>(), It.IsAny<Domain.CommonTypes.DTO.DemandeResiliationPourCreation>()));
        }

        #endregion Test SurPortabiliteSortante

        #region Test SuspendreLigne

        /// <summary>
        /// Test de la méthode SuspendreLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void SuspendreLigne_ParametresOK_OK()
        {
            // Arrange.
            Identite identite = this.identite;
            long cleLigne = this.CleLigneValide;

            // Act.
            TestDelegate action = () => this.service.SuspendreLigne(identite, cleLigne);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode SuspendreLigne dans le cas où l'identite est nulle.
        /// </summary>
        [Test]
        public void SuspendreLigne_IdentiteNulle_ExceptionLevee()
        {
            // Arrange.
            Identite identite = null;
            long cleLigne = this.CleLigneValide;

            // Act.
            TestDelegate action = () => this.service.SuspendreLigne(identite, cleLigne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode SuspendreLigne dans le cas où la clé ligne est invalide.
        /// </summary>
        [Test]
        public void SuspendreLigne_CleLigneInvalide_ExceptionLevee()
        {
            // Arrange.
            Identite identite = this.identite;
            long cleLigne = -1;

            // Act.
            TestDelegate action = () => this.service.SuspendreLigne(identite, cleLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Test SuspendreLigne

        #region Test RemettreEnServiceLigne

        /// <summary>
        /// Test de la méthode RemettreEnServiceLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void RemettreEnServiceLigne_ParametresOK_OK()
        {
            // Arrange.
            Identite identite = this.identite;
            long cleLigne = this.CleLigneValide;
            this.ligne.Suspendre(identite);

            // Act.
            TestDelegate action = () => this.service.RemettreEnServiceLigne(identite, cleLigne);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode RemettreEnServiceLigne dans le cas où l'identite est nulle.
        /// </summary>
        [Test]
        public void RemettreEnServiceLigne_IdentiteNulle_ExceptionLevee()
        {
            // Arrange.
            Identite identite = null;
            long cleLigne = this.CleLigneValide;

            // Act.
            TestDelegate action = () => this.service.RemettreEnServiceLigne(identite, cleLigne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode RemettreEnServiceLigne dans le cas où la clé ligne est invalide.
        /// </summary>
        [Test]
        public void RemettreEnServiceLigne_CleLigneInvalide_ExceptionLevee()
        {
            // Arrange.
            Identite identite = this.identite;
            long cleLigne = -1;

            // Act.
            TestDelegate action = () => this.service.RemettreEnServiceLigne(identite, cleLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Test RemettreEnServiceLigne

        #region Test ObtenirInformationsContactDepuisCleLigne

        /// <summary>
        /// Test de la méthode ObtenirInformationsContactDepuisCleLigne avec les paramètres OK.
        /// </summary>
        public void ObtenirInformationsContactDepuisCleLigne_ParametreOK_OK()
        {
            // Act.
            InformationsContactPourDetail info = this.service.ObtenirInformationsContactDepuisCleLigne(this.identite, this.CleLigneValide);
            //Verify
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            // Assert.
            Assert.AreEqual(info.CleTiers, this.tiersPourDetail.Cle);
            Assert.AreEqual(info.Email, this.tiersPourDetail.EmailContact);
            Assert.AreEqual(info.NumeroLigne, this.ligne.Numero);
            Assert.AreEqual(info.TelephoneMobileDeContact, this.tiersPourDetail.NumeroMobileDeContact);
            Assert.AreEqual(info.UrlSelfCare, this.marque.SiteWeb);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsContactDepuisCleLigne avec l'identité nulle. Une exception est levée.
        /// </summary>
        public void ObtenirInformationsContactDepuisCleLigne_IdentiteNulle_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsContactDepuisCleLigne(null, this.CleLigneValide);
            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsContactDepuisCleLigne avec la clé ligne invalide. Une exception est levée.
        /// </summary>
        public void ObtenirInformationsContactDepuisCleLigne_CleLigneInvalide_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsContactDepuisCleLigne(this.identite, -1);
            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Test ObtenirInformationsContactDepuisCleLigne

        #region Test ModifierInformationsContactTiers

        /// <summary>
        /// Test de ModifierInformationsContactTiers avec une identié null. Lève une exception.
        /// </summary>
        [Test]
        public void ModifierInformationsContactTiers_IdentiteNulle_LeveeException()
        {
            // Arrange.
            ParametreInformationsContact parametreInformationsContact = new ParametreInformationsContact()
            {
                CleTiers = this.CleTiersValide,
                ContactCourrier = false,
                ContactMail = false,
                ContactMessageVocal = false,
                ContactSms = false,
                ContactTelevente = false
            };

            // Act.
            TestDelegate action = () => this.service.ModifierInformationsContactTiers(null, parametreInformationsContact);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ModifierInformationsContactTiers avec le paramètre ParametreInformationsContact null. Lève une exception.
        /// </summary>
        [Test]
        public void ModifierInformationsContactTiers_ParametreInformationsContactNull_LeveeException()
        {
            // Arrange.
            ParametreInformationsContact parametreInformationsContact = null;

            // Act.
            TestDelegate action = () => this.service.ModifierInformationsContactTiers(this.identite, parametreInformationsContact);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de ModifierInformationsContactTiers avec les paramètres valide.
        /// </summary>
        [Test]
        public void ModifierInformationsContactTiers_ParametresOK_OK()
        {
            // Arrange.
            ParametreInformationsContact parametreInformationsContact = new ParametreInformationsContact()
            {
                CleTiers = this.CleTiersValide,
                ContactCourrier = false,
                ContactMail = false,
                ContactMessageVocal = false,
                ContactSms = false,
                ContactTelevente = false
            };

            // Act.
            this.service.ModifierInformationsContactTiers(this.identite, parametreInformationsContact);

            // Assert.
            this.serviceTechnique.Verify(x => x.MessagingSystem.Publish(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ModifierPreferencesDeContactTiersEvent>()));
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCleTiers(this.CleTiersValide));
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identite, It.IsAny<long>(), It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
        }

        #endregion Test ModifierInformationsContactTiers

        #region Test ObtenirInformationsRioDepuisCleLigne

        /// <summary>
        /// Test de la méthode ObtenirInformationsRioDepuisCleLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsRioDepuisCleLigne_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsRioDepuisCleLigne(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsRioDepuisCleLigne dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsRioDepuisCleLigne_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsRioDepuisCleLigne(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsRioDepuisCleLigne dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsRioDepuisCleLigne_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ObtenirInformationsRioDepuisCleLigne(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsRioDepuisCleLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirInformationsRioDepuisCleLigne_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            InformationsRioPourDetail informationsRioPourDetail = ligneService.ObtenirInformationsRioDepuisCleLigne(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identite, It.IsAny<long>(), It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            Assert.AreEqual(ligne.Numero, informationsRioPourDetail.NumeroLigne);
            Assert.AreEqual(ligne.Rio, informationsRioPourDetail.Rio);
        }

        #endregion Test ObtenirInformationsRioDepuisCleLigne

        #region Test EnvoyerRioParMail

        /// <summary>
        /// Test de la méthode EnvoyerRioParMail dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParMail_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParMail(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParMail dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParMail_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParMail(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParMail dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParMail_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParMail(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParMail dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void EnvoyerRioParMail_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.EnvoyerRioParMail(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque));
            this.briquesServicesExterne.Verify(x => x.CommunicationClientServiceExterne.EnvoyerEmailRio(identite, It.IsAny<ParametresEmailRio>()));
        }

        #endregion Test EnvoyerRioParMail

        #region Test EnvoyerRioParCourrier

        /// <summary>
        /// Test de la méthode EnvoyerRioParCourrier dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParCourrier_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParCourrier(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParCourrier dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParCourrier_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParCourrier(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParCourrier dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void EnvoyerRioParCourrier_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.EnvoyerRioParCourrier(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParCourrier dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void EnvoyerRioParCourrier_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.EnvoyerRioParCourrier(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque));
            this.briquesServicesExterne.Verify(x => x.CommunicationClientServiceExterne.EnvoyerCourrierRio(identite, It.IsAny<ParametresCourrierRio>()));
        }

        #endregion Test EnvoyerRioParCourrier

        #region Test ObtenirInformationsLignePourRechercherDocuments

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRechercherDocuments aves la CleLigne OK et la ReferenceExterne OK..
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRechercherDocuments_CleLigneOK_OK()
        {
            // Act.
            InformationsLignePourRechercherDocuments informations = this.service.ObtenirInformationsLignePourRechercherDocuments(this.identite, this.CleLigneValide, this.referenceExterne);
            //Verify.
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            repositories.Verify(c => c.DocumentLigneRepository.Lister());
            //Asssert.
            Assert.AreEqual(informations.DocumentsPourLister[0].Libelle, this.documentsLigne[0].Libelle);
            Assert.AreEqual(informations.DocumentsPourLister[0].RefDoc, this.documentsLigne[0].RefDoc);
            Assert.AreEqual(informations.NumeroLigne, this.ligne.Numero);
            Assert.AreEqual(informations.ReferenceExterne, this.ligne.ReferenceExterne);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRechercherDocuments aves la CleLigne nulle et la ReferenceExterne OK.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRechercherDocuments_CleLigneNulle_ReferenceExterneOK_OK()
        {
            // Act.
            InformationsLignePourRechercherDocuments informations = this.service.ObtenirInformationsLignePourRechercherDocuments(this.identite, null, this.referenceExterne);
            //Verify.
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>()));
            repositories.Verify(c => c.DocumentLigneRepository.Lister());
            //Asssert.
            Assert.AreEqual(informations.DocumentsPourLister[0].Libelle, this.documentsLigne[0].Libelle);
            Assert.AreEqual(informations.DocumentsPourLister[0].RefDoc, this.documentsLigne[0].RefDoc);
            Assert.AreEqual(informations.NumeroLigne, this.ligne.Numero);
            Assert.AreEqual(informations.ReferenceExterne, this.ligne.ReferenceExterne);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRechercherDocuments aves la CleLigne nulle et la ReferenceExterne vide.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRechercherDocuments_CleLigneNulle_ReferenceExterneKO_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourRechercherDocuments(this.identite, null, null);
            //Asssert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRechercherDocuments aves l'identite nulle.
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRechercherDocuments_IdentiteNulle_ExceptionLevee()
        {
            // Act.
            TestDelegate action = () => this.service.ObtenirInformationsLignePourRechercherDocuments(null, this.CleLigneValide, this.referenceExterne);
            //Asssert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test ObtenirInformationsLignePourRechercherDocuments

        #region Test DebloquerCompteMyPartnerTv

        /// <summary>
        /// Test de la méthode DebloquerCompteMyPartnerTv dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void DebloquerCompteMyPartnerTv_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.DebloquerCompteMyPartnerTv(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailLigneParCle dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void DebloquerCompteMyPartnerTv_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.DebloquerCompteMyPartnerTv(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DebloquerCompteMyPartnerTv dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void DebloquerCompteMyPartnerTv_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.DebloquerCompteMyPartnerTv(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DebloquerCompteMyPartnerTv dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void DebloquerCompteMyPartnerTv_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            ligneService.DebloquerCompteMyPartnerTv(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesServicesExterne.Verify(x => x.SfrFixeCompteTvServiceExterne.Debloquer(It.IsAny<Identite>(), this.referenceExterne));
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identite, It.IsAny<long>(), It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
        }

        #endregion Test DebloquerCompteMyPartnerTv

        #region Test ListerHistoriqueReinitialisationLoginDepuisCleLigne

        /// <summary>
        /// Test de la méthode ListerHistoriqueReinitialisationLoginDepuisCleLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ListerHistoriqueReinitialisationLoginDepuisCleLigne_IdentiteNull_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ListerHistoriqueReinitialisationLoginDepuisCleLigne(null, this.CleLigneValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ListerHistoriqueReinitialisationLoginDepuisCleLigne dans le cas où la clé de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ListerHistoriqueReinitialisationLoginDepuisCleLigne_CleLigneAZero_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ListerHistoriqueReinitialisationLoginDepuisCleLigne(this.identite, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ListerHistoriqueReinitialisationLoginDepuisCleLigne dans le cas où la clé de ligne est négativve. Lève une exception.
        /// </summary>
        [Test]
        public void ListerHistoriqueReinitialisationLoginDepuisCleLigne_CleLigneNegative_LeveException()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ListerHistoriqueReinitialisationLoginDepuisCleLigne(this.identite, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ListerHistoriqueReinitialisationLoginDepuisCleLigne dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ListerHistoriqueReinitialisationLoginDepuisCleLigne_ParametresOK_OK()
        {
            // Arrange.
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Mock<HistoriqueReinitialiserLogin> histo1 = new Mock<HistoriqueReinitialiserLogin>();
            Mock<HistoriqueReinitialiserLogin> histo2 = new Mock<HistoriqueReinitialiserLogin>();
            Mock<HistoriqueReinitialiserLogin> histo3 = new Mock<HistoriqueReinitialiserLogin>();

            histo1.Setup(x => x.DateDemande).Returns(new DateTime(2018, 06, 2));
            histo2.Setup(x => x.DateDemande).Returns(new DateTime(2018, 06, 3));
            histo3.Setup(x => x.DateDemande).Returns(new DateTime(2018, 06, 1));

            this.repositories.Setup(x => x.HistoriqueReinitialiserLoginRepository.ListerDepuisCleLigne(this.CleLigneValide)).Returns(new List<HistoriqueReinitialiserLogin>()
            {
                histo1.Object,
                histo2.Object,
                histo3.Object
            });

            // Act.
            HistoriqueReinitialiserLoginPourLister[] historiquesReinitialiserLoginPourLister = ligneService.ListerHistoriqueReinitialisationLoginDepuisCleLigne(this.identite, this.CleLigneValide);

            // Assert.
            this.repositories.Verify(x => x.HistoriqueReinitialiserLoginRepository.ListerDepuisCleLigne(this.CleLigneValide));
            Assert.AreEqual(3, historiquesReinitialiserLoginPourLister[0].DateDemande.Day);
            Assert.AreEqual(2, historiquesReinitialiserLoginPourLister[1].DateDemande.Day);
            Assert.AreEqual(1, historiquesReinitialiserLoginPourLister[2].DateDemande.Day);

            Assert.Greater(historiquesReinitialiserLoginPourLister[0].DateDemande, historiquesReinitialiserLoginPourLister[1].DateDemande);
            Assert.Greater(historiquesReinitialiserLoginPourLister[1].DateDemande, historiquesReinitialiserLoginPourLister[2].DateDemande);
        }

        #endregion Test ListerHistoriqueReinitialisationLoginDepuisCleLigne

        #region Test ReinitialiserCodeConfidentielSelfCare

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec les paramètre OK. Envoi par Email.
        /// </summary>
        [Test]
        public void Verify_ReinitialiserCodeConfidentielSelfCare_ParametreOK_Email_OK()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Email;
            string canalDemande = "canalDemande";
            // Act.
            this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, this.CleLigneValide, canal, canalDemande);
            //Verify.
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(s => s.AuthentificationServiceExterne.ReinitialiserMotDePasseSfc(It.IsAny<Identite>(), It.IsAny<string>()));
            this.briquesServicesExterne.Verify(s => s.CommunicationClientServiceExterne.EnvoyerEmailConfirmationReinitialisationCodeSelfCare(It.IsAny<Identite>(), It.IsAny<ParametreEmailConfirmationReinitialisationCodeSelfCare>()));
            repositories.Verify(c => c.HistoriqueReinitialiserLoginRepository.Ajouter(It.IsAny<HistoriqueReinitialiserLogin>()));
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec les paramètre OK. Envoi par Email.
        /// </summary>
        [Test]
        public void ReinitialiserCodeConfidentielSelfCare_ParametreOK_Email_OK()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Email;
            string canalDemande = "canalDemande";
            // Act.
            TestDelegate action = () => this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, this.CleLigneValide, canal, canalDemande);
            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec les paramètre OK. Envoi par Sms.
        /// </summary>
        [Test]
        public void Verify_ReinitialiserCodeConfidentielSelfCare_ParametreOK_Sms_OK()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Sms;
            string canalDemande = "canalDemande";
            // Act.
            this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, this.CleLigneValide, canal, canalDemande);
            //Verify.
            repositories.Verify(c => c.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.servicesExternes.Verify(s => s.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(s => s.AuthentificationServiceExterne.ReinitialiserMotDePasseSfc(It.IsAny<Identite>(), It.IsAny<string>()));
            this.briquesServicesExterne.Verify(s => s.CommunicationClientServiceExterne.EnvoyerSmsConfirmationReinitialisationCodeSelfCare(It.IsAny<Identite>(), It.IsAny<ParametreSMSConfirmationReinitialisationCodeSelfCare>()));
            repositories.Verify(c => c.HistoriqueReinitialiserLoginRepository.Ajouter(It.IsAny<HistoriqueReinitialiserLogin>()));
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec les paramètre OK. Envoi par Sms.
        /// </summary>
        [Test]
        public void ReinitialiserCodeConfidentielSelfCare_ParametreOK_Sms_OK()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Sms;
            string canalDemande = "canalDemande";
            // Act.
            TestDelegate action = () => this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, this.CleLigneValide, canal, canalDemande);
            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec l'identite nulle. Exception levée.
        /// </summary>
        [Test]
        public void ReinitialiserCodeConfidentielSelfCare_IdentiteNulle_ExceptionLevee()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Sms;
            string canalDemande = "canalDemande";
            // Act.
            TestDelegate action = () => this.service.ReinitialiserCodeConfidentielSelfCare(null, this.CleLigneValide, canal, canalDemande);
            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec la clé ligne invalide. Exception levée.
        /// </summary>
        [Test]
        public void ReinitialiserCodeConfidentielSelfCare_CleLigneInvalide_ExceptionLevee()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Sms;
            string canalDemande = "canalDemande";
            // Act.
            TestDelegate action = () => this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, -1, canal, canalDemande);
            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ReinitialiserCodeConfidentielSelfCare avec le canalDemande null. Exception levée.
        /// </summary>
        [Test]
        public void ReinitialiserCodeConfidentielSelfCare_CanalDemandeNull_ExceptionLevee()
        {
            // Arrange.
            CanalCommunication canal = CanalCommunication.Sms;
            // Act.
            TestDelegate action = () => this.service.ReinitialiserCodeConfidentielSelfCare(this.identite, this.CleLigneValide, canal, "");
            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test ReinitialiserCodeConfidentielSelfCare

        #region ObtenirInformationsLignePourSelfcareDepuisCleTiers

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourSelfcareDepuisCleTiers avec identité Nulle. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourSelfcareDepuisCleTiers_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourSelfcareDepuisCleTiers(null, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourSelfcareDepuisCleTiers avec clé tiers Nulle. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourSelfcareDepuisCleTiers_CleTiersNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourSelfcareDepuisCleTiers(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourSelfcareDepuisCleTiers avec clé tiers négative. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourSelfcareDepuisCleTiers_CleTiersNegative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourSelfcareDepuisCleTiers(this.identite, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourSelfcareDepuisCleTiers avec clé tiers négative. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourSelfcareDepuisCleTiers_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourSelfcareDepuisCleTiers(this.identite, 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourSelfcareDepuisCleTiers avec clé tiers négative. 
        /// </summary>
        [Test]
        public void VerifierObtenirInformationsLignePourSelfcareDepuisCleTiers_ParametreValide_OK()
        {
            InformationsLignePourSelfcare reponse = this.service.ObtenirInformationsLignePourSelfcareDepuisCleTiers(this.identite, 1);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCleTiers(It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(x => x.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(It.IsAny<Identite>(), It.IsAny<string>()));
            this.servicesExternes.Verify(x => x.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>()));

            //Assert
            Assert.IsNotNull(reponse);
            Assert.IsNotNull(reponse.AdresseInstallation);
            Assert.AreEqual(reponse.AdresseInstallation.Cle, 1);
            Assert.AreEqual(reponse.AdresseInstallation.CodePostal, "59000");
            Assert.IsNull(reponse.AdresseInstallation.Complement);
            Assert.AreEqual(reponse.AdresseInstallation.Numero, "11");
            Assert.AreEqual(reponse.AdresseInstallation.Rue, "test");
            Assert.AreEqual(reponse.AdresseInstallation.Ville, "test");
            Assert.AreEqual(reponse.CleCompteFacturation, 1);
            Assert.AreEqual(reponse.CleLigne, 1);
            Assert.AreEqual(reponse.CleMarque, 1);
            Assert.AreEqual(reponse.CleOffre, 3);
            Assert.AreEqual(reponse.NumeroTelephone, "0123456789");
            Assert.AreEqual(reponse.PrixLocationBox, 1);
            Assert.AreEqual(reponse.PrixOffreRemise, -11);
            Assert.AreEqual(reponse.ReferenceExterne, "123456789");
            Assert.AreEqual(reponse.Rio, "rio");
        }

        #endregion ObtenirInformationsLignePourSelfcareDepuisCleTiers

        #region ObtenirPromotionsOffreActivesDepuisCleLigne

        /// <summary>
        /// Test de la méthode ObtenirPromotionsOffreActivesDepuisCleLigne avec identité Nulle. 
        /// </summary>
        [Test]
        public void ObtenirPromotionsOffreActivesDepuisCleLigne_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirPromotionsOffreActivesDepuisCleLigne(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirPromotionsOffreActivesDepuisCleLigne avec clé ligne Nulle. 
        /// </summary>
        [Test]
        public void ObtenirPromotionsOffreActivesDepuisCleLigne_CleLigneNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirPromotionsOffreActivesDepuisCleLigne(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirPromotionsOffreActivesDepuisCleLigne avec clé ligne négative. 
        /// </summary>
        [Test]
        public void ObtenirPromotionsOffreActivesDepuisCleLigne_CleLLigneNegative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirPromotionsOffreActivesDepuisCleLigne(this.identite, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirPromotionsOffreActivesDepuisCleLigne avec clé ligne négative. 
        /// </summary>
        [Test]
        public void ObtenirPromotionsOffreActivesDepuisCleLigne_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ObtenirPromotionsOffreActivesDepuisCleLigne(this.identite, 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ObtenirPromotionsOffreActivesDepuisCleLigne avec clé ligne négative. 
        /// </summary>
        [Test]
        public void VerifierObtenirPromotionsOffreActivesDepuisCleLigne_ParametreValide_OK()
        {
            List<PromotionPourLister> reponse = this.service.ObtenirPromotionsOffreActivesDepuisCleLigne(this.identite, 1);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>()));

            //Assert
            Assert.IsNotNull(reponse);
            Assert.AreEqual(reponse.Count, 1);
            Assert.AreEqual(reponse.First().Cle, 1);
            Assert.AreEqual(reponse.First().Descriptif, "Descriptif");
            Assert.AreEqual(reponse.First().DureeValiditeEnMois, 30);
            Assert.AreEqual(reponse.First().PrixTtc, 12);
        }

        #endregion ObtenirPromotionsOffreActivesDepuisCleLigne

        #region DemanderOtp

        /// <summary>
        /// Test de la méthode DemanderOtp avec identité Nulle. 
        /// </summary>
        [Test]
        public void DemanderOtp_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.DemanderOtp(null, "login", 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode DemanderOtp avec login Nulle. 
        /// </summary>
        [Test]
        public void DemanderOtp_LoginNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.DemanderOtp(identite, string.Empty, 1);

            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la méthode DemanderOtp avec clé ligne Nulle. 
        /// </summary>
        [Test]
        public void DemanderOtp_CleLigneVide_ExceptionLevee()
        {
            TestDelegate action = () => this.service.DemanderOtp(identite, "login", 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DemanderOtp avec clé ligne négative. 
        /// </summary>
        [Test]
        public void DemanderOtp_CleLigneNégative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.DemanderOtp(identite, "login", -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DemanderOtp avec parametres ok. 
        /// </summary>
        [Test]
        public void DemanderOtp_ParametreValide_Ok()
        {
            TestDelegate action = () => this.service.DemanderOtp(identite, "login", 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode DemanderOtp avec parametres ok. 
        /// </summary>
        [Test]
        public void VerifierDemanderOtp_ParametreValide_Ok()
        {
            this.service.DemanderOtp(identite, "login", 1);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(x => x.AuthentificationServiceExterne.DemanderOtp(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>()));
        }

        #endregion DemanderOtp

        #region ValiderOtp
        /// <summary>
        /// Test de la méthode ValiderOtp avec identité Nulle. 
        /// </summary>
        [Test]
        public void ValiderOtp_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ValiderOtp(null, "login", 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ValiderOtp avec login Nulle. 
        /// </summary>
        [Test]
        public void ValiderOtp_LoginNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ValiderOtp(identite, string.Empty, 1);

            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la méthode ValiderOtp avec clé ligne Nulle. 
        /// </summary>
        [Test]
        public void ValiderOtp_CleLigneVide_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ValiderOtp(identite, "login", 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ValiderOtp avec clé ligne négative. 
        /// </summary>
        [Test]
        public void ValiderOtp_CleLigneNégative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ValiderOtp(identite, "login", -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ValiderOtp avec parametres ok. 
        /// </summary>
        [Test]
        public void ValiderOtp_ParametreValide_Ok()
        {
            TestDelegate action = () => this.service.ValiderOtp(identite, "login", 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ValiderOtp avec parametres ok. 
        /// </summary>
        [Test]
        public void VerifierValiderOtp_ParametreValide_Ok()
        {
            this.service.ValiderOtp(identite, "login", 1);

            this.briquesServicesExterne.Verify(x => x.AuthentificationServiceExterne.ValiderOtp(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>()));
        }

        #endregion ValiderOtp

        #region Test de la méthode CreerDemandeRetractation

        /// <summary>
        /// Test de la méthode de creation de demande de retractation.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_ParametreOK_OK()
        {

            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeRetractationPourCreation informationsRetractation = new Interface.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = true,
                TiersEnvoiBonRetour = new Interface.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourDetail()
                    {
                        CodePostal = "59000",
                        Complement = "APT 59",
                        Ville = "LILLE",
                        Voie = "RUE DE LILLE"
                    },
                    Civilite = Civilite.M,
                    Nom = "NOM",
                    Prenom = "PRENOM"
                }
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeRetractation(this.identite, this.CleLigneValide, informationsRetractation);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode Retractation avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeRetractationPourCreation informationsRetractation = new Interface.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = true,
                TiersEnvoiBonRetour = new Interface.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourDetail()
                    {
                        CodePostal = "59000",
                        Complement = "APT 59",
                        Ville = "LILLE",
                        Voie = "RUE DE LILLE"
                    },
                    Civilite = Civilite.M,
                    Nom = "NOM",
                    Prenom = "PRENOM"
                }
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeRetractation(null, this.CleLigneValide, informationsRetractation);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Retractation avec la cle de ligne invalide. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_CleLigneInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);
            Interface.DTO.DemandeRetractationPourCreation informationsRetractation = new Interface.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = null
            };

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeRetractation(this.identite, -1, informationsRetractation);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode Retractation avec les informations null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_DemandeRetractationPourCreationNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.CreerDemandeRetractation(this.identite, this.CleLigneValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode CreerDemandeRetractation

        #region ObtenirLigneDepuisCleTiers
        /// <summary>
        /// Test de la méthode ObtenirLigneDepuisCleTiers avec identité Nulle. 
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisCleTiers_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisCleTiers(null, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirLigneDepuisCleTiers avec clé tiers Nulle. 
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisCleTiers_CleTiersNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisCleTiers(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirLigneDepuisCleTiers avec clé tiers négative. 
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisCleTiers_CleTiersNegative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisCleTiers(this.identite, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirLigneDepuisCleTiers avec parametres ok. 
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisCleTiers_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisCleTiers(this.identite, 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ObtenirLigneDepuisCleTiers avec . 
        /// </summary>
        [Test]
        public void VerifierObtenirLigneDepuisCleTiers_ParametreValide_OK()
        {
            LignePourDetail reponse = this.service.ObtenirLigneDepuisCleTiers(this.identite, 1);


            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCleTiers(It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirTechnologieParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identite, It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(It.IsAny<Identite>(), It.IsAny<long>()));

            //Assert
            Assert.IsNotNull(reponse);
            Assert.IsNotNull(reponse.AdresseInstallation);
            Assert.AreEqual(reponse.AdresseInstallation.Cle, 1);
            Assert.AreEqual(reponse.AdresseInstallation.CodePostal, "59000");
            Assert.IsNull(reponse.AdresseInstallation.Complement);
            Assert.AreEqual(reponse.AdresseInstallation.Numero, "11");
            Assert.AreEqual(reponse.AdresseInstallation.Rue, "test");
            Assert.AreEqual(reponse.AdresseInstallation.Ville, "test");

            Assert.AreEqual(reponse.Cle, 1);
            Assert.AreEqual(reponse.Etat, EtatLigne.Activee);
            Assert.AreEqual(reponse.Numero, "0123456789");
            Assert.AreEqual(reponse.Offre, "Nom");
            Assert.AreEqual(reponse.ReferenceExterne, "123456789");
            Assert.AreEqual(reponse.Technologie, "technologie");

            Assert.IsNotNull(reponse.Tiers);
            Assert.AreEqual(reponse.Tiers.AgeCalcule, 7);
            Assert.AreEqual(reponse.Tiers.Civilite, Civilite.M);
            Assert.IsNotNull(reponse.Tiers.Cle);
            Assert.IsNotNull(reponse.Tiers.DepartementNaissance);
            Assert.AreEqual(reponse.Tiers.Email, "test@test.fr");
            Assert.AreEqual(reponse.Tiers.EstContactCourrierPossible, false);
            Assert.AreEqual(reponse.Tiers.EstContactEmailPossible, false);
            Assert.AreEqual(reponse.Tiers.EstContactMessageVocalPossible, false);
            Assert.AreEqual(reponse.Tiers.EstContactSmsPossible, false);
            Assert.AreEqual(reponse.Tiers.EstContactTeleventePossible, false);
            Assert.AreEqual(reponse.Tiers.Nom, "Nom");
            Assert.AreEqual(reponse.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(reponse.Tiers.NumeroTelephoneFixeContact, "0123456789");
            Assert.AreEqual(reponse.Tiers.Prenom, "Prenom");

            Assert.IsNotNull(reponse.Tiers.AdressePrincipale);
            Assert.AreEqual(reponse.Tiers.AdressePrincipale.CodePostal, "CodePostal");
            Assert.AreEqual(reponse.Tiers.AdressePrincipale.Complement, "ComplementIdentification");
            Assert.AreEqual(reponse.Tiers.AdressePrincipale.Ville, "Ville");
            Assert.AreEqual(reponse.Tiers.AdressePrincipale.Voie, "Voie");
            Assert.AreEqual(reponse.CleMarque, 1);

        }
        #endregion ObtenirLigneDepuisCleTiers

        #region ObtenirInformationsLignePourRioParNumeroLigne
        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRioParNumeroLigne avec identité Nulle. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRioParNumeroLigne_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourRioParNumeroLigne(null, "numeroLigne");

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRioParNumeroLigne avec numero ligne Nulle. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRioParNumeroLigne_CleTiersNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourRioParNumeroLigne(this.identite, string.Empty);

            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRioParNumeroLigne avec parametres ok. 
        /// </summary>
        [Test]
        public void ObtenirInformationsLignePourRioParNumeroLigne_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ObtenirInformationsLignePourRioParNumeroLigne(this.identite, "numeroLigne");

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ObtenirInformationsLignePourRioParNumeroLigne avec . 
        /// </summary>
        [Test]
        public void VerifierObtenirInformationsLignePourRioParNumeroLigne_ParametreValide_OK()
        {
            InformationsLignePourSviRio reponse = this.service.ObtenirInformationsLignePourRioParNumeroLigne(this.identite, "numeroLigne");

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));
            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identite, It.IsAny<long>()));

            //Assert
            Assert.IsNotNull(reponse);
            Assert.AreEqual(reponse.CleLigne, 1);
            Assert.AreEqual(reponse.CleMarque, 1);
            Assert.AreEqual(reponse.NumeroMobileContactTiers, "0123456789");
            Assert.AreEqual(reponse.Rio, "rio");
        }
        #endregion ObtenirInformationsLignePourRioParNumeroLigne

        #region EnvoyerRioParSms
        /// <summary>
        /// Test de la méthode EnvoyerRioParSms avec identité Nulle. 
        /// </summary>
        [Test]
        public void EnvoyerRioParSms_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.EnvoyerRioParSms(null, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParSms avec clé tiers Nulle. 
        /// </summary>
        [Test]
        public void EnvoyerRioParSms_CleTiersNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.EnvoyerRioParSms(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParSms avec clé tiers négative. 
        /// </summary>
        [Test]
        public void EnvoyerRioParSms_CleTiersNegative_ExceptionLevee()
        {
            TestDelegate action = () => this.service.EnvoyerRioParSms(this.identite, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParSms avec parametres ok. 
        /// </summary>
        [Test]
        public void EnvoyerRioParSms_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.EnvoyerRioParSms(this.identite, 1);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode EnvoyerRioParSms avec tous les parametres ok. 
        /// </summary>
        [Test]
        public void VerifierEnvoyerRioParSms_ParametreValide_OK()
        {
            this.service.EnvoyerRioParSms(this.identite, 1);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));

            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));

            this.briquesServicesExterne.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identite, It.IsAny<long>()));

            this.briquesServicesExterne.Verify(s => s.CommunicationClientServiceExterne.EnvoyerSmsConfirmationRio(It.IsAny<Identite>(), It.IsAny<ParametresSmsRio>()));
        }

        #endregion EnvoyerRioParSms

        #region ChangerMotDePasseSelfcare
        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec identité Nulle. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_IdentiteNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(null, "login", "ancienMotDePasse", "nouveauMotDePasse");

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec login Nulle. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_LoginNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, string.Empty, "ancienMotDePasse", "nouveauMotDePasse");

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec ancien mot de passe nulle. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_AncienMotDePasseNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, "login", string.Empty, "nouveauMotDePasse");

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec nouveau mot de passe nulle. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_NouveauMotDePasseNulle_ExceptionLevee()
        {
            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, "login", "ancienMotDePasse", string.Empty);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec parametres ok. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_ParametreValide_Ok()
        {
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(reponseModificationMotDePasse);

            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, "login", "ancienMotDePasse", "nouveauMotDePasse");

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec parametres ok. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_ParametreValide_ReponseModifier_LeveException()
        {
            reponseModificationMotDePasse.EstModifie = false;

            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(reponseModificationMotDePasse);

            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, "login", "ancienMotDePasse", "nouveauMotDePasse");

            Assert.That(action, Throws.Exception);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec parametres ok. 
        /// </summary>
        [Test]
        public void ChangerMotDePasseSelfcare_ParametreValide_ReponseCode200_LeveException()
        {
            reponseModificationMotDePasse.EstModifie = false;
            reponseModificationMotDePasse.CodeErreur = 200;

            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(reponseModificationMotDePasse);

            TestDelegate action = () => this.service.ChangerMotDePasseSelfcare(identite, "login", "ancienMotDePasse", "nouveauMotDePasse");

            Assert.That(action, Throws.Exception);
        }

        /// <summary>
        /// Test de la méthode ChangerMotDePasseSelfcare avec parametres ok. 
        /// </summary>
        [Test]
        public void VerifyChangerMotDePasseSelfcare_ParametreValide_Ok()
        {
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(reponseModificationMotDePasse);

            this.service.ChangerMotDePasseSelfcare(identite, "login", "ancienMotDePasse", "nouveauMotDePasse");

            this.briquesServicesExterne.Verify(x => x.AuthentificationServiceExterne.ChangerMotDePasseSelfcare(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));

        }
        #endregion ChangerMotDePasseSelfcare

        #region Test de la méthode ValiderCguFixe
        /// <summary>
        /// Test de la méthode de validation des CGU Fixe.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void ValiderCguFixe_ParametreOK_OK()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            Mock<IBriquesServicesExternes> briqueServiceExterneMock = new Mock<IBriquesServicesExternes>();
            briqueServiceExterneMock.Setup(r => r.AuthentificationServiceExterne.ValiderCguFixe(It.IsAny<Identite>(), It.IsAny<string>()));

            // Act.
            TestDelegate action = () => ligneService.ValiderCguFixe(this.identite, this.EmailValide);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode de validation des CGU Fixe avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderCguFixe_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderCguFixe(null, this.EmailValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de validation des CGU Fixe avec la cle de ligne invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderCguFixe_LoginInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderCguFixe(this.identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test de la méthode ValiderCguFixe

        #region Test de la méthode ValiderCguMobile
        /// <summary>
        /// Test de la méthode de validation des CGU Mobile.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void ValiderCguMobile_ParametreOK_OK()
        {

            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);


            Mock<IBriquesServicesExternes> briqueServiceExterneMock = new Mock<IBriquesServicesExternes>();
            briqueServiceExterneMock.Setup(r => r.AuthentificationServiceExterne.ValiderCguMobile(It.IsAny<Identite>(), It.IsAny<string>()));

            // Act.
            TestDelegate action = () => ligneService.ValiderCguMobile(this.identite, this.EmailValide);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode de validation des CGU Mobile avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderCguMobile_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderCguMobile(null, this.EmailValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de validation des CGU Mobile avec la cle de ligne invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderCguMobile_LoginInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderCguMobile(this.identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test de la méthode ValiderCguMobile

        #region Test de la méthode ValiderParcoursBienvenue
        /// <summary>
        /// Test de la méthode de validation du parcours de bienvenue SFC.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void ValiderParcoursBienvenue_ParametreOK_OK()
        {
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(ligneMock.Object);
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);


            Mock<IBriquesServicesExternes> briqueServiceExterneMock = new Mock<IBriquesServicesExternes>();
            briqueServiceExterneMock.Setup(r => r.AuthentificationServiceExterne.ValiderParcoursBienvenue(It.IsAny<Identite>(), It.IsAny<string>()));

            // Act.
            TestDelegate action = () => ligneService.ValiderParcoursBienvenue(this.identite, this.EmailValide, this.referenceExterne);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode de validation du parcours de bienvenue SFC avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderParcoursBienvenue_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderParcoursBienvenue(null, this.EmailValide, this.referenceExterne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de validation du parcours de bienvenue SFC avec le login invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderParcoursBienvenue_LoginInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderParcoursBienvenue(this.identite, null, this.referenceExterne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de validation du parcours de bienvenue SFC avec la référence externe invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ValiderParcoursBienvenue_ReferenceExterneInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ValiderParcoursBienvenue(this.identite, this.EmailValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test de la méthode ValiderParcoursBienvenue

        #region Test de la méthode CreerCompteMyPartnerTv
        /// <summary>
        /// Test de la méthode de création d'un compte My Partner TV.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void CreerCompteMyPartnerTv_ParametreOK_OK()
        {

            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);


            Mock<IBriquesServicesExternes> briqueServiceExterneMock = new Mock<IBriquesServicesExternes>();
            briqueServiceExterneMock.Setup(r => r.SfrFixeCompteTvServiceExterne.CreerCompteMyPartnerTv(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>()));

            // Act.
            TestDelegate action = () => ligneService.CreerCompteMyPartnerTv(this.identite, this.referenceExterne, "monIdentifiant");

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode de création d'un compte My Partner TV avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerCompteMyPartnerTv_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.CreerCompteMyPartnerTv(null, this.referenceExterne, "monIdentifiant");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de création d'un compte My Partner TV avec la référence externe invalide. Lève une exception.
        /// </summary>
        [Test]
        public void CreerCompteMyPartnerTv_ReferenceExterneInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.CreerCompteMyPartnerTv(this.identite, null, "monIdentifiant");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de création d'un compte My Partner TV avec l'identifiant invalide. Lève une exception.
        /// </summary>
        [Test]
        public void CreerCompteMyPartnerTv_IdentifiantInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.CreerCompteMyPartnerTv(this.identite, this.referenceExterne, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test de la méthode CreerCompteMyPartnerTv

        #region Test de la méthode ModifierMotDePasseMyPartnerTv
        /// <summary>
        /// Test de la méthode de modification du mot de passe d'un compte My Partner TV.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void ModifierMotDePasseMyPartnerTv_ParametreOK_OK()
        {

            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);


            Mock<IBriquesServicesExternes> briqueServiceExterneMock = new Mock<IBriquesServicesExternes>();
            briqueServiceExterneMock.Setup(r => r.SfrFixeCompteTvServiceExterne.ModifierMotDePasseMyPartnerTv(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>()));

            // Act.
            TestDelegate action = () => ligneService.ModifierMotDePasseMyPartnerTv(this.identite, this.referenceExterne, "motDePasse");
            service.ModifierMotDePasseMyPartnerTv(this.identite, this.referenceExterne, "monIdentifiant");

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode de modification du mot de passe d'un compte My Partner TV avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ModifierMotDePasseMyPartnerTv_IdentiteNull_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ModifierMotDePasseMyPartnerTv(null, this.referenceExterne, "monIdentifiant");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de modification du mot de passe d'un compte My Partner TV avec la référence externe invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ModifierMotDePasseMyPartnerTv_ReferenceExterneInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ModifierMotDePasseMyPartnerTv(this.identite, null, "monIdentifiant");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode de modification du mot de passe d'un compte My Partner TV avec le mot de passe invalide. Lève une exception.
        /// </summary>
        [Test]
        public void ModifierMotDePasseMyPartnerTv_MotDePasseInvalide_LeveException()
        {
            LigneService ligneService = new LigneService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.serviceTechnique.Object);

            // Act.
            TestDelegate action = () => ligneService.ModifierMotDePasseMyPartnerTv(this.identite, this.referenceExterne, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test de la méthode ModifierMotDePasseMyPartnerTv

        #region Test ListerLignesDepuisClesLignes
        /// <summary>
        /// ListerLignesDepuisClesLignes avec identite null.
        /// </summary>
        [Test]
        public void ListerLignesDepuisClesLignes_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerLignesDepuisClesLignes(null, this.tableauCle);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ListerLignesDepuisClesLignes avec la liste des cles null.
        /// </summary>
        [Test]
        public void ListerLignesDepuisClesLignes_ListeCleNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerLignesDepuisClesLignes(this.identite, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ListerLignesDepuisClesLignes.
        /// </summary>
        [Test]
        public void ListerLignesDepuisClesLignes_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ListerLignesDepuisClesLignes(this.identite, this.tableauCle);

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// ListerLignesDepuisClesLignes.
        /// </summary>
        [Test]
        public void VerifierListerLignesDepuisClesLignes_ParametreValide_OK()
        {
            LignePourDetail[] reponse = this.service.ListerLignesDepuisClesLignes(this.identite, this.tableauCle);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>()));

            Assert.AreEqual(reponse.Length, 1);
            LignePourDetail lignePourDetail = reponse.First();
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Cle, 1);
            Assert.AreEqual(lignePourDetail.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Numero, "11");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Rue, "test");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Ville, "test");

            Assert.AreEqual(lignePourDetail.Cle, this.ligne.Cle);
            Assert.AreEqual(lignePourDetail.DateFinEngagement, this.ligne.DateFinEngagement);
            Assert.AreEqual(lignePourDetail.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(lignePourDetail.Numero, this.ligne.Numero);
            Assert.AreEqual(lignePourDetail.Offre, "Nom");
            Assert.AreEqual(lignePourDetail.ReferenceExterne, this.ligne.ReferenceExterne);
            Assert.AreEqual(lignePourDetail.Technologie, "technologie");

            Assert.AreEqual(lignePourDetail.Tiers.Civilite, Civilite.M);
            Assert.AreEqual(lignePourDetail.Tiers.Cle, 1);
            Assert.AreEqual(lignePourDetail.Tiers.DateNaissance, new DateTime(2010, 11, 12));
            Assert.AreEqual(lignePourDetail.Tiers.DepartementNaissance, "50");
            Assert.AreEqual(lignePourDetail.Tiers.Email, "test@test.fr");
            Assert.AreEqual(lignePourDetail.Tiers.Nom, "Nom");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneFixeContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.Prenom, "Prenom");
        }
        #endregion Test ListerLignesDepuisClesLignes

        #region Test ObtenirLigneDepuisReferenceExterne
        /// <summary>
        /// ObtenirLigneDepuisReferenceExterne avec identite null.
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisReferenceExterne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisReferenceExterne(null, this.referenceExterne);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ObtenirLigneDepuisReferenceExterne avec reference externe null.
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisReferenceExterne_ReferenceExterneNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisReferenceExterne(this.identite, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ObtenirLigneDepuisReferenceExterne.
        /// </summary>
        [Test]
        public void ObtenirLigneDepuisReferenceExterne_ParametreValide_OK()
        {
            TestDelegate action = () => this.service.ObtenirLigneDepuisReferenceExterne(this.identite, "refext");

            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// ObtenirLigneDepuisReferenceExterne.
        /// </summary>
        [Test]
        public void VerifierObtenirLigneDepuisReferenceExterne_ParametreValide_OK()
        {
            LignePourDetail lignePourDetail = this.service.ObtenirLigneDepuisReferenceExterne(this.identite, "123456789");

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>()));

            Assert.AreEqual(lignePourDetail.AdresseInstallation.Cle, 1);
            Assert.AreEqual(lignePourDetail.AdresseInstallation.CodePostal, "59000");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Numero, "11");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Rue, "test");
            Assert.AreEqual(lignePourDetail.AdresseInstallation.Ville, "test");

            Assert.AreEqual(lignePourDetail.Cle, this.ligne.Cle);
            Assert.AreEqual(lignePourDetail.DateFinEngagement, this.ligne.DateFinEngagement);
            Assert.AreEqual(lignePourDetail.Etat, this.ligne.ValeurEtat);
            Assert.AreEqual(lignePourDetail.Numero, this.ligne.Numero);
            Assert.AreEqual(lignePourDetail.Offre, "Nom");
            Assert.AreEqual(lignePourDetail.ReferenceExterne, this.ligne.ReferenceExterne);
            Assert.AreEqual(lignePourDetail.Technologie, "technologie");

            Assert.AreEqual(lignePourDetail.Tiers.Civilite, Civilite.M);
            Assert.AreEqual(lignePourDetail.Tiers.Cle, 1);
            Assert.AreEqual(lignePourDetail.Tiers.DateNaissance, new DateTime(2010, 11, 12));
            Assert.AreEqual(lignePourDetail.Tiers.DepartementNaissance, "50");
            Assert.AreEqual(lignePourDetail.Tiers.Email, "test@test.fr");
            Assert.AreEqual(lignePourDetail.Tiers.Nom, "Nom");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.NumeroTelephoneFixeContact, "0123456789");
            Assert.AreEqual(lignePourDetail.Tiers.Prenom, "Prenom");
        }

        #endregion Test ObtenirLigneDepuisReferenceExterne

        #region Test RechercherCleLigneDepuisReferenceExterne

        /// <summary>
        /// RechercherCleLigneDepuisReferenceExterne avec une identite null.
        /// </summary>
        [Test]
        public void RechercherCleLigneDepuisReferenceExterne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.RechercherCleLigneDepuisReferenceExterne(null, this.referenceExterne);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// RechercherCleLigneDepuisReferenceExterne avec une reference externe null.
        /// </summary>
        [Test]
        public void RechercherCleLigneDepuisReferenceExterne_ReferenceExterneNull_LeveException()
        {
            TestDelegate action = () => this.service.RechercherCleLigneDepuisReferenceExterne(this.identite, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// RechercherCleLigneDepuisReferenceExterne avec une reference externe ne correspondant pas à une ligne, retourne null.
        /// </summary>
        [Test]
        public void RechercherLigneDepuisReferenceExterne_ParametreValide_ReferenceExterneNonExistante()
        {
            string referenceExterne = "Inconnu";
            long? lignePourDetail = this.service.RechercherCleLigneDepuisReferenceExterne(this.identite, referenceExterne);

            this.repositories.Verify(x => x.LigneRepository.RechercherParReferenceExterne(referenceExterne));

            Assert.IsNull(lignePourDetail);
        }

        /// <summary>
        /// RechercherCleLigneDepuisReferenceExterne avec une reference externe correspondant à une ligne, retourne une clé valide.
        /// </summary>
        [Test]
        public void RechercherCleLigneDepuisReferenceExterne_ParametreValide_ReferenceExterneExistante()
        {
            string referenceExterne = this.referenceExterne;
            long? lignePourDetail = this.service.RechercherCleLigneDepuisReferenceExterne(this.identite, referenceExterne);

            this.repositories.Verify(x => x.LigneRepository.RechercherParReferenceExterne(referenceExterne));

            Assert.AreEqual(1, lignePourDetail);
        }

        #endregion  Test RechercherCleLigneDepuisReferenceExterne

        #region Test RechercherInfoDossierGboParCleDossier
        /// <summary>
        /// RechercherInfoDossierGboParCleDossier avec des paramètres valides et une ligne existante pour la clé de dossier
        /// </summary>
        [Test]
        public void RechercherInfoDossierGboParCleDossier_ParametreValide_OK()
        {
            InfoDossierGboPourDetail infoDossierGbo = null;

            Assert.DoesNotThrow(() =>  infoDossierGbo = this.service.RechercherInfoDossierGboParCleDossier(this.identite, this.CleDossierGboValide));
            Assert.IsNotNull(infoDossierGbo);
        }

        /// <summary>
        /// RechercherInfoDossierGboParCleDossier avec des paramètres valides et une ligne inexistante pour la clé de dossier
        /// </summary>
        [Test]
        public void RechercherInfoDossierGboParCleDossier_ParametreValide_LigneInexistante_OK()
        {
            InfoDossierGboPourDetail infoDossierGbo = null;

            Assert.DoesNotThrow(() =>  infoDossierGbo = this.service.RechercherInfoDossierGboParCleDossier(this.identite, this.CleDossierGboSansLigne));
            Assert.IsNotNull(infoDossierGbo);
        }

        #endregion


        #region Test RechercherInfoDossierGboParListeCleDossier

        /// <summary>
        /// RechercherInfoDossierGboParListeCleDossier avec des paramètres valides
        /// </summary>
        [Test]
        public void RechercherInfoDossierGboParListeCleDossier_ParametreValide_OK()
        {
            List<InfoDossierGboPourListe> ListeInfoDossierGbo = null;
            var listeClesDossiersGbo = new[] {this.CleDossierGboValide, this.CleDossierGboSansLigne}.ToList();
            
            List<HistoriqueDossierGboLigne> listeHistorique = new List<HistoriqueDossierGboLigne>();
            listeHistorique.Add(new HistoriqueDossierGboLigne(this.identite, 1L, this.referenceExterne, this.CleDossierGboValide));
            listeHistorique.Add(new HistoriqueDossierGboLigne(this.identite, 2L, this.referenceExterne, this.CleDossierGboSansLigne));

            this.repositories.Setup(x => x.HistoriqueDossierGboLigneRepository.RechercherParListeCleDossier(listeClesDossiersGbo)).Returns(listeHistorique);

            Assert.DoesNotThrow(() =>
                ListeInfoDossierGbo = this.service.RechercherInfoDossierGboParListeCleDossier(this.identite, listeClesDossiersGbo));
            Assert.IsNotNull(ListeInfoDossierGbo);
            Assert.IsTrue(ListeInfoDossierGbo.Any());
            Assert.AreEqual(this.CleDossierGboValide, ListeInfoDossierGbo[0].CleDossier);
            Assert.AreEqual(this.CleDossierGboSansLigne, ListeInfoDossierGbo[1].CleDossier);
        }

        #endregion
    }
}
