﻿using System;
using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Classe de test du service Tiers.
    /// </summary>
    [TestFixture]
    public class TiersServiceTest
    {
        #region Propriétés 

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private Mock<IServicesTechniques> servicesTechniques { get; set; }

        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Clé valide d'un tiers.
        /// </summary>
        private int CleTiersValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Clé valide d'une ligne.
        /// </summary>
        private int CleLigneValide
        {
            get
            {
                return 10;
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identiteValide = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserRepositories();
        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.repositories.Setup(x => x.LigneRepository).Returns(ligneRepository.Object);

            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide)).Returns(new Mock<Ligne>().Object);
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();

            this.servicesExternes.Setup(x => x.HistoriqueServiceExterne).Returns(new Mock<IHistoriqueServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne).Returns(new Mock<IReferentielServiceExterne>().Object);

            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(this.identiteValide, It.IsAny<int>())).Returns(new Mock<Domain.CommonTypes.DTO.Marque>().Object);
            this.servicesExternes.Setup(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identiteValide, this.CleLigneValide, It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
            Mock<ITiersServiceExterne> tierServiceExterne = new Mock<ITiersServiceExterne>();
            this.briquesExternes.Setup(x => x.TiersServiceExterne).Returns(tierServiceExterne.Object);
            this.briquesExternes.Setup(x => x.TiersServiceExterne.ObtenirParCle(this.identiteValide, this.CleTiersValide)).Returns(new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
            {
                Cle = this.CleTiersValide,
                ListeAdresses = new List<Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers>()
                {
                    new Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers()
                    {
                        CodePostal = "CodePostal",
                        ComplementIdentification = "Complement",
                        Ville = "Ville",
                        Voie = "Voie",
                        EstPrincipale = true
                    }
                }
            });

            Mock<ICommunicationClientServiceExterne> communicationClientServiceExterne = new Mock<ICommunicationClientServiceExterne>();
            this.briquesExternes.Setup(x => x.CommunicationClientServiceExterne).Returns(communicationClientServiceExterne.Object);
            this.briquesExternes.Setup(x => x.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementEmail(this.identiteValide, It.IsAny<Domain.CommonTypes.DTO.CommunicationClientServiceExterne.ParametresChangement>()));


            this.briquesExternes.Setup(s => s.TiersServiceExterne.ObtenirParCle(this.identiteValide, this.CleTiersValide)).Returns(new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail
            {
                Cle = this.CleTiersValide,
                NumeroMobileDeContact = "0656988754",
                Civilite = Fixe.Domain.CommonTypes.Civilite.M,
                VilleNaissance = "Lille",
                EmailContact = "test@test.com",
                NumeroFixeDeContact = "0365322154",
                ListeAdresses=new List<Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers>
                {
                    new Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers
                    {
                        EstPrincipale=true,
                        Cle=1,
                        CodePostal="59000",
                         Ville="Lille",
                         Voie="Rue Solférino"
                    }
                }
            });
        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        #endregion Méthodes d'initialisation et de vérification

        #region Tests de l'initialisation du service

        /// <summary>
        /// Test du constructeur de TiersService dans le cas ou l'interface des repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void TiersService_RepositoriesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de TiersService dans le cas ou l'interface des services externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void TiersService_ServiceExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new TiersService(this.briquesExternes.Object, null, this.repositories.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de TiersService dans le cas ou l'interface des briques externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void TiersService_BriquesExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new TiersService(null, this.servicesExternes.Object, this.repositories.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de TiersService dans le cas ou le repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void TiersService_ParametresOK_OK()
        {
            // Act.
            TestDelegate action = () => new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de l'initialisation du service

        #region Tests de la méthode EnregistrerInformationsTitulaireLigne

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_IdentiteNull_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(null, this.CleTiersValide, this.CleLigneValide, informationsTitulaireLigne);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où la CleTiers est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_CleTierAZero_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, 0, this.CleLigneValide, informationsTitulaireLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où la CleTiers est négative. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_CleTierNegative_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, -400, this.CleLigneValide, informationsTitulaireLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où la CleLigne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_CleLigneAZero_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, this.CleTiersValide, 0, informationsTitulaireLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où la CleLigne est négative. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_CleLigneNegative_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, this.CleTiersValide, -400, informationsTitulaireLigne);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas où le paramètre InformationsTitulaireLigne est null. Lève une exception.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_InformationsTitulaireLigneNull_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            TestDelegate action = () => tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, this.CleTiersValide, this.CleLigneValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la méthode EnregistrerInformationsTitulaireLigne dans le cas les paramètres sont valide.
        /// </summary>
        [Test]
        public void EnregistrerInformationsTitulaireLigne_ParametresOK_OK()
        {

            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
            Interface.DTO.InformationsTitulaireLignePourModification informationsTitulaireLigne = new Interface.DTO.InformationsTitulaireLignePourModification()
            {
                Email = "Email@Valide.com",
                TelephoneFixe = "0303030303",
                TelephoneMobile = "0606060606"
            };

            // Act.
            tiersService.EnregistrerInformationsTitulaireLigne(this.identiteValide, this.CleTiersValide, this.CleLigneValide, informationsTitulaireLigne);

            // Assert.

        }

        #endregion Tests de la méthode EnregistrerInformationsTitulaireLigne

        #region Tests de la méthode ObtenirDetailTitulaireLigneParCleTiers

        /// <summary>
        /// Test de la méthode ObtenirDetailTitulaireLigneParCleTiers dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailTitulaireLigneParCleTiers_IdentiteNull_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            TestDelegate action = () => tiersService.ObtenirDetailTitulaireLigneParCleTiers(null, this.CleTiersValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailTitulaireLigneParCleTiers dans le cas où la CleTiers est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailTitulaireLigneParCleTiers_CleTierAZero_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            TestDelegate action = () => tiersService.ObtenirDetailTitulaireLigneParCleTiers(this.identiteValide, 0);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailTitulaireLigneParCleTiers dans le cas où la CleTiers est négative. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirDetailTitulaireLigneParCleTiers_CleTierNegative_LeveException()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            TestDelegate action = () => tiersService.ObtenirDetailTitulaireLigneParCleTiers(this.identiteValide, -400);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirDetailTitulaireLigneParCleTiers dans le cas les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirDetailTitulaireLigneParCleTiers_ParametresOK_OK()
        {
            // Arrange.
            TiersService tiersService = new TiersService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            tiersService.ObtenirDetailTitulaireLigneParCleTiers(this.identiteValide, this.CleTiersValide);

            // Assert.
            this.briquesExternes.Verify(x => x.TiersServiceExterne.ObtenirParCle(this.identiteValide, this.CleTiersValide));
        }

        #endregion Tests de la méthode ObtenirDetailTitulaireLigneParCleTiers
    }
}
