﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Castle.Components.DictionaryAdapter;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Souscription.Domain.ExternalServices;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using IHistoriqueServiceExterne = EIT.Fixe.VieClient.Domain.ServiceExterne.IHistoriqueServiceExterne;
using IReferentielServiceExterne = EIT.Fixe.VieClient.Domain.ServiceExterne.IReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Tests de la classe FormulaireGboService
    /// </summary>
    [TestFixture]
    public class FormulaireGboServiceTest
    {

        private Identite identite;
        private IFormulaireGboService service;
        private Mock<IRepositories> repositories;
        private Mock<IServicesTechniques> servicesTechniques;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;

        private DateTime DateTimeNow = DateTime.Now;
        private string ReferenceExterneValide = "THD0123456789";
        private string ReferenceExterneInvalide = "THD987654321";

        private MotifDysfonctionnement MotifDysfonctionnement_1, MotifDysfonctionnement_2;
        private MotifQualification MotifQualification_1, MotifQualification_2;
        private NatureDemandeIntervention NatureDemandeIntervention_1, NatureDemandeIntervention_2;
        private OrigineDysfonctionnement OrigineDysfonctionnement_1, OrigineDysfonctionnement_2;
        private RegionCDC RegionCDC_1, RegionCDC_2;

        private Domain.Entities.TableParametrageGBO.MotifDysfonctionnement MotifDysfonctionnement_Domain_1, MotifDysfonctionnement_Domain_2;
        private Domain.Entities.TableParametrageGBO.MotifQualification MotifQualification_Domain_1, MotifQualification_Domain_2;
        private Domain.Entities.TableParametrageGBO.NatureDemandeIntervention NatureDemandeIntervention_Domain_1, NatureDemandeIntervention_Domain_2;
        private Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement OrigineDysfonctionnement_Domain_1, OrigineDysfonctionnement_Domain_2;
        private Domain.Entities.TableParametrageGBO.RegionCDC RegionCDC_Domain_1, RegionCDC_Domain_2;

        private FormulaireGBO FormulaireGBO;
        private FormulaireCN2DI FormulaireCN2DI;
        private FormulaireCN3EQ FormulaireCN3EQ;
        private FormulaireMPS FormulaireMPS;
        private FormulaireRisqueResiliation FormulaireRisqueResiliation;

        private List<PieceJointeFormulaireGbo> ListePieceJointeFormulaireGbo;
        private PieceJointeFormulaireGbo PieceJointeFormulaireGbo_1, PieceJointeFormulaireGbo_2;

        private Domain.Entities.FormulaireGBO.FormulaireGBO FormulaireGBO_Domain;
        private Domain.Entities.FormulaireGBO.FormulaireCN2DI FormulaireCN2DI_Domain;
        private Domain.Entities.FormulaireGBO.FormulaireCN3EQ FormulaireCN3EQ_Domain;
        private Domain.Entities.FormulaireGBO.FormulaireMPS FormulaireMPS_Domain;

        private List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> ListePieceJointeFormulaireGbo_Domain;
        private Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation FormulaireRisqueResiliation_Domain;
        private Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo PieceJointeFormulaireGbo_Domain_1, PieceJointeFormulaireGbo_Domain_2;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            InitialiserObjets();
            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();
            this.InitialiserBriqueServiceExterne();
            
            this.InitialiserRepository();

            this.service = new FormulaireGboService(this.briquesServicesExterne.Object,this.servicesExternes.Object, this.repositories.Object, this.servicesTechniques.Object);
        }

        /// <summary>
        /// Initialisation des objets
        /// </summary>
        private void InitialiserObjets()
        {
            this.MotifDysfonctionnement_1 = GenererMotifDysfonctionnement(1);
            this.MotifDysfonctionnement_2 = GenererMotifDysfonctionnement(2);
            this.MotifQualification_1 = GenererMotifQualification(1);
            this.MotifQualification_2 = GenererMotifQualification(2);
            this.NatureDemandeIntervention_1 = GenererNatureDemandeIntervention(1);
            this.NatureDemandeIntervention_2 = GenererNatureDemandeIntervention(2);
            this.OrigineDysfonctionnement_1 = GenererOrigineDysfonctionnement(1);
            this.OrigineDysfonctionnement_2 = GenererOrigineDysfonctionnement(2);
            this.RegionCDC_1 = GenererRegionCDC(1);
            this.RegionCDC_2 = GenererRegionCDC(2);

            this.MotifDysfonctionnement_Domain_1 = GenererMotifDysfonctionnementDomain(1);
            this.MotifDysfonctionnement_Domain_2 = GenererMotifDysfonctionnementDomain(2);
            this.MotifQualification_Domain_1 = GenererMotifQualificationDomain(1);
            this.MotifQualification_Domain_2 = GenererMotifQualificationDomain(2);
            this.NatureDemandeIntervention_Domain_1 = GenererNatureDemandeInterventionDomain(1);
            this.NatureDemandeIntervention_Domain_2 = GenererNatureDemandeInterventionDomain(2);
            this.OrigineDysfonctionnement_Domain_1 = GenererOrigineDysfonctionnementDomain(1);
            this.OrigineDysfonctionnement_Domain_2 = GenererOrigineDysfonctionnementDomain(2);
            this.RegionCDC_Domain_1 = GenererRegionCDCDomain(1);
            this.RegionCDC_Domain_2 = GenererRegionCDCDomain(2);

            int idPieceJointeFormulaireGbo = 1;
            this.PieceJointeFormulaireGbo_1 = GenererPieceJointeFormulaireGbo(idPieceJointeFormulaireGbo++);
            this.PieceJointeFormulaireGbo_2 = GenererPieceJointeFormulaireGbo(idPieceJointeFormulaireGbo++);

            ListePieceJointeFormulaireGbo = new List<PieceJointeFormulaireGbo>();
            ListePieceJointeFormulaireGbo.Add(this.PieceJointeFormulaireGbo_1);
            ListePieceJointeFormulaireGbo.Add(this.PieceJointeFormulaireGbo_2);

            int idFormulaireGBO = 1;
            this.FormulaireGBO = GenererFormulaireGBO(idFormulaireGBO++, 1, this.RegionCDC_1, this.ReferenceExterneValide);
            this.FormulaireCN2DI = GenererFormulaireCN2DI(idFormulaireGBO++, 1, this.RegionCDC_1, this.ReferenceExterneValide, this.MotifDysfonctionnement_1, this.OrigineDysfonctionnement_1, ListePieceJointeFormulaireGbo);
            this.FormulaireCN3EQ = GenererFormulaireCN3EQ(idFormulaireGBO++, 1, this.RegionCDC_1, this.ReferenceExterneValide, this.NatureDemandeIntervention_1, ListePieceJointeFormulaireGbo);
            this.FormulaireMPS = GenererFormulaireMPS(idFormulaireGBO++, 1, this.RegionCDC_1, this.ReferenceExterneValide, ProfilSurconsommation.ClientStandard);
            this.FormulaireRisqueResiliation = GenererFormulaireRisqueResiliation(idFormulaireGBO++, 1, this.RegionCDC_1, this.ReferenceExterneValide, "Offre", this.MotifQualification_1, "Commentaire");

            int idPieceJointeFormulaireGbo_Domain = 1;
            this.PieceJointeFormulaireGbo_Domain_1 = GenererPieceJointeFormulaireGbo_Domain(idPieceJointeFormulaireGbo_Domain++);
            this.PieceJointeFormulaireGbo_Domain_2 = GenererPieceJointeFormulaireGbo_Domain(idPieceJointeFormulaireGbo_Domain++);

            ListePieceJointeFormulaireGbo_Domain =
                new List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();
            ListePieceJointeFormulaireGbo_Domain.Add(this.PieceJointeFormulaireGbo_Domain_1);
            ListePieceJointeFormulaireGbo_Domain.Add(this.PieceJointeFormulaireGbo_Domain_2);

            int idFormulaireGBODomain = 1;
            this.FormulaireGBO_Domain = GenererFormulaireGBO_Domain(idFormulaireGBODomain++, 1, this.RegionCDC_Domain_1, this.ReferenceExterneValide);
            this.FormulaireCN2DI_Domain = GenererFormulaireCN2DI_Domain(idFormulaireGBODomain++, 1, this.RegionCDC_Domain_1, this.ReferenceExterneValide, this.MotifDysfonctionnement_Domain_1, this.OrigineDysfonctionnement_Domain_1, ListePieceJointeFormulaireGbo_Domain);
            this.FormulaireCN3EQ_Domain = GenererFormulaireCN3EQ_Domain(idFormulaireGBODomain++, 1, this.RegionCDC_Domain_1, this.ReferenceExterneValide, this.NatureDemandeIntervention_Domain_1, ListePieceJointeFormulaireGbo_Domain);
            this.FormulaireMPS_Domain = GenererFormulaireMPS_Domain(idFormulaireGBODomain++, 1, this.RegionCDC_Domain_1, this.ReferenceExterneValide, this.DateTimeNow, ProfilSurconsommation.ClientStandard, "Commentaire");
            this.FormulaireRisqueResiliation_Domain = GenererFormulaireRisqueResiliation_Domain(idFormulaireGBODomain++, 1, this.RegionCDC_Domain_1, this.ReferenceExterneValide, "Offre", this.MotifQualification_Domain_1, "Commentaire");
        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            IGenerateurCles generateurCles = new GenerateurCles();
            Mock<Domain.ServiceExterne.IParametrage> parametrage = new Mock<Domain.ServiceExterne.IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            sourceDonnees.Add(this.MotifDysfonctionnement_1);
            sourceDonnees.Add(this.MotifDysfonctionnement_2);
            sourceDonnees.Add(this.MotifQualification_1);
            sourceDonnees.Add(this.MotifQualification_2);
            sourceDonnees.Add(this.NatureDemandeIntervention_1);
            sourceDonnees.Add(this.NatureDemandeIntervention_2);
            sourceDonnees.Add(this.OrigineDysfonctionnement_1);
            sourceDonnees.Add(this.OrigineDysfonctionnement_2);
            sourceDonnees.Add(this.RegionCDC_1);
            sourceDonnees.Add(this.RegionCDC_2);

            return sourceDonnees;
        }

        /// <summary>
        /// Initialisation du Repositorie
        /// </summary>
        private void InitialiserRepository()
        {
            Mock<IFormulaireGboRepository> FormulaireGboRepository = new Mock<IFormulaireGboRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.FormulaireGboRepository).Returns(FormulaireGboRepository.Object);

            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirMotifDysfonctionnementParCle(It.IsAny<long>())).Returns(this.MotifDysfonctionnement_Domain_1);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirMotifQualificationParCle(It.IsAny<long>())).Returns(this.MotifQualification_Domain_1);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirNatureDemandeInterventionParCle(It.IsAny<long>())).Returns(this.NatureDemandeIntervention_Domain_1);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirOrigineDysfonctionnementParCle(It.IsAny<long>())).Returns(this.OrigineDysfonctionnement_Domain_1);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirRegionCdcParCle(It.IsAny<long>())).Returns(this.RegionCDC_Domain_1);
            
            this.repositories.Setup(s => s.FormulaireGboRepository.ListerMotifDysfonctionnement()).Returns(new List<Domain.Entities.TableParametrageGBO.MotifDysfonctionnement>()
            {
                this.MotifDysfonctionnement_Domain_1,
                this.MotifDysfonctionnement_Domain_2
            });

            this.repositories.Setup(s => s.FormulaireGboRepository.ListerMotifQualification()).Returns(new List<Domain.Entities.TableParametrageGBO.MotifQualification>()
            {
                this.MotifQualification_Domain_1,
                this.MotifQualification_Domain_2
            });

            this.repositories.Setup(s => s.FormulaireGboRepository.ListerNatureDemandeIntervention()).Returns(new List<Domain.Entities.TableParametrageGBO.NatureDemandeIntervention>()
            {
                this.NatureDemandeIntervention_Domain_1,
                this.NatureDemandeIntervention_Domain_2
            });

            this.repositories.Setup(s => s.FormulaireGboRepository.ListerOrigineDysfonctionnement()).Returns(new List<Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement>()
            {
                this.OrigineDysfonctionnement_Domain_1,
                this.OrigineDysfonctionnement_Domain_2
            });

            this.repositories.Setup(s => s.FormulaireGboRepository.ListerRegionCdc()).Returns(new List<Domain.Entities.TableParametrageGBO.RegionCDC>()
            {
                this.RegionCDC_Domain_1,
                this.RegionCDC_Domain_2
            });

            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirFormulaireGboParCle(It.IsAny<long>())).Returns(this.FormulaireGBO_Domain);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirFormulaireCN2DiParCle(It.IsAny<long>())).Returns(this.FormulaireCN2DI_Domain);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirFormulaireCN3EqParCle(It.IsAny<long>())).Returns(this.FormulaireCN3EQ_Domain);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirFormulaireMpsParCle(It.IsAny<long>())).Returns(this.FormulaireMPS_Domain);
            this.repositories.Setup(s => s.FormulaireGboRepository.ObtenirFormulaireRisqueResiliationParCle(It.IsAny<long>())).Returns(this.FormulaireRisqueResiliation_Domain);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();
            Mock<IBriqueGboServiceExterne> briqueGboServiceExterne = new Mock<IBriqueGboServiceExterne>();
            Mock<IBriqueDataMartLigneServiceExterne> briqueDataMartLigneServiceExterne = new Mock<IBriqueDataMartLigneServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.BriqueGboServiceExterne).Returns(briqueGboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.BriqueDataMartLigneServiceExterne).Returns(briqueDataMartLigneServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(s => s.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(It.IsAny<Identite>(), this.ReferenceExterneValide)).Returns(true);
            this.briquesServicesExterne.Setup(s => s.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(It.IsAny<Identite>(), this.ReferenceExterneInvalide)).Returns(false);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();
            Mock<IGboServiceExterne> gboService = new Mock<IGboServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
            this.servicesExternes.Setup(s => s.GboServiceExterne).Returns(gboService.Object);
        }

        #region Test Constructeur

        /// <summary>
        /// Creation du service avec BriquesServicesExternes null.
        /// </summary>
        [Test]
        public void ConstruireFormulaireGboService_BriquesServicesExternesNull_LeveException()
        {

            TestDelegate action = () => new FormulaireGboService(null, this.servicesExternes.Object, this.repositories.Object, this.servicesTechniques.Object);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation du service avec ServicesExternes null.
        /// </summary>
        [Test]
        public void ConstruireFormulaireGboService_ServicesExternesNull_LeveException()
        {

            TestDelegate action = () => new FormulaireGboService(this.briquesServicesExterne.Object, null, this.repositories.Object, this.servicesTechniques.Object);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation du service avec repositories null.
        /// </summary>
        [Test]
        public void ConstruireFormulaireGboService_RepositoriesNull_LeveException()
        {

            TestDelegate action = () => new FormulaireGboService(this.briquesServicesExterne.Object, this.servicesExternes.Object, null, this.servicesTechniques.Object);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation du service avec ServiceTechnique null.
        /// </summary>
        [Test]
        public void ConstruireFormulaireGboService_ServicesTechniquesNull_LeveException()
        {

            TestDelegate action = () => new FormulaireGboService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation du service.
        /// </summary>
        [Test]
        public void ConstruireFormulaireGboService_ParametresValide_OK()
        {
            TestDelegate action = () => new FormulaireGboService(this.briquesServicesExterne.Object, this.servicesExternes.Object, this.repositories.Object, this.servicesTechniques.Object);

            Assert.That(action, Throws.Nothing);
        }

        #endregion Test Constructeur

        #region Méthodes - FormulaireGboService

        #region Tables de Paramétrage

        #region Utiles

        /// <summary>
        /// Générer un MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private MotifDysfonctionnement GenererMotifDysfonctionnement(long cle)
        {
            return new MotifDysfonctionnement
            {
                Cle = cle,
                Libelle = "MotifDysfonctionnement-" + cle
            };
        }

        /// <summary>
        /// Générer un MotifDysfonctionnement (Domain).
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Domain.Entities.TableParametrageGBO.MotifDysfonctionnement GenererMotifDysfonctionnementDomain(long cle)
        {
            MotifDysfonctionnement objetBase = GenererMotifDysfonctionnement(cle);
            return new Domain.Entities.TableParametrageGBO.MotifDysfonctionnement(this.identite, objetBase.Cle, objetBase.Libelle);
        }

        /// <summary>
        /// Générer un MotifQualification.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private MotifQualification GenererMotifQualification(long cle)
        {
            return new MotifQualification
            {
                Cle = cle,
                Libelle = "MotifQualification-" + cle
            };
        }

        /// <summary>
        /// Générer un MotifQualification (Domain).
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Domain.Entities.TableParametrageGBO.MotifQualification GenererMotifQualificationDomain(long cle)
        {
            MotifQualification objetBase = GenererMotifQualification(cle);
            return new Domain.Entities.TableParametrageGBO.MotifQualification(this.identite, objetBase.Cle, objetBase.Libelle);
        }

        /// <summary>
        /// Générer un NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private NatureDemandeIntervention GenererNatureDemandeIntervention(long cle)
        {
            return new NatureDemandeIntervention
            {
                Cle = cle,
                Libelle = "NatureDemandeIntervention-" + cle
            };
        }

        /// <summary>
        /// Générer un NatureDemandeIntervention (Domain).
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Domain.Entities.TableParametrageGBO.NatureDemandeIntervention GenererNatureDemandeInterventionDomain(long cle)
        {
            NatureDemandeIntervention objetBase = GenererNatureDemandeIntervention(cle);
            return new Domain.Entities.TableParametrageGBO.NatureDemandeIntervention(this.identite, objetBase.Cle, objetBase.Libelle);
        }

        /// <summary>
        /// Générer un OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private OrigineDysfonctionnement GenererOrigineDysfonctionnement(long cle)
        {
            return new OrigineDysfonctionnement
            {
                Cle = cle,
                Libelle = "OrigineDysfonctionnement-" + cle
            };
        }

        /// <summary>
        /// Générer un OrigineDysfonctionnement (Domain).
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement GenererOrigineDysfonctionnementDomain(long cle)
        {
            OrigineDysfonctionnement objetBase = GenererOrigineDysfonctionnement(cle);
            return new Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement(this.identite, objetBase.Cle, objetBase.Libelle);
        }

        /// <summary>
        /// Générer un RegionCDC.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private RegionCDC GenererRegionCDC(long cle)
        {
            return new RegionCDC
            {
                Cle = cle,
                Libelle = "RegionCDC-" + cle
            };
        }

        /// <summary>
        /// Générer un RegionCDC (Domain).
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Domain.Entities.TableParametrageGBO.RegionCDC GenererRegionCDCDomain(long cle)
        {
            RegionCDC objetBase = GenererRegionCDC(cle);
            return new Domain.Entities.TableParametrageGBO.RegionCDC(this.identite, objetBase.Cle, objetBase.Libelle);
        }

        #endregion Utiles

        #region MotifDysfonctionnement

        #region ObtenirMotifDysfonctionnementParCle

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirMotifDysfonctionnementParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirMotifDysfonctionnementParCle(null, cleInvalide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec la cle à z&ro.
        /// </summary>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirMotifDysfonctionnementParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_ParametreValide_OK()
        {
            MotifDysfonctionnement motifDysfonctionnement = this.service.ObtenirMotifDysfonctionnementParCle(this.identite, this.MotifDysfonctionnement_Domain_1.Cle);
            
            Assert.Multiple(() =>
            {
                Assert.AreEqual(motifDysfonctionnement.Cle, this.MotifDysfonctionnement_1.Cle, "Cle incorrecte");
                Assert.AreEqual(motifDysfonctionnement.Libelle, this.MotifDysfonctionnement_1.Libelle, "Libelle incorrecte");
            });
        }

        #endregion ObtenirMotifDysfonctionnementParCle

        #region ListerMotifDysfonctionnement

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ListerMotifDysfonctionnement_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerMotifDysfonctionnement(null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ListerMotifDysfonctionnement_ParametreValide_OK()
        {
            MotifDysfonctionnement[] tableauMotifDysfonctionnement = this.service.ListerMotifDysfonctionnement(this.identite);

            Assert.AreEqual(tableauMotifDysfonctionnement.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauMotifDysfonctionnement[0].Cle, this.MotifDysfonctionnement_1.Cle, "Cle incorrecte élément 1");
            Assert.AreEqual(tableauMotifDysfonctionnement[0].Libelle, this.MotifDysfonctionnement_1.Libelle, "Libelle incorrecte élément 1");
            Assert.AreEqual(tableauMotifDysfonctionnement[1].Cle, this.MotifDysfonctionnement_2.Cle, "Cle incorrecte élément 2");
            Assert.AreEqual(tableauMotifDysfonctionnement[1].Libelle, this.MotifDysfonctionnement_2.Libelle, "Libelle incorrecte élément 2");
        }

        #endregion ListerMotifDysfonctionnement

        #endregion MotifDysfonctionnement

        #region MotifQualification

        #region ObtenirMotifQualificationParCle

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirMotifQualificationParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirMotifQualificationParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirMotifQualificationParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirMotifQualificationParCle(null, cleInvalide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec la cle à z&ro.
        /// </summary>
        [Test]
        public void ObtenirMotifQualificationParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirMotifQualificationParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ObtenirMotifQualificationParCle_ParametreValide_OK()
        {
            MotifQualification motifQualification = this.service.ObtenirMotifQualificationParCle(this.identite, this.MotifQualification_Domain_1.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(motifQualification.Cle, this.MotifQualification_1.Cle, "Cle incorrecte");
                Assert.AreEqual(motifQualification.Libelle, this.MotifQualification_1.Libelle, "Libelle incorrecte");
            });
        }

        #endregion ObtenirMotifQualificationParCle

        #region ListerMotifQualification

        /// <summary>
        /// Recherche tous les MotifQualification avec l'identite null.
        /// </summary>
        [Test]
        public void ListerMotifQualification_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerMotifQualification(null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Recherche tous les MotifQualification avec l'identite null.
        /// </summary>
        [Test]
        public void ListerMotifQualification_ParametreValide_OK()
        {
            MotifQualification[] tableauMotifQualification = this.service.ListerMotifQualification(this.identite);

            Assert.AreEqual(tableauMotifQualification.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauMotifQualification[0].Cle, this.MotifQualification_1.Cle, "Cle incorrecte élément 1");
            Assert.AreEqual(tableauMotifQualification[0].Libelle, this.MotifQualification_1.Libelle, "Libelle incorrecte élément 1");
            Assert.AreEqual(tableauMotifQualification[1].Cle, this.MotifQualification_2.Cle, "Cle incorrecte élément 2");
            Assert.AreEqual(tableauMotifQualification[1].Libelle, this.MotifQualification_2.Libelle, "Libelle incorrecte élément 2");
        }

        #endregion ListerMotifQualification

        #endregion MotifQualification

        #region NatureDemandeIntervention

        #region ObtenirNatureDemandeInterventionParCle

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirNatureDemandeInterventionParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirNatureDemandeInterventionParCle(null, cleInvalide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec la cle à z&ro.
        /// </summary>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirNatureDemandeInterventionParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_ParametreValide_OK()
        {
            NatureDemandeIntervention natureDemandeIntervention = this.service.ObtenirNatureDemandeInterventionParCle(this.identite, this.NatureDemandeIntervention_Domain_1.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(natureDemandeIntervention.Cle, this.NatureDemandeIntervention_1.Cle, "Cle incorrecte");
                Assert.AreEqual(natureDemandeIntervention.Libelle, this.NatureDemandeIntervention_1.Libelle, "Libelle incorrecte");
            });
        }

        #endregion ObtenirNatureDemandeInterventionParCle

        #region ListerNatureDemandeIntervention

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention avec l'identite null.
        /// </summary>
        [Test]
        public void ListerNatureDemandeIntervention_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerNatureDemandeIntervention(null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention avec l'identite null.
        /// </summary>
        [Test]
        public void ListerNatureDemandeIntervention_ParametreValide_OK()
        {
            NatureDemandeIntervention[] tableauNatureDemandeIntervention = this.service.ListerNatureDemandeIntervention(this.identite);

            Assert.AreEqual(tableauNatureDemandeIntervention.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauNatureDemandeIntervention[0].Cle, this.NatureDemandeIntervention_1.Cle, "Cle incorrecte élément 1");
            Assert.AreEqual(tableauNatureDemandeIntervention[0].Libelle, this.NatureDemandeIntervention_1.Libelle, "Libelle incorrecte élément 1");
            Assert.AreEqual(tableauNatureDemandeIntervention[1].Cle, this.NatureDemandeIntervention_2.Cle, "Cle incorrecte élément 2");
            Assert.AreEqual(tableauNatureDemandeIntervention[1].Libelle, this.NatureDemandeIntervention_2.Libelle, "Libelle incorrecte élément 2");
        }

        #endregion ListerNatureDemandeIntervention

        #endregion NatureDemandeIntervention

        #region OrigineDysfonctionnement

        #region ObtenirOrigineDysfonctionnementParCle

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirOrigineDysfonctionnementParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirOrigineDysfonctionnementParCle(null, cleInvalide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec la cle à z&ro.
        /// </summary>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirOrigineDysfonctionnementParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_ParametreValide_OK()
        {
            OrigineDysfonctionnement origineDysfonctionnement = this.service.ObtenirOrigineDysfonctionnementParCle(this.identite, this.OrigineDysfonctionnement_Domain_1.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(origineDysfonctionnement.Cle, this.OrigineDysfonctionnement_1.Cle, "Cle incorrecte");
                Assert.AreEqual(origineDysfonctionnement.Libelle, this.OrigineDysfonctionnement_1.Libelle, "Libelle incorrecte");
            });
        }

        #endregion ObtenirOrigineDysfonctionnementParCle

        #region ListerOrigineDysfonctionnement

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ListerOrigineDysfonctionnement_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerOrigineDysfonctionnement(null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement avec l'identite null.
        /// </summary>
        [Test]
        public void ListerOrigineDysfonctionnement_ParametreValide_OK()
        {
            OrigineDysfonctionnement[] tableauOrigineDysfonctionnement = this.service.ListerOrigineDysfonctionnement(this.identite);

            Assert.AreEqual(tableauOrigineDysfonctionnement.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauOrigineDysfonctionnement[0].Cle, this.OrigineDysfonctionnement_1.Cle, "Cle incorrecte élément 1");
            Assert.AreEqual(tableauOrigineDysfonctionnement[0].Libelle, this.OrigineDysfonctionnement_1.Libelle, "Libelle incorrecte élément 1");
            Assert.AreEqual(tableauOrigineDysfonctionnement[1].Cle, this.OrigineDysfonctionnement_2.Cle, "Cle incorrecte élément 2");
            Assert.AreEqual(tableauOrigineDysfonctionnement[1].Libelle, this.OrigineDysfonctionnement_2.Libelle, "Libelle incorrecte élément 2");
        }

        #endregion ListerOrigineDysfonctionnement

        #endregion OrigineDysfonctionnement

        #region RegionCDC

        #region ObtenirRegionCdcParCle

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirRegionCdcParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirRegionCdcParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirRegionCdcParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirRegionCdcParCle(null, cleInvalide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec la cle à z&ro.
        /// </summary>
        [Test]
        public void ObtenirRegionCdcParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirRegionCdcParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Lister les pannes collectives.
        /// </summary>
        [Test]
        public void ObtenirRegionCdcParCle_ParametreValide_OK()
        {
            RegionCDC regionCDC = this.service.ObtenirRegionCdcParCle(this.identite, this.RegionCDC_Domain_1.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(regionCDC.Cle, this.RegionCDC_1.Cle, "Cle incorrecte");
                Assert.AreEqual(regionCDC.Libelle, this.RegionCDC_1.Libelle, "Libelle incorrecte");
            });
        }

        #endregion ObtenirRegionCdcParCle

        #region ListerRegionCdc

        /// <summary>
        /// Recherche tous les RegionCDC avec l'identite null.
        /// </summary>
        [Test]
        public void ListerRegionCdc_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ListerRegionCdc(null);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Recherche tous les RegionCDC avec l'identite null.
        /// </summary>
        [Test]
        public void ListerRegionCdc_ParametreValide_OK()
        {
            RegionCDC[] tableauRegionCDC = this.service.ListerRegionCdc(this.identite);

            Assert.AreEqual(tableauRegionCDC.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauRegionCDC[0].Cle, this.RegionCDC_1.Cle, "Cle incorrecte élément 1");
            Assert.AreEqual(tableauRegionCDC[0].Libelle, this.RegionCDC_1.Libelle, "Libelle incorrecte élément 1");
            Assert.AreEqual(tableauRegionCDC[1].Cle, this.RegionCDC_2.Cle, "Cle incorrecte élément 2");
            Assert.AreEqual(tableauRegionCDC[1].Libelle, this.RegionCDC_2.Libelle, "Libelle incorrecte élément 2");
        }

        #endregion ListerRegionCdc

        #endregion RegionCDC

        #endregion Tables de Paramétrage

        #region Formulaires

        #region Utiles

        #region FormulaireGBO

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        private FormulaireGBO GenererFormulaireGBO(long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc, string referenceExterne)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk(regionCdc.Cle, referenceExterne);
            return new FormulaireGBO
            {
                Cle = cleFormulaireGbo,
                CleDossierGbo = cleDossierGbo,
                TypeFormulaireGbo = TypeFormulaireGBO.NonDefini,
                CdcCodeBanque = parametresCreationFormulaireGbo.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireGbo.CdcLigneDirecte,
                RegionCdc = regionCdc,
                CdcNomPrenom = parametresCreationFormulaireGbo.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireGbo.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireGbo.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireGbo.ReferenceExterne
            };
        }

        private Domain.Entities.FormulaireGBO.FormulaireGBO GenererFormulaireGBO_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc, string referenceExterne)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk_Domain(cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne);
            return new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, parametresCreationFormulaireGbo);
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk(long cleRegionCdc, string referenceExterne)
        {
            InformationsCdcPourCreation informationsCdcPourCreation = GenerateInformationsCdcPourCreationOk();
            return new ParametresCreationFormulaireGbo
            {
                CdcAdresseMail = informationsCdcPourCreation.CdcAdresseMail,
                CdcCleRegion = cleRegionCdc,
                CdcCodeBanque = informationsCdcPourCreation.CdcCodeBanque,
                CdcCodeBranche = informationsCdcPourCreation.CdcCodeBranche,
                CdcLigneDirecte = informationsCdcPourCreation.CdcLigneDirecte,
                CdcNomPrenom = informationsCdcPourCreation.CdcNomPrenom,
                ReferenceExterne = referenceExterne
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc, string referenceExterne)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                cleFormulaireGbo,
                cleDossierGbo,
                regionCdc,
                GenerateInformationsCdcPourCreationOk(),
                referenceExterne);
        }

        public InformationsCdcPourCreation GenerateInformationsCdcPourCreationOk()
        {
            return new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };
        }

        #endregion FormulaireGBO

        #region FormulaireCN2DI

        private FormulaireCN2DI GenererFormulaireCN2DI(
            long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc, string referenceExterne,
            MotifDysfonctionnement motifDysfonctionnement, OrigineDysfonctionnement origineDysfonctionnement,
            List<PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            long? cleOrigineDysfonctionnement = null;
            if(origineDysfonctionnement != null)
                cleOrigineDysfonctionnement = origineDysfonctionnement.Cle;

            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(regionCdc.Cle, referenceExterne, motifDysfonctionnement.Cle, cleOrigineDysfonctionnement);

            return new FormulaireCN2DI
            {
                Cle = cleFormulaireGbo,
                CleDossierGbo = cleDossierGbo,
                TypeFormulaireGbo = TypeFormulaireGBO.FormulaireCN2DI,
                CdcCodeBanque = parametresCreationFormulaireCN2DI.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireCN2DI.CdcLigneDirecte,
                RegionCdc = regionCdc,
                CdcNomPrenom = parametresCreationFormulaireCN2DI.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireCN2DI.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireCN2DI.CdcAdresseMail,
                NomClient = parametresCreationFormulaireCN2DI.NomClient,
                PrenomClient = parametresCreationFormulaireCN2DI.PrenomClient,
                ReferenceExterne = parametresCreationFormulaireCN2DI.ReferenceExterne,
                MotifDysfonctionnement = motifDysfonctionnement,
                OrigineDysfonctionnement = origineDysfonctionnement,
                DemandeClient = parametresCreationFormulaireCN2DI.DemandeClient,
                NumeroCommandeClient = parametresCreationFormulaireCN2DI.NumeroCommandeClient,
                RaisonsDysfonctionnement = parametresCreationFormulaireCN2DI.RaisonsDysfonctionnement,
                SolutionsDejaApportees = parametresCreationFormulaireCN2DI.SolutionsDejaApportees,
                DateApproxAppelServiceClient = parametresCreationFormulaireCN2DI.DateApproxAppelServiceClient,
                ListePiecesJointes = listePieceJointeFormulaireGbo.ToArray()
            };
        }

        private Domain.Entities.FormulaireGBO.FormulaireCN2DI GenererFormulaireCN2DI_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            Domain.Entities.TableParametrageGBO.MotifDysfonctionnement motifDysfonctionnement,
            Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement origineDysfonctionnement,
            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk_Domain(
                    cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne,
                    motifDysfonctionnement, origineDysfonctionnement);
            return new Domain.Entities.FormulaireGBO.FormulaireCN2DI(
                this.identite,
                parametresCreationFormulaireCN2DI,
                listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN2DI GenerateParametresCreationFormulaireCN2DIOk(
            long cleRegionCdc, string referenceExterne,
            long cleMotifDysfonctionnement, long? cleOrigineDysfonctionnement)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk(cleRegionCdc, referenceExterne);

            InformationsSupplementairesCN2DiPourCreation informationsSupplementairesCN2DiPourCreation =
                GenerateInformationsSupplementairesCN2DiPourCreationOk();

            InformationsClientPourCreation informationsClientPourCreation =
                GenerateInformationsClientPourCreation();

            return new ParametresCreationFormulaireCN2DI
            {
                CdcCodeBanque = parametresCreationFormulaireGbo.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireGbo.CdcLigneDirecte,
                CdcCleRegion = parametresCreationFormulaireGbo.CdcCleRegion,
                CdcNomPrenom = parametresCreationFormulaireGbo.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireGbo.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireGbo.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireGbo.ReferenceExterne,
                NomClient = informationsClientPourCreation.NomClient,
                PrenomClient = informationsClientPourCreation.PrenomClient,
                CleMotifDysfonctionnement = cleMotifDysfonctionnement,
                CleOrigineDysfonctionnement = cleOrigineDysfonctionnement,
                DemandeClient = informationsSupplementairesCN2DiPourCreation.DemandeClient,
                NumeroCommandeClient = informationsSupplementairesCN2DiPourCreation.NumeroCommandeClient,
                RaisonsDysfonctionnement = informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement,
                SolutionsDejaApportees = informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees,
                DateApproxAppelServiceClient = informationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI GenerateParametresCreationFormulaireCN2DIOk_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            Domain.Entities.TableParametrageGBO.MotifDysfonctionnement motifDysfonctionnement,
            Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement origineDysfonctionnement)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(
                GenerateParametresCreationFormulaireGboOk_Domain(cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne),
                GenerateInformationsClientPourCreation(),
                GenerateInformationsSupplementairesCN2DiPourCreationOk(),
                motifDysfonctionnement,
                origineDysfonctionnement);
        }

        public InformationsSupplementairesCN2DiPourCreation GenerateInformationsSupplementairesCN2DiPourCreationOk()
        {
            return new InformationsSupplementairesCN2DiPourCreation
            {
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions",
                DateApproxAppelServiceClient = this.DateTimeNow,
                RaisonsDysfonctionnement = "Raisons",
                NumeroCommandeClient = "123456"
            };
        }

        #endregion FormulaireCN2DI

        #region FormulaireCN3EQ

        private FormulaireCN3EQ GenererFormulaireCN3EQ(
            long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc, string referenceExterne,
            NatureDemandeIntervention natureDemandeIntervetion,
            List<PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(regionCdc.Cle, referenceExterne, natureDemandeIntervetion.Cle);

            return new FormulaireCN3EQ
            {
                Cle = cleFormulaireGbo,
                CleDossierGbo = cleDossierGbo,
                TypeFormulaireGbo = TypeFormulaireGBO.FormulaireCN3EQ,
                CdcCodeBanque = parametresCreationFormulaireCN3EQ.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireCN3EQ.CdcLigneDirecte,
                RegionCdc = regionCdc,
                CdcNomPrenom = parametresCreationFormulaireCN3EQ.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireCN3EQ.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireCN3EQ.CdcAdresseMail,
                DateReponseCelluleN2 = parametresCreationFormulaireCN3EQ.DateReponseCelluleN2,
                DemandeClient = parametresCreationFormulaireCN3EQ.DemandeClient,
                ReferenceExterne = parametresCreationFormulaireCN3EQ.ReferenceExterne,
                NumeroSuiviDossier = parametresCreationFormulaireCN3EQ.NumeroSuiviDossier,
                RaisonContestation = parametresCreationFormulaireCN3EQ.RaisonContestation,
                SolutionsDejaApportees = parametresCreationFormulaireCN3EQ.SolutionsDejaApportees,
                NatureDemandeIntervention = natureDemandeIntervetion,
                ListePiecesJointes = listePieceJointeFormulaireGbo.ToArray()
            };
        }

        private Domain.Entities.FormulaireGBO.FormulaireCN3EQ GenererFormulaireCN3EQ_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            Domain.Entities.TableParametrageGBO.NatureDemandeIntervention natureDemandeIntervention,
            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk_Domain(
                    cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne,
                    natureDemandeIntervention);
            return new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN3EQ GenerateParametresCreationFormulaireCN3EQOk(
            long cleRegionCdc, string referenceExterne,
            long cleNatureDemandeIntervention)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk(cleRegionCdc, referenceExterne);

            InformationsSupplementairesCN3EqPourCreation informationsSupplementairesCN3EqPourCreation =
                GenerateInformationsSupplementairesCN3EqPourCreationOk();

            return new ParametresCreationFormulaireCN3EQ
            {
                CleNatureDemandeIntervention = cleNatureDemandeIntervention,
                CdcCodeBanque = parametresCreationFormulaireGbo.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireGbo.CdcLigneDirecte,
                CdcCleRegion = parametresCreationFormulaireGbo.CdcCleRegion,
                CdcNomPrenom = parametresCreationFormulaireGbo.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireGbo.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireGbo.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireGbo.ReferenceExterne,
                DateReponseCelluleN2 = informationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2,
                DemandeClient = informationsSupplementairesCN3EqPourCreation.DemandeClient,
                NumeroSuiviDossier = informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier,
                RaisonContestation = informationsSupplementairesCN3EqPourCreation.RaisonContestation,
                SolutionsDejaApportees = informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ GenerateParametresCreationFormulaireCN3EQOk_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            Domain.Entities.TableParametrageGBO.NatureDemandeIntervention natureDemandeIntervention)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(
                GenerateParametresCreationFormulaireGboOk_Domain(cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne),
                GenerateInformationsSupplementairesCN3EqPourCreationOk(),
                natureDemandeIntervention);
        }

        public InformationsSupplementairesCN3EqPourCreation GenerateInformationsSupplementairesCN3EqPourCreationOk()
        {
            return new InformationsSupplementairesCN3EqPourCreation
            {
                NumeroSuiviDossier = "12345",
                DateReponseCelluleN2 = this.DateTimeNow,
                RaisonContestation = "Raison",
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions"
            };
        }

        #endregion FormulaireCN3EQ

        #region FormulaireMPS

        private FormulaireMPS GenererFormulaireMPS(
            long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc, string referenceExterne,
            ProfilSurconsommation profilSurconsoDemande)
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS =
                GenerateParametresCreationFormulaireMPSOk(regionCdc.Cle, referenceExterne, profilSurconsoDemande);

            return new FormulaireMPS
            {
                Cle = cleFormulaireGbo,
                CleDossierGbo = cleDossierGbo,
                TypeFormulaireGbo = TypeFormulaireGBO.FormulaireMPS,
                CdcCodeBanque = parametresCreationFormulaireMPS.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireMPS.CdcLigneDirecte,
                RegionCdc = regionCdc,
                CdcNomPrenom = parametresCreationFormulaireMPS.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireMPS.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireMPS.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireMPS.ReferenceExterne,
                NomClient = parametresCreationFormulaireMPS.NomClient,
                PrenomClient = parametresCreationFormulaireMPS.PrenomClient,
                DateEffetDemande = parametresCreationFormulaireMPS.DateEffetDemande,
                ProfilSurconsoDemande = parametresCreationFormulaireMPS.ProfilSurconsoDemande,
                Commentaire = parametresCreationFormulaireMPS.Commentaire
            };
        }

        private Domain.Entities.FormulaireGBO.FormulaireMPS GenererFormulaireMPS_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            DateTime dateEffetDemande, ProfilSurconsommation profilSurconsoDemande, string commentaire)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS parametresCreationFormulaireMPS =
                GenerateParametresCreationFormulaireMPSOk_Domain(
                    cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne,
                    dateEffetDemande, profilSurconsoDemande, commentaire);
            return new Domain.Entities.FormulaireGBO.FormulaireMPS(this.identite, parametresCreationFormulaireMPS);
        }

        public ParametresCreationFormulaireMPS GenerateParametresCreationFormulaireMPSOk(
            long cleRegionCdc, string referenceExterne,
            ProfilSurconsommation profilSurconsoDemande)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk(cleRegionCdc, referenceExterne);

            InformationsClientPourCreation informationsClientPourCreation =
                GenerateInformationsClientPourCreation();

            return new ParametresCreationFormulaireMPS
            {
                CdcCodeBanque = parametresCreationFormulaireGbo.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireGbo.CdcLigneDirecte,
                CdcCleRegion = parametresCreationFormulaireGbo.CdcCleRegion,
                CdcNomPrenom = parametresCreationFormulaireGbo.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireGbo.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireGbo.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireGbo.ReferenceExterne,
                NomClient = informationsClientPourCreation.NomClient,
                PrenomClient = informationsClientPourCreation.PrenomClient,
                DateEffetDemande = this.DateTimeNow,
                ProfilSurconsoDemande = profilSurconsoDemande,
                Commentaire = "Commentaire"
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS GenerateParametresCreationFormulaireMPSOk_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            DateTime dateEffetDemande, ProfilSurconsommation profilSurconsoDemande, string commentaire)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(
                GenerateParametresCreationFormulaireGboOk_Domain(cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne),
                GenerateInformationsClientPourCreation(),
                dateEffetDemande,
                profilSurconsoDemande,
                commentaire);
        }

        #endregion FormulaireMPS

        #region FormulaireRisqueResiliation

        private FormulaireRisqueResiliation GenererFormulaireRisqueResiliation(
            long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc, string referenceExterne,
            string offreClient, MotifQualification motifQualification, string commentaire)
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation =
                GenerateParametresCreationFormulaireRisqueResiliationOk(regionCdc.Cle, referenceExterne, offreClient, motifQualification.Cle, commentaire);

            return new FormulaireRisqueResiliation
            {
                Cle = cleFormulaireGbo,
                CleDossierGbo = cleDossierGbo,
                TypeFormulaireGbo = TypeFormulaireGBO.FormulaireRisqueResiliation,
                CdcCodeBanque = parametresCreationFormulaireRisqueResiliation.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireRisqueResiliation.CdcLigneDirecte,
                RegionCdc = regionCdc,
                CdcNomPrenom = parametresCreationFormulaireRisqueResiliation.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireRisqueResiliation.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireRisqueResiliation.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireRisqueResiliation.ReferenceExterne,
                NomClient = parametresCreationFormulaireRisqueResiliation.NomClient,
                PrenomClient = parametresCreationFormulaireRisqueResiliation.PrenomClient,
                OffreClient = parametresCreationFormulaireRisqueResiliation.OffreClient,
                MotifQualification = motifQualification,
                Commentaire = parametresCreationFormulaireRisqueResiliation.Commentaire
            };
        }

        private Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation GenererFormulaireRisqueResiliation_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            string offreClient,
            Domain.Entities.TableParametrageGBO.MotifQualification motifQualification,
            string commentaire)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation =
                GenerateParametresCreationFormulaireRisqueResiliationOk_Domain(
                    cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne,
                    offreClient, motifQualification, commentaire);
            return new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);
        }

        public ParametresCreationFormulaireRisqueResiliation GenerateParametresCreationFormulaireRisqueResiliationOk(
            long cleRegionCdc, string referenceExterne,
            string offreClient, long cleMotifQualification, string commentaire)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGbo =
                GenerateParametresCreationFormulaireGboOk(cleRegionCdc, referenceExterne);

            InformationsClientPourCreation informationsClientPourCreation =
                GenerateInformationsClientPourCreation();

            return new ParametresCreationFormulaireRisqueResiliation
            {
                CdcCodeBanque = parametresCreationFormulaireGbo.CdcCodeBanque,
                CdcLigneDirecte = parametresCreationFormulaireGbo.CdcLigneDirecte,
                CdcCleRegion = parametresCreationFormulaireGbo.CdcCleRegion,
                CdcNomPrenom = parametresCreationFormulaireGbo.CdcNomPrenom,
                CdcCodeBranche = parametresCreationFormulaireGbo.CdcCodeBranche,
                CdcAdresseMail = parametresCreationFormulaireGbo.CdcAdresseMail,
                ReferenceExterne = parametresCreationFormulaireGbo.ReferenceExterne,
                NomClient = informationsClientPourCreation.NomClient,
                PrenomClient = informationsClientPourCreation.PrenomClient,
                OffreClient = offreClient,
                CleMotifQualification = cleMotifQualification,
                Commentaire = commentaire
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation GenerateParametresCreationFormulaireRisqueResiliationOk_Domain(
            long cleFormulaireGbo, long cleDossierGbo,
            Domain.Entities.TableParametrageGBO.RegionCDC regionCdc,
            string referenceExterne,
            string offreClient, Domain.Entities.TableParametrageGBO.MotifQualification motifQualification, string commentaire)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(
                GenerateParametresCreationFormulaireGboOk_Domain(cleFormulaireGbo, cleDossierGbo, regionCdc, referenceExterne),
                GenerateInformationsClientPourCreation(),
                offreClient,
                motifQualification,
                commentaire);
        }

        #endregion FormulaireRisqueResiliation

        #region PieceJointeFormulaireGbo

        private PieceJointeFormulaireGbo GenererPieceJointeFormulaireGbo(long clePieceJointeFormulaireGbo)
        {
            ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo =
                GenerateParametresCreationPieceJointeFormulaireGboOk(clePieceJointeFormulaireGbo);

            return new PieceJointeFormulaireGbo
            {
                Cle = clePieceJointeFormulaireGbo,
                GuDocId = parametresCreationPieceJointeFormulaireGbo.GuDocId,
                NomFichier = parametresCreationPieceJointeFormulaireGbo.NomFichier
            };
        }

        private Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo GenererPieceJointeFormulaireGbo_Domain(
            long clePieceJointeFormulaireGbo)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo =
                GenerateParametresCreationPieceJointeFormulaireGboOk_Domain(clePieceJointeFormulaireGbo);
            return new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, parametresCreationPieceJointeFormulaireGbo);
        }

        public ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk(long clePieceJointeFormulaireGbo)
        {
            Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo =
                GenerateParametresCreationPieceJointeFormulaireGboOk_Domain(clePieceJointeFormulaireGbo);

            return new ParametresCreationPieceJointeFormulaireGbo
            {
                GuDocId = parametresCreationPieceJointeFormulaireGbo.GuDocId,
                NomFichier = parametresCreationPieceJointeFormulaireGbo.NomFichier
            };
        }

        public Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk_Domain(
            long clePieceJointeFormulaireGbo)
        {
            return new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                clePieceJointeFormulaireGbo,
                "GUDOCID_TEST_" + clePieceJointeFormulaireGbo,
                "NomFichierTest_" + clePieceJointeFormulaireGbo + ".xml");
        }

        public List<ParametresCreationPieceJointeFormulaireGbo> GenerateListeParametresCreationPieceJointeFormulaireGboOk(int nbParametresACreer)
        {
            List<ParametresCreationPieceJointeFormulaireGbo> result =
                new List<ParametresCreationPieceJointeFormulaireGbo>();

            for (int i = 1; i <= nbParametresACreer; i++)
            {
                result.Add(GenerateParametresCreationPieceJointeFormulaireGboOk(i));
            }

            return result;
        }

        public List<Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo> GenerateListeParametresCreationPieceJointeFormulaireGboOk_Domain(int nbParametresACreer)
        {
            List<Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo> result =
                new List<Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo>();

            for (int i = 1; i <= nbParametresACreer; i++)
            {
                result.Add(GenerateParametresCreationPieceJointeFormulaireGboOk_Domain(i));
            }

            return result;
        }

        #endregion PieceJointeFormulaireGbo

        #endregion Utiles

        #region FormulaireGBO

        #region ObtenirFormulaireGboParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirFormulaireGboParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirFormulaireGboParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirFormulaireGboParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirFormulaireGboParCle(this.identite, cleInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec la cle à zéro.
        /// </summary>
        [Test]
        public void ObtenirFormulaireGboParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirFormulaireGboParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO.
        /// </summary>
        [Test]
        public void ObtenirFormulaireGboParCle_ParametreValide_OK()
        {
            FormulaireGBO formulaireGBO = this.service.ObtenirFormulaireGboParCle(this.identite, this.FormulaireGBO.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(formulaireGBO.Cle, this.FormulaireGBO.Cle, "Cle incorrecte");
                Assert.AreEqual(formulaireGBO.CleDossierGbo, this.FormulaireGBO.CleDossierGbo, "CleDossierGbo incorrecte");
                Assert.AreEqual(formulaireGBO.CdcAdresseMail, this.FormulaireGBO.CdcAdresseMail, "CdcAdresseMail incorrecte");
                Assert.AreEqual(formulaireGBO.CdcCodeBanque, this.FormulaireGBO.CdcCodeBanque, "CdcCodeBanque incorrect");
                Assert.AreEqual(formulaireGBO.CdcCodeBranche, this.FormulaireGBO.CdcCodeBranche, "CdcCodeBranche incorrect");
                Assert.AreEqual(formulaireGBO.CdcLigneDirecte, this.FormulaireGBO.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
                Assert.AreEqual(formulaireGBO.CdcNomPrenom, this.FormulaireGBO.CdcNomPrenom, "CdcNomPrenom incorrect");
                Assert.AreEqual(formulaireGBO.RegionCdc.Cle, this.FormulaireGBO.RegionCdc.Cle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireGBO.RegionCdc.Libelle, this.FormulaireGBO.RegionCdc.Libelle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireGBO.TypeFormulaireGbo, this.FormulaireGBO.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
            });
        }

        #endregion ObtenirFormulaireGboParCle

        #endregion FormulaireGBO

        #region FormulaireCN2DI

        #region CreerFormulaireCN2DI

        #region Parametre - Identite

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec identite nulle.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_IdentiteNull_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI = GenerateParametresCreationFormulaireCN2DIOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                this.MotifDysfonctionnement_1.Cle,
                this.OrigineDysfonctionnement_1.Cle
                );

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(null, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - Identite

        #region Parametre - ParametresCreationFormulaireCN2DI

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec ParametresCreationFormulaireCN2DI null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_ParametresCreationFormulaireCN2DINull_LeveException()
        {
            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, null, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - ParametresCreationFormulaireCN2DI

        #region Attribut - CleMotifDysfonctionnement

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec CleMotifDysfonctionnement négative.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_CleMotifDysfonctionnementNegative_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    -1,
                    this.OrigineDysfonctionnement_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec CleMotifDysfonctionnement zéro.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_CleMotifDysfonctionnementZero_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    0,
                    this.OrigineDysfonctionnement_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - CleMotifDysfonctionnement

        #region Attribut - CleOrigineDysfonctionnement

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec CleOrigineDysfonctionnement négative.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_CleOrigineDysfonctionnementNegative_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    -1);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec CleOrigineDysfonctionnement zéro.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_CleOrigineDysfonctionnementZero_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    0);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - CleOrigineDysfonctionnement

        #region Attribut - RaisonsDysfonctionnement

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec RaisonsDysfonctionnement null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_RaisonsDysfonctionnementNull_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.RaisonsDysfonctionnement = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec RaisonsDysfonctionnement vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_RaisonsDysfonctionnementVide_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.RaisonsDysfonctionnement = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - RaisonsDysfonctionnement

        #region Attribut - DemandeClient

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec DemandeClient null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientNull_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.DemandeClient = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientVide_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.DemandeClient = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - DemandeClient

        #region Attribut - SolutionsDejaApportees

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec SolutionsDejaApportees null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_SolutionsDejaApporteesNull_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.SolutionsDejaApportees = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_SolutionsDejaApporteesVide_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            parametresCreationFormulaireCN2DI.SolutionsDejaApportees = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - SolutionsDejaApportees

        #region Attribut - ReferenceExterne

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec ReferenceExterne Invalide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_ReferenceExterneInvalide_LeveException()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneInvalide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ReferenceExterne

        /// <summary>
        /// Créer un Formulaire de niveau 2 de demande d'intervention avec Paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_ParametreValide_OK()
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.MotifDysfonctionnement_1.Cle,
                    this.OrigineDysfonctionnement_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.That(action, Throws.Nothing);
        }

        #endregion CreerFormulaireCN2DI

        #region ObtenirFormulaireCN2DiParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirFormulaireCN2DiParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirFormulaireCN2DiParCle(this.identite, cleInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec la cle à zéro.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirFormulaireCN2DiParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_ParametreValide_OK()
        {
            FormulaireCN2DI formulaireCN2DI = this.service.ObtenirFormulaireCN2DiParCle(this.identite, this.FormulaireCN2DI.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(formulaireCN2DI.Cle, this.FormulaireCN2DI.Cle, "Cle incorrecte");
                Assert.AreEqual(formulaireCN2DI.CleDossierGbo, this.FormulaireCN2DI.CleDossierGbo, "CleDossierGbo incorrecte "+ formulaireCN2DI.CleDossierGbo + " != "+ this.FormulaireCN2DI.CleDossierGbo);
                Assert.AreEqual(formulaireCN2DI.CdcAdresseMail, this.FormulaireCN2DI.CdcAdresseMail, "CdcAdresseMail incorrecte");
                Assert.AreEqual(formulaireCN2DI.CdcCodeBanque, this.FormulaireCN2DI.CdcCodeBanque, "CdcCodeBanque incorrect");
                Assert.AreEqual(formulaireCN2DI.CdcCodeBranche, this.FormulaireCN2DI.CdcCodeBranche, "CdcCodeBranche incorrect");
                Assert.AreEqual(formulaireCN2DI.CdcLigneDirecte, this.FormulaireCN2DI.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
                Assert.AreEqual(formulaireCN2DI.CdcNomPrenom, this.FormulaireCN2DI.CdcNomPrenom, "CdcNomPrenom incorrect");
                Assert.AreEqual(formulaireCN2DI.RegionCdc.Cle, this.FormulaireCN2DI.RegionCdc.Cle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireCN2DI.RegionCdc.Libelle, this.FormulaireCN2DI.RegionCdc.Libelle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes.Length, this.FormulaireCN2DI.ListePiecesJointes.Length, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[0].Cle, this.FormulaireCN2DI.ListePiecesJointes[0].Cle, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[0].GuDocId, this.FormulaireCN2DI.ListePiecesJointes[0].GuDocId, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[0].NomFichier, this.FormulaireCN2DI.ListePiecesJointes[0].NomFichier, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[1].Cle, this.FormulaireCN2DI.ListePiecesJointes[1].Cle, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[1].GuDocId, this.FormulaireCN2DI.ListePiecesJointes[1].GuDocId, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.ListePiecesJointes[1].NomFichier, this.FormulaireCN2DI.ListePiecesJointes[1].NomFichier, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN2DI.TypeFormulaireGbo, this.FormulaireCN2DI.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
                Assert.AreEqual(formulaireCN2DI.ReferenceExterne, this.FormulaireCN2DI.ReferenceExterne, "ReferenceExterne incorrect");
                Assert.AreEqual(formulaireCN2DI.NomClient, this.FormulaireCN2DI.NomClient, "NomClient incorrect");
                Assert.AreEqual(formulaireCN2DI.PrenomClient, this.FormulaireCN2DI.PrenomClient, "PrenomClient incorrect");
                Assert.AreEqual(formulaireCN2DI.NumeroCommandeClient, this.FormulaireCN2DI.NumeroCommandeClient, "NumeroCommandeClient incorrecte");
                Assert.AreEqual(formulaireCN2DI.MotifDysfonctionnement.Cle, this.FormulaireCN2DI.MotifDysfonctionnement.Cle, "MotifDysfonctionnement.Cle incorrect");
                Assert.AreEqual(formulaireCN2DI.MotifDysfonctionnement.Libelle, this.FormulaireCN2DI.MotifDysfonctionnement.Libelle, "MotifDysfonctionnement.Libelle incorrect");
                Assert.AreEqual(formulaireCN2DI.OrigineDysfonctionnement.Cle, this.FormulaireCN2DI.OrigineDysfonctionnement.Cle, "OrigineDysfonctionnement.Cle incorrecte");
                Assert.AreEqual(formulaireCN2DI.OrigineDysfonctionnement.Libelle, this.FormulaireCN2DI.OrigineDysfonctionnement.Libelle, "OrigineDysfonctionnement.Libelle incorrecte");
                Assert.AreEqual(formulaireCN2DI.DateApproxAppelServiceClient, this.FormulaireCN2DI.DateApproxAppelServiceClient, "DateApproxAppelServiceClient incorrecte");
                Assert.AreEqual(formulaireCN2DI.RaisonsDysfonctionnement, this.FormulaireCN2DI.RaisonsDysfonctionnement, "RaisonsDysfonctionnement incorrecte");
                Assert.AreEqual(formulaireCN2DI.DemandeClient, this.FormulaireCN2DI.DemandeClient, "DemandeClient incorrecte");
                Assert.AreEqual(formulaireCN2DI.SolutionsDejaApportees, this.FormulaireCN2DI.SolutionsDejaApportees, "SolutionsDejaApportees incorrecte");
            });
        }

        #endregion ObtenirFormulaireCN2DiParCle

        #endregion FormulaireCN2DI

        #region FormulaireCN3EQ

        #region CreerFormulaireCN3EQ

        #region Parametre - Identite

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec Identite nulle.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_IdentiteNull_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ = GenerateParametresCreationFormulaireCN3EQOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                this.NatureDemandeIntervention_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(null, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - Identite

        #region Parametre - ParametresCreationFormulaireCN3EQ

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_ParametresCreationFormulaireCN3EQNull_LeveException()
        {

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);
            
            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, null, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - ParametresCreationFormulaireCN3EQ

        #region Attribut - CleNatureDemandeIntervention

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec CleNatureDemandeIntervention négative.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_CleNatureDemandeInterventionNegative_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    -1);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec CleNatureDemandeIntervention zero.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_CleNatureDemandeInterventionZero_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    0);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - CleNatureDemandeIntervention

        #region Attribut - NumeroSuiviDossier

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec NumeroSuiviDossier null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_NumeroSuiviDossierNull_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.NumeroSuiviDossier = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec NumeroSuiviDossier vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_NumeroSuiviDossierVide_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.NumeroSuiviDossier = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - NumeroSuiviDossier

        #region Attribut - DateReponseCelluleN2

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec DateReponseCelluleN2 null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DateReponseCelluleN2Null_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.DateReponseCelluleN2 = default(DateTime);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - DateReponseCelluleN2

        #region Attribut - ReferenceExterne

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec ReferenceExterne Invalide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_ReferenceExterneInvalide_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneInvalide,
                    this.NatureDemandeIntervention_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ReferenceExterne

        #region Attribut - RaisonContestation

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec RaisonContestation null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_RaisonContestationNull_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.RaisonContestation = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec RaisonContestation vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_RaisonContestationVide_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.RaisonContestation = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - RaisonContestation

        #region Attribut - DemandeClient

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec DemandeClient null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DemandeClientNull_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.DemandeClient = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DemandeClientVide_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.DemandeClient = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - DemandeClient

        #region Attribut - SolutionsDejaApportees

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec SolutionsDejaApportees null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_SolutionsDejaApporteesNull_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.SolutionsDejaApportees = null;

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_SolutionsDejaApporteesVide_LeveException()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            parametresCreationFormulaireCN3EQ.SolutionsDejaApportees = "";

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - SolutionsDejaApportees

        /// <summary>
        /// Créer un Formulaire de niveau 3 d'engagement qualité avec Paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_ParametreValide_OK()
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    this.RegionCDC_1.Cle,
                    this.ReferenceExterneValide,
                    this.NatureDemandeIntervention_1.Cle);

            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo =
                GenerateListeParametresCreationPieceJointeFormulaireGboOk(2);

            TestDelegate action = () => service.CreerFormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listeParametresCreationPieceJointeFormulaireGbo);

            Assert.That(action, Throws.Nothing);
        }

        #endregion CreerFormulaireCN3EQ

        #region ObtenirFormulaireCN3EqParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirFormulaireCN3EqParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirFormulaireCN3EqParCle(this.identite, cleInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec la cle à zéro.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirFormulaireCN3EqParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ.
        /// </summary>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_ParametreValide_OK()
        {
            FormulaireCN3EQ formulaireCN3EQ = this.service.ObtenirFormulaireCN3EqParCle(this.identite, this.FormulaireCN3EQ.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(formulaireCN3EQ.Cle, this.FormulaireCN3EQ.Cle, "Cle incorrecte");
                Assert.AreEqual(formulaireCN3EQ.CleDossierGbo, this.FormulaireCN3EQ.CleDossierGbo, "CleDossierGbo incorrecte " + formulaireCN3EQ.CleDossierGbo + " != " + this.FormulaireCN3EQ.CleDossierGbo);
                Assert.AreEqual(formulaireCN3EQ.CdcAdresseMail, this.FormulaireCN3EQ.CdcAdresseMail, "CdcAdresseMail incorrecte");
                Assert.AreEqual(formulaireCN3EQ.CdcCodeBanque, this.FormulaireCN3EQ.CdcCodeBanque, "CdcCodeBanque incorrect");
                Assert.AreEqual(formulaireCN3EQ.CdcCodeBranche, this.FormulaireCN3EQ.CdcCodeBranche, "CdcCodeBranche incorrect");
                Assert.AreEqual(formulaireCN3EQ.CdcLigneDirecte, this.FormulaireCN3EQ.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
                Assert.AreEqual(formulaireCN3EQ.CdcNomPrenom, this.FormulaireCN3EQ.CdcNomPrenom, "CdcNomPrenom incorrect");
                Assert.AreEqual(formulaireCN3EQ.RegionCdc.Cle, this.FormulaireCN3EQ.RegionCdc.Cle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireCN3EQ.RegionCdc.Libelle, this.FormulaireCN3EQ.RegionCdc.Libelle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes.Length, this.FormulaireCN3EQ.ListePiecesJointes.Length, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[0].Cle, this.FormulaireCN3EQ.ListePiecesJointes[0].Cle, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[0].GuDocId, this.FormulaireCN3EQ.ListePiecesJointes[0].GuDocId, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[0].NomFichier, this.FormulaireCN3EQ.ListePiecesJointes[0].NomFichier, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[1].Cle, this.FormulaireCN3EQ.ListePiecesJointes[1].Cle, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[1].GuDocId, this.FormulaireCN3EQ.ListePiecesJointes[1].GuDocId, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ListePiecesJointes[1].NomFichier, this.FormulaireCN3EQ.ListePiecesJointes[1].NomFichier, "ListePiecesJointes incorrecte");
                Assert.AreEqual(formulaireCN3EQ.TypeFormulaireGbo, this.FormulaireCN3EQ.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
                Assert.AreEqual(formulaireCN3EQ.DateReponseCelluleN2, this.FormulaireCN3EQ.DateReponseCelluleN2, "DateReponseCelluleN2 incorrecte");
                Assert.AreEqual(formulaireCN3EQ.DemandeClient, this.FormulaireCN3EQ.DemandeClient, "DemandeClient incorrecte");
                Assert.AreEqual(formulaireCN3EQ.NatureDemandeIntervention.Cle, this.FormulaireCN3EQ.NatureDemandeIntervention.Cle, "NatureDemandeIntervention.Cle incorrecte");
                Assert.AreEqual(formulaireCN3EQ.NatureDemandeIntervention.Libelle, this.FormulaireCN3EQ.NatureDemandeIntervention.Libelle, "NatureDemandeIntervention.Libelle incorrecte");
                Assert.AreEqual(formulaireCN3EQ.ReferenceExterne, this.FormulaireCN3EQ.ReferenceExterne, "ReferenceExterne incorrect");
                Assert.AreEqual(formulaireCN3EQ.NumeroSuiviDossier, this.FormulaireCN3EQ.NumeroSuiviDossier, "NumeroSuiviDossier incorrect");
                Assert.AreEqual(formulaireCN3EQ.RaisonContestation, this.FormulaireCN3EQ.RaisonContestation, "RaisonContestation incorrecte");
                Assert.AreEqual(formulaireCN3EQ.SolutionsDejaApportees, this.FormulaireCN3EQ.SolutionsDejaApportees, "SolutionsDejaApportees incorrecte");
            });
        }

        #endregion ObtenirFormulaireCN3EqParCle

        #endregion FormulaireCN3EQ

        #region FormulaireMPS

        #region CreerFormulaireMps

        #region Parametre - Identite

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec identite nulle.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_IdentiteNull_LeveException()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                ProfilSurconsommation.ClientStandard);

            TestDelegate action = () => service.CreerFormulaireMps(null, parametresCreationFormulaireMPS);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - Identite

        #region Parametre - ParametresCreationFormulaireMPS

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec ParametresCreationFormulaireMPS null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_ParametresCreationFormulaireMPSNull_LeveException()
        {
            TestDelegate action = () => service.CreerFormulaireMps(this.identite, null);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - ParametresCreationFormulaireMPS

        #region Attribut - ReferenceExterne

        /// <summary>
        /// Créer unFormulaire de modification de profil surconsommation avec ReferenceExterne Invalide.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_ReferenceExterneInvalide_LeveException()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneInvalide,
                ProfilSurconsommation.ClientStandard);

            TestDelegate action = () => service.CreerFormulaireMps(this.identite, parametresCreationFormulaireMPS);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ReferenceExterne

        #region Attribut - DateEffetDemande

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec DateEffetDemande null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_DateEffetDemandeNull_LeveException()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                ProfilSurconsommation.ClientStandard);

            parametresCreationFormulaireMPS.DateEffetDemande = default(DateTime);

            TestDelegate action = () => service.CreerFormulaireMps(this.identite, parametresCreationFormulaireMPS);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - DateEffetDemande

        #region Attribut - Commentaire

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec Commentaire null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_CommentaireNull_LeveException()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                ProfilSurconsommation.ClientStandard);

            parametresCreationFormulaireMPS.Commentaire = null;

            TestDelegate action = () => service.CreerFormulaireMps(this.identite, parametresCreationFormulaireMPS);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec Commentaire vide.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_CommentaireVide_LeveException()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                ProfilSurconsommation.ClientStandard);

            parametresCreationFormulaireMPS.Commentaire = "";

            TestDelegate action = () => service.CreerFormulaireMps(this.identite, parametresCreationFormulaireMPS);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - Commentaire

        /// <summary>
        /// Créer un Formulaire de modification de profil surconsommation avec Paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_ParametreValide_OK()
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                ProfilSurconsommation.ClientStandard);

            TestDelegate action = () => this.service.CreerFormulaireMps(this.identite, parametresCreationFormulaireMPS);

            Assert.That(action, Throws.Nothing);
        }

        #endregion CreerFormulaireMps
        
        #region ObtenirFormulaireMpsParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirFormulaireMpsParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirFormulaireMpsParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirFormulaireMpsParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirFormulaireMpsParCle(this.identite, cleInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec la cle à zéro.
        /// </summary>
        [Test]
        public void ObtenirFormulaireMpsParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirFormulaireMpsParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS.
        /// </summary>
        [Test]
        public void ObtenirFormulaireMpsParCle_ParametreValide_OK()
        {
            FormulaireMPS formulaireMPS = this.service.ObtenirFormulaireMpsParCle(this.identite, this.FormulaireMPS.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(formulaireMPS.Cle, this.FormulaireMPS.Cle, "Cle incorrecte");
                Assert.AreEqual(formulaireMPS.CleDossierGbo, this.FormulaireMPS.CleDossierGbo, "CleDossierGbo incorrecte " + formulaireMPS.CleDossierGbo + " != " + this.FormulaireMPS.CleDossierGbo);
                Assert.AreEqual(formulaireMPS.CdcAdresseMail, this.FormulaireMPS.CdcAdresseMail, "CdcAdresseMail incorrecte");
                Assert.AreEqual(formulaireMPS.CdcCodeBanque, this.FormulaireMPS.CdcCodeBanque, "CdcCodeBanque incorrect");
                Assert.AreEqual(formulaireMPS.CdcCodeBranche, this.FormulaireMPS.CdcCodeBranche, "CdcCodeBranche incorrect");
                Assert.AreEqual(formulaireMPS.CdcLigneDirecte, this.FormulaireMPS.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
                Assert.AreEqual(formulaireMPS.CdcNomPrenom, this.FormulaireMPS.CdcNomPrenom, "CdcNomPrenom incorrect");
                Assert.AreEqual(formulaireMPS.RegionCdc.Cle, this.FormulaireMPS.RegionCdc.Cle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireMPS.RegionCdc.Libelle, this.FormulaireMPS.RegionCdc.Libelle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireMPS.TypeFormulaireGbo, this.FormulaireMPS.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
                Assert.AreEqual(formulaireMPS.ReferenceExterne, this.FormulaireMPS.ReferenceExterne, "ReferenceExterne incorrect");
                Assert.AreEqual(formulaireMPS.NomClient, this.FormulaireMPS.NomClient, "NomClient incorrect");
                Assert.AreEqual(formulaireMPS.PrenomClient, this.FormulaireMPS.PrenomClient, "NomClient incorrect");
                Assert.AreEqual(formulaireMPS.DateEffetDemande, this.FormulaireMPS.DateEffetDemande, "DateEffetDemande incorrecte");
                Assert.AreEqual(formulaireMPS.ProfilSurconsoDemande, this.FormulaireMPS.ProfilSurconsoDemande, "ProfilSurconsoDemande incorrecte");
                Assert.AreEqual(formulaireMPS.Commentaire, this.FormulaireMPS.Commentaire, "Commentaire incorrect");
            });
        }

        #endregion ObtenirFormulaireMpsParCle

        #endregion FormulaireMPS

        #region FormulaireRisqueResiliation

        #region CreerFormulaireRisqueResiliation

        #region Parametre - Identite

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec Identite nulle.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_IdentiteNull_LeveException()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", this.MotifQualification_1.Cle, "Commentaire");

            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(null, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - Identite

        #region Parametre - ParametresCreationFormulaireRisqueResiliation

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec ParametresCreationFormulaireRisqueResiliation null.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_ParametresCreationFormulaireRisqueResiliationNull_LeveException()
        {
            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(this.identite, null);

            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Parametre - ParametresCreationFormulaireRisqueResiliation

        #region Attribut - ReferenceExterne

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec ReferenceExterne Invalide.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_ReferenceExterneInvalide_LeveException()
        {

            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneInvalide,
                "Offre", this.MotifQualification_1.Cle, "Commentaire");

            TestDelegate action = () => this.service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ReferenceExterne

        #region Attribut - CleMotifQualification

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec CleMotifQualification Négative.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_CleMotifQualificationNegative_LeveException()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", -1, "Commentaire");

            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec CleMotifQualification Zéro.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_CleMotifQualificationZero_LeveException()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", 0, "Commentaire");

            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - CleMotifQualification

        #region Attribut - Commentaire

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec Commentaire null.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_CommentaireNull_LeveException()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", 1, null);

            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec Commentaire vide.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_CommentaireVide_LeveException()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", 1, "");

            TestDelegate action = () => service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - Commentaire

        /// <summary>
        /// Créer un Formulaire de risque de résiliation avec Paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_ParametreValide_OK()
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk(
                this.RegionCDC_1.Cle,
                this.ReferenceExterneValide,
                "Offre", this.MotifQualification_1.Cle, "Commentaire");

            TestDelegate action = () => this.service.CreerFormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);

            Assert.That(action, Throws.Nothing);
        }

        #endregion CreerFormulaireRisqueResiliation

        #region ObtenirFormulaireRisqueResiliationParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec l'identite null.
        /// </summary>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.service.ObtenirFormulaireRisqueResiliationParCle(null, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec la cle négative.
        /// </summary>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_CleNegative_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => this.service.ObtenirFormulaireRisqueResiliationParCle(this.identite, cleInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec la cle à zéro.
        /// </summary>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_CleZero_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => this.service.ObtenirFormulaireRisqueResiliationParCle(this.identite, cle);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation.
        /// </summary>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_ParametreValide_OK()
        {
            FormulaireRisqueResiliation formulaireRisqueResiliation = this.service.ObtenirFormulaireRisqueResiliationParCle(this.identite, this.FormulaireRisqueResiliation.Cle);

            Assert.Multiple(() =>
            {
                Assert.AreEqual(formulaireRisqueResiliation.Cle, this.FormulaireRisqueResiliation.Cle, "Cle incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.CleDossierGbo, this.FormulaireRisqueResiliation.CleDossierGbo, "CleDossierGbo incorrecte " + formulaireRisqueResiliation.CleDossierGbo + " != " + this.FormulaireRisqueResiliation.CleDossierGbo);
                Assert.AreEqual(formulaireRisqueResiliation.CdcAdresseMail, this.FormulaireRisqueResiliation.CdcAdresseMail, "CdcAdresseMail incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.CdcCodeBanque, this.FormulaireRisqueResiliation.CdcCodeBanque, "CdcCodeBanque incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.CdcCodeBranche, this.FormulaireRisqueResiliation.CdcCodeBranche, "CdcCodeBranche incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.CdcLigneDirecte, this.FormulaireRisqueResiliation.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.CdcNomPrenom, this.FormulaireRisqueResiliation.CdcNomPrenom, "CdcNomPrenom incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.RegionCdc.Cle, this.FormulaireRisqueResiliation.RegionCdc.Cle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.RegionCdc.Libelle, this.FormulaireRisqueResiliation.RegionCdc.Libelle, "RegionCDC incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.TypeFormulaireGbo, this.FormulaireRisqueResiliation.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.ReferenceExterne, this.FormulaireRisqueResiliation.ReferenceExterne, "ReferenceExterne incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.NomClient, this.FormulaireRisqueResiliation.NomClient, "NomClient incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.PrenomClient, this.FormulaireRisqueResiliation.PrenomClient, "NomClient incorrect");
                Assert.AreEqual(formulaireRisqueResiliation.OffreClient, this.FormulaireRisqueResiliation.OffreClient, "OffreClient incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.MotifQualification.Cle, this.FormulaireRisqueResiliation.MotifQualification.Cle, "MotifQualification.Cle incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.MotifQualification.Libelle, this.FormulaireRisqueResiliation.MotifQualification.Libelle, "MotifQualification.Libelle incorrecte");
                Assert.AreEqual(formulaireRisqueResiliation.Commentaire, this.FormulaireRisqueResiliation.Commentaire, "Commentaire incorrect");
            });
        }

        #endregion ObtenirFormulaireRisqueResiliationParCle

        #endregion FormulaireRisqueResiliation

        #endregion Formulaires

        #endregion Méthodes - FormulaireGboService
    }
}
