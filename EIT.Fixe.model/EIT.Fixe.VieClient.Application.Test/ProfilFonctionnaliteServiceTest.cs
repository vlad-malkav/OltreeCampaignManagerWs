﻿using System;
using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Classe de test du service ProfilFonctionnalite.
    /// </summary>
    [TestFixture]
    public class ProfilFonctionnaliteServiceTest
    {
        #region Propriétés 

        private ProfilFonctionnaliteService profilFonctionnaliteService;

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private Mock<IServicesTechniques> servicesTechniques { get; set; }

        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Mock de l'objet DemandeResiliation. Est renvoyé par les repositories.
        /// </summary>
        private Mock<ProfilPtf> profilPtf { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Clé d'un profilPtf Valide.
        /// </summary>
        private long CleProfilPtfValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une ressource sas valide.
        /// </summary>
        private string RessourceSasValide
        {
            get
            {
                return "RessourceSasValide";
            }
        }

        private ProfilPtf[] listeProfils;

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identiteValide = new Identite() { Memoid = "MemoId" };

            this.InitialiserServiceTechnique();
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserProfilPtf();
            this.InitialiserRepositories();

            this.listeProfils = new ProfilPtf[] { this.profilPtf.Object };

            profilFonctionnaliteService = new ProfilFonctionnaliteService(this.repositories.Object, this.servicesTechniques.Object);
        }

        /// <summary>
        /// Initialise la demande de résiliation.
        /// </summary>
        private void InitialiserProfilPtf()
        {
            this.profilPtf = new Mock<ProfilPtf>();
            profilPtf.Setup(p => p.Cle).Returns(1);
            profilPtf.Setup(p => p.RessourceSas).Returns("Ressource");

            Mock<Fonctionnalite> FonctionnaliteMock = new Mock<Fonctionnalite>();
            FonctionnaliteMock.Setup(x => x.Code).Returns("CodeFonctionnalite1");

            Mock<GroupeFonctionnalites> groupeFoncMock = new Mock<GroupeFonctionnalites>();
            FonctionnaliteMock.Setup(x => x.Code).Returns("CodeGroupeFonctionnalite1");
            groupeFoncMock.Setup(x => x.ListeFonctionnalites).Returns(new List<Fonctionnalite>() { FonctionnaliteMock.Object });
            
            profilPtf.Setup(p => p.ListeGroupesFonctionnalites).Returns(new List<GroupeFonctionnalites>() { groupeFoncMock.Object });

        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
            
            this.repositories.Setup(x => x.ProfilRepository).Returns(new Mock<IProfilRepository>().Object);
            this.repositories.Setup(x => x.GroupeFonctionnalitesRepository).Returns(new Mock<IGroupeFonctionnalitesRepository>().Object);
            this.repositories.Setup(x => x.FonctionnaliteRepository).Returns(new Mock<IFonctionnaliteRepository>().Object);
            this.repositories.Setup(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(It.IsAny<string>())).Returns(this.profilPtf.Object);
            this.repositories.Setup(x => x.ProfilRepository.ListerProfilsActifs()).Returns(this.listeProfils);            
            
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        #endregion Méthodes d'initialisation et de vérification

        #region Tests de l'initialisation du service

        /// <summary>
        /// Test du constructeur de ProfilFonctionnaliteService dans le cas ou l'interface des services repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void ProfilFonctionnaliteService_RepositoriesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new ProfilFonctionnaliteService(null, this.servicesTechniques.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de ProfilFonctionnaliteService dans le cas ou l'interface des services techniques est à null. Lève une exception.
        /// </summary>
        [Test]
        public void ProfilFonctionnaliteService_ServicesTechniquesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new ProfilFonctionnaliteService(this.repositories.Object, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de ProfilFonctionnaliteService dans le cas ou le repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void ProfilFonctionnaliteService_ParametresOK_OK()
        {
            // Act.
            TestDelegate action = () => new ProfilFonctionnaliteService(this.repositories.Object, this.servicesTechniques.Object);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de l'initialisation du service

        #region Test de la méthode ObtenirFonctionnalitesDepuisListeProfils

        /// <summary>
        /// Test de la méthode ObtenirFonctionnalitesDepuisListeProfils dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirFonctionnalitesDepuisListeProfils_IdentiteNull_LeveException()
        {
            // Arrange.
            string[] ressourcesSas = new string[] { "1", "2", "3" };

            // Act.
            TestDelegate action = () => this.profilFonctionnaliteService.ObtenirFonctionnalitesDepuisListeProfils(null, ressourcesSas);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirFonctionnalitesDepuisListeProfils dans le cas où ressourcesSas est à null. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirFonctionnalitesDepuisListeProfils_RessourcesSasNull_LeveException()
        {
            // Arrange.
            string[] ressourcesSas = null;

            // Act.
            TestDelegate action = () => this.profilFonctionnaliteService.ObtenirFonctionnalitesDepuisListeProfils(this.identiteValide, ressourcesSas);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirFonctionnalitesDepuisListeProfils dans le cas où les paramètres sont valide.
        /// </summary>
        [Test]
        public void ObtenirFonctionnalitesDepuisListeProfils_ParametresOK_OK()
        {
            // Arrange.
            string[] ressourcesSas = new string[] { "1", "2", "3" };

            string code1 = "code1";
            Mock<Fonctionnalite> fonctionnaliteMock1 = new Mock<Fonctionnalite>();
            fonctionnaliteMock1.Setup(x => x.Code).Returns(code1);
            Mock<GroupeFonctionnalites> goupeFonctionnalite1 = new Mock<GroupeFonctionnalites>();
            goupeFonctionnalite1.Setup(x => x.ListeFonctionnalites).Returns(new List<Fonctionnalite>() { fonctionnaliteMock1.Object });
            Mock<ProfilPtf> profilPtf1 = new Mock<ProfilPtf>();
            profilPtf1.Setup(x => x.EstActif).Returns(true);
            profilPtf1.Setup(x => x.ListeGroupesFonctionnalites).Returns(new List<GroupeFonctionnalites>() { goupeFonctionnalite1.Object });
            this.repositories.Setup(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[0])).Returns(profilPtf1.Object);

            string code2 = "code2";
            Mock<Fonctionnalite> fonctionnaliteMock2 = new Mock<Fonctionnalite>();
            fonctionnaliteMock2.Setup(x => x.Code).Returns(code2);
            Mock<GroupeFonctionnalites> goupeFonctionnalite2 = new Mock<GroupeFonctionnalites>();
            goupeFonctionnalite2.Setup(x => x.ListeFonctionnalites).Returns(new List<Fonctionnalite>() { fonctionnaliteMock2.Object });
            Mock<ProfilPtf> profilPtf2 = new Mock<ProfilPtf>();
            profilPtf2.Setup(x => x.EstActif).Returns(false);
            profilPtf2.Setup(x => x.ListeGroupesFonctionnalites).Returns(new List<GroupeFonctionnalites>() { goupeFonctionnalite2.Object });
            this.repositories.Setup(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[1])).Returns(profilPtf2.Object);

            string code3 = "code3";
            Mock<Fonctionnalite> fonctionnaliteMock3 = new Mock<Fonctionnalite>();
            fonctionnaliteMock3.Setup(x => x.Code).Returns(code3);
            Mock<GroupeFonctionnalites> goupeFonctionnalite3 = new Mock<GroupeFonctionnalites>();
            goupeFonctionnalite3.Setup(x => x.ListeFonctionnalites).Returns(new List<Fonctionnalite>() { fonctionnaliteMock3.Object });
            Mock<ProfilPtf> profilPtf3 = new Mock<ProfilPtf>();
            profilPtf3.Setup(x => x.EstActif).Returns(true);
            profilPtf3.Setup(x => x.ListeGroupesFonctionnalites).Returns(new List<GroupeFonctionnalites>() { goupeFonctionnalite3.Object });
            this.repositories.Setup(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[2])).Returns(profilPtf3.Object);

            // Act.
            string[] fonctionnalites = this.profilFonctionnaliteService.ObtenirFonctionnalitesDepuisListeProfils(this.identiteValide, ressourcesSas);

            // Assert.
            this.repositories.Verify(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[0]));
            this.repositories.Verify(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[1]));
            this.repositories.Verify(x => x.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourcesSas[2]));
            Assert.Contains(code1, fonctionnalites);
            Assert.Contains(code3, fonctionnalites);
            Assert.AreEqual(2, fonctionnalites.Length);
        }

        #endregion Test de la méthode ObtenirFonctionnalitesDepuisListeProfils

        #region Test de ListerProfilsExistants

        /// <summary>
        /// Test de la méthode ListerProfilsExistants avec les paramètre OK.
        /// </summary>
        [Test]
        public void ListerProfilsExistants_ParametreOK_OK()
        {
            //Act.
            string[] listeProfils = this.profilFonctionnaliteService.ListerProfilsExistants(this.identiteValide);
            //Verify.
            this.repositories.Verify(r => r.ProfilRepository.ListerProfilsActifs());
            //Assert.
            Assert.AreEqual(listeProfils[0], this.profilPtf.Object.RessourceSas);
        }

        /// <summary>
        /// Test de la méthode ListerProfilsExistants avec l'identite nulle. Exception levée.
        /// </summary>
        [Test]
        public void ListerProfilsExistants_IdentiteNulle_ExceptionLevee()
        {
            //Act.
            TestDelegate action = () => this.profilFonctionnaliteService.ListerProfilsExistants(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de ListerProfilsExistants

        #region Test de VerifierFichierMiseAJourCrm
        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec les paramètre OK.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreOK_OK()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, true);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec les libellés différent pour un même profil.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreLibelleProfilKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP2;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec une description différente pour un même profil.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreDescriptionProfilKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP2;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec une ressource sas différente pour un même profil.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreSasProfilKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS7;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec un libellé différent pour un même groupe.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreLibelleGroupeKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG4;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec une description différente pour un même groupe.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreDescriptionGroupeKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG6;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }

        /// <summary>
        /// Test de la méthode VerifierFichierMiseAJourCrm avec une description différente pour une même fonctionnalité.
        /// </summary>
        [Test]
        public void VerifierFichierMiseAJourCrm_ParametreDescriptionFonctionnaliteKo_Ok()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF1",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            RetourVerificationFichierMiseAJourCrm retour = this.profilFonctionnaliteService.VerifierFichierMiseAJourCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.AreEqual(retour.EstFichierValide, false);
            Assert.AreEqual(9, retour.NombreLignesTraitees);
        }
        #endregion Test de VerifierFichierMiseAJourCrm

        #region Test de ModifierDroitsCrm
        [Test]
        public void ModifierDroitsCrm_ParametreOK_OK()
        {
            List<string> lignes = new List<string>()
            {
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F1;DF1",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F2;DF2",
                "P1;LP1;DP1;SAS1;G1;LG1;DG1;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F3;DF3",
                "P1;LP1;DP1;SAS1;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F3;DF3",
                "P2;LP2;DP2;SAS2;G2;LG2;DG2;F4;DF4",
                "P2;LP2;DP2;SAS2;G3;LG3;DG3;F1;DF1",
                "P2;LP2;DP2;SAS2;G4;LG4;DG4;F5;DF5",
            };

            //Act.
            TestDelegate action = ()=> this.profilFonctionnaliteService.ModifierDroitsCrm(this.identiteValide, lignes.ToArray());

            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test de ModifierDroitsCrm
    }
}
