﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Classe de test du service TransfertAppel.
    /// </summary>
    public class TransfertAppelServiceTest
    {
        private Ligne ligne;
        private Identite identite;

        private ThemeQualificationAppel theme1;
        private ThemeQualificationAppel theme2;
        private ThemeQualificationAppel theme3;

        private string numeroLigneFixe = "0123456789";
        private int delaiTransfertAppel = 123;
        private string libelleActiviteTransfertAppel = "Libellé activité transfert appel";
        private string referenceExterneValide = "THD0000123";

        private TransfertAppelService transfertAppelService;

        private Mock<IServicesExternes> servicesExternesMock;
        private Mock<IServicesTechniques> serviceTechniqueMock;
        private Mock<IBriquesServicesExternes> briquesServicesExterneMock;

        private Mock<IRepositories> repositories;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite()
            {
                Memoid = "MemoId",
                ApplicationAppelante = "EIT.Fixe.VieClient",
                Canal = Canal.NonDefini
            };

            this.InitialiserServiceExterne();
            this.InitialiserServiceTechnique();
            this.InitialiserBriqueServiceExterne();



            // Initialisation du repository Ligne.
            this.InitialiserRepositories();

            // Initialisation du service TransfertAppelService.
            this.transfertAppelService = new TransfertAppelService(this.briquesServicesExterneMock.Object, this.servicesExternesMock.Object, this.repositories.Object, this.serviceTechniqueMock.Object);

        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            this.servicesExternesMock = new Mock<IServicesExternes>();

            Mock<Domain.ServiceExterne.IHistoriqueServiceExterne> historiqueServiceExterneMock = new Mock<Domain.ServiceExterne.IHistoriqueServiceExterne>();
            this.servicesExternesMock.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterneMock.Object);

            // Mock de historiqueServiceExterne.ObtenirThemesTransfertAppel
            this.theme1 = new ThemeQualificationAppel() { Cle = 1, Libelle = "Thème 1" };
            this.theme2 = new ThemeQualificationAppel() { Cle = 2, Libelle = "Thème 2" };
            this.theme3 = new ThemeQualificationAppel() { Cle = 3, Libelle = "Thème 3" };
            ThemeQualificationAppel[] tableauRetour = new ThemeQualificationAppel[] { this.theme1, this.theme2, this.theme3 };
            this.servicesExternesMock.Setup(s => s.HistoriqueServiceExterne.ObtenirThemesTransfertAppel(It.IsAny<Identite>())).Returns(tableauRetour);
        }

        /// <summary>
        /// Initialisation du serviceTechniques.
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<Domain.ServiceExterne.IParametrage> parametrage = new Mock<Domain.ServiceExterne.IParametrage>();

            this.serviceTechniqueMock = new Mock<IServicesTechniques>();
            this.serviceTechniqueMock.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.serviceTechniqueMock.Setup(s => s.Parametrage).Returns(parametrage.Object);

            this.serviceTechniqueMock.Setup(t => t.Parametrage.DelaiTransfertAppel).Returns(this.delaiTransfertAppel);
            this.serviceTechniqueMock.Setup(t => t.Parametrage.LibelleActiviteTransfertAppel).Returns(this.libelleActiviteTransfertAppel);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            this.briquesServicesExterneMock = new Mock<IBriquesServicesExternes>();
        }


        /// <summary>
        /// Initialisation des Repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);

            // Initialisation de l'entite Ligne.
            DetailLignePourCreation detailLigne = new DetailLignePourCreation()
            {
                Cle = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                ReferenceExterne = "123456789",
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                DateFinEngagement = new DateTime(2018, 12, 31),
                IdentifiantTransactionOperateur = 1,
                Numero = this.numeroLigneFixe,
                NumeroContratOperateur = "0123",
                CleKitBox = 1,
                Rio = "rio",
                CleCommandeExpedition = 1
            };
            this.ligne = new Ligne(this.identite, detailLigne, this.serviceTechniqueMock.Object, this.servicesExternesMock.Object, this.briquesServicesExterneMock.Object, this.repositories.Object);

            // Setup des méthodes du repository
            this.repositories.Setup(mock => mock.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(this.ligne);
        }


        /// <summary>
        /// Mock. Identite valide.
        /// </summary>
        public Identite IdentiteValide
        {
            get
            {
                return new Identite()
                {
                    ApplicationAppelante = "Test",
                    Canal = Canal.Televente,
                    Memoid = "Memo",
                    PointDeVente = "Point de vente"
                };
            }
        }


        #region Test ObtenirInformationsInitialisationEcranTransfertAppel

        /// <summary>
        /// Test de la WM ObtenirInformationsInitialisationEcranTransfertAppel. Paramètres ok ok .
        /// </summary>
        [Test]
        public void ObtenirInformationsInitialisationEcranTransfertAppel_ParametresOk_Ok()
        {
            //Arrange
            Identite identite = this.IdentiteValide;
            long cleLigne = 1;

            //Act
            InformationsInitialisationEcranTransfertAppel resultat = this.transfertAppelService.ObtenirInformationsInitialisationEcranTransfertAppel(identite, cleLigne);

            //Assert
            this.servicesExternesMock.Verify(s => s.HistoriqueServiceExterne.ObtenirThemesTransfertAppel(It.IsAny<Identite>()));
            Assert.AreEqual(resultat.NumeroLigneFixe, this.numeroLigneFixe);
            Assert.AreEqual(resultat.Delai, this.delaiTransfertAppel);
            Assert.AreEqual(resultat.LibelleActivite, this.libelleActiviteTransfertAppel);
            Assert.True(resultat.ListeThemeTransfertAppel.Count() == 3);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[0].Cle, this.theme1.Cle);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[0].Libelle, this.theme1.Libelle);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[1].Cle, this.theme2.Cle);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[1].Libelle, this.theme2.Libelle);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[2].Cle, this.theme3.Cle);
            Assert.AreEqual(resultat.ListeThemeTransfertAppel[2].Libelle, this.theme3.Libelle);
        }


        /// <summary>
        /// Test de la WM ObtenirInformationsInitialisationEcranTransfertAppel. Paramètre identite nul, lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsInitialisationEcranTransfertAppel_IdentiteNulle_ExceptionLevee()
        {
            //Arrange
            Identite identite = null;
            long cleLigne = 1;

            //Act
            TestDelegate action = () => this.transfertAppelService.ObtenirInformationsInitialisationEcranTransfertAppel(identite, cleLigne);

            //Assert            
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la WM ObtenirInformationsInitialisationEcranTransfertAppel. Paramètre cleLigne invalide, lève une exception.
        /// </summary>
        [Test]
        public void ObtenirInformationsInitialisationEcranTransfertAppel_cleLigneInvalide_ExceptionLevee()
        {
            //Arrange
            Identite identite = this.IdentiteValide;
            long cleLigne = 0;

            //Act
            TestDelegate action = () => this.transfertAppelService.ObtenirInformationsInitialisationEcranTransfertAppel(identite, cleLigne);

            //Assert            
            Assert.That(action, Throws.InstanceOf(typeof(ArgumentOutOfRangeException)));
        }

        #endregion Test ObtenirInformationsInitialisationEcranTransfertAppel

        #region Test ListerNiveau1TransfertDesAppelsParCleTheme
        /// <summary>
        /// Test de la WM ListerNiveau1TransfertDesAppelsParCleTheme. Paramètres ok ok .
        /// </summary>
        [Test]
        public void ListerNiveau1TransfertDesAppelsParCleTheme_ParametresOk_Ok()
        {
            //Arrange
            int cleTheme = 324;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            Mock<Domain.ServiceExterne.IHistoriqueServiceExterne> historiqueServiceMock = new Mock<Domain.ServiceExterne.IHistoriqueServiceExterne>();
            Niveau1QualificationAppel qualif1 = new Niveau1QualificationAppel() { Cle = 1, Libelle = "Niveau1.1" };
            Niveau1QualificationAppel qualif2 = new Niveau1QualificationAppel() { Cle = 2, Libelle = "Niveau1.2" };
            Niveau1QualificationAppel qualif3 = new Niveau1QualificationAppel() { Cle = 3, Libelle = "Niveau1.3" };
            Niveau1QualificationAppel[] tableauRetour = new Niveau1QualificationAppel[] { qualif1, qualif2, qualif3 };
            historiqueServiceMock.Setup(h => h.ObtenirNiveau1TransfertAppelParCleTheme(identite, cleTheme)).Returns(tableauRetour);

            servicesExtenresMock.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceMock.Object);

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);
            //Act
            Niveau1TransfertAppel[] resultat = service.ListerNiveau1TransfertDesAppelsParCleTheme(identite, cleTheme);
            //Assert
            historiqueServiceMock.Verify(h => h.ObtenirNiveau1TransfertAppelParCleTheme(identite, cleTheme));
            Assert.That(resultat[0].Cle, Is.EqualTo(qualif1.Cle));
            Assert.That(resultat[0].Libelle, Is.EqualTo(qualif1.Libelle));
            Assert.That(resultat[1].Cle, Is.EqualTo(qualif2.Cle));
            Assert.That(resultat[1].Libelle, Is.EqualTo(qualif2.Libelle));
            Assert.That(resultat[2].Cle, Is.EqualTo(qualif3.Cle));
            Assert.That(resultat[2].Libelle, Is.EqualTo(qualif3.Libelle));
            Assert.That(resultat.Count, Is.EqualTo(tableauRetour.Count()));
        }

        /// <summary>
        /// Test de la WM ListerNiveau1TransfertDesAppelsParCleTheme. Identite nulle, exception levée.
        /// </summary>
        [Test]
        public void ListerNiveau1TransfertDesAppelsParCleTheme_IdentiteNulle_ExceptionLevee()
        {
            //Arrange
            int cleTheme = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);
            //Act
            TestDelegate action = () => service.ListerNiveau1TransfertDesAppelsParCleTheme(null, cleTheme);
            //Assert
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la WM ListerNiveau1TransfertDesAppelsParCleTheme. Cle Invalide, exception levée.
        /// </summary>
        [Test]
        public void ListerNiveau1TransfertDesAppelsParCleTheme_CleInvalide_ExceptionLevee()
        {
            //Arrange
            int cleThemeInvalide = -1;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);
            //Act
            TestDelegate action = () => service.ListerNiveau1TransfertDesAppelsParCleTheme(identite, cleThemeInvalide);
            //Assert
            Assert.That(action, Throws.InstanceOf(typeof(ArgumentOutOfRangeException)));

        }

        /// <summary>
        /// Test de la WM ListerNiveau1TransfertDesAppelsParCleTheme. Cle null, exception levée.
        /// </summary>
        [Test]
        public void ListerNiveau1TransfertDesAppelsParCleTheme_CleNull_ExceptionLevee()
        {
            //Arrange
            int cleTheme = 0;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);
            //Act
            TestDelegate action = () => service.ListerNiveau1TransfertDesAppelsParCleTheme(identite, cleTheme);
            //Assert
            Assert.That(action, Throws.InstanceOf(typeof(ArgumentOutOfRangeException)));

        }
        #endregion Test ListerNiveau1TransfertDesAppelsParCleTheme

        #region Test ListerNiveau2TransfertDesAppelsParcleNiveau1

        /// <summary>
        /// Test de la WM ListerNiveau2TransfertDesAppelsParcleNiveau1. Paramètres ok ok .
        /// </summary>
        [Test]
        public void ListerNiveau2TransfertDesAppelsParCleNiveau1_ParametresOk_Ok()
        {
            //Arrange
            int cleNiveau1 = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            Mock<Domain.ServiceExterne.IHistoriqueServiceExterne> historiqueServiceMock = new Mock<Domain.ServiceExterne.IHistoriqueServiceExterne>();
            Niveau2QualificationAppel qualif1 = new Niveau2QualificationAppel() { Cle = 1, Libelle = "Niveau2.1" };
            Niveau2QualificationAppel qualif2 = new Niveau2QualificationAppel() { Cle = 2, Libelle = "Niveau2.2" };
            Niveau2QualificationAppel qualif3 = new Niveau2QualificationAppel() { Cle = 3, Libelle = "Niveau2.3" };
            Niveau2QualificationAppel[] tableauRetour = new Niveau2QualificationAppel[] { qualif1, qualif2, qualif3 };
            historiqueServiceMock.Setup(h => h.ObtenirNiveau2TransfertAppelParCleNiveau1(identite, cleNiveau1)).Returns(tableauRetour);

            servicesExtenresMock.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceMock.Object);

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            Niveau2TransfertAppel[] resultat = service.ListerNiveau2TransfertDesAppelsParCleNiveau1(identite, cleNiveau1);

            //Assert
            historiqueServiceMock.Verify(h => h.ObtenirNiveau2TransfertAppelParCleNiveau1(identite, cleNiveau1));
            Assert.That(resultat[0].Cle, Is.EqualTo(qualif1.Cle));
            Assert.That(resultat[0].Libelle, Is.EqualTo(qualif1.Libelle));
            Assert.That(resultat[1].Cle, Is.EqualTo(qualif2.Cle));
            Assert.That(resultat[1].Libelle, Is.EqualTo(qualif2.Libelle));
            Assert.That(resultat[2].Cle, Is.EqualTo(qualif3.Cle));
            Assert.That(resultat[2].Libelle, Is.EqualTo(qualif3.Libelle));
            Assert.That(resultat.Count, Is.EqualTo(tableauRetour.Count()));
        }

        /// <summary>
        /// Test de la WM ListerNiveau2TransfertDesAppelsParcleNiveau1. Identite nulle, exception levée.
        /// </summary>
        [Test]
        public void ListerNiveau2TransfertDesAppelsParCleNiveau1_IdentiteNulle_ExceptionLevee()
        {
            //Arrange
            int cleNiveau1 = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            TestDelegate action = () => service.ListerNiveau2TransfertDesAppelsParCleNiveau1(null, cleNiveau1);

            //Assert
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la WM ListerNiveau2TransfertDesAppelsParcleNiveau1. Cle Invalide, exception levée.
        /// </summary>
        [Test]
        public void ListerNiveau2TransfertDesAppelsParCleNiveau1_Cleinvalide_ExceptionLevee()
        {
            //Arrange
            int cleNiveau1 = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            TestDelegate action = () => service.ListerNiveau2TransfertDesAppelsParCleNiveau1(identite, -cleNiveau1);

            //Assert
            Assert.That(action, Throws.InstanceOf(typeof(ArgumentOutOfRangeException)));
        }
        #endregion Test ListerNiveau2TransfertDesAppelsParcleNiveau1

        #region TransfererAppelServiceTechnique
        /// <summary>
        /// Test de la WM TransfererAppelServiceTechnique. Paramètres ok, ok.
        /// </summary>
        [Test]
        public void TransfererAppelServiceTechnique_ParametresOk_Ok()
        {
            //Arrange
            int cleLigne = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<Domain.ServiceExterne.IParametrage> parametrage = new Mock<Domain.ServiceExterne.IParametrage>();
            servicesTechniquesMock.Setup(x => x.Parametrage).Returns(parametrage.Object);
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<ILigneRepository> ligneRepoMock = new Mock<ILigneRepository>();
            Mock<Ligne> ligneMock = new Mock<Ligne>();
            ligneMock.Setup(l => l.CleTiers).Returns(1);
            ligneRepoMock.Setup(l => l.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(ligneMock.Object);
            repositoriesMock.Setup(r => r.LigneRepository).Returns(ligneRepoMock.Object);
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            Mock<IBriqueGboServiceExterne> gboMock = new Mock<IBriqueGboServiceExterne>();
            gboMock.Setup(g => g.CreerDossier(identite, It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>()));
            briquesMock.Setup(b => b.BriqueGboServiceExterne).Returns(gboMock.Object);

            Mock<Domain.ServiceExterne.IHistoriqueServiceExterne> historiqueMock = new Mock<Domain.ServiceExterne.IHistoriqueServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceMock = new Mock<ITiersServiceExterne>();
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiersMock = new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail() { Prenom = "Prenom", Nom = "Nom" };
            tiersServiceMock.Setup(t => t.ObtenirParCle(identite, It.IsAny<long>())).Returns(tiersMock);
            historiqueMock.Setup(h => h.CreerHistoriqueAppel(identite, It.IsAny<HistoriqueAppelPourCreation>()));
            servicesExtenresMock.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueMock.Object);
            briquesMock.Setup(b => b.TiersServiceExterne).Returns(tiersServiceMock.Object);

            ParametresTransfertAppelVersLeSupportTechnique parametres = new ParametresTransfertAppelVersLeSupportTechnique()
            {
                CleLigne = cleLigne,
                CleNiveau1 = 1,
                CleNiveau2 = 1,
                CleTheme = 12,
                Commentaire = "Ceci est un commentaire",
                ReferenceExterne = referenceExterneValide
            };
            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            service.TransfererAppelServiceTechnique(identite, parametres);

            //Assert
            gboMock.Verify(g => g.CreerDossier(identite, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>()));
            historiqueMock.Verify(h => h.CreerHistoriqueAppel(identite, It.IsAny<HistoriqueAppelPourCreation>()));
        }

        /// <summary>
        /// Test de la WM TransfererAppelServiceTechnique. Identite nulle, exception levée.
        /// </summary>
        [Test]
        public void TransfererAppelServiceTechnique_IdentiteNulle_ExceptionLevee()
        {
            //Arrange
            int cleLigne = 1234;
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            ParametresTransfertAppelVersLeSupportTechnique parametres = new ParametresTransfertAppelVersLeSupportTechnique()
            {
                CleLigne = cleLigne,
                CleNiveau1 = 1,
                CleNiveau2 = 1,
                CleTheme = 12,
                Commentaire = "Ceci est un commentaire"
            };
            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            TestDelegate action = () => service.TransfererAppelServiceTechnique(null, parametres);

            //Assert
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test de la WM TransfererAppelServiceTechnique. ParametresTransfertAppelVersLeSupportTechnique nulle, exception levée.
        /// </summary>
        [Test]
        public void TransfererAppelServiceTechnique_ParametresTransfertAppelVersLeSupportTechniqueNulle_ExceptionLevee()
        {
            //Arrange
            Identite identite = this.IdentiteValide;
            Mock<IServicesExternes> servicesExtenresMock = new Mock<IServicesExternes>();
            Mock<IServicesTechniques> servicesTechniquesMock = new Mock<IServicesTechniques>();
            Mock<IRepositories> repositoriesMock = new Mock<IRepositories>();
            Mock<IBriquesServicesExternes> briquesMock = new Mock<IBriquesServicesExternes>();

            TransfertAppelService service = new TransfertAppelService(briquesMock.Object, servicesExtenresMock.Object, repositoriesMock.Object, servicesTechniquesMock.Object);

            //Act
            TestDelegate action = () => service.TransfererAppelServiceTechnique(identite, null);

            //Assert
            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test TransfererAppelServiceTechnique
    }
}
