﻿using System;
using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Application.Services;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Application.Test
{
    /// <summary>
    /// Classe de test du service Annuaire.
    /// </summary>
    [TestFixture]
    public class AnnuaireServiceTest
    {
        #region Propriétés 
        
        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Offre pour détail.
        /// </summary>
        OffrePourDetail offrePourDetail { get; set; }

        /// <summary>
        /// Information annuaire universel .
        /// </summary>
        InformationsAnnuaireUniversel informationsAnnuaireUniversel { get; set; }

        /// <summary>
        /// Liste de professions.
        /// </summary>
        List<ParamProfession> listeProfessions { get; set; }


        /// <summary>
        /// Mock de Ligne
        /// </summary>
        private Mock<Ligne> ligneMock { get; set; }




        /// <summary>
        /// Clé valide d'un tiers.
        /// </summary>
        private int CleTiersValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Clé valide d'une ligne.
        /// </summary>
        private int CleLigneValide
        {
            get
            {
                return 10;
            }
        }


        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.Init();
            this.identiteValide = new Identite() { Memoid = "MemoId" };
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserRepositories();
        }
        

        private void Init()
        {
            this.offrePourDetail = new OffrePourDetail()
            {
                Descriptif = "descriptif de l'offre"
            };

            this.listeProfessions = new List<ParamProfession>();
            for (int i = 1; i <= 10; i++)
                this.listeProfessions.Add(new ParamProfession() { Cle = i, Libelle = "Profession " + i });

            this.informationsAnnuaireUniversel = new InformationsAnnuaireUniversel()
            {
                CleTiers = 1,
                DiffusionAnnuaireUniversel = true,
                DiffusionEmail = true,
                DiffusionPrenom = true,
                DiffusionProfession = true,
                InscriptionAnnuaireInverse = true,
                LimiterDiffusionAdresseVille = true,
                NumeroTelephone = "0102030405",
                Profession = this.listeProfessions[0],
                ReferenceExterne = "0123456789",
                UtilisationMarketing = true
            };


            // Initialisation de l'entite Ligne.
            ligneMock = new Mock<Ligne>();
            this.ligneMock.Setup(l => l.CleOffre).Returns(123);
            this.ligneMock.Setup(l => l.CleTiers).Returns(222);
            this.ligneMock.Setup(l => l.Numero).Returns("0102030405");
            this.ligneMock.Setup(l => l.ReferenceExterne).Returns("0123456789");
            // mock de la liste d'historiques de la ligne
            Mock<HistoriqueEtatLigne>  historiqueEtatLigneMock = new Mock<HistoriqueEtatLigne>();
            historiqueEtatLigneMock.Setup(x=> x.NouvelEtat).Returns(EtatLigne.Activee);
            historiqueEtatLigneMock.Setup(x => x.DateChangementEtat).Returns(new DateTime(2018,04,01,13,37,00));
            List<HistoriqueEtatLigne> historiqueEtatsLigne = new List<HistoriqueEtatLigne>();
            historiqueEtatsLigne.Add(historiqueEtatLigneMock.Object);
            this.ligneMock.Setup(l => l.ListeHistoriqueEtats).Returns(historiqueEtatsLigne);

        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();

            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.repositories.Setup(x => x.LigneRepository).Returns(ligneRepository.Object);
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(this.ligneMock.Object);
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
            
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne).Returns(new Mock<IReferentielServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirOffreParCle(this.identiteValide, It.IsAny<int>())).Returns(this.offrePourDetail);

            this.servicesExternes.Setup(x => x.SouscriptionServiceExterne).Returns(new Mock<ISouscriptionServiceExterne>().Object);            
            this.servicesExternes.Setup(x => x.SouscriptionServiceExterne.ListerProfessionAnnuaire(It.IsAny<Identite>())).Returns(this.listeProfessions);

            this.servicesExternes.Setup(x => x.AnnuaireServiceExterne.ObtenirAnnuaireUniversel(It.IsAny<Identite>(), It.IsAny<string>())).Returns(this.informationsAnnuaireUniversel);
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
            Mock<ITiersServiceExterne> tierServiceExterne = new Mock<ITiersServiceExterne>();
            this.briquesExternes.Setup(x => x.TiersServiceExterne).Returns(tierServiceExterne.Object);
            this.briquesExternes.Setup(x => x.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(
                new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
                                        {
                                            Cle = this.CleTiersValide,
                                            EmailContact = "sup@man.com"
                                        }
                );

        }
        

        #endregion Méthodes d'initialisation et de vérification

        #region Tests de l'initialisation du service

        /// <summary>
        /// Test du constructeur de AnnuaireService dans le cas ou l'interface des repositories est à null. Lève une exception.
        /// </summary>
        [Test]
        public void AnnuaireService_RepositoriesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new InfosAnnuaireService(this.briquesExternes.Object, this.servicesExternes.Object, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        /// Test du constructeur de AnnuaireService dans le cas ou l'interface des services externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void AnnuaireService_ServiceExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new InfosAnnuaireService(this.briquesExternes.Object, null, this.repositories.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de AnnuaireService dans le cas ou l'interface des briques externes est à null. Lève une exception.
        /// </summary>
        [Test]
        public void AnnuaireService_BriquesExternesNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new InfosAnnuaireService(null, this.servicesExternes.Object, this.repositories.Object);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de AnnuaireService. Tous paramètres OK. exécution OK.
        /// </summary>
        [Test]
        public void TiersService_ParametresOK_OK()
        {
            // Act.
            TestDelegate action = () => new InfosAnnuaireService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de l'initialisation du service



        #region Tests de la méthode ObtenirParutionAnnuaireUniverselDepuisCleLigne

        

        /// <summary>
        /// Test de la méthode ListerProfessionAnnuaire . Résultat Ok.
        /// </summary>
        [Test]
        public void ObtenirParutionAnnuaireUniverselDepuisCleLigne_OK()
        {
            // Arrange.            
            InfosAnnuaireService annuaireServive = new InfosAnnuaireService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);

            // Act.
            TestDelegate action = () => annuaireServive.ObtenirParutionAnnuaireUniverselDepuisCleLigne(this.identiteValide, 123);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de la méthode ObtenirParutionAnnuaireUniverselDepuisCleLigne



        #region Tests de la méthode EnregistrerParutionAnnuaireUniversel

        

        #endregion Tests de la méthode EnregistrerParutionAnnuaireUniversel



        #region Tests de la méthode ListerProfessionAnnuaire

        /// <summary>
        /// Test de la méthode ListerProfessionAnnuaire . Résultat Ok.
        /// </summary>
        [Test]
        public void ListerProfessionAnnuaire_OK()
        {
            // Arrange.            
            InfosAnnuaireService annuaireServive = new InfosAnnuaireService(this.briquesExternes.Object, this.servicesExternes.Object, this.repositories.Object);
                        
            // Act.
            TestDelegate action = () => annuaireServive.ListerProfessionAnnuaire(this.identiteValide);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Tests de la méthode ListerProfessionAnnuaire

    }
}
