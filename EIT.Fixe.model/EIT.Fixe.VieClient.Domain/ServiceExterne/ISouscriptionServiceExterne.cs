﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la domaine externe Souscription.
    /// </summary>
    public interface ISouscriptionServiceExterne
    {
        /// <summary>
        /// Récupération d'une commande de souscription depuis sa référence externe.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Informations de la commande de souscription.</returns>
        CommandeSouscriptionPourDetail RechercherCommandeSouscriptionParReferenceExterne(Identite identite, string referenceExterne);

        /// <summary>
        /// Permet de récupérer l'adresseInstallation depuis la ref externe.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleAdresseInstallation">Cle d'adresse installation.</param>
        /// <returns>AdresseInstallation.</returns>
        AdresseInstallationPourDetail ObtenirAdresseInstallationParCleEligibilite(Identite identite, long cleAdresseInstallation);
        
        /// <summary>
        /// Liste les professions disponibles pour l’annuaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <returns>Liste des professions disponibles dans l’annuaire.</returns>
        List<ParamProfession> ListerProfessionAnnuaire(Identite identite);

    }
}