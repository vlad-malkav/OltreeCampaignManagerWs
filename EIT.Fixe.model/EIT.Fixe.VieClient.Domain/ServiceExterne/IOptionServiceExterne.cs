﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe Options.
    /// </summary>
    public interface IOptionServiceExterne
    {
        /// <summary>
        /// Permet de récupérer les informations d'une location de box par clé du gestionnaire d'option.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaire">Cle du gestionnaire.</param>
        /// <returns>InformationLocationBoxPourDetail</returns>
        InformationsLocationBoxPourDetail ObtenirLocationBoxParCleGestionnaire(Systeme.Identification.Identite identite, long cleGestionnaire);
    }
}