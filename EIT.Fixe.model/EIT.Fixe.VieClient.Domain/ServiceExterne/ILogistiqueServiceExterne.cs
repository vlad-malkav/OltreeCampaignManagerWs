﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des intéractions avec le service logistique.
    /// </summary>
    public interface ILogistiqueServiceExterne
    {
        /// <summary>
        /// Permet de créer une demande de retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Une demande de retour équipement correspodant à la référence externe donnée en paramètre.</returns>
        DemandeRetourEquipement CreerDemandeRetourEquipement(Identite identite, string referenceExterne);

        /// <summary>
        /// Permet de gérer les traitements liés à la commande de retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="informationsCommandeRetourEquipement">Informations de la commande de retour équipement à créer.</param>
        void GererCommandeRetourEquipement(Identite identite, string referenceExterne, CommandeRetourEquipementPourCreation informationsCommandeRetourEquipement);

        /// <summary>
        /// Permet d'obtenir une liste de commande d'expédition reférence commerciale pour lister.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleCommandeExpedition">Clé de la commande d'expédition.</param>
        /// <returns>Une liste CommandeExpeditionReferenceCommercialePourLister.</returns>
        List<CommandeExpeditionReferenceCommercialePourLister> ObtenirCommandeExpeditionParCle(Identite identite, long cleCommandeExpedition);

        /// <summary>
        /// Retourne les informations décrivant l'équipement.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleEquipement">Clé unique de l'équipement.</param>
        /// <returns></returns>
        Equipement ObtenirEquipementDepuisCle(Identite identite, long cleEquipement);
    }
}