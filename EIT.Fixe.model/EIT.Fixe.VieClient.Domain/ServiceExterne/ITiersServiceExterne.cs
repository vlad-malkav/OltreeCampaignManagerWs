﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe Tiers.
    /// </summary>
    public interface ITiersServiceExterne
    {
        /// <summary>
        /// Obtient le login SFC du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Email/LoginSFC du tiers.</returns>
        string ObtenirLoginSfcParCleTiers(Identite identite, long cleTiers);

        /// <summary>
        /// Obtient le tiers par clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Ensemble des informations du tiers.</returns>
        TiersPourDetail ObtenirParCle(Identite identite, long cleTiers);

        /// <summary>
        /// Obtient la clé mobile d'un tiers via la clé fixe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiersFixe">Clé fixe du tiers.</param>
        /// <returns>Informations du tiers associé.</returns>
        TiersAssociePourDetail ObtenirCleTiersMobileParCleTiersFixe(Identite identite, int cleTiersFixe);

        /// <summary>
        /// Permet de modifier l'email de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <param name="email">Email de contact du tiers.</param>
        void ModifierEmailContactTiers(Identite identite, long cleTiers, string email);

        /// <summary>
        /// Permet de modifier les numéros de téléphones de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <param name="numeroMobile">Téléphone mobile de contact du tiers.</param>
        /// <param name="numeroFixe">Téléphone fixe de contact du tiers.</param>
        void ModifierTelephonesContactTiers(Identite identite, long cleTiers, string numeroMobile, string numeroFixe);

        /// <summary>
        /// Permet de modifier les préférences de contact du tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="preferences">Préférences de contact.</param>
        void ModifierPreferenceDeContactTiers(Identite identite, ParametrePreferencesContactTiers preferences);
    }
}