﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interactions avec la service externe Annuaire (Souscription).
    /// </summary>
    public interface IAnnuaireServiceExterne
    {

        /// <summary>
        /// Modifie les informations de parution dans l’annuaire universel, en dehors du parcours de souscription.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="parametresDefinitionAnnuaire">Informations de l’annuaire universel.</param>
        void ModifierParutionAnnuaireUniverselParReferenceExterne(Identite identite, string referenceExterne, ParametresDefinirAnnuaire parametresDefinirAnnuaire);

        /// <summary>
        /// Définit le refus du tiers à figurer dans l’annuaire universel, en dehors du parcours de souscription.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        void DefinirRefusAnnuaireUniverselParReferenceExterne(Identite identite, string referenceExterne);


        /// <summary>
        /// Obtient les informations relatives à la parution dans l’annuaire universel associées à une référence externe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Informations relatives à la parution dans l’annuaire universel.</returns>
        InformationsAnnuaireUniversel ObtenirAnnuaireUniversel(Identite identite, string referenceExterne);


    }
}