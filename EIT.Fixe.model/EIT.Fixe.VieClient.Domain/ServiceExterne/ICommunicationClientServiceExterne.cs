﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des intéractions avec le service CommunicationClient.
    /// </summary>
    public interface ICommunicationClientServiceExterne
    {
        /// <summary>
        /// Permet d'envoyer un mail d'annulation de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailAnnulerResiliation(Identite identite, ParametresEmailAnnulerResiliation parametres);

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement d'email.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailConfirmerChangementEmail(Identite identite, ParametresChangement parametres);

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement d'options.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailConfirmerChangementOptions(Identite identite, ParametresEmailConfirmerChangementOptions parametres);

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de changement de numéro de téléphone.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailConfirmerChangementTelephone(Identite identite, ParametresEmailConfirmerChangementTelephone parametres);

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de résiliation avec étiquette.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailConfirmerResiliationAvecEtiquette(Identite identite, ParametresEmailConfirmerResiliationAvecEtiquette parametres);

        /// <summary>
        /// Permet d'envoyer un mail de confirmation de résiliation sans étiquette.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerMailConfirmerResiliationSansEtiquette(Identite identite, ParametresEmailConfirmerResiliationSansEtiquette parametres);

        /// <summary>
        /// Permet d'envoyer un courrier de confirmation de résiliation sans étiquette.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du courrier.</param>
        void EnvoyerCourrierConfirmerResiliationSansEtiquette(Identite identite, ParametresCourrierConfirmerResiliationSansEtiquette parametres);

        /// <summary>
        /// Permet d'envoyer une confirmation par SMS pour la réinitialisation du code du SelfCare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètre du SMS.</param>
        void EnvoyerSmsConfirmationReinitialisationCodeSelfCare(Identite identite, ParametreSMSConfirmationReinitialisationCodeSelfCare parametres);

        /// <summary>
        /// Permet d'envoyer une confirmation par SMS pour la remise en service.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètre du SMS.</param>
        void EnvoyerSmsRemiseEnService(Identite identite, ParametreSmsRemiseEnService parametres);

        /// <summary>
        /// Permet d'envoyer un mail avec le RIO. VIECLIENT_COM_CONFIRMRIO_MAIL.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres de l'email.</param>
        void EnvoyerEmailRio(Identite identite, ParametresEmailRio parametres);

        /// <summary>
        /// Envoi un email de confirmation de réinitialisation du code Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du mail.</param>
        void EnvoyerEmailConfirmationReinitialisationCodeSelfCare(Identite identite, ParametreEmailConfirmationReinitialisationCodeSelfCare parametres);

        /// <summary>
        /// Permet d'envoyer un courrier avec le RIO.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du courrier.</param>
        void EnvoyerCourrierRio(Identite identite, ParametresCourrierRio parametres);

        /// <summary>
        /// Permet d'envoyer un SMS à un client pour la confirmation du RIO.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametres">Paramètres pour l'envoi du SMS.</param>
        void EnvoyerSmsConfirmationRio(Identite identite, ParametresSmsRio parametres);

        /// <summary>
        /// Envoi un email pour confirmation de la demande de résiliation.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="parametres">Paramètres du mail.</param>
        void EnvoyerMailConfirmationDemandeResiliation(Identite identite, ParametresEmailConfirmerDemandeResiliation parametres);
    }
}