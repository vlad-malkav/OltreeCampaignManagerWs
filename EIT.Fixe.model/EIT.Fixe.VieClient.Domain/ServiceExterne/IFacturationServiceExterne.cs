﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des intéractions avec le service Facturation.
    /// </summary>
    public interface IFacturationServiceExterne
    {
        /// <summary>
        /// Obtenir la date de la dernière facture par clé de ligne.
        /// </summary>
        /// <param name="identite">Identité.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Date de la dernière facture.</returns>
        DateTime? RechercherDateDerniereFactureParCleLigne(Identite identite, long cleLigne);
        
        /// <summary>
        /// Retourne la liste des motifs de suspension de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns></returns>
        List<string> ObtenirListeMotifsSuspensionParReferenceExterne(Identite identite, string referenceExterne);


        /// <summary>
        ///  Retourne les informations des seuils de surconsommation  de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Informations des seuils de surconsommation.</returns>
        InformationsSeuilsSurconsommation ObtenirInformationsSeuilsSurconsommationParReferenceExterne(Identite identite, string referenceExterne);
    }
}