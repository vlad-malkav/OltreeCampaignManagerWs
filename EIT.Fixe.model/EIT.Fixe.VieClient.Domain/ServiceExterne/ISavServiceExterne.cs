﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des interactions avec le service externe SAV.
    /// </summary>
    public interface ISavServiceExterne
    {

        /// <summary>
        /// Retourne la liste des clés des "SAV équipement" associés à la ligne depuis sa référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        List<long> ListerClesSavEquipementParReferenceExterne(Identite identite, string referenceExterne);


        /// <summary>
        /// Indique si un SAV technicien est en cours sur une ligne.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <returns>Présence d'un SAV technicien en cours sur la ligne.</returns>
        bool VerifierSavTechnicienEnCoursParReferenceExterne(Identite identite, string referenceExterne);

    }
}