﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Intéractions avec la brique externe Référentiel.
    /// </summary>
    public interface IReferentielServiceExterne
    {
        /// <summary>
        /// Récupère les informations de la technologie de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleTechnologie">Clé de la technologie.</param>
        /// <returns>Technologie correspondante à la clé.</returns>
        TechnologiePourDetail ObtenirTechnologieParCle(Identite identite, int cleTechnologie);

        /// <summary>
        /// Permet de récupérer l'ensemble des informations d'une offre par sa clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Offre correspondante à la clé.</returns>
        OffrePourDetail ObtenirOffreParCle(Identite identite, int cleOffre);

        /// <summary>
        /// Permet de récupérer le libellé d'une marque par sa clé.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleMarque">Cle de la marque.</param>
        /// <returns>Libellé de la marque correspondante.</returns>
        string ObtenirLibelleMarqueParCle(Identite identite, int cleMarque);

        /// <summary>
        /// Permet de récupérer une promotion par sa clé.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="clePromotion">Clé unique de la promotion.</param>
        ///  <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Ensemble des informations d'une promotion.</returns>
        PromotionPourDetail ObtenirPromotionParCle(Identite identite, int clePromotion, int cleOffre);

        /// <summary>
        /// Recherche une liste de promotions par leurs clés.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="listeClesPromotion">Liste de clés uniques de promotions.</param>
        /// <returns>Tableau de promotions.</returns>
        PromotionPourDetail[] RechercherPromotionsDepuisListeCles(Identite identite, int[] listeClesPromotion);

        /// <summary>
        /// Recherche une liste de promotions par leurs clés.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="listeClesPromotion">Liste de clés uniques de promotions.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Tableau de promotions.</returns>
        PromotionPourDetail[] RechercherPromotionsDepuisListeClesEtCleOffre(Identite identite, int cleOffre, int[] listeClesPromotion);

        /// <summary>
        /// Fournit la liste des promotions éligibles pour l'offre.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Liste des promotions éligibles.</returns>
        PromotionPourDetail[] ObtenirPromotionsEligiblesParCleOffre(Identite identite, int cleOffre);

        /// <summary>
        /// Teste l’éligibilité d’un code promo par rapport à une ligne.
        /// </summary>
        /// <param name="identite">Information d'identification de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <param name="clePromo">Clé unique de la promotion.</param>
        /// <returns></returns>
        bool TesterEligibiliteCodePromo(Identite identite, int cleOffre, int clePromo);

        /// <summary>
        /// Retourne les informations du kit de la box.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleKitBox">Clé du KitBox.</param>
        /// <returns>Informations du KitBox.</returns>
        RefComKitBox ObtenirRefComKitBox(Identite identite, int cleKitBox);

        /// <summary>
        /// Retourne les informations de la "référence commerciale".
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="codeRefCom">Code de la "référence commerciale".</param>
        /// <returns>Informations de la référence commerciale sérialisée.</returns>
        RefComSerialisee ObtenirRefComSerialiseeDepuisCodeRefCom(Identite identite, string codeRefCom);

        /// <summary>
        /// Permet d'obtenir une marque.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleMarque">Clé de la marque.</param>
        /// <returns>Informations sur la marque.</returns>
        Marque ObtenirMarqueParCle(Identite identite, int cleMarque);
    }
}