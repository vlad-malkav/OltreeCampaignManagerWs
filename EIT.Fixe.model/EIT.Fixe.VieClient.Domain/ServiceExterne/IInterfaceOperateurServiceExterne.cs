﻿using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des intéractions avec le service InterfaceOperateur.
    /// </summary>
    public interface IInterfaceOperateurServiceExterne
    {
        /// <summary>
        /// Permet de créer une demande de résiliation auprès de l'opérateur.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        void CreerDemandeResiliation(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur);

        /// <summary>
        /// Permet de créer une demande de suspension de ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        void CreerDemandeSuspension(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur);

        /// <summary>
        /// Permet de créer une demande de remise en service.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        void CreerDemandeRemiseEnService(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur);

        /// <summary>
        /// Permet de créer une demande de rétractation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="identifiantTransactionOperateur">Identifiant de transaction opérateur.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        void CreerDemandeRetractation(Identite identite, int identifiantTransactionOperateur, string numeroContratOperateur);
    }
}