﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des interactions avec le service externe SAV Equipement.
    /// </summary>
    public interface ISavEquipementServiceExterne
    {       
        
        /// <summary>
        /// Retourne le numéro de retour colis associé à un "SAV équipement".
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cleSavEquipement">Clé du SAV Equipement.</param>
        string ObtenirNumeroRetourColisDepuisCleSavEquipement(Identite identite, long cleSavEquipement);

    }
}