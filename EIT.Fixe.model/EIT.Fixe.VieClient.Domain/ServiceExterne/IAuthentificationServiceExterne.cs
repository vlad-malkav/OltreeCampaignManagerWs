﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe login.
    /// </summary>
    public interface IAuthentificationServiceExterne
    {
        /// <summary>
        /// Permet de récupérer les niveaux d’accès à l’espace client, par la clé ligne.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cleLigne">Clé technique du compte client.</param>
        string ObtenirLoginLigneParCleLigne(Identite identite, int cleLigne);

        /// <summary>
        /// Permet de récupérer les informations de login d’un compte client, par sa clé.
        /// </summary>
        /// <param name="cleCompteClient">Clé technique du compte client.</param>
        /// <param name="identite">Informations de l’appelant.</param>
        InformationsLoginCompteClient ObtenirLoginCcParCleCompteClient(Identite identite, int cleCompteClient);

        /// <summary>
        /// Permet de réinitialiser le mot de passe SFC.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        /// <returns>Le mot de passe temporaire SFC.</returns>
        string ReinitialiserMotDePasseSfc(Identite identite, string login);

        /// <summary>
        /// Permet de changer le mot de passe d'accès au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login associé au mot de passe à modifier.</param>
        /// <param name="ancienMotDePasse">Ancien mot de passe.</param>
        /// <param name="nouveauMotDePasse">Nouveau mot de passe.</param>
        /// <returns>Réponse de la modification de mot de passe.</returns>
        ReponseModificationMotDePasse ChangerMotDePasseSelfcare(Identite identite, string login, string ancienMotDePasse, string nouveauMotDePasse);

        /// <summary>
        /// Permet d'envoyer un OTP sur l'email du login passé en paramètre.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login sur lequel on doit envoyer un OTP.</param>
        /// <param name="cleMarque">Clé de la marque.</param>
        void DemanderOtp(Identite identite, string login, int cleMarque);

        /// <summary>
        /// Permet de vérifier l'exactitude de l'OTP passé en paramètre.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login sur lequel un OTP a été envoyé.</param>
        /// <param name="codeOtp">Code de l'OTP envoyé.</param>
        /// <returns>Résultat du contrôle de validation de l'OTP.</returns>
        ReponseValidationOtp ValiderOtp(Identite identite, string login, int codeOtp);

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        void ValiderCguFixe(Identite identite, string login);

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Mobile.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        void ValiderCguMobile(Identite identite, string login);

        /// <summary>
        /// Permet de valider le parcours de bienvenue sur le Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        void ValiderParcoursBienvenue(Identite identite, string login);
    }
}