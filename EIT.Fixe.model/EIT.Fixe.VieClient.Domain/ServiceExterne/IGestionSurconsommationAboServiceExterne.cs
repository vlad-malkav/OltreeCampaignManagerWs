﻿using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe de gestion
    /// de consommation Abo.
    /// </summary>
    public interface IGestionSurconsommationAboServiceExterne
    {
        /// <summary>
        /// Permet de récupérer le seuil de surconsommation d’une ligne mobile par sa clé.
        /// </summary>
        /// <param name="cleLigne">Clé technique de la ligne mobile.</param>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <returns>Le seuil de surconsommation de la ligne.</returns>
        decimal ObtenirSeuilParCleLigne(Identite identite, int cleLigne);
    }
}