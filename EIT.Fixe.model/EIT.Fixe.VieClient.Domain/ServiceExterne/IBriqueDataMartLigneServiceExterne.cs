﻿using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.Souscription.Domain.ExternalServices
{
    /// <summary>
    /// Interface du service externe DataMart.
    /// </summary>
    public interface IBriqueDataMartLigneServiceExterne
    {
        /// <summary>
        /// Méthode qui ermet de vérifier l'existence d'une Référence Externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="referenceExterne">La Référence Externe à vérifier.</param>
        /// <returns>Résultat de la vérification.</returns>
        bool EstReferenceExterneExistante(Identite identite, string referenceExterne);
    }
}
