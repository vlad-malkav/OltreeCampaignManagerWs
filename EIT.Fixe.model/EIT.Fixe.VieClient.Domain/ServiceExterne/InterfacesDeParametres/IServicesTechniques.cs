﻿using EIT.Fixe.Systeme.Persistance;
using EIT.Messaging;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres
{
    /// <summary>
    /// Interface du service technique.
    /// </summary>
    public interface IServicesTechniques
    {
        /// <summary>
        /// Retourne l'interface de GenerateurCles.
        /// </summary>
        IGenerateurCles GenerateurCles { get; }

        /// <summary>
        /// Retourne l'interface de Parametrage.
        /// </summary>
        IParametrage Parametrage { get; }

        /// <summary>
        /// Service d'envoi de message.
        /// </summary>
        IMessagingSystem MessagingSystem { get; }

        /// <summary>
        /// Service de génération de séquences.
        /// </summary>
        IGenerateurSequences GenerateurSequences { get; }
    }
}