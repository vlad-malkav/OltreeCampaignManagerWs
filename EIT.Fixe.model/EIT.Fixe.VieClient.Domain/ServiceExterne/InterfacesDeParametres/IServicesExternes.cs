﻿namespace EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres
{
    /// <summary>
    /// Interface du service externes.
    /// </summary>
    public interface IServicesExternes
    {
        /// <summary>
        /// Retourne l'interface de ReferentielServiceExterne.
        /// </summary>
        IReferentielServiceExterne ReferentielServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de HistoriqueServiceExterne.
        /// </summary>
        IHistoriqueServiceExterne HistoriqueServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de SouscriptionServiceExterne.
        /// </summary>
        ISouscriptionServiceExterne SouscriptionServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IFacturationServiceExterne.
        /// </summary>
        IFacturationServiceExterne FacturationServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de ILogistiqueServiceExterne.
        /// </summary>
        ILogistiqueServiceExterne LogistiqueServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de ISavServiceExterne.
        /// </summary>
        ISavServiceExterne SavServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de ISavEquipementServiceExterne.
        /// </summary>
        ISavEquipementServiceExterne SavEquipementServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IAnnuaireServiceExterne (Souscription).
        /// </summary>
        IAnnuaireServiceExterne AnnuaireServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IGBOServiceExterne.
        /// </summary>
        Fixe.Domain.ExternalServices.IGboServiceExterne GboServiceExterne { get; }
    }
}