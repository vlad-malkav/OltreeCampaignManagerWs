﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Souscription.Domain.ExternalServices;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres
{
    /// <summary>
    /// Interface regroupant les interfaces des briques externes.
    /// </summary>
    public interface IBriquesServicesExternes
    {
        /// <summary>
        /// Retourne l'interface de ComptesClientServiceExterne.
        /// </summary>
        IComptesClientServiceExterne ComptesClientServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IBriqueGBOServiceExterne.
        /// </summary>
        Fixe.Domain.ExternalServices.IBriqueGboServiceExterne BriqueGboServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IGestionSurconsommationAboServiceExterne.
        /// </summary>
        IGestionSurconsommationAboServiceExterne GestionSurconsommationAboServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IAuthentificationServiceExterne.
        /// </summary>
        IAuthentificationServiceExterne AuthentificationServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de ITiersServiceExterne.
        /// </summary>
        ITiersServiceExterne TiersServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface IOptionsServiceExterne.
        /// </summary>
        IOptionsServiceExterne OptionsServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IValorisationServiceExterne.
        /// </summary>
        IValorisationServiceExterne ValorisationServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface ISfrFixeCompteTvServiceExterne.
        /// </summary>
        ISfrFixeCompteTvServiceExterne SfrFixeCompteTvServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de ICommunicationClientServiceExterne.
        /// </summary>
        ICommunicationClientServiceExterne CommunicationClientServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IIcnServiceExterne.
        /// </summary>
        IBriqueIcnServiceExterne IcnServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IInterfaceOperateurServiceExterne.
        /// </summary>
        IInterfaceOperateurServiceExterne InterfaceOperateurServiceExterne { get; }

        /// <summary>
        /// Retourne l'interface de IBriqueDataMartLigneServiceExterne.
        /// </summary>
        IBriqueDataMartLigneServiceExterne BriqueDataMartLigneServiceExterne { get; }
    }
}