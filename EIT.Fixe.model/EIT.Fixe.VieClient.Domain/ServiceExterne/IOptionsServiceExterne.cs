﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe Options.
    /// </summary>
    public interface IOptionsServiceExterne
    {
        /// <summary>
        /// Permet de récupérer les informations d'une location de box par clé du gestionnaire d'option.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaire">Cle du gestionnaire.</param>
        /// <returns>InformationLocationBoxPourDetail.</returns>
        InformationsLocationBoxPourDetail ObtenirLocationBoxParCleGestionnaire(Identite identite, string cleGestionnaire);

        /// <summary>
        /// Permet d'enregistrer des modifications d'options (souscription/résiliation) sur le gestionnaire.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        /// <param name="clesOptionsAAjouter">Liste des clés des options à ajouter.</param>
        /// <param name="clesOptionsASupprimer">Liste des clés des options à supprimer.</param>
        void ModifierOptionsGestionnaire(Identite identite, string cleGestionnaireOptions, List<int> clesOptionsAAjouter, List<int> clesOptionsASupprimer);

        /// <summary>
        /// Permet de lister les options associées au gestionnaire.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        /// <param name="clesOptions">Liste des clés d'options à retourner.</param>
        /// <returns>Liste des options.</returns>
        ReponseListeOptions RechercherOptionsParCleGestionnaire(Identite identite, string cleGestionnaireOptions, int[] clesOptions);

        /// <summary>
        /// Permet de résilier le gestionnaire d'options.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'options.</param>
        void ResilierGestionnaireOptions(Identite identite, string cleGestionnaireOptions);
    }
}