﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
   /// <summary>
   /// Contrat d'interface du service d'intéractions avec la brique externe de comptesclients.
   /// </summary>
    public interface IComptesClientServiceExterne
    {
        /// <summary>
        /// Permet de récupérer l’ensemble des comptes clients d’un tiers, par sa clé.
        /// Remarque : il s’agit de la clé tiers dans le SI Mobile.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cleTiersMobile">Clé unique du tiers au sein du SI Mobile.</param>
        /// <returns>La liste des comptes clients.</returns>
        CompteClientPourLister[] RechercherComptesClientParCleTiersTitulaireLight(Identite identite, int cleTiersMobile);

        /// <summary>
        /// Permet de récupérer l’ensemble des informations d’un compte client, par sa clé.
        /// </summary>
        /// <param name="identite">Informations de l’appelant.</param>
        /// <param name="cle">Clé technique du compte client.</param>
        /// <returns>Le compte client correspondant.</returns>
        CompteClientPourDetail ObtenirCompteClientParCle(Identite identite, long cle);
    }
}