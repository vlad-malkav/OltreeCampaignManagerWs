﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Contrat d'interface du service d'intéractions avec la brique externe historique.
    /// </summary>
    public interface IHistoriqueServiceExterne
    {
        /// <summary>
        /// Obtient la liste des historiques correspondant à la référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe sur laquelle effectuer la recherche.</param>
        /// <returns>Liste des historiques.</returns>
        HistoriquePourLister[] RechercherHistoriquesParReferenceExterne(Identite identite, string referenceExterne);

        /// <summary>
        /// Obtient la liste des historiques correspondant à la référence externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe sur laquelle effectuer la recherche.</param>
        /// <param name="indexPage">Index de la page.</param>
        /// <param name="nombreResultats">Nombre de résultats maximum à retourner.</param>
        /// <returns>Liste des historiques.</returns>
        HistoriquePourLister[] RechercherHistoriquesParReferenceExterne(Identite identite, string referenceExterne, int indexPage, int nombreResultats);

        /// <summary>
        /// Permet de créer un historique appel dans la brique externe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="informationsHistorique">Informations de l'historique à créer.</param>
        /// <returns>Clé de l'Historique Appel créé.</returns>
        long CreerHistoriqueAppel(Identite identite, HistoriqueAppelPourCreation informationsHistorique);

        /// <summary>
        /// Méthode permet d'obtenir la liste des thèmes pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'iden,tification de l'applant.</param>
        /// <returns>Tableau de thèmes pour le transfert des appels.</returns>
        ThemeQualificationAppel[] ObtenirThemesTransfertAppel(Identite identite);

        /// <summary>
        /// Méthode permet d'obteniur la liste des types de "Niveau1" associés à un Thème pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'applant.</param>
        /// <param name="cleTheme">Clé du thème.</param>
        /// <returns>Liste des "Niveau1" associés à un thème pour le transfert des appels</returns>
        Niveau1QualificationAppel[] ObtenirNiveau1TransfertAppelParCleTheme(Identite identite, int cleTheme);

        /// <summary>
        /// Méthode permet d'obteniur la liste des types de "Niveau1" associés à un Thème pour le transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'applant.</param>
        /// <param name="cleNiveau1">Clé du Niveau1.</param>
        /// <returns>Liste des "Niveau2" associés à un "Niveau1" pour le transfert des appels</returns>
        Niveau2QualificationAppel[] ObtenirNiveau2TransfertAppelParCleNiveau1(Identite identite, int cleNiveau1);

        /// <summary>
        /// Méthode permet de retrouver les informations d'un média à partir de sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'applant.</param>
        /// <param name="cleMedia">Clé technique d'un média.</param>
        /// <returns>Objet de présentation de type MediaHistorique.</returns>
        MediaHistorique ObtenirMediaParCle(Identite identite, int cleMedia);

        /// <summary>
        /// Permet de créer un historique fonctionnel dans la brique externe et stocker la liaison historique/ligne dans le SI Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne cncernés par l'historique.</param>
        /// <param name="informationsHistorique">Informations de l'ihstorique à créer.</param>
        /// <returns>Cle de l'HistoriqueFonctionnel créé.</returns>
        long CreerHistoriqueFonctionnelPourLigne(Identite identite, long cleLigne, HistoriquePourCreation informationsHistorique);

        /// <summary>
        /// Obtention d'une liste d'historiques d'appels depuis une liste de clés.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="listeCles">Liste de clés techniques des historiques à rechercher.</param>
        /// <returns>Liste des historiques d'appel correspondant aux clés techniques fournies.</returns>
        HistoriqueAppelPourLister[] ListerHistoriquesAppelsParListeCles(Identite identite, long[] listeCles);

        /// <summary>
        /// Création de l'historique fonctionnel pour une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="informationsHistorique">Informations nécessaire à la création d'un historique.</param>
        void CreerHistoriquePourDemandeResiliation(Identite identite, HistoriqueFonctionnelPourCreation informationsHistorique);
    }
}