﻿using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface de la brique externe SfrFixeCompteTv.
    /// </summary>
    public interface ISfrFixeCompteTvServiceExterne
    {
        /// <summary>
        /// Permet de débloquer le compte MyPartnerTV.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        void Debloquer(Identite identite, string referenceExterne);

        /// <summary>
        /// Permet de modifier le mot de passe du compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        /// <param name="motDePasse">Mot de passe du compte My Partner TV.</param>
        void ModifierMotDePasseMyPartnerTv(Identite identite, string referenceExterne, string motDePasse);

        /// <summary>
        /// Permet de créer un compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        /// <param name="identifiant">Identifiant du compte My Partner TV.</param>
        void CreerCompteMyPartnerTv(Identite identite, string referenceExterne, string identifiant);
    }
}
