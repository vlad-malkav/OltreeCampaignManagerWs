﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface des intéractions avec le service valorisation.
    /// </summary>
    public interface IValorisationServiceExterne
    {
        /// <summary>
        /// Permet de résilier la ligne au sens valorisation : positionner une date de résiliation sur le contrat.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="dateResiliation">Date de résiliation programmée.</param>
        /// <param name="estFraisResiliationAppliques">Indique si des frais de résiliation sont appliqués.</param>
        /// <param name="montantHtFraisResiliation">Montant HT des frais de résiliation.</param>
        /// <param name="tvaFraisResiliation">TVA sur les frais de résiliation.</param>
        void ResilierLigne(Identite identite, string referenceExterne, DateTime dateResiliation, bool estFraisResiliationAppliques, decimal montantHtFraisResiliation, decimal tvaFraisResiliation);

        /// <summary>
        /// Permet d’ajouter, de mettre à jour ou de supprimer des remises dans la brique Valorisation.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="refExterne">Référence externe de la ligne.</param>
        /// <param name="remises">Liste des remises à transmettre à la Valorisation.</param>
        void ChangerRemise(Identite identite, string refExterne, List<RemisePourValorisation> remises);
    }
}