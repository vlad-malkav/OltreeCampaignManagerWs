﻿namespace EIT.Fixe.VieClient.Domain.ServiceExterne
{
    /// <summary>
    /// Interface du service de paramétrage.
    /// </summary>
    public interface IParametrage
    {
        /// <summary>
        /// Nombre maximum d’historiques à afficher sur la fiche de synthèse de la ligne fixe.
        /// </summary>
        int NombreHistoriquesFicheSyntheseLigne { get; }

        /// <summary>
        /// Nombre maximum de dossier GBO à afficher sur la fiche de synthèse de ligne fixe.
        /// </summary>
        int NombreDossierFicheSyntheseLigne { get; }

        /// <summary>
        /// Code opérateur d'un réseau full. Les autres codes opérateur offrent une réseau light.
        /// </summary>
        string CodeOperateurReseauFull { get; }

        /// <summary>
        /// Durée de validité des données concernant les pannes collectives, en minutes.
        /// </summary>
        /// <remarks>Passé ce délai en minutes, les données ne sont plus exploitables.</remarks>
        int DureeValiditeDonneesPannesCollectives { get; }

        /// <summary>
        /// Delai (en heures) affiché sur la page de transfert des appels.
        /// </summary>
        int DelaiTransfertAppel { get; }

        /// <summary>
        /// Libellé de l’activité affiché sur la page de transfert des appels.
        /// </summary>
        string LibelleActiviteTransfertAppel { get; }

        /// <summary>
        /// Montant HT des frais fixes de résiliation.
        /// </summary>
        decimal MontantHtFraisResiliation { get; }

        /// <summary>
        /// Tva des frais fixes de résiliation.
        /// </summary>
        decimal TvaFraisResiliation { get; }

        /// <summary>
        /// Clé du motif de résiliation "Portabilité Sortante".
        /// </summary>
        long CleMotifResiliationPortabiliteSortante { get; }

        /// <summary>
        /// Clé du motif de résiliation "Impayés".
        /// </summary>
        long CleMotifResiliationImpayes { get; }

        /// <summary>
        /// Clé du motif de résiliation "Rétractation".
        /// </summary>
        long CleMotifResiliationRetractation { get; }

        #region Urls

        /// <summary>
        /// Web service de la brique Tiers.
        /// </summary>
        string UrlBriqueTiers { get; }

        /// <summary>
        /// Web service de la brique Historique.
        /// </summary>
        string UrlBriqueHistorique { get; }

        /// <summary>
        /// Web service de la brique CompteClient.
        /// </summary>
        string UrlBriqueComptesClient { get; }

        /// <summary>
        /// Web service de la brique GestionSurconsommationAbo.
        /// </summary>
        string UrlBriqueGestionSurconsommationAbo { get; }

        /// <summary>
        /// Web service de la brique Login.
        /// </summary>
        string UrlBriqueLogin { get; }

        /// <summary>
        /// Web service de Options.
        /// </summary>
        string UrlBriqueOptions { get; }

        /// <summary>
        /// URL du web service Valorisation.
        /// </summary>
        string UrlBriqueValorisation { get; }

        /// <summary>
        /// URL du web service InterfaceOperateur.
        /// </summary>
        string UrlBriqueInterfaceOperateur { get; }

        /// <summary>
        /// URL du web service Icn.
        /// </summary>
        string UrlBriqueIcn { get; }

        /// <summary>
        /// URL du web service Compte TV.
        /// </summary>
        string UrlBriqueCompteTV { get; }

        /// <summary>
        /// URL du web service DataMart Ligne.
        /// </summary>
        string UrlBriqueDataMartLigne { get; }

        #endregion Urls
    }
}