﻿namespace EIT.Fixe.VieClient.Domain.Constantes
{
    /// <summary>
    /// Constantes utilisées dans l'objet métier DemandeResiliation.
    /// </summary>
    public static class ConstantesDemandeResiliation
    {
        /// <summary>
        /// Ref doc du courrier de confirmation de résiliation sans étiquette.
        /// </summary>
        public static readonly string REFDOC_COURRIER_CONFIRMER_RESILIATION_SANS_ETIQUETTE = "0107170057";

        /// <summary>
        /// Pays pour l'adresse courrier.
        /// </summary>
        public static readonly string PAYS_ADRESSE_COURRIER = "France";

        /// <summary>
        /// Délai, en jours, pour l'envoi du matériel suite à une résiliation.
        /// </summary>
        public static readonly string DELAI_ENVOI_MATERIEL_SUITE_RESILIATION = "20";
    }
}