﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des pannes collectives.
    /// </summary>
    public sealed class PanneCollectiveRepository : Repository, IPanneCollectiveRepository
    {
        #region Champs

        /// <summary>
        /// Registre d'accès à la persistance des lignes fixes.
        /// </summary>
        private readonly ILigneRepository ligneRepository;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        /// <param name="ligneRepository">Registre d'accès à la persistance des lignes fixes.</param>
        public PanneCollectiveRepository(IDataSource dataSource, ILigneRepository ligneRepository)
            : base(dataSource)
        {
            ligneRepository.Valider(nameof(ligneRepository)).NonNul();

            this.ligneRepository = ligneRepository;
        }

        #endregion Constructeurs

        #region Méthodes - IPanneCollectiveRepository

        /// <summary>
        /// Création d'une panne collective.
        /// </summary>
        /// <param name="panne">La panne à créer.</param>
        public void Creer(PanneCollective panne)
        {
            panne.Valider(nameof(panne)).NonNul();

            this.DataSource.Add(panne);
        }

        /// <summary>
        /// Liste les pannes collectives valides impactant une ligne.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleLigne">Clé de la ligne fixe pour laquelle récupérer les pannes collectives valides.</param>
        /// <param name="dureeValidite">Durée de validité des données, en minutes.</param>
        /// <returns>Pannes collectives en cours impactant cette ligne fixe.</returns>
        public IEnumerable<PanneCollective> ListerPannesCollectivesParCleLigne(Identite identite, long cleLigne, int dureeValidite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            dureeValidite.Valider(nameof(dureeValidite)).NonNul();

            // Obtention de la ligne.
            Ligne ligne = this.ligneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Liste et retourne les pannes collectives valides de la ligne.
            return ligne.ListePannesCollectives.Where(pnn => pnn.DateDebut <= DateTime.Now.AddMinutes(dureeValidite));
        }

        #endregion Méthodes - IPanneCollectiveRepository
    }
}