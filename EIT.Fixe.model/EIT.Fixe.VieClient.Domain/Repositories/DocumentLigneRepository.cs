﻿using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des documents de ligne.
    /// </summary>
    public sealed class DocumentLigneRepository : Repository, IDocumentLigneRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public DocumentLigneRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - IDocumentLigneRepository

        /// <summary>
        /// Liste tous les documents.
        /// </summary>
        /// <returns>Tableau d'objet DocumentLigne.</returns>
        public DocumentLigne[] Lister()
        {
            return this.DataSource.Query<DocumentLigne>().Select(d => d).ToArray();
        }

        #endregion Méthodes - IDocumentLigneRepository
    }
}
