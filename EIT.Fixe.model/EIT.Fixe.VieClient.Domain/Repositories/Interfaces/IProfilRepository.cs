﻿using EIT.Fixe.VieClient.Domain.Entities;
using System;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre des profils.
    /// </summary>
    public interface IProfilRepository
    {

        /// <summary>
        /// Insérer un profil en base.
        /// </summary>
        /// <param name="profil">Profil à ajouter</param>
        void Ajouter(ProfilPtf profil);

        /// <summary>
        /// Liste les profils actifs.
        /// </summary>
        /// <returns>Liste des profils actifs.</returns>
        ProfilPtf[] ListerProfilsActifs();

        /// <summary>
        /// Lister les dates d'imports différentes.
        /// </summary>
        /// <returns>Tableau contenant les dates d'imports.</returns>
        DateTime[] ListerDatesSuiviCreation();

        /// <summary>
        /// Recherche un profil ptf via sa ressource sas.
        /// </summary>
        /// <param name="ressourceSas">Ressource sas.</param>
        /// <returns>Le profil correspondant à la ressource sas passée en paramètre.</returns>
        ProfilPtf RechercherProfilActifDepuisRessourceSas(string ressourceSas);

        /// <summary>
        /// Supprime les profils ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date de création du profil.</param>
        void SupprimerDepuisDate(DateTime date);
    }
}
