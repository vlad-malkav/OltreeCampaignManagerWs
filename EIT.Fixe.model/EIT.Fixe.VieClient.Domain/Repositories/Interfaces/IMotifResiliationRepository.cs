﻿using EIT.Fixe.VieClient.Domain.Entities;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Repository des motifs de résiliation.
    /// </summary>
    public interface IMotifResiliationRepository
    {
        /// <summary>
        /// Liste les motifs de résiliation.
        /// </summary>
        /// <returns>Liste des motifs de résiliation.</returns>
        List<MotifResiliation> ListerMotifsResiliation();

        /// <summary>
        /// Obtient un motif de résiliation par sa clé.
        /// </summary>
        /// <param name="cle">Clé permettant de trouver un motif de résiliation.</param>
        /// <returns>Objet MotifResiliation possédant la clé passée en paramètre.</returns>
        MotifResiliation ObtenirDepuisCle(long cle);
    }
}
