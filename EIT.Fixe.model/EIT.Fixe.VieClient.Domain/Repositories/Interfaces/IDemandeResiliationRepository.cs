﻿using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Repository des demandes de résiliation.
    /// </summary>
    public interface IDemandeResiliationRepository
    {
        /// <summary>
        /// Obtient un objet métier de type DemandeResiliation.
        /// </summary>
        /// <param name="cle">Clé technique de la demande de résiliation.</param>
        /// <returns>L'objet métier DemandeResiliation correspondant à la clé donnée en paramètre.</returns>
        DemandeResiliation ObtenirDepuisCle(long cle);

        /// <summary>
        /// Recherche les demandes de résiliation pour lesquelles la date de résiliation programmée est égale à la date du jour.
        /// </summary>
        /// <returns>Liste des demandes de résiliation à traiter.</returns>
        List<DemandeResiliation> RechercherDemandesResiliationATraiter();
    }
}
