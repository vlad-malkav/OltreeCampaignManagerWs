﻿using EIT.Fixe.VieClient.Domain.Entities;
using System;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre des groupes de fonctionnalités.
    /// </summary>
    public interface IGroupeFonctionnalitesRepository
    {
        /// <summary>
        /// Lister les groupes de fonctionnalités actifs.
        /// </summary>
        /// <returns>Tableau contenant les groupes de fonctionnalités actifs.</returns>
        GroupeFonctionnalites[] ListerGroupesFonctionnalitesActifs();

        /// <summary>
        /// Insérer un groupe de fonctionnalité en base.
        /// </summary>
        /// <param name="groupeFonctionnalite">Groupe à ajouter.</param>
        void Ajouter(GroupeFonctionnalites groupeFonctionnalite);

        /// <summary>
        /// Supprime les groupes ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date à supprimer.</param>
        void SupprimerDepuisDate(DateTime date);
    }
}
