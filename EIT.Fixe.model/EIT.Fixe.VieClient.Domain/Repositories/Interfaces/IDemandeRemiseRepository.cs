﻿using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Définit le repository qui permet d'accéder à la persistance de PromotionApliqueeRepository.
    /// </summary>
    public interface IDemandeRemiseRepository
    {
        /// <summary>
        /// Liste les promotions a expirer.
        /// </summary>
        /// <returns>Dictionnaire associant une cleLigneà une liste de clePromotion.</returns>
        Dictionary<long, List<long>> ListerPromotionsAExpirer();
    }
}
