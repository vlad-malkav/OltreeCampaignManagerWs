﻿using EIT.Fixe.VieClient.Domain.Entities;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre des historiques de réinitialisation de login.
    /// </summary>
    public interface IHistoriqueReinitialiserLoginRepository
    {
        /// <summary>
        /// Liste les historiques de réinitialisation de login lié à une ligne.
        /// </summary>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Liste d'historiques de réinitialisation de login.</returns>
        List<HistoriqueReinitialiserLogin> ListerDepuisCleLigne(long cleLigne);

        /// <summary>
        /// Permet d'ajouter un HistoriqueReinitialiserLogin en BDD.
        /// </summary>
        /// <param name="historique">HistoriqueReinitialiserLogin à ajouter.</param>
        void Ajouter(HistoriqueReinitialiserLogin historique);
    }
}
