﻿using EIT.Fixe.VieClient.Domain.Entities.Ligne;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre de données des lignes fixes.
    /// </summary>
    public interface ILigneRepository
    {
        /// <summary>
        /// Obtient un objet métier de type Ligne.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>L'objet ligne correspondant à la clé passée en paramètre.</returns>
        Ligne ObtenirDepuisCle(long cle);

        /// <summary>
        /// Recherche un objet métier de type Ligne.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>L'objet ligne correspondant à la clé passée en paramètre.</returns>
        Ligne RechercherParCle(long cle);

        /// <summary>
        /// Retourne la référence externe de la ligne depuis sa clé technique.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>La référence externe de la ligne correspondant à la clé passée en paramètre.</returns>
        string ObtenirReferenceExterneDepuisCle(long cle);

        /// <summary>
        /// Retourne le numero de la ligne depuis sa clé technique.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Numéro de la ligne correspondant à la clé passée en paramètre.</returns>
        string ObtenirNumeroDepuisCle(long cle);

        /// <summary>
        /// Ajoute une ligne à la persistance de données.
        /// </summary>
        /// <param name="ligne">La ligne à ajouter.</param>
        void AjouterLigne(Ligne ligne);

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro.
        /// </summary>
        /// <param name="numero">Numéro de la ligne fixe.</param>
        /// <returns>Ligne fixe correspondant au numéro.</returns>
        Ligne ObtenirDepuisNumero(string numero);

        /// <summary>
        /// Recherche un objet métier de type Ligne en fonction de son numéro.
        /// </summary>
        /// <param name="numero">Numéro de la ligne fixe.</param>
        /// <returns>Ligne fixe correspondant au numéro.</returns>
        Ligne RechercherParNumero(string numero);

        /// <summary>
        /// Rechercher une ligne par sa clé d'ICN.
        /// </summary>
        /// <param name="cleIcn">Clé ICN de la ligne recherchée.</param>
        /// <returns>Ligne recherchée.</returns>
        Ligne RechercherParCleIcn(long cleIcn);

        /// <summary>
        /// Rechercher une ligne par sa clé tiers.
        /// </summary>
        /// <param name="cleTiers">Clé du titulaire de la ligne recherchée.</param>
        /// <returns>Ligne recherchée.</returns>
        Ligne RechercherParCleTiers(long cleTiers);

        /// <summary>
        /// Obtient une ligne par sa clé Tiers.
        /// </summary>
        /// <param name="cleTiers">Clé du titulaire de la ligne obtenue.</param>
        /// <returns>Ligne obtenue.</returns>
        Ligne ObtenirDepuisCleTiers(long cleTiers);

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro de contrat.
        /// </summary>
        /// <param name="numeroContrat">Numéro de contrat de la ligne.</param>
        /// <returns>Objet Ligne possédant le numéro de contrat passé en paramètre.</returns>
        /// <remarks>Lève une exception si aucune ligne ne correspond.</remarks>
        Ligne ObtenirDepuisNumeroContrat(string numeroContrat);

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro de contrat.
        /// </summary>
        /// <param name="numeroContrat">Numéro de contrat de la ligne.</param>
        /// <returns>Objet Ligne correspondant au numéro de contrat passé en paramètre.</returns>
        /// <remarks>Ne lève aucune exception si aucune ligne ne correspond (retourne null).</remarks>
        Ligne RechercherParNumeroContrat(string numeroContrat);

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de sa référence externe.
        /// </summary>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Objet Ligne possédant la référence externe passée en paramètre.</returns>
        /// <remarks>Lève une exception si aucune ligne ne correspond.</remarks>
        Ligne ObtenirDepuisReferenceExterne(string referenceExterne);

        /// <summary>
        /// Recherche de ligne par référence externe.
        /// </summary>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Ligne correspondant à la référence externe fournie.</returns>
        /// <remarks>Ne lève aucune exception si aucune ligne ne correspond (retourne null).</remarks>
        Ligne RechercherParReferenceExterne(string referenceExterne);

        /// <summary>
        /// Obtenir la ligne qui correspond 
        /// </summary>
        /// <param name="cleGestionnaireOptions"></param>
        /// <returns></returns>
        Ligne ObtenirDepuisCleGestionnaireOptions(string cleGestionnaireOptions);
    }
}