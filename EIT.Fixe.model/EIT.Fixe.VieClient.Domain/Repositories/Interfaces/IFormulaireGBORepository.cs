﻿using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre de données des Formulaires GBO.
    /// </summary>
    public interface IFormulaireGboRepository
    {

        #region Tables de Paramétrage

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique du MotifDysfonctionnement.</param>
        /// <returns></returns>
        MotifDysfonctionnement ObtenirMotifDysfonctionnementParCle(long cle);

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifDysfonctionnement.</returns>
        IEnumerable<MotifDysfonctionnement> ListerMotifDysfonctionnement();

        /// <summary>
        /// Obtient un objet métier de type MotifQualification.
        /// </summary>
        /// <param name="cle">Clé technique du MotifQualification.</param>
        /// <returns></returns>
        MotifQualification ObtenirMotifQualificationParCle(long cle);

        /// <summary>
        /// Recherche tous les MotifQualification.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifQualification.</returns>
        IEnumerable<MotifQualification> ListerMotifQualification();

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">Clé technique de la NatureDemandeIntervention.</param>
        /// <returns></returns>
        NatureDemandeIntervention ObtenirNatureDemandeInterventionParCle(long cle);

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention.
        /// </summary>
        /// <returns>Retourne la liste de tous les NatureDemandeIntervention.</returns>
        IEnumerable<NatureDemandeIntervention> ListerNatureDemandeIntervention();

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique de l'OrigineDysfonctionnement.</param>
        /// <returns></returns>
        OrigineDysfonctionnement ObtenirOrigineDysfonctionnementParCle(long cle);

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les OrigineDysfonctionnement.</returns>
        IEnumerable<OrigineDysfonctionnement> ListerOrigineDysfonctionnement();

        /// <summary>
        /// Obtient un objet métier de type RegionCDC.
        /// </summary>
        /// <param name="cle">Clé technique de la RegionCDC.</param>
        /// <returns></returns>
        RegionCDC ObtenirRegionCdcParCle(long cle);

        /// <summary>
        /// Recherche tous les RegionCDC.
        /// </summary>
        /// <returns>Retourne la liste de tous les RegionCDC.</returns>
        IEnumerable<RegionCDC> ListerRegionCdc();

        #endregion Tables de Paramétrage

        #region Formulaires

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO de base.</param>
        /// <returns></returns>
        FormulaireGBO ObtenirFormulaireGboParCle(long cle);

        /// <summary>
        /// Création d'un Formulaire de niveau 2 de demande d'intervention.
        /// </summary>
        /// <param name="formulaire">.</param>
        long CreerFormulaireCN2DI(FormulaireCN2DI formulaire);

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 2 de demande d'intervention.</param>
        /// <returns></returns>
        FormulaireCN2DI ObtenirFormulaireCN2DiParCle(long cle);

        /// <summary>
        /// Création d'un Formulaire de niveau 3 d'engagement qualité.
        /// </summary>
        /// <param name="formulaire">.</param>
        long CreerFormulaireCN3EQ(FormulaireCN3EQ formulaire);

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 3 d'engagement qualité.</param>
        /// <returns></returns>
        FormulaireCN3EQ ObtenirFormulaireCN3EqParCle(long cle);

        /// <summary>
        /// Création d'un Formulaire de modification de profil surconsommation.
        /// </summary>
        /// <param name="formulaire">.</param>
        long CreerFormulaireMps(FormulaireMPS formulaire);

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de modification de profil surconsommation.</param>
        /// <returns></returns>
        FormulaireMPS ObtenirFormulaireMpsParCle(long cle);

        /// <summary>
        /// Création d'un Formulaire de risque de résiliation.
        /// </summary>
        /// <param name="formulaire">.</param>
        long CreerFormulaireRisqueResiliation(FormulaireRisqueResiliation formulaire);

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de risque de résiliation.</param>
        /// <returns></returns>
        FormulaireRisqueResiliation ObtenirFormulaireRisqueResiliationParCle(long cle);

        #endregion Formulaires

        /// <summary>
        /// Obtient la clé d'un Formulaire GBO à partir de la Clé Dossier GBO associée.
        /// </summary>
        /// <param name="cle">Clé technique du Dossier GBO.</param>
        /// <returns></returns>
        long ObtenirCleFormulaireGboDepuisCleDossier(long cle);

        /// <summary>
        /// Obtient le type d'un Formulaire GBO à partir de la Clé Formulaire
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO.</param>
        /// <returns></returns>
        TypeFormulaireGBO ObtenirTypeFormulaireGboParCle(long cle);
    }
}