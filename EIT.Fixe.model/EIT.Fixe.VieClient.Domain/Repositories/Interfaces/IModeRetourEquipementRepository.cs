﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Repository des modes de retour des équipements.
    /// </summary>
    public interface IModeRetourEquipementRepository
    {
        /// <summary>
        /// Obtient un mode de retour équipement par sa clé.
        /// </summary>
        /// <param name="cle">Clé du mode de retour équipement.</param>
        /// <returns>Objet métier ModeRetourEquipement possédant la clé passée en paramètre.</returns>
        ModeRetourEquipement ObtenirDepuisCle(long cle);

        /// <summary>
        /// Obtient un mode de retour équipement par son type d'envoi.
        /// </summary>
        /// <param name="typeEnvoi">Type d'envoi du mode de retour équipement.</param>
        /// <returns>Objet métier ModeRetourEquipement possédant la clé passée en paramètre.</returns>
        ModeRetourEquipement ObtenirDepuisTypeEnvoi(TypeEnvoi typeEnvoi);
    }
}
