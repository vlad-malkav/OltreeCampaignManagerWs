﻿using EIT.Fixe.VieClient.Domain.Entities;
using System;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre des fonctionnalités.
    /// </summary>
    public interface IFonctionnaliteRepository
    {
        /// <summary>
        /// Lister les fonctionnalités actives.
        /// </summary>
        /// <returns>Tableau des fonctionnalités actives.</returns>
        Fonctionnalite[] ListerFonctionnalitesActives();

        /// <summary>
        /// Insérer une fonctionnalité en base.
        /// </summary>
        /// <param name="fonctionnalite">Fonctionnalité à ajouter</param>
        void Ajouter(Fonctionnalite fonctionnalite);

        /// <summary>
        /// Supprime les fonctionnalités ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date à supprimer.</param>
        void SupprimerDepuisDate(DateTime date);
    }
}
