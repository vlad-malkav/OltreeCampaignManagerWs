﻿using EIT.Fixe.Domain.Repositories;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du repositories
    /// </summary>
    public interface IRepositories
    {
        /// <summary>
        /// Registre de données des historiques des lignes fixes.
        /// </summary>
        ILigneRepository LigneRepository { get; }

        /// <summary>
        /// Registre de données des historiques des pannes collectives.
        /// </summary>
        IPanneCollectiveRepository PanneCollectiveRepository { get; }

        /// <summary>
        /// Retourne l'interface de PromotionApliqueeRepository.
        /// </summary>
        IDemandeRemiseRepository DemandeRemiseRepository { get; }

        /// <summary>
        /// Registre de données des motifs de résiliation.
        /// </summary>
        IMotifResiliationRepository MotifResiliationRepository { get; }

        /// <summary>
        /// Repository des modes de retour d'équipement.
        /// </summary>
        IModeRetourEquipementRepository ModeRetourEquipementRepository { get; }

        /// <summary>
        /// Repository des demandes de résiliation.
        /// </summary>
        IDemandeResiliationRepository DemandeResiliationRepository { get; }

        /// <summary>
        /// Repository des documents de ligne.
        /// </summary>
        IDocumentLigneRepository DocumentLigneRepository { get; }
        /// <summary>
        /// Registre de données des Formulaires GBO.
        /// </summary>
        IFormulaireGboRepository FormulaireGboRepository { get; }


        /// <summary>
        /// Repository des profils.
        /// </summary>
        IProfilRepository ProfilRepository { get; }

        /// <summary>
        /// Repository des groupes de fonctionnalité.
        /// </summary>
        IGroupeFonctionnalitesRepository GroupeFonctionnalitesRepository { get; }

        /// <summary>
        /// Repository des fonctionnalités.
        /// </summary>
        IFonctionnaliteRepository FonctionnaliteRepository { get; }

        /// <summary>
        /// Repository des historiques de réinitialisation de login.
        /// </summary>
        IHistoriqueReinitialiserLoginRepository HistoriqueReinitialiserLoginRepository { get; }

        /// <summary>
        /// Repository des historiques des dossiers GBO
        /// </summary>
        IHistoriqueDossierGboLigneRepository HistoriqueDossierGboLigneRepository { get; }
    }
}