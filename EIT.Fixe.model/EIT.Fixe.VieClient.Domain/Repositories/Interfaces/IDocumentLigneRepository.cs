﻿using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Repository de document de ligne.
    /// </summary>
    public interface IDocumentLigneRepository
    {
        /// <summary>
        /// Liste tous les documents.
        /// </summary>
        /// <returns>Tableau d'objet DocumentLigne.</returns>
        DocumentLigne[] Lister();
    }
}
