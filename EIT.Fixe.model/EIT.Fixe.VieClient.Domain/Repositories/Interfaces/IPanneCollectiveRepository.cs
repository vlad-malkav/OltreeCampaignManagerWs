﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Repositories.Interfaces
{
    /// <summary>
    /// Interface du registre de données des pannes collectives.
    /// </summary>
    public interface IPanneCollectiveRepository
    {
        /// <summary>
        /// Création d'une panne collective.
        /// </summary>
        /// <param name="panne">La panne à créer.</param>
        void Creer(PanneCollective panne);

        /// <summary>
        /// Liste les pannes collectives valides impactant une ligne.
        /// </summary>
        /// <param name="cleLigne">Clé de la ligne fixe pour laquelle récupérer les pannes collectives valides.</param>
        /// <param name="dureeValidite">Durée de validité des données, en minutes.</param>
        /// <returns></returns>
        IEnumerable<PanneCollective> ListerPannesCollectivesParCleLigne(Identite identite,long cleLigne, int dureeValidite);
    }
}