﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des demandes de résiliation.
    /// </summary>
    public sealed class DemandeResiliationRepository : Repository, IDemandeResiliationRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public DemandeResiliationRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - IDemandeResiliationRepository

        /// <summary>
        /// Obtient un objet métier de type DemandeResiliation.
        /// </summary>
        /// <param name="cle">Clé technique de la demande de résiliation.</param>
        /// <returns>L'objet métier DemandeResiliation correspondant à la clé donnée en paramètre.</returns>
        public DemandeResiliation ObtenirDepuisCle(long cle)
        {
            DemandeResiliation demandeResiliation = this.DataSource.Query<DemandeResiliation>()
                .SingleOrDefault(x => x.Cle == cle);

            demandeResiliation.Valider(nameof(demandeResiliation)).NonNul();

            return demandeResiliation;
        }

        /// <summary>
        /// Recherche les demandes de résiliation pour lesquelles la date de résiliation programmée est égale à la date du jour.
        /// </summary>
        /// <returns>Liste des demandes de résiliation à traiter.</returns>
        public List<DemandeResiliation> RechercherDemandesResiliationATraiter()
        {
            return this.DataSource.Query<DemandeResiliation>()
                .Where(x => x.DateResiliationProgrammee.HasValue 
                && DateTime.Compare(x.DateResiliationProgrammee.Value, DateTime.Now) <= 0
                && x.Etat.Valeur == CommonTypes.Enumerations.EtatDemandeResiliation.EnCours)
                .ToList();
        }

        #endregion Méthodes - IDemandeResiliationRepository
    }
}