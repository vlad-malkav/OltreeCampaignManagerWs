﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Classe du registre des historiques de réinitialisation de login.
    /// </summary>
    public class HistoriqueReinitialiserLoginRepository : Repository, IHistoriqueReinitialiserLoginRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public HistoriqueReinitialiserLoginRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region IHistoriqueReinitialiserLoginRepository

        /// <summary>
        /// Liste les historiques de réinitialisation de login lié à une ligne.
        /// </summary>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Liste d'historiques de réinitialisation de login.</returns>
        public List<HistoriqueReinitialiserLogin> ListerDepuisCleLigne(long cleLigne)
        {
            // Vérification du paramètre d'entrée.
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            return this.DataSource.Query<HistoriqueReinitialiserLogin>().Where(p => p.CleLigne == cleLigne).ToList();
        }


        /// <summary>
        /// Permet d'ajouter un HistoriqueReinitialiserLogin en BDD.
        /// </summary>
        /// <param name="historique">HistoriqueReinitialiserLogin à ajouter.</param>
        public void Ajouter(HistoriqueReinitialiserLogin historique)
        {
            historique.Valider(nameof(historique)).NonNul();
            this.DataSource.Add(historique);
        }

        #endregion IHistoriqueReinitialiserLoginRepository
    }
}
