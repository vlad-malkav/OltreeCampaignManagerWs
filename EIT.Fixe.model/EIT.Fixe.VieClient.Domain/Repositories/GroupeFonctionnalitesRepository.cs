﻿using System;
using EIT.DataAccess;
using System.Linq;
using EIT.Fixe.Infrastructure;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Classe du registre des groupes de fonctionnalités.
    /// </summary>
    public class GroupeFonctionnalitesRepository : Repository, IGroupeFonctionnalitesRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public GroupeFonctionnalitesRepository(IDataSource dataSource) : base(dataSource)
        {

        }
        #endregion Constructeurs

        /// <summary>
        /// Lister les groupes de fonctionnalités actifs.
        /// </summary>
        /// <returns>Tableau contenant les groupes de fonctionnalités actifs.</returns>
        public GroupeFonctionnalites[] ListerGroupesFonctionnalitesActifs()
        {
            return this.DataSource.Query<GroupeFonctionnalites>().Where(p => p.EstActif).Select(p => p).ToArray();
        }

        /// <summary>
        /// Insérer un groupe de fonctionnalité en base.
        /// </summary>
        /// <param name="groupeFonctionnalite">Groupe à insérer.</param>
        public void Ajouter(GroupeFonctionnalites groupeFonctionnalite)
        {
            groupeFonctionnalite.Valider(nameof(groupeFonctionnalite)).NonNul();

            this.DataSource.Add(groupeFonctionnalite);
        }

        /// <summary>
        /// Supprime les groupes ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date à supprimer.</param>
        public void SupprimerDepuisDate(DateTime date)
        {
            date.Valider(nameof(date)).NonNul();

            List<GroupeFonctionnalites> groupesASupprimer = this.DataSource.Query<GroupeFonctionnalites>().Where(g => g.SuiviDateCreation == date).ToList();

            if (groupesASupprimer != null)
            {

                groupesASupprimer.Where(g=>g.ListeFonctionnalites != null).ToList().ForEach(g => g.ListeFonctionnalites.ToList().RemoveAll(f=>true));
                this.DataSource.RemoveRange<GroupeFonctionnalites>(groupesASupprimer);
            }
        }
    }
}
