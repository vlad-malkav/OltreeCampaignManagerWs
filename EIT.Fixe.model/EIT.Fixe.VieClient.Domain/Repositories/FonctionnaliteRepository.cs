﻿using System;
using EIT.DataAccess;
using System.Linq;
using EIT.Fixe.Infrastructure;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Classe du registre des fonctionnalités.
    /// </summary>
    public class FonctionnaliteRepository : Repository, IFonctionnaliteRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public FonctionnaliteRepository(IDataSource dataSource) : base(dataSource)
        {

        }
        #endregion Constructeurs

        /// <summary>
        /// Lister les fonctionnalités actives.
        /// </summary>
        /// <returns>Tableau des fonctionnalités actives.</returns>
        public Fonctionnalite[] ListerFonctionnalitesActives()
        {
            return this.DataSource.Query<Fonctionnalite>().Where(p => p.EstActif).Select(p => p).ToArray();
        }

        /// <summary>
        /// Insérer une foncionnalité en base.
        /// </summary>
        /// <param name="fonctionnalite">Fonctionnalité à insérer.</param>
        public void Ajouter(Fonctionnalite fonctionnalite)
        {
            fonctionnalite.Valider(nameof(fonctionnalite)).NonNul();

            this.DataSource.Add(fonctionnalite);
        }

        /// <summary>
        /// Supprime les fonctionnalités ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date à supprimer.</param>
        public void SupprimerDepuisDate(DateTime date)
        {
            date.Valider(nameof(date)).NonNul();

            List<Fonctionnalite> fonctionnalitesASupprimer = this.DataSource.Query<Fonctionnalite>().Where(f => f.SuiviDateCreation == date).ToList();

            if (fonctionnalitesASupprimer != null)
            {
                this.DataSource.RemoveRange<Fonctionnalite>(fonctionnalitesASupprimer);
            }
        }
    }
}
