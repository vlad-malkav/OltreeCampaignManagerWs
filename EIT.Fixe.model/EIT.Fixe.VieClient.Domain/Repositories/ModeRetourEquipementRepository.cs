﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des modes de retour équipement.
    /// </summary>
    public sealed class ModeRetourEquipementRepository : Repository, IModeRetourEquipementRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public ModeRetourEquipementRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - IModeRetourEquipementRepository

        /// <summary>
        /// Obtient un mode de retour équipement par sa clé.
        /// </summary>
        /// <param name="cle">Clé du mode de retour équipement.</param>
        /// <returns>Objet métier ModeRetourEquipement correspondant à la clé passée en paramètre.</returns>
        public ModeRetourEquipement ObtenirDepuisCle(long cle)
        {
            ModeRetourEquipement modeRetourEquipement = this.DataSource.Query<ModeRetourEquipement>()
                .SingleOrDefault(x => x.Cle == cle);

            modeRetourEquipement.Valider(nameof(modeRetourEquipement)).NonNul();

            return modeRetourEquipement;
        }

        /// <summary>
        /// Obtient un mode de retour équipement par son type d'envoi.
        /// </summary>
        /// <param name="typeEnvoi">Type d'envoi du mode de retour équipement.</param>
        /// <returns>Objet métier ModeRetourEquipement correspondant au type d'envoi passé en paramètre.</returns>
        public ModeRetourEquipement ObtenirDepuisTypeEnvoi(TypeEnvoi typeEnvoi)
        {
            ModeRetourEquipement modeRetourEquipement = this.DataSource.Query<ModeRetourEquipement>()
                .SingleOrDefault(x => x.TypeEnvoi == typeEnvoi);

            modeRetourEquipement.Valider(nameof(modeRetourEquipement)).NonNul();

            return modeRetourEquipement;
        }

        #endregion Méthodes - IModeRetourEquipementRepository
    }
}