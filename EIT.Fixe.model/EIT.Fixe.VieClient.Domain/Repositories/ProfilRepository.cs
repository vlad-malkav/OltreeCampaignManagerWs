﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Linq;
using System;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Classe du registre des profils.
    /// </summary>
    public class ProfilRepository : Repository, IProfilRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public ProfilRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region IProfilRepository

        /// <summary>
        /// Insérer un profil PTF en base.
        /// </summary>
        /// <param name="profil">Profil à ajouter.</param>
        public void Ajouter(ProfilPtf profil)
        {
            profil.Valider(nameof(profil)).NonNul();

            this.DataSource.Add(profil);
        }

        /// <summary>
        /// Liste les profils actifs.
        /// </summary>
        /// <returns>Liste des profils actifs.</returns>
        public ProfilPtf[] ListerProfilsActifs()
        {
            return this.DataSource.Query<ProfilPtf>().Where(p => p.EstActif).Select(p => p).ToArray();
        }

        /// <summary>
        /// Liste les dates d'imports différentes.
        /// </summary>
        /// <returns>Tableau contenant les dates d'imports.</returns>
        public DateTime[] ListerDatesSuiviCreation()
        {
            return this.DataSource.Query<ProfilPtf>().Select(p => p.SuiviDateCreation).Distinct().OrderBy(d => d).ToArray();
        }

        /// <summary>
        /// Recherche un profil ptf via sa ressource sas.
        /// </summary>
        /// <param name="ressourceSas">Ressource sas.</param>
        /// <returns>Le profil correspondant à la ressource sas passée en paramètre.</returns>
        public ProfilPtf RechercherProfilActifDepuisRessourceSas(string ressourceSas)
        {
            ressourceSas.Valider(nameof(ressourceSas)).Obligatoire();

            return this.DataSource.Query<ProfilPtf>().SingleOrDefault(x => x.RessourceSas == ressourceSas && x.EstActif);
        }
        
        /// <summary>
        /// Supprime les profils ayant une certaine date de création.
        /// </summary>
        /// <param name="date">Date de création du profil.</param>
        public void SupprimerDepuisDate(DateTime date)
        {
            List<ProfilPtf> profilsASupprimer = this.DataSource.Query<ProfilPtf>().Where(p => p.SuiviDateCreation == date).ToList();

            if (profilsASupprimer != null)
            {
                profilsASupprimer.ForEach(p => p.ListeGroupesFonctionnalites.ToList().RemoveAll(g => true));
                this.DataSource.RemoveRange<ProfilPtf>(profilsASupprimer);
            }
        }

        #endregion IProfilRepository
    }
}
