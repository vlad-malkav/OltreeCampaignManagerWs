﻿using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des demandes de remise.
    /// </summary>
    public sealed class DemandeRemiseRepository : Repository, IDemandeRemiseRepository
    {
        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public DemandeRemiseRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        /// <summary>
        /// Liste les promotions a expirer.
        /// </summary>
        /// <returns>Dictionnaire associant une cleLigne à une liste de clePromotion.</returns>
        public Dictionary<long, List<long>> ListerPromotionsAExpirer()
        {
            IEnumerable<Ligne> listeLigne = this.DataSource.Query<Ligne>().Select(l => l);
            List<PromotionEligibleAExpirer> listePromotionEligibleAExpirer = new List<PromotionEligibleAExpirer>();

            foreach (var ligne in listeLigne)
            {
                IList<AbstractDemandeRemise> listePromotionsAExpirer = ligne.GestionnaireDemandeRemises.ListerPromotionsAExpirer();
                foreach (var promotionsAExpirer in listePromotionsAExpirer)
                {
                    listePromotionEligibleAExpirer.Add(new PromotionEligibleAExpirer() { CleLigne = ligne.Cle, ClePromotion = promotionsAExpirer.ClePromotion() });
                }
            }
            
            IEnumerable<IGrouping<long,long>> groupe = listePromotionEligibleAExpirer
                .GroupBy(groupBy => groupBy.CleLigne, g => g.ClePromotion);
            
            Dictionary<long, List<long>> listerPromotionsAExpirer = new Dictionary<long, List<long>>();
            List<long> listeClePromotion;

            foreach (IGrouping<long, long> item in groupe)
            {
                listeClePromotion = new List<long>();
                foreach (var clePromotion in item)
                {
                    listeClePromotion.Add(clePromotion);
                }
                listerPromotionsAExpirer.Add(item.Key, listeClePromotion);
            }

            return listerPromotionsAExpirer;
        }
    }
 }