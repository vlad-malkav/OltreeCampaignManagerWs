﻿using System.Collections.Generic;
using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Linq;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des Formulaires GBO.
    /// </summary>
    public sealed class FormulaireGboRepository : Repository, IFormulaireGboRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public FormulaireGboRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - IFormulaireGboRepository - Tables de Paramétrage

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique du MotifDysfonctionnement.</param>
        /// <returns></returns>
        public MotifDysfonctionnement ObtenirMotifDysfonctionnementParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            MotifDysfonctionnement motifDysfonctionnement = this.DataSource.Query<MotifDysfonctionnement>()
                .SingleOrDefault(x => x.Cle == cle);

            motifDysfonctionnement.Valider(nameof(motifDysfonctionnement)).NonNul();

            return motifDysfonctionnement;
        }

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifDysfonctionnement.</returns>
        public IEnumerable<MotifDysfonctionnement> ListerMotifDysfonctionnement()
        {
            return this.DataSource.Query<MotifDysfonctionnement>();
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification.
        /// </summary>
        /// <param name="cle">Clé technique du MotifQualification.</param>
        /// <returns></returns>
        public MotifQualification ObtenirMotifQualificationParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            MotifQualification motifQualification = this.DataSource.Query<MotifQualification>()
                .SingleOrDefault(x => x.Cle == cle);

            motifQualification.Valider(nameof(motifQualification)).NonNull();

            return motifQualification;
        }

        /// <summary>
        /// Recherche tous les MotifQualification.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifQualification.</returns>
        public IEnumerable<MotifQualification> ListerMotifQualification()
        {
            return this.DataSource.Query<MotifQualification>();
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">Clé technique de la NatureDemandeIntervention.</param>
        /// <returns></returns>
        public NatureDemandeIntervention ObtenirNatureDemandeInterventionParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            NatureDemandeIntervention natureDemandeIntervention = this.DataSource.Query<NatureDemandeIntervention>()
                .SingleOrDefault(x => x.Cle == cle);

            natureDemandeIntervention.Valider(nameof(natureDemandeIntervention)).NonNull();

            return natureDemandeIntervention;
        }

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention.
        /// </summary>
        /// <returns>Retourne la liste de tous les NatureDemandeIntervention.</returns>
        public IEnumerable<NatureDemandeIntervention> ListerNatureDemandeIntervention()
        {
            return this.DataSource.Query<NatureDemandeIntervention>();
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique de l'OrigineDysfonctionnement.</param>
        /// <returns></returns>
        public OrigineDysfonctionnement ObtenirOrigineDysfonctionnementParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            OrigineDysfonctionnement origineDysfonctionnement = this.DataSource.Query<OrigineDysfonctionnement>()
                .SingleOrDefault(x => x.Cle == cle);

            origineDysfonctionnement.Valider(nameof(origineDysfonctionnement)).NonNull();

            return origineDysfonctionnement;
        }

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les OrigineDysfonctionnement.</returns>
        public IEnumerable<OrigineDysfonctionnement> ListerOrigineDysfonctionnement()
        {
            return this.DataSource.Query<OrigineDysfonctionnement>();
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC.
        /// </summary>
        /// <param name="cle">Clé technique de la RegionCDC.</param>
        /// <returns></returns>
        public RegionCDC ObtenirRegionCdcParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            RegionCDC regionCDC = this.DataSource.Query<RegionCDC>()
                .SingleOrDefault(x => x.Cle == cle);

            regionCDC.Valider(nameof(regionCDC)).NonNull();

            return regionCDC;
        }

        /// <summary>
        /// Recherche tous les RegionCDC.
        /// </summary>
        /// <returns>Retourne la liste de tous les RegionCDC.</returns>
        public IEnumerable<RegionCDC> ListerRegionCdc()
        {
            return this.DataSource.Query<RegionCDC>();
        }

        #endregion Méthodes - IFormulaireGboRepository - Tables de Paramétrage

        #region Méthodes - IFormulaireGboRepository - Formulaires

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO de base.</param>
        /// <returns></returns>
        public FormulaireGBO ObtenirFormulaireGboParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            FormulaireGBO formulaire = this.DataSource.Query<FormulaireGBO>()
                .SingleOrDefault(x => x.Cle == cle);

            return formulaire;
        }

        /// <summary>
        /// Création d'un Formulaire de niveau 2 de demande d'intervention.
        /// </summary>
        /// <param name="formulaire">Le Formulaire de niveau 2 de demande d'intervention à ajouter.</param>
        public long CreerFormulaireCN2DI(FormulaireCN2DI formulaire)
        {
            formulaire.Valider(nameof(formulaire)).NonNull();

            //Ajout de formulaire au DataSource.
            this.DataSource.Add(formulaire);

            return formulaire.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 2 de demande d'intervention.</param>
        /// <returns></returns>
        public FormulaireCN2DI ObtenirFormulaireCN2DiParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            FormulaireCN2DI formulaire = this.DataSource.Query<FormulaireCN2DI>()
                .SingleOrDefault(x => x.Cle == cle);

            return formulaire;
        }

        /// <summary>
        /// Création d'un Formulaire de niveau 3 d'engagement qualité.
        /// </summary>
        /// <param name="formulaire">Le Formulaire de niveau 3 d'engagement qualité à ajouter.</param>
        public long CreerFormulaireCN3EQ(FormulaireCN3EQ formulaire)
        {
            formulaire.Valider(nameof(formulaire)).NonNull();

            //Ajout de formulaire au DataSource.
            this.DataSource.Add(formulaire);

            return formulaire.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 3 d'engagement qualité.</param>
        /// <returns></returns>
        public FormulaireCN3EQ ObtenirFormulaireCN3EqParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            FormulaireCN3EQ formulaire = this.DataSource.Query<FormulaireCN3EQ>()
                .SingleOrDefault(x => x.Cle == cle);

            return formulaire;
        }

        /// <summary>
        /// Création d'un Formulaire de modification de profil surconsommation.
        /// </summary>
        /// <param name="formulaire">Le Formulaire de modification de profil surconsommation à ajouter.</param>
        public long CreerFormulaireMps(FormulaireMPS formulaire)
        {
            formulaire.Valider(nameof(formulaire)).NonNull();

            //Ajout de formulaire au DataSource.
            this.DataSource.Add(formulaire);

            return formulaire.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de modification de profil surconsommation.</param>
        /// <returns></returns>
        public FormulaireMPS ObtenirFormulaireMpsParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            FormulaireMPS formulaire = this.DataSource.Query<FormulaireMPS>()
                .SingleOrDefault(x => x.Cle == cle);

            return formulaire;
        }

        /// <summary>
        /// Création d'un Formulaire de risque de résiliation.
        /// </summary>
        /// <param name="formulaire">Le Formulaire de risque de résiliation à ajouter.</param>
        public long CreerFormulaireRisqueResiliation(FormulaireRisqueResiliation formulaire)
        {
            formulaire.Valider(nameof(formulaire)).NonNull();

            //Ajout de formulaire au DataSource.
            this.DataSource.Add(formulaire);

            return formulaire.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de risque de résiliation.</param>
        /// <returns></returns>
        public FormulaireRisqueResiliation ObtenirFormulaireRisqueResiliationParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            FormulaireRisqueResiliation formulaire = this.DataSource.Query<FormulaireRisqueResiliation>()
                .SingleOrDefault(x => x.Cle == cle);

            return formulaire;
        }

        #endregion Méthodes - IFormulaireGboRepository - Formulaires

        /// <summary>
        /// Obtient la clé d'un Formulaire GBO à partir de la Clé Dossier GBO associée.
        /// </summary>
        /// <param name="cle">Clé technique du Dossier GBO.</param>
        /// <returns></returns>
        public long ObtenirCleFormulaireGboDepuisCleDossier(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            return this.DataSource.Query<FormulaireGBO>()
                .Where(x => x.CleDossierGbo == cle).Select(x => x.Cle).FirstOrDefault();
        }

        /// <summary>
        /// Obtient le type d'un Formulaire GBO à partir de la Clé Formulaire
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO.</param>
        /// <returns></returns>
        public TypeFormulaireGBO ObtenirTypeFormulaireGboParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            return this.DataSource.Query<FormulaireGBO>()
                .Where(x => x.Cle == cle).Select(x => x.TypeFormulaireGbo).FirstOrDefault();
        }
    }
}