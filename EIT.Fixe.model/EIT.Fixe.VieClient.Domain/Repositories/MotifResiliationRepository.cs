﻿using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des motifs de résiliation.
    /// </summary>
    public sealed class MotifResiliationRepository : Repository, IMotifResiliationRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public MotifResiliationRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - IMotifResiliationRepository

        /// <summary>
        /// Liste les motifs de résiliation.
        /// </summary>
        /// <returns>Liste des motifs de résiliation.</returns>
        public List<MotifResiliation> ListerMotifsResiliation()
        {
            List<MotifResiliation> motifsResiliation = this.DataSource.Query<MotifResiliation>().ToList();

            motifsResiliation.Valider(nameof(motifsResiliation)).NonNul();

            return motifsResiliation;
        }

        /// <summary>
        /// Obtient un motif de résiliation par sa clé.
        /// </summary>
        /// <param name="cle">Clé permettant de trouver un motif de résiliation.</param>
        /// <returns>Objet MotifResiliation correspondant à la clé passée en paramètre.</returns>
        public MotifResiliation ObtenirDepuisCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            MotifResiliation motif = this.RechercherParCle(cle);
            motif.Valider(nameof(motif)).NonNul();

            return motif;
        }


        /// <summary>
        /// Recherche un motif de résiliation par sa clé.
        /// </summary>
        /// <param name="cle">Clé permettant de trouver un motif de résiliation.</param>
        /// <returns>Objet MotifResiliation correspondant à la clé passée en paramètre.</returns>
        public MotifResiliation RechercherParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            return this.DataSource.Query<MotifResiliation>().SingleOrDefault(x => x.Cle == cle);
        }

        #endregion Méthodes - IMotifResiliationRepository
    }
}