﻿using System.Collections.Generic;
using EIT.DataAccess;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using System.Linq;
using System;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Registre de données des lignes fixes.
    /// </summary>
    public sealed class LigneRepository : Repository, ILigneRepository
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="dataSource">Source de données.</param>
        public LigneRepository(IDataSource dataSource) : base(dataSource)
        {

        }

        #endregion Constructeurs

        #region Méthodes - ILigneRepository

        /// <summary>
        /// Obtention d'un objet métier de type Ligne.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Objet métier ligne.</returns>
        /// <remarks>Lève une exception en cas de ligne non-retrouvée.</remarks>
        public Ligne ObtenirDepuisCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            Ligne ligne = this.RechercherParCle(cle);
            ligne.Valider(nameof(ligne)).NonNul();

            return ligne;
        }

        /// <summary>
        /// Recherche un objet métier de type Ligne.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Objet métier ligne.</returns>
        /// <remarks>Lève une exception en cas de ligne non-retrouvée.</remarks>
        public Ligne RechercherParCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            return this.DataSource.Query<Ligne>().SingleOrDefault(x => x.Cle == cle);
        }

        /// <summary>
        /// Retourne la référence externe de la ligne depuis sa clé technique.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Référence externe de la ligne.</returns>
        /// <remarks>Lève une exception en cas de valeur non-retrouvée.</remarks>
        public string ObtenirReferenceExterneDepuisCle(long cle)
        {
            cle.Valider(nameof(cle)).StrictementPositif();

            return this.DataSource.Query<Ligne>()
               .Where(x => x.Cle == cle)
                .Select(x => x.ReferenceExterne)
               .Single();
        }

        /// <summary>
        /// Ajoute une ligne à la persistance de données.
        /// </summary>
        /// <param name="ligne">La ligne à ajouter.</param>
        public void AjouterLigne(Ligne ligne)
        {
            ligne.Valider(nameof(ligne)).NonNul();

            this.DataSource.Add(ligne);
        }

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro.
        /// </summary>
        /// <param name="numero">Numéro de la ligne fixe.</param>
        /// <returns>Ligne fixe correspondant au numéro.</returns>
        /// <remarks>Lève une exception en cas de ligne non-retrouvée.</remarks>
        public Ligne ObtenirDepuisNumero(string numero)
        {
            Ligne ligne = this.RechercherParNumero(numero);

            ligne.Valider(nameof(ligne)).NonNul();

            return ligne;
        }

        /// <summary>
        /// Recherche un objet métier de type Ligne en fonction de son numéro.
        /// </summary>
        /// <param name="numero">Numéro de la ligne fixe.</param>
        /// <remarks>Ne lève pas d'exception en cas de ligne non-retrouvée.</remarks>
        public Ligne RechercherParNumero(string numero)
        {
            numero.Valider(nameof(numero)).Obligatoire();

            return this.DataSource.Query<Ligne>().SingleOrDefault(lge => lge.Numero == numero);
        }

        /// <summary>
        /// Rechercher une ligne par sa clé d'ICN.
        /// </summary>
        /// <param name="cleIcn">Clé ICN de la ligne recherchée.</param>
        /// <returns>Ligne recherchée.</returns>
        public Ligne RechercherParCleIcn(long cleIcn)
        {
            cleIcn.Valider(nameof(cleIcn)).StrictementPositif();

            return this.DataSource.Query<Ligne>().FirstOrDefault(l => l.CleIcn == cleIcn);
        }

        /// <summary>
        /// Rechercher une ligne par sa clé Tiers.
        /// </summary>
        /// <param name="cleTiers">Clé du titulaire de la ligne recherchée.</param>
        /// <returns>Ligne recherchée.</returns>
        public Ligne RechercherParCleTiers(long cleTiers)
        {
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            return this.DataSource.Query<Ligne>().FirstOrDefault(l => l.CleTiers == cleTiers);
        }

        /// <summary>
        /// Obtient une ligne par la clé du tiers.
        /// </summary>
        /// <param name="cleTiers">Clé du titulaire de la ligne obtenue.</param>
        /// <returns>Ligne obtenue.</returns>
        public Ligne ObtenirDepuisCleTiers(long cleTiers)
        {
            Ligne ligne = this.RechercherParCleTiers(cleTiers);

            ligne.Valider(nameof(ligne)).NonNul();

            return ligne;
        }

        /// <summary>
        /// Retourne le numéro de la ligne depuis sa clé technique.
        /// </summary>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Numéro de ligne.</returns>
        public string ObtenirNumeroDepuisCle(long cle)
        {
            return this.DataSource.Query<Ligne>().Where(x => x.Cle == cle).Select(x => x.Numero).FirstOrDefault();
        }

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro de contrat.
        /// </summary>
        /// <param name="numeroContrat">Numéro de contrat de la ligne.</param>
        /// <returns>Objet Ligne correspondant au numéro de contrat passé en paramètre.</returns>
        /// <remarks>Lève une exception si aucune ligne ne correspond.</remarks>
        public Ligne ObtenirDepuisNumeroContrat(string numeroContrat)
        {
            Ligne ligne = this.RechercherParNumeroContrat(numeroContrat);
            ligne.Valider(nameof(ligne)).NonNul();
            return ligne;
        }

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de son numéro de contrat.
        /// </summary>
        /// <param name="numeroContrat">Numéro de contrat de la ligne.</param>
        /// <returns>Objet Ligne correspondant au numéro de contrat passé en paramètre.</returns>
        /// <remarks>Ne lève aucune exception si aucune ligne ne correspond (retourne null).</remarks>
        public Ligne RechercherParNumeroContrat(string numeroContrat)
        {
            numeroContrat.Valider(nameof(numeroContrat)).Obligatoire();

            return this.DataSource.Query<Ligne>()
                .SingleOrDefault(lge => lge.NumeroContratOperateur == numeroContrat);
        }

        /// <summary>
        /// Obtient un objet métier de type Ligne en fonction de sa référence externe.
        /// </summary>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Objet Ligne possédant la référence externe passée en paramètre.</returns>
        /// <remarks>Lève une exception si aucune ligne ne correspond.</remarks>
        public Ligne ObtenirDepuisReferenceExterne(string referenceExterne)
        {
            Ligne ligne = this.RechercherParReferenceExterne(referenceExterne);
            ligne.Valider(nameof(ligne)).NonNul();
            return ligne;
        }

        /// <summary>
        /// Recherche de ligne par référence externe.
        /// </summary>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Ligne correspondant à la référence externe fournie.</returns>
        /// <remarks>Ne lève aucune exception si aucune ligne ne correspond (retourne null).</remarks>
        public Ligne RechercherParReferenceExterne(string referenceExterne)
        {
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            return this.DataSource.Query<Ligne>()
                .SingleOrDefault(l => l.ReferenceExterne.Trim().ToUpper() == referenceExterne.Trim().ToUpper());
        }

        /// <summary>
        /// Obtenir la ligne qui correspond 
        /// </summary>
        /// <param name="cleGestionnaireOptions"></param>
        /// <returns></returns>
        public Ligne ObtenirDepuisCleGestionnaireOptions(string cleGestionnaireOptions)
        {
            cleGestionnaireOptions.Valider(nameof(cleGestionnaireOptions)).NonNul();

            List<Ligne> resultatRecherche =  this.DataSource.Query<Ligne>().Where(l => l.CleGestionnaireOptions == cleGestionnaireOptions).ToList();

            // Obligatoirement une ligne
            if (!resultatRecherche.Any())
            {
                throw new InvalidOperationException(
                    $"Aucune ligne n'a été trouvée pour la clé gestionnaire option {cleGestionnaireOptions}");
            }
            // Obligatoirement une seule ligne par clé du gestionnaire d'option
            if (resultatRecherche.Count > 1)
            {
                throw new InvalidOperationException(
                    $"Plusieurs lignes ont été retournées pour la clé gestionnaire options {cleGestionnaireOptions}");
            }
            return resultatRecherche.First();
        }

        #endregion Méthodes - ILigneRepository
    }
}