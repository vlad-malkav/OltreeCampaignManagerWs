﻿
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;

namespace EIT.Fixe.VieClient.Domain.Repositories
{
    /// <summary>
    /// Mise à disposition de l'ensemble des repositories du domaine Vie Client.
    /// </summary>
    public sealed class Repositories : IRepositories
    {
        #region Champs
        
        /// <summary>
        /// Registre de données des historiques des lignes fixes.
        /// </summary>
        private readonly ILigneRepository ligneRepository;

        /// <summary>
        /// Registre de données des historiques des pannes collectives.
        /// </summary>
        private readonly IPanneCollectiveRepository panneCollectiveRepository;

        /// <summary>
        /// Registre de données des demandes de remises.
        /// </summary>
        private readonly IDemandeRemiseRepository demandeRemiseRepository;

        /// <summary>
        /// Registre de données des motifs de résiliation.
        /// </summary>
        private readonly IMotifResiliationRepository motifResiliationRepository;

        /// <summary>
        /// Repository du mode de retour équipement.
        /// </summary>
        private readonly IModeRetourEquipementRepository modeRetourEquipementRepository;

        /// <summary>
        /// Repository des demandes de résiliation.
        /// </summary>
        private readonly IDemandeResiliationRepository demandeResiliationRepository;

        /// <summary>
        /// Repository des documents de ligne.
        /// </summary>
        private readonly IDocumentLigneRepository documentLigneRepository;

        /// <summary>
        /// Repository des profils.
        /// </summary>
        private readonly IProfilRepository profilRepository;

        /// <summary>
        /// Repository des groupes de fonctionnalités.
        /// </summary>
        private readonly IGroupeFonctionnalitesRepository groupeFonctionnalitesRepository;

        /// <summary>
        /// Repository des fonctionnalités.
        /// </summary>
        private readonly IFonctionnaliteRepository fonctionnaliteRepository;

        /// <summary>
        /// Repository des historiques de réinitialisation login.
        /// </summary>
        private readonly IHistoriqueReinitialiserLoginRepository historiqueReinitialiserLoginRepository;
        
        /// <summary>
        /// Registre de données des Formulaires GBO.
        /// </summary>
        private readonly IFormulaireGboRepository formulaireGboRepository;
        /// <summary>
        /// Repository des historiques des dossiers GBO
        /// </summary>
        private readonly IHistoriqueDossierGboLigneRepository historiqueDossierGboLigneRepository;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="ligneHistoriqueHistoriqueRepository">Registre de données des historiques techniques d'historiques fonctionnels.</param>
        /// <param name="ligneRepository">Registre de données des lignes fixes.</param>
        /// <param name="panneCollectiveRepository">Registre de données des pannes collectives.</param>
        /// <param name="motifResiliationRepository">Registre des motifs de résiliation.</param>
        /// <param name="modeRetourEquipementRepository">Registre des modes de retour équipements.</param>
        /// <param name="demandeResiliationRepository">Registre des demandes de résiliation.</param>
        /// <param name="documentLigneRepository">Registre des documents de ligne.</param>
        /// <param name="profilRepository">Registre des profils.</param>
        /// <param name="groupeFonctionnalitesRepository">Registre des groupes de fonctionnalités.</param>
        /// <param name="fonctionnaliteRepository">Registre des fonctionnalités.</param>
        /// <param name="historiqueReinitialiserLoginRepository">Registre des historiques de réinitialisation.</param>
        /// <param name="demandeRemiseRepository">Registre de données des demandes de remises.</param>
        /// <param name="FormulaireGboRepository">Registre de données des Formulaires GBO.</param>
        /// <param name="historiqueDossierGboLigneRepository">Repository des historiques des dossiers GBO</param>
        public Repositories(
            ILigneRepository ligneRepository, 
            IPanneCollectiveRepository panneCollectiveRepository, 
            IMotifResiliationRepository motifResiliationRepository, 
            IModeRetourEquipementRepository modeRetourEquipementRepository,
            IDemandeResiliationRepository demandeResiliationRepository, 
            IDocumentLigneRepository documentLigneRepository,
            IProfilRepository profilRepository, 
            IGroupeFonctionnalitesRepository groupeFonctionnalitesRepository,
            IFonctionnaliteRepository fonctionnaliteRepository, 
            IHistoriqueReinitialiserLoginRepository historiqueReinitialiserLoginRepository,
            IDemandeRemiseRepository demandeRemiseRepository, 
            IFormulaireGboRepository formulaireGboRepository,
            IHistoriqueDossierGboLigneRepository historiqueDossierGboLigneRepository)
        {
            // Vérification des entrées.
            ligneRepository.Valider(nameof(ligneRepository)).NonNul();
            panneCollectiveRepository.Valider(nameof(panneCollectiveRepository)).NonNul();
            motifResiliationRepository.Valider(nameof(motifResiliationRepository)).NonNul();
            modeRetourEquipementRepository.Valider(nameof(modeRetourEquipementRepository)).NonNul();
            demandeResiliationRepository.Valider(nameof(demandeResiliationRepository)).NonNul();
            documentLigneRepository.Valider(nameof(documentLigneRepository)).NonNul();
            profilRepository.Valider(nameof(profilRepository)).NonNul();
            groupeFonctionnalitesRepository.Valider(nameof(groupeFonctionnalitesRepository)).NonNul();
            fonctionnaliteRepository.Valider(nameof(fonctionnaliteRepository)).NonNul();
            historiqueReinitialiserLoginRepository.Valider(nameof(historiqueReinitialiserLoginRepository)).NonNul();
            demandeRemiseRepository.Valider(nameof(demandeRemiseRepository)).NonNul();
            formulaireGboRepository.Valider(nameof(formulaireGboRepository)).NonNul();
            historiqueDossierGboLigneRepository.Valider(nameof(historiqueDossierGboLigneRepository)).NonNull();
            
            // Initialisation des champs.
            this.ligneRepository = ligneRepository;
            this.panneCollectiveRepository = panneCollectiveRepository;
            this.motifResiliationRepository = motifResiliationRepository;
            this.modeRetourEquipementRepository = modeRetourEquipementRepository;
            this.demandeResiliationRepository = demandeResiliationRepository;
            this.documentLigneRepository = documentLigneRepository;
            this.profilRepository = profilRepository;
            this.groupeFonctionnalitesRepository = groupeFonctionnalitesRepository;
            this.fonctionnaliteRepository = fonctionnaliteRepository;
            this.historiqueReinitialiserLoginRepository = historiqueReinitialiserLoginRepository;
            this.demandeRemiseRepository = demandeRemiseRepository;
            this.formulaireGboRepository = formulaireGboRepository;
            this.historiqueDossierGboLigneRepository = historiqueDossierGboLigneRepository;
        }

        #endregion Constructeurs

        #region IRepositories

        /// <summary>
        /// Registre de données des historiques des lignes fixes.
        /// </summary>
        public ILigneRepository LigneRepository
        {
            get
            {
                return this.ligneRepository;
            }
        }

        /// <summary>
        /// Registre de données des historiques des pannes collectives.
        /// </summary>
        public IPanneCollectiveRepository PanneCollectiveRepository
        {
            get
            {
                return this.panneCollectiveRepository;
            }
        }

        /// <summary>
        /// Définit le repository qui permet d'accéder à la persistance de PromotionApliqueeRepository.
        /// </summary>
        public IDemandeRemiseRepository DemandeRemiseRepository
        {
            get
            {
                return this.demandeRemiseRepository;
            }
        }

        /// <summary>
        /// Registre de données des Formulaires GBO.
        /// </summary>
        public IFormulaireGboRepository FormulaireGboRepository
        {
            get { return this.formulaireGboRepository; }
        }

        /// <summary>
        /// Registre des motifs de résiliation.
        /// </summary>
        public IMotifResiliationRepository MotifResiliationRepository
        {
            get
            {
                return this.motifResiliationRepository;
            }
        }

        /// <summary>
        /// Repository des modes de retour équipement.  
        /// </summary>
        public IModeRetourEquipementRepository ModeRetourEquipementRepository
        {
            get
            {
                return this.modeRetourEquipementRepository;
            }
        }

        /// <summary>
        /// Repository des demandes de résiliation.
        /// </summary>
        public IDemandeResiliationRepository DemandeResiliationRepository
        {
            get
            {
                return this.demandeResiliationRepository;
            }
        }

        /// <summary>
        /// Repository des documents de ligne.
        /// </summary>
        public IDocumentLigneRepository DocumentLigneRepository
        {
            get
            {
                return this.documentLigneRepository;
            }
        }

        /// <summary>
        /// Repository des profils.
        /// </summary>
        public IProfilRepository ProfilRepository
        {
            get
            {
                return this.profilRepository;
            }
        }

        /// <summary>
        /// Repository des groupes de fonctionnalités.
        /// </summary>
        public IGroupeFonctionnalitesRepository GroupeFonctionnalitesRepository
        {
            get
            {
                return this.groupeFonctionnalitesRepository;
            }
        }

        /// <summary>
        /// Repository des fonctionnalités.
        /// </summary>
        public IFonctionnaliteRepository FonctionnaliteRepository
        {
            get
            {
                return this.fonctionnaliteRepository;
            }
        }

        /// <summary>
        /// Repository des historiques de réinitialisation du login.
        /// </summary>
        public IHistoriqueReinitialiserLoginRepository HistoriqueReinitialiserLoginRepository
        {
            get
            {
                return this.historiqueReinitialiserLoginRepository;
            }
        }
        /// <summary>
        /// Repository des historiques des dossiers GBO
        /// </summary>
        public IHistoriqueDossierGboLigneRepository HistoriqueDossierGboLigneRepository
        {
            get { return this.historiqueDossierGboLigneRepository; }
        }

        #endregion IRepositories
    }
}