﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des équipements de la ligne.
    /// </summary>
    [CustomTableName("T_EQULIG")]
    public class EquipementLigne : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire de l'équipement de la ligne.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        [CustomColumnName("CLELIGNE")]
        public virtual Ligne.Ligne Ligne { get; set; }

        /// <summary>
        /// Clé de l'équipement livré issu de la commande d'expédition.
        /// </summary>
        [CustomColumnName("CLEEQUIPEMENT")]
        public virtual long CleEquipement { get; set; }

        /// <summary>
        /// Code de la référence commerciale.
        /// </summary>
        [CustomColumnName("CODEREFCOM")]
        public virtual string CodeRefCom { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'initiative de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de dernière modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        /// <summary>
        /// Agent à l'initiative de la dernière modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected EquipementLigne()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cle">Clé primaire de l'équipement de la ligne.</param>
        /// <param name="ligne">Ligne de l'équipement.</param>
        /// <param name="cleEquipement">Clé de l'équipement livré issu de la commande d'expédition.</param>
        /// <param name="codeRefCom">Code de la référence commerciale.</param>
        public EquipementLigne(Identite identite, long cle, Ligne.Ligne ligne, long cleEquipement, string codeRefCom)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            ligne.Valider(nameof(ligne)).NonNul();
            cleEquipement.Valider(nameof(cleEquipement)).StrictementPositif();
            codeRefCom.Valider(nameof(codeRefCom)).NonNul().Obligatoire();

            // Assignation des valeurs.
            this.Cle = cle;
            this.Ligne = ligne;
            this.CleEquipement = cleEquipement;
            this.CodeRefCom = codeRefCom;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviDateCreation = DateTime.Now;
            this.SuiviDateModification = DateTime.Now;
            this.SuiviAgentModification = identite.Memoid;
        }

        #endregion Constructeurs
    }
}