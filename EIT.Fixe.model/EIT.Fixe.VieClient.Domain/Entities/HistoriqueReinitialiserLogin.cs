﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier d'un historique des réinitialisations de login.
    /// </summary>
    [CustomTableName("T_HISREILGN")]
    public class HistoriqueReinitialiserLogin : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        [CustomColumnName("CLELIGNE")]
        public virtual long CleLigne { get; set; }

        /// <summary>
        /// Type de demande.
        /// </summary>
        [CustomColumnName("TYPE")]
        public virtual string Type { get; set; }

        /// <summary>
        /// Date de la demande.
        /// </summary>
        [CustomColumnName("DATE")]
        public virtual DateTime DateDemande { get; set; }

        /// <summary>
        /// Identifiant du titulaire de la ligne.
        /// </summary>
        [CustomColumnName("IDENTIFIANT")]
        public virtual string Identifiant { get; set; }

        /// <summary>
        /// Mode d'envoi de la réinitialisation.
        /// </summary>
        [CustomColumnName("MODEENVOI")]
        public virtual CanalCommunication ModeEnvoi { get; set; }

        /// <summary>
        /// Destinataire de la réinitialisation.
        /// </summary>
        [CustomColumnName("DESTINATAIRE")]
        public virtual string Destinataire { get; set; }

        /// <summary>
        /// Canal de la demande.
        /// </summary>
        [CustomColumnName("CANAL")]
        public virtual string Canal { get; set; }

        /// <summary>
        /// Agent à l'origine de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected HistoriqueReinitialiserLogin()
        {
            
        }

        /// <summary>
        /// Constructeur pour l'instanciation d'un groupe de fonctionnalités.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreCreation">Paramètre de création.</param>
        public HistoriqueReinitialiserLogin(Identite identite, ParametreHistoriqueReinitialiserLoginPourCreation parametreCreation)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametreCreation.Valider(nameof(parametreCreation)).NonNul();

            // Affectation des données.
            this.Cle = parametreCreation.Cle;
            this.DateDemande = DateTime.Now;
            this.Type = "Login Email";
            this.CleLigne = parametreCreation.CleLigne;
            this.Destinataire = parametreCreation.Destinataire;
            this.Identifiant = parametreCreation.Identifiant;
            this.ModeEnvoi = parametreCreation.ModeEnvoi;
            this.Canal = parametreCreation.CanalDemande;
            this.SuiviDateCreation = DateTime.Now;
            this.SuiviAgentCreation = identite.Memoid;
        }

        #endregion Constructeurs

    }
}
