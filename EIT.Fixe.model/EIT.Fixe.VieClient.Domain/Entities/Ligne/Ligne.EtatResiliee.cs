﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une Ligne.
    /// </summary>
    public partial class Ligne : Entity
    {
        /// <summary>
        /// Représente l'état Resiliee d'une ligne.
        /// </summary>
        public sealed class EtatResiliee : AbstractEtat
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Motif de résiliation.
            /// </summary>
            public override string MotifResiliation
            {
               
                get
                {
                    // récupération de la "Demande de Résiliation" au staut "Traité" la plus récente
                    DemandeResiliation.DemandeResiliation demandeResiliation = this.Entite.ListeDemandeResiliation.Where(demande => demande.Etat.Valeur == EtatDemandeResiliation.Traitee)
                                                                                                                    .OrderByDescending(demande => demande.SuiviDateCreation)
                                                                                                                    .FirstOrDefault();

                    // si la demande de résiliation n'est pas nulle et que sa clé est supérieure à 0
                    if (demandeResiliation != null
                        && demandeResiliation.Cle > 0)
                    {
                        // Appeler la méthode ObtenirDepuisCle du registre MotifResiliationRepository
                        MotifResiliation motif = this.Entite.repositories.MotifResiliationRepository.ObtenirDepuisCle(demandeResiliation.CleMotifResiliation);

                        // retourner le libellé
                        return motif.Libelle;
                    }
                    return string.Empty;
                }
            }

            #endregion Propriétés dynamiques

            #region Constructeurs
            /// <summary>
            /// Constructeur.
            /// </summary>
            /// <param name="identite">Identite de la personne qui fait l'action.</param>
            /// <param name="ligne">La ligne.</param>
            /// <param name="ancienEtat">L'ancien etat.</param>
            public EtatResiliee(Identite identite, Ligne ligne, EtatLigne ancienEtat) : base(identite, ligne, ancienEtat)
            {
            }
            #endregion Constructeurs

            #region Etat<Ligne, EtatLigne>
            /// <summary>
            /// Valeur de l'etat.
            /// </summary>
            public override EtatLigne Valeur
            {
                get
                {
                    return EtatLigne.Resiliee;
                }
            }
            #endregion Etat<Ligne, EtatLigne>
        }
    }
}