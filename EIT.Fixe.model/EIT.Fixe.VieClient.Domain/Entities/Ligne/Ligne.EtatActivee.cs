﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une Ligne fixe.
    /// </summary>
    public partial class Ligne : Entity
    {
        /// <summary>
        /// Représente l'état Activee d'une ligne fixe.
        /// </summary>
        private class EtatActivee : AbstractEtat
        {
            #region Constructeurs

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identite de la personne qui fait l'action.</param>
            /// <param name="ligne">La ligne.</param>
            /// <param name="ancienEtat">L'ancien etat.</param>
            public EtatActivee(Identite identite, Ligne ligne, EtatLigne ancienEtat) : base(identite, ligne, ancienEtat)
            {
            }

            #endregion Constructeurs

            #region Etat<Ligne, EtatLigne>

            /// <summary>
            /// Valeur de l'etat.
            /// </summary>
            public override EtatLigne Valeur
            {
                get
                {
                    return EtatLigne.Activee;
                }
            }

            #endregion Etat<Ligne, EtatLigne>

            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la ligne peut être résiliée.
            /// </summary>
            public override bool EstResiliable
            {
                get
                {
                    return EstResiliableInterne();
                }
            }

            #endregion Propriétés dynamiques

            #region Méthodes

            /// <summary>
            /// Méthode permet de mettre à jour le statut de surconsommation de la ligne.
            /// </summary>
            /// <param name="identite">Informations d'identité de l'appelant.</param>
            /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne.</param>
            public override void ModifierStatutSurconsommation(Identite identite, ProfilSurconsommation statutSurconsommation)
            {
                this.ModifierStatutSurconsommationInterne(identite, statutSurconsommation);
            }

            /// <summary>
            /// Méthode implémentant la création d'une demande de résiliation associée à la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="informationsDemandeResiliation">Informations pour la création de la demande de résiliation.</param>
            public override void CreerDemandeResiliation(Identite identite, DemandeResiliationPourCreation informationsDemandeResiliation)
            {
                //Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();
                informationsDemandeResiliation.Valider(nameof(informationsDemandeResiliation)).NonNul();

                this.Entite.CreerDemandeResiliationInterne(identite, informationsDemandeResiliation);
            }

            /// <summary>
            /// Résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void Resilier(Identite identite)
            {
                identite.Valider(nameof(identite)).NonNul();

                this.Entite.ResilierInterne(identite);
            }

            /// <summary>
            /// Suspension de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void Suspendre(Identite identite)
            {
                //Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();

                int identifiantTransactionOperateur = this.Entite.IdentifiantTransactionOperateur;
                string numeroContratOperateur = this.Entite.NumeroContratOperateur;

                this.Entite.briquesExternes.InterfaceOperateurServiceExterne.CreerDemandeSuspension(identite, identifiantTransactionOperateur, numeroContratOperateur);

                this.Entite.Etat = new LigneMachineEtats(new EtatSuspendue(identite, this.Entite, this.Valeur));
            }

            #endregion Méthodes
        }
    }
}