﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Systeme.Entites;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une Ligne fixe.
    /// </summary>
    public partial class Ligne : Entity
    {
        /// <summary>
        /// Represente la machine à états de ligne fixe.
        /// </summary>
        public class LigneMachineEtats : MachineEtats<Ligne, EtatLigne, AbstractEtat>
        {
            #region Constructeurs

            /// <summary>
            /// Constructeur sans paramètre nécessaire pour l'accès aux données.
            /// </summary>
            private LigneMachineEtats()
            {
            }

            /// <summary>
            /// Construit une machine à état pour une ligne à partir de l'état initial.
            /// </summary>
            /// <param name="etatInitial">Etat initial de la commande.</param>
            public LigneMachineEtats(AbstractEtat etatInitial) : base(etatInitial)
            {
            }

            #endregion Constructeurs
        }
    }
}