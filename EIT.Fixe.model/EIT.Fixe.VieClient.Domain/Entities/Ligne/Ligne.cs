﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.Gbo;
using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Infrastructure.Helpers;
using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Events;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une ligne fixe.
    /// </summary>
    [AccesConcurrent]
    [CustomTableName("T_LIG")]
    public partial class Ligne : Entity
    {
        #region Champs

        /// <summary>
        /// Services externes.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        /// <summary>
        /// Interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesExternes;

        #endregion Champs

        #region Propriétés

        #region Protected

        /// <summary>
        /// Etat courant de la ligne fixe.
        /// </summary>
        protected virtual AbstractEtat EtatCourant
        {
            get { return this.Etat.Obtenir(this); }
            set { this.Etat.Definir(value); }
        }

        #endregion Protected

        #region Public

        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [CustomColumnName("CLE")]
        [Key]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Valeur de l’état en cours de la ligne.
        /// </summary>
        [CustomColumnName("ETAT")]
        public virtual LigneMachineEtats Etat { get; set; }

        /// <summary>
        /// Valeur de l'état de la ligne fixe.
        /// </summary>
        public EtatLigne ValeurEtat
        {
            get
            {
                return this.Etat.Valeur;
            }
        }

        /// <summary>
        /// Clé unique de la technologie de la ligne.
        /// </summary>
        [CustomColumnName("CLETECHNOLOGIE")]
        public virtual int CleTechnologie { get; set; }

        /// <summary>
        /// Référence externe, commune avec la commande de souscription, la commande d’activation ainsi que la commande d’expédition. 
        /// Remarque : a été mis en place afin de faciliter les interactions entre ces entités appartenant à des domaines distincts.
        /// </summary>
        [CustomColumnName("REFERENCEEXTERNE")]
        public virtual string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [CustomColumnName("NUMERO")]
        public virtual string Numero { get; set; }

        /// <summary>
        /// Clé de l’adresse d’installation.
        /// </summary>
        /// <remarks>
        /// La clé d'adresse d'installation et la clé d'éligibilité sont une seule et même donnée. On parle
        /// d'adresse d'éligiblité en Souscription et d'adresse d'installation en post-Souscription.
        /// </remarks>
        [CustomColumnName("CLEADRESSEINSTALLATION")]
        public virtual long CleAdresseInstallation { get; set; }

        /// <summary>
        /// Clé du compte de facturation de la ligne.
        /// </summary>
        [CustomColumnName("CLECOMPTEFACTURATION")]
        public virtual long CleCompteFacturation { get; set; }

        /// <summary>
        /// Clé du gestionnaire des options.
        /// </summary>
        [CustomColumnName("CLEGESTIONNAIREOPTIONS")]
        public virtual string CleGestionnaireOptions { get; set; }

        /// <summary>
        /// Numéro de contrat fourni par l’opérateur.
        /// </summary>
        [CustomColumnName("NUMEROCONTRATIO")]
        public virtual string NumeroContratOperateur { get; set; }

        /// <summary>
        /// Identifiant de transaction avec l’opérateur.
        /// </summary>
        [CustomColumnName("IDENTIFIANTIO")]
        public virtual int IdentifiantTransactionOperateur { get; set; }

        /// <summary>
        /// Clé marque.
        /// </summary>
        [CustomColumnName("CLEMARQUE")]
        public virtual int CleMarque { get; set; }

        /// <summary>
        /// Statut de surconsommation de la ligne.
        /// </summary>
        [CustomColumnName("STATUTSURCONSOMMATION")]
        public virtual ProfilSurconsommation StatutSurconsommation { get; set; }

        /// <summary>
        /// Date de fin d’engagement.
        /// </summary>
        [CustomColumnName("DATEFINENGAGEMENT")]
        public virtual DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Clé de l’offre souscrite.
        /// </summary>
        [CustomColumnName("CLEOFFRE")]
        public virtual int CleOffre { get; set; }

        /// <summary>
        /// Clé du tiers ayant souscrit l’offre.
        /// </summary>
        [CustomColumnName("CLETIERS")]
        public virtual long CleTiers { get; set; }

        /// <summary>
        /// Clé ICN.
        /// </summary>
        [CustomColumnName("CLEICN")]
        public virtual int? CleIcn { get; set; }

        /// <summary>
        /// Numéro RIO sartant de la ligne.
        /// </summary>
        [CustomColumnName("RIO")]
        public virtual string Rio { get; set; }

        /// <summary>
        /// Historique des états de la ligne.
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLELIGNE")]
        public virtual ICollection<HistoriqueEtatLigne> ListeHistoriqueEtats { get; set; }

        /// <summary>
        /// Liste des KitBox.
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLELIGNE")]
        public virtual ICollection<KitBox> ListeKitBox { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent de création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de dernière modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime? SuiviDateModification { get; set; }

        /// <summary>
        /// Agent ayant effectué la dernière modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        /// <summary>
        /// Liste des pannes collectives ayant impacté la ligne.
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLELIGNE")]
        public virtual ICollection<PanneCollective> ListePannesCollectives { get; protected set; }

        /// <summary>
        /// Gestionnaire de demandes de remise.
        /// </summary>
        [CustomColumnName("CLEGESTIONNAIREREMISE")]
        public virtual GestionnaireDemandeRemises GestionnaireDemandeRemises { get; protected set; }

        /// <summary>
        /// Générateur de clés techniques.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get
            {
                return this.serviceTechnique.GenerateurCles;
            }
        }

        /// <summary>
        /// Liste des demandes de résiliation de la ligne.
        /// </summary>
        [OneToMany]
        [InverseProperty(nameof(DemandeResiliation.DemandeResiliation.Ligne))]
        public virtual ICollection<DemandeResiliation.DemandeResiliation> ListeDemandeResiliation { get; set; }

        /// <summary>
        /// Liste des équipements de la ligne.
        /// </summary>
        [OneToMany]
        [InverseProperty(nameof(EquipementLigne.Ligne))]
        public virtual ICollection<EquipementLigne> ListeEquipement { get; set; }

        #endregion Public

        #region Propriétés dynamiques


        /// <summary>
        /// Indique si une demande de résiliation est en cours.
        /// </summary>
        public bool DemandeResiliationEnCours
        {
            get
            {
                if (this.ListeDemandeResiliation.FirstOrDefault(d => d.Etat.Valeur == EtatDemandeResiliation.EnCours) != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Indique si une ligne peut être résiliée.
        /// </summary>
        public bool EstResiliable
        {
            get
            {
                return this.EtatCourant.EstResiliable;
            }
        }

        /// <summary>
        /// Motif de résiliation.
        /// </summary>
        public string MotifResiliation
        {
            get
            {
                return this.EtatCourant.MotifResiliation;
            }
        }


        /// <summary>
        /// Liste des motifs de suspension.
        /// </summary>
        public virtual List<string> ListeMotifsSuspension(Identite identite)
        {
            return this.EtatCourant.ListeMotifsSuspension(identite);
        }

        #endregion Propriétés dynamiques

        #endregion Propriétés

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected Ligne()
        { }

        /// <summary>
        /// Constructeur d’initialisation.
        /// </summary>
        /// <param name="identite">Informations d’identité de l’appelant.</param>
        /// <param name="informationsLigne">Informations de la ligne à instancier.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        /// <param name="serviceExterne">L'interface du serviceExterne.</param>
        /// <param name="briqueServiceExterne">L'interface de briqueServiceExterne.</param>
        /// <param name="repositories">L'interface de repositories.</param>
        public Ligne(Identite identite, DetailLignePourCreation informationsLigne, IServicesTechniques serviceTechnique,
            IServicesExternes serviceExterne, IBriquesServicesExternes briqueServiceExterne, IRepositories repositories)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            informationsLigne.Valider(nameof(informationsLigne)).NonNul();
            informationsLigne.Cle.Valider(nameof(informationsLigne.Cle)).NonNul().StrictementPositif();
            informationsLigne.CleCompteFacturation.Valider(nameof(informationsLigne.CleCompteFacturation)).NonNul().StrictementPositif();
            informationsLigne.CleAdresseInstallation.Valider(nameof(informationsLigne.CleAdresseInstallation)).NonNul().StrictementPositif();
            informationsLigne.CleGestionnaireOptions.Valider(nameof(informationsLigne.CleGestionnaireOptions)).Obligatoire();
            informationsLigne.CleMarque.Valider(nameof(informationsLigne.CleMarque)).NonNul().StrictementPositif();
            informationsLigne.CleOffre.Valider(nameof(informationsLigne.CleOffre)).NonNul().StrictementPositif();
            informationsLigne.CleTechnologie.Valider(nameof(informationsLigne.CleTechnologie)).NonNul().StrictementPositif();
            informationsLigne.CleTiers.Valider(nameof(informationsLigne.CleTiers)).NonNul().StrictementPositif();
            informationsLigne.CleCommandeExpedition.Valider(nameof(informationsLigne.CleCommandeExpedition)).NonNul().StrictementPositif();
            informationsLigne.DateFinEngagement.Valider(nameof(informationsLigne.DateFinEngagement)).NonNul().Si(informationsLigne.DateFinEngagement > DateTime.MinValue);
            informationsLigne.Numero.Valider(nameof(informationsLigne.Numero)).Obligatoire().LongueurMax(10);
            informationsLigne.NumeroContratOperateur.Valider(nameof(informationsLigne.NumeroContratOperateur)).Obligatoire().LongueurMax(30);
            informationsLigne.ReferenceExterne.Valider(nameof(informationsLigne.ReferenceExterne)).Obligatoire().LongueurMax(12);
            informationsLigne.IdentifiantTransactionOperateur.Valider(nameof(informationsLigne.IdentifiantTransactionOperateur)).NonNul();
            informationsLigne.Rio.Valider(nameof(informationsLigne.Rio)).Obligatoire();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();
            serviceExterne.Valider(nameof(serviceExterne)).NonNul();
            briqueServiceExterne.Valider(nameof(briqueServiceExterne)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();

            // Valeurs par défaut
            this.ListeHistoriqueEtats = new List<HistoriqueEtatLigne>();
            this.ListePannesCollectives = new List<PanneCollective>();
            this.ListeKitBox = new List<KitBox>();
            this.ListeDemandeResiliation = new List<DemandeResiliation.DemandeResiliation>();
            this.ListeEquipement = new List<EquipementLigne>();

            // Affectation des valeurs entrées en paramètre
            this.serviceTechnique = serviceTechnique;
            this.repositories = repositories;
            this.servicesExternes = serviceExterne;
            this.briquesExternes = briqueServiceExterne;

            this.Cle = informationsLigne.Cle;
            this.ReferenceExterne = informationsLigne.ReferenceExterne;
            this.Numero = informationsLigne.Numero;
            this.CleCompteFacturation = informationsLigne.CleCompteFacturation;
            this.CleGestionnaireOptions = informationsLigne.CleGestionnaireOptions;
            this.NumeroContratOperateur = informationsLigne.NumeroContratOperateur;
            this.IdentifiantTransactionOperateur = informationsLigne.IdentifiantTransactionOperateur;
            this.CleMarque = informationsLigne.CleMarque;
            this.DateFinEngagement = informationsLigne.DateFinEngagement;
            this.CleTechnologie = informationsLigne.CleTechnologie;
            this.CleOffre = informationsLigne.CleOffre;
            this.CleTiers = informationsLigne.CleTiers;
            this.CleIcn = informationsLigne.CleIcn;
            this.Rio = informationsLigne.Rio;
            this.StatutSurconsommation = ProfilSurconsommation.NouveauClient;
            this.CleAdresseInstallation = informationsLigne.CleAdresseInstallation;

            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
            this.SuiviDateCreation = DateTime.Now;

            this.CreerGestionnaireDemandesRemises(identite, informationsLigne.ListeDemandeRemisePourCreation);

            this.Etat = new LigneMachineEtats(new EtatActivee(identite, this, EtatLigne.NA));

            KitBox kitBox = new KitBox(identite, this.GenerateurCles.ObtenirCleLongue<KitBox>(), informationsLigne.CleKitBox);
            this.ListeKitBox.Add(kitBox);
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Mise à jour du statut de surconsommation de la ligne.
        /// </summary>
        /// <param name="identite">Informations d’identité de l’appelant.</param>
        /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne.</param>
        public virtual void ModifierStatutSurconsommation(Identite identite, ProfilSurconsommation statutSurconsommation)
        {
            identite.Valider(nameof(identite)).NonNul();
            statutSurconsommation.Valider<Enum>(nameof(statutSurconsommation)).NonAttribuee();

            this.EtatCourant.ModifierStatutSurconsommation(identite, statutSurconsommation);
        }

        /// <summary>
        /// Initialise le gestionnaire qui va permettre de mettre en place des demandes de remise sur la ligne.
        /// </summary>
        /// <param name="identite">Informations de l'appelant.</param>
        /// <param name="listeDemandeRemisePourCreation">Liste des informations des demandes de remises à mettre en place sur la ligne.</param>
        private void CreerGestionnaireDemandesRemises(Identite identite, IList<DemandeRemisePourCreation> listeDemandeRemisePourCreation)
        {
            long cle = this.GenerateurCles.ObtenirCleLongue<GestionnaireDemandeRemises>();

            this.GestionnaireDemandeRemises = new GestionnaireDemandeRemises(identite, cle, this.ReferenceExterne,
                listeDemandeRemisePourCreation, this.Cle, this.CleOffre, this.servicesExternes, this.repositories, this.briquesExternes, this.serviceTechnique);
        }

        /// <summary>
        /// Création d'une demande de résiliation de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="informationsDemandeResiliation">Informations pour la création de la demande de résiliation.</param>
        public virtual void CreerDemandeResiliation(Identite identite, DemandeResiliationPourCreation informationsDemandeResiliation)
        {
            identite.Valider(nameof(identite)).NonNul();
            informationsDemandeResiliation.Valider(nameof(informationsDemandeResiliation)).NonNul();

            this.EtatCourant.CreerDemandeResiliation(identite, informationsDemandeResiliation);
        }

        /// <summary>
        /// Résiliation de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void Resilier(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.EtatCourant.Resilier(identite);
        }

        /// <summary>
        /// Suspension de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void Suspendre(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.EtatCourant.Suspendre(identite);
        }

        /// <summary>
        /// Permet de remettre en service la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void RemettreEnService(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            this.EtatCourant.RemettreEnService(identite);
        }

        /// <summary>
        /// Permet de creér une demande de rétractation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action;</param>
        /// <param name="informationsDemandeRetractation">Informations nécessaire à la création d'une demande de rétractation.</param>
        public void CreerDemandeRetractation(Identite identite, DemandeRetractationPourCreation informationsDemandeRetractation)
        {
            // Vérification des entrées.
            informationsDemandeRetractation.Valider(nameof(informationsDemandeRetractation)).NonNul();

            //Récupération de la clé du motif de rétractation.
            long cleMotifRetractation = this.serviceTechnique.Parametrage.CleMotifResiliationRetractation;

            //Récupération du motif résiliation.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(cleMotifRetractation);

            //Instanciation d'un objet DemandeResiliationPourCreation.
            DemandeResiliationPourCreation informationsDemandeResiliation = new DemandeResiliationPourCreation()
            {
                CleMotifResiliation = cleMotifRetractation,
                CleModeRetourEquipement = motifResiliation.ListeModeRetourEquipement.FirstOrDefault(x => x.EstCocheParDefaut).Cle,
                DateReceptionCourrierAr = informationsDemandeRetractation.DateReceptionCourierAr,
                DateResiliationProgrammee = null,
                Email = informationsDemandeRetractation.Email,
                EstNouveauTiersEnvoiBonRetour = informationsDemandeRetractation.EstNouveauTiersEnvoiBonRetour,
                TiersEnvoiBonRetour = informationsDemandeRetractation.TiersEnvoiBonRetour
            };

            //Appel à la méthode de création de demande de resiliation.
            this.CreerDemandeResiliationInterne(identite, informationsDemandeResiliation);
        }


        /// <summary>
        /// Retourne le KitBox actuellement associe a la ligne.
        /// </summary>
        public KitBox ObtenirKitBoxCourant()
        {
            this.ListeKitBox.Valider(nameof(this.ListeKitBox)).NonNull();
            IEnumerable<KitBox> kitBoxActif = this.ListeKitBox.Where(x => x.EstActif);

            if (!kitBoxActif.Any())
            {
                throw new Exception($"La ligne '{this.Cle}' ne possède aucun KitBox actif.");
            }

            if (kitBoxActif.Count() > 1)
            {
                throw new Exception($"La ligne '{this.Cle}' possède plus d'un KitBox actif.");
            }

            return kitBoxActif.First();

        }

        #endregion Méthodes

        #region Méthodes internes

        /// <summary>
        /// Méthode implémentant la création d'une demande de résiliation associée à la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="informationsDemandeResiliation">Informations de la demande de résiliation.</param>
        protected void CreerDemandeResiliationInterne(Identite identite, DemandeResiliationPourCreation informationsDemandeResiliation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            informationsDemandeResiliation.Valider(nameof(informationsDemandeResiliation)).NonNul();

            // Création de la clé.
            long cleTechnique = this.GenerateurCles.ObtenirCleLongue<DemandeResiliation.DemandeResiliation>();

            // Calcul de la date de résiliation programmée.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(informationsDemandeResiliation.CleMotifResiliation);
            informationsDemandeResiliation.DateResiliationProgrammee = informationsDemandeResiliation.DateReceptionCourrierAr.AddDays(motifResiliation.DelaiResiliation);

            // Instanciation de la demande de résiliation.
            DemandeResiliation.DemandeResiliation demandeResiliation = new DemandeResiliation.DemandeResiliation(
                identite,
                cleTechnique,
                this.Cle,
                informationsDemandeResiliation,
                this.repositories,
                this.servicesExternes,
                this.serviceTechnique,
                this.briquesExternes);

            // Ajout de la demande dans la liste.
            this.ListeDemandeResiliation.Add(demandeResiliation);

            // Appel de la méthode Traiter.
            demandeResiliation.Traiter(identite);

            //Création de l'historique.
            HistoriqueFonctionnelPourCreation informationsHistorique = new HistoriqueFonctionnelPourCreation()
            {
                CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                CleMetier2 = TypeHistoriqueMetierNiveau2.ResiliationEffective,
                CleOrigine = null,
                Commentaire = string.Format("Résiliation effective au {0}", informationsDemandeResiliation.DateResiliationProgrammee.Value),
                ReferenceExterne = this.ReferenceExterne
            };

            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriquePourDemandeResiliation(identite, informationsHistorique);

            // Récupération de la marque.
            Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, this.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Obtention du tiers.
            TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, this.CleTiers);

            //Envoi du mail de confirmation.
            ParametresEmailConfirmerDemandeResiliation parametres = new ParametresEmailConfirmerDemandeResiliation()
            {
                CleMarque = this.CleMarque,
                ReferenceExterne = this.ReferenceExterne,
                DateDemandeResiliation = demandeResiliation.SuiviDateCreation,
                DateResiliationEffective = demandeResiliation.DateResiliationProgrammee.Value,
                EmailDestinataire = informationsDemandeResiliation.TiersEnvoiBonRetour.EmailTiers,
                HeureFermetureSC = marque.HeureFermetureSc,
                HeureOuvertureSC = marque.HeureOuvertureSc,
                LibelleMarque = marque.Libelle,
                TelephoneFixeSC = marque.TelephoneFixeSc,
                TelephoneMobileContact = informationsDemandeResiliation.TiersEnvoiBonRetour.TelephoneMobileTiers,
                TelephoneMobileSC = marque.TelephoneMobileSc,
                NumeroLigne = this.Numero,
                UrlAssistance = marque.UrlAssistance,
                CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                NomTitulaire = tiers.Nom
            };
            this.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmationDemandeResiliation(identite, parametres);

            // Suivi de modification.
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        /// <summary>
        /// Méthode qui implémente la résiliation de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        protected void ResilierInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Appels à des logiques métiers factorisées.
            GererValorisationPourResiliationInterne(identite);
            GererLogistiquePourResiliationInterne(identite);
            GererInterfaceOperateurPourResiliationInterne(identite);
            GererOptionsPourResiliationInterne(identite);

            // Si la clé ICN possède une valeur, on clos l'ICN.
            if (this.CleIcn.HasValue)
            {
                this.briquesExternes.IcnServiceExterne.CloreIcn(identite, this.CleIcn.Value, DateTime.Now);
            }

            // Ajout d'un nouvel état à la liste des historiques des états.
            long cleHistorique = this.serviceTechnique.GenerateurCles.ObtenirCleLongue<HistoriqueEtatLigne>();
            this.ListeHistoriqueEtats.Add(new HistoriqueEtatLigne(identite, cleHistorique, EtatLigne.Resiliee, this.ValeurEtat));

            // Passage à l'état "Resiliee".
            this.Etat = new LigneMachineEtats(new EtatResiliee(identite, this, this.EtatCourant.Valeur));

            // Envoi du message ResiliationEffectuee avec la date du jour et la référence externe.
            ResiliationEffectuee resiliationEffectuee = new ResiliationEffectuee()
            {
                Date = DateTime.Now,
                ReferenceExterne = this.ReferenceExterne,
                Headers = EventHelper.InitialiserHeadersEvenementAvecIdentite(identite)
            };
            this.serviceTechnique.MessagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), resiliationEffectuee);

            // Ajout d'un historique VIECLIENT_HISTO_ACTE_RESIL.
            long cleHistoriqueCree = this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                this.Cle,
                new HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.Resiliation,
                    Commentaire = "Demande de résiliation",
                    ReferenceExterne = this.ReferenceExterne,
                    CleOrigine = null
                });

            // Création d'un dossier GBO : VIECLIENT_DOSSIER_RESIL_DEMANDERETOUREQPT.
            ReponseCreationDossierGbo reponseCreationDossierGbo = this.briquesExternes.BriqueGboServiceExterne.CreerDossier(identite,
                this.ReferenceExterne,
                "Effectuer un appel sortant pour indiquer au client que suite à la résiliation, nous n'avons pas reçu le matériel. " +
                "Vérifier avec le client s'il a renvoyé le matériel ou l'inviter à faire le renvoi en rappelant les moyens mis à sa dispositon. " +
                "A défaut de réception à date résiliation + 40j : facturation des frais de non retours d'équipement",
                67,
                2);

            // Création de l'association historique/historique dossier GBO.
            this.servicesExternes.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(identite, cleHistoriqueCree, reponseCreationDossierGbo.CleHistoriqueAssociationDossierGboLigne);

            // Suivi de modification.
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        /// <summary>
        /// Permet de remettre en service la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        protected void RemettreEnServiceInterne(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.Etat = new LigneMachineEtats(new EtatActivee(identite, this, this.EtatCourant.Valeur));

            TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, this.CleTiers);
            if (!string.IsNullOrWhiteSpace(tiers.NumeroMobileDeContact))
            {
                Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, this.CleMarque);

                ParametreSmsRemiseEnService parametre = new ParametreSmsRemiseEnService()
                {
                    CleMarque = this.CleMarque,
                    ReferenceExterne = this.ReferenceExterne,
                    TelephoneFixeLigne = this.Numero,
                    TelephoneMobileContact = tiers.NumeroMobileDeContact,
                    LibelleMarque = marque.Libelle
                };

                this.briquesExternes.CommunicationClientServiceExterne.EnvoyerSmsRemiseEnService(identite, parametre);
            }
        }

        #region Méthodes privées

        /// <summary>
        /// Méthode pour le traitement envoyé à la brique logistique.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        private void GererLogistiquePourResiliationInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            DemandeRetourEquipement demandeRetourEquipement = this.servicesExternes.LogistiqueServiceExterne.CreerDemandeRetourEquipement(identite, this.ReferenceExterne);
            demandeRetourEquipement.Valider(nameof(demandeRetourEquipement)).NonNul();

            DemandeResiliation.DemandeResiliation demandeResiliationEnCours = this.ListeDemandeResiliation.FirstOrDefault(d => d.Etat.Valeur == EtatDemandeResiliation.EnCours);
            demandeResiliationEnCours.Valider(nameof(demandeResiliationEnCours)).NonNul();

            // On lève un évènement pour assigner de manière asynchrone les valeurs du numéro de retour et de 
            // la clé de demande de retour.
            DemandeRetourEquipementCreee eventDemandeRetourEquipementCreee = new DemandeRetourEquipementCreee
            {
                CleDemandeResiliation = demandeResiliationEnCours.Cle,
                CleDemandeRetour = demandeRetourEquipement.Cle,
                NumeroRetour = demandeRetourEquipement.Numero,
                Headers = EventHelper.InitialiserHeadersEvenementAvecIdentite(identite)
            };
            this.serviceTechnique.MessagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), eventDemandeRetourEquipementCreee);
        }

        /// <summary>
        /// Méthode pour les traitements envoyés à la brique InterfaceOperateur.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        private void GererInterfaceOperateurPourResiliationInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Récupération de la CleMotifResiliationRetractation du service parametrage.
            long cleMotifResiliationRetractation = this.serviceTechnique.Parametrage.CleMotifResiliationRetractation;

            // Obtention de la demande de résiliation.
            DemandeResiliation.DemandeResiliation demandeResiliationEnCours = this.ListeDemandeResiliation.FirstOrDefault(d => d.Etat.Valeur == EtatDemandeResiliation.EnCours);
            demandeResiliationEnCours.Valider(nameof(demandeResiliationEnCours)).NonNul();
            demandeResiliationEnCours.IdentifiantTransactionOperateur.Valider(nameof(demandeResiliationEnCours.IdentifiantTransactionOperateur)).StrictementPositif();

            // Si une DemandeResiliation est en cours et que sa clé de MotifResiliation correspond à celle du service parametrage.
            if (this.DemandeResiliationEnCours && cleMotifResiliationRetractation == demandeResiliationEnCours.CleMotifResiliation)
            {
                // On créé une demande de rétractation.
                this.briquesExternes.InterfaceOperateurServiceExterne.CreerDemandeRetractation(
                    identite, demandeResiliationEnCours.IdentifiantTransactionOperateur, this.NumeroContratOperateur);
            }
            else
            {
                // On créé une demande de résiliation.
                this.briquesExternes.InterfaceOperateurServiceExterne.CreerDemandeResiliation(
                    identite, demandeResiliationEnCours.IdentifiantTransactionOperateur, this.NumeroContratOperateur);
            }
        }

        /// <summary>
        /// Méthode pour le traitement envoyé à la brique option.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        private void GererOptionsPourResiliationInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            this.briquesExternes.OptionsServiceExterne.ResilierGestionnaireOptions(identite, this.CleGestionnaireOptions);
        }

        /// <summary>
        /// Méthode pour les traitements envoyés à la brique Valorisation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        private void GererValorisationPourResiliationInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            DemandeResiliation.DemandeResiliation demandeResiliationEnCours = this.ListeDemandeResiliation.FirstOrDefault(d => d.Etat.Valeur == EtatDemandeResiliation.EnCours);
            demandeResiliationEnCours.Valider(nameof(demandeResiliationEnCours)).NonNul();

            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(demandeResiliationEnCours.CleMotifResiliation);
            motifResiliation.Valider(nameof(motifResiliation)).NonNul();

            bool estFraisResiliationAppliquee = (motifResiliation.TypeResiliation == TypeResiliation.AvecFrais);

            decimal montantHtFraisResiliation = 0;
            decimal tvaFraisResiliation = 0;

            if (estFraisResiliationAppliquee)
            {
                montantHtFraisResiliation = this.serviceTechnique.Parametrage.MontantHtFraisResiliation;
                tvaFraisResiliation = this.serviceTechnique.Parametrage.TvaFraisResiliation;
            }

            this.briquesExternes.ValorisationServiceExterne.ResilierLigne(identite,
                this.ReferenceExterne,
                demandeResiliationEnCours.DateResiliationProgrammee.Value,
                estFraisResiliationAppliquee,
                montantHtFraisResiliation,
                tvaFraisResiliation);
        }

        #endregion Méthodes privées

        #endregion Méthodes internes
    }
}