﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une ligne fixe.
    /// </summary>
    public partial class Ligne : Entity
    {
        /// <summary>
        /// Représente l'état d'une ligne fixe.
        /// </summary>
        public abstract class AbstractEtat : Etat<Ligne, EtatLigne>
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la ligne peut être résiliée.
            /// </summary>
            public virtual bool EstResiliable
            {
                get
                {
                    return false;
                }
            }

            /// <summary>
            /// Motif de résiliation.
            /// </summary>
            public virtual string MotifResiliation
            {
                get
                {
                    return string.Empty;
                }
            }


            /// <summary>
            /// Liste des motifs de suspension.
            /// </summary>
            public virtual List<string> ListeMotifsSuspension(Identite identite)
            {
                return new List<string>();
            }

            #endregion Propriétés dynamiques

            #region Constructeur

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
            /// <param name="entite">Objet métier ciblé par la machine état.</param>
            /// <param name="ancienEtat">Etat de l'objet métier avant que l'appel à ce constructeur soit fait.</param>
            public AbstractEtat(Identite identite, Ligne entite, EtatLigne ancienEtat) : base(entite)
            {
                //Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();
                entite.Valider(nameof(entite)).NonNul();

                this.Entite.SuiviDateModification = DateTime.Now;
                this.Entite.SuiviAgentModification = identite.Memoid;

                long cle = this.Entite.GenerateurCles.ObtenirCle<HistoriqueEtatLigne>();

                this.Entite.ListeHistoriqueEtats.Add(new HistoriqueEtatLigne(identite, cle, ancienEtat, this.Valeur));
            }

            #endregion Constructeurs

            #region Méthodes

            /// <summary>
            /// Mise à jour de statut de surconsommation de la ligne fixe.
            /// </summary>
            /// <param name="identite">Informations d'identité de l'appelant.</param>
            /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne.</param>
            public virtual void ModifierStatutSurconsommation(Identite identite, ProfilSurconsommation statutSurconsommation)
            {
                throw new InvalidOperationException(
                    $"Impossible de modifier le statut de surconsommation de la ligne '{this.Entite.IdentifiantTransactionOperateur}' dans l'état '{this.Valeur}'.");
            }

            /// <summary>
            /// Mise à jour du statut de surconsommation de la ligne fixe.
            /// </summary>
            /// <param name="identite">Informations d'identité de l'appelant.</param>
            /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne.</param>
            protected virtual void ModifierStatutSurconsommationInterne(Identite identite, ProfilSurconsommation statutSurconsommation)
            {
                // Vérification des paramètres entrants.
                identite.Valider(nameof(identite)).NonNul();
                statutSurconsommation.Valider<Enum>(nameof(statutSurconsommation)).NonAttribuee();

                // Assignations des valeurs.
                this.Entite.StatutSurconsommation = statutSurconsommation;
                this.Entite.SuiviDateModification = DateTime.Now;
                this.Entite.SuiviAgentModification = identite.Memoid;
            }

            /// <summary>
            /// Indique si la ligne peut être résiliée selon l'existence d'une demande de résiliation en cours.
            /// </summary>
            /// <returns>Selon s'il y a une demande de résiliation en cours.</returns>
            protected bool EstResiliableInterne()
            {
                return !this.Entite.DemandeResiliationEnCours;
            }

            /// <summary>
            /// Résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void Resilier(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible de résilier la ligne {this.Entite.Numero} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Permet de créer une demande de résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="informationsDemandeResiliation">Informations pour la création de la demande de résiliation.</param>
            public virtual void CreerDemandeResiliation(Identite identite, DemandeResiliationPourCreation informationsDemandeResiliation)
            {
                throw new InvalidOperationException
                    ($"Impossible de creer une demande de résiliation de la ligne {this.Entite.Numero} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Permet de remettre en service la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void RemettreEnService(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible de remettre en service la ligne {this.Entite.Numero} à l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Permet de suspendre la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void Suspendre(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible de suspendre la ligne {this.Entite.Numero} à l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            #endregion Méthodes
        }
    }
}