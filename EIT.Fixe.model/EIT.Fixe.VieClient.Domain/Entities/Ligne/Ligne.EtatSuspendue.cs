﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Entities.Ligne
{
    /// <summary>
    /// Classe métier d'une Ligne fixe.
    /// </summary>
    public partial class Ligne : Entity
    {
        /// <summary>
        /// Représente l'état 'Suspendue' d'une ligne fixe.
        /// </summary>
        public sealed class EtatSuspendue : AbstractEtat
        {
            #region Constructeurs

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identite de la personne qui fait l'action.</param>
            /// <param name="ligne">La ligne.</param>
            /// <param name="ancienEtat">L'ancien etat.</param>
            public EtatSuspendue(Identite identite, Ligne ligne, EtatLigne ancienEtat) 
                : base(identite, ligne, ancienEtat)
            {
            }

            #endregion Constructeurs

            #region Etat<Ligne, EtatLigne>

            /// <summary>
            /// Valeur de l'etat.
            /// </summary>
            public override EtatLigne Valeur
            {
                get
                {
                    return EtatLigne.Suspendue;
                }
            }

            #endregion Etat<Ligne, EtatLigne>

            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la ligne peut être résiliée.
            /// </summary>
            public override bool EstResiliable
            {
                get
                {
                    return EstResiliableInterne();
                }
            }

            /// <summary>
            /// Liste des motifs de suspension.
            /// </summary>
            public override List<string> ListeMotifsSuspension(Identite identite)
            {
                return this.Entite.servicesExternes.FacturationServiceExterne.ObtenirListeMotifsSuspensionParReferenceExterne(identite, this.Entite.ReferenceExterne);
            }

            #endregion Propriétés dynamiques

            #region Méthodes

            /// <summary>
            /// Mise à jour du statut de surconsommation de la ligne.
            /// </summary>
            /// <param name="identite">Informations d'identité de l'appelant.</param>
            /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne.</param>
            public override void ModifierStatutSurconsommation(Identite identite, ProfilSurconsommation statutSurconsommation)
            {
                this.ModifierStatutSurconsommationInterne(identite, statutSurconsommation);
            }

            /// <summary>
            /// Permet de créer une demande de résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
            /// <param name="informationsDemandeResiliation">Informations pour la création de la demande de résiliation.</param>
            public override void CreerDemandeResiliation(Identite identite, DemandeResiliationPourCreation informationsDemandeResiliation)
            {
                this.Entite.CreerDemandeResiliationInterne(identite, informationsDemandeResiliation);
            }

            /// <summary>
            /// Méthode qui permet de résilier la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void Resilier(Identite identite)
            {
                this.Entite.ResilierInterne(identite);
            }

            /// <summary>
            /// Méthode qui permet de remettre en service la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void RemettreEnService(Identite identite)
            {
                // Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();

                int identifiantTransactionOperateur = this.Entite.IdentifiantTransactionOperateur;
                string numeroContratOperateur = this.Entite.NumeroContratOperateur;

                this.Entite.briquesExternes.InterfaceOperateurServiceExterne.CreerDemandeRemiseEnService(
                    identite, 
                    identifiantTransactionOperateur,
                    numeroContratOperateur);

                this.Entite.RemettreEnServiceInterne(identite);
            }

            #endregion Méthodes
        }
    }
}