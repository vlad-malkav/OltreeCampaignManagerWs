﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using EIT.Fixe.Systeme.Entites;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe du gestionnaire de demande de remise.
    /// </summary>
    [AccesConcurrent]
    [CustomTableName("T_GESDMDREM")]
    public class GestionnaireDemandeRemises : Entity
    {
        #region Champs

        /// <summary>
        /// Services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface qui regroupe les répositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface des briques services externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesServicesExternes;

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        #endregion Champs

        #region Membres

        /// <summary>
        /// Clé unique du gestionnaire de demande de remise.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; protected set; }

        /// <summary>
        /// Référence externe de la ligne.
        /// </summary>
        [CustomColumnName("REFERENCEEXTERNE")]
        public virtual string RefExterne { get; protected set; }

        /// <summary>
        /// Date de creation.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; protected set; }

        /// <summary>
        /// Agent de creation.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; protected set; }

        /// <summary>
        /// Liste des demandes de remises associées à la ligne par l'intermédiare du gestionnaire
        /// de demandes de remises.
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLEGESTIONNAIRE")]
        public virtual ICollection<AbstractDemandeRemise> ListeDemandesRemises { get; protected set; }

        /// <summary>
        /// Référentiel service externe.
        /// </summary>
        public IReferentielServiceExterne ReferentielServiceExterne
        {
            get
            {
                return this.servicesExternes.ReferentielServiceExterne;
            }
        }
        /// <summary>
        /// Historique service externe.
        /// </summary>
        public IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get
            {
                return this.servicesExternes.HistoriqueServiceExterne;
            }
        }
        /// <summary>
        /// Répository de la ligne.
        /// </summary>
        public ILigneRepository LigneRepository
        {
            get
            {
                return this.repositories.LigneRepository;
            }
        }
        /// <summary>
        /// Interface de valorisation service externe.
        /// </summary>
        public IValorisationServiceExterne ValorisationServiceExterne
        {
            get
            {
                return this.briquesServicesExternes.ValorisationServiceExterne;
            }
        }

        /// <summary>
        /// Référentiel service externe.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get
            {
                return this.serviceTechnique.GenerateurCles;
            }
        }

        #endregion Membres

        #region Constructeurs

        /// <summary>
        /// Constructeur protégé.
        /// </summary>
        protected GestionnaireDemandeRemises()
        {

        }

        /// <summary>
        /// Constructeur spécifique.
        /// </summary>
        /// <param name="identite">Indentification d'identification de l'appelant.</param>
        /// <param name="cle">Clé unique du gestionnaire de demande de remise.</param>
        /// <param name="refExterne">Référence externe de la ligne.</param>
        /// <param name="listeDemandePourCreation">Liste des informations.</param>
        /// <param name="cleLigne">Clé unique de la ligne.</param>
        /// <param name="cleOffre">Clé unique de l'offre.</param>
        /// <param name="servicesExternes">Service externe.</param>
        /// <param name="repositories">Interfaces qui regroupe les répositories.</param>
        /// <param name="briquesServicesExternes">Interface qui regroupe les briques services externes.</param>
        public GestionnaireDemandeRemises(Identite identite, long cle, string refExterne, IList<DemandeRemisePourCreation> listeDemandePourCreation,
            long cleLigne, int cleOffre, IServicesExternes servicesExternes, IRepositories repositories,
            IBriquesServicesExternes briquesServicesExternes, IServicesTechniques serviceTechnique)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            refExterne.Valider(nameof(refExterne)).Obligatoire();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();
            briquesServicesExternes.Valider(nameof(briquesServicesExternes)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            // Affectation des valeurs entrées en paramètre.
            this.Cle = cle;
            this.RefExterne = refExterne;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviDateCreation = DateTime.Now;

            this.servicesExternes = servicesExternes;
            this.repositories = repositories;
            this.briquesServicesExternes = briquesServicesExternes;
            this.serviceTechnique = serviceTechnique;

            this.ListeDemandesRemises = new List<AbstractDemandeRemise>();

            if (listeDemandePourCreation != null)
            {
                foreach (var item in listeDemandePourCreation)
                {
                    this.AjouterDemandeRemise(identite, item, false, cleLigne, cleOffre);
                }
            }

        }
        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Crée une nouvelle demande de remise et l'ajoute dans la collection de demandes de remises du gestionnaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="demandeRemisePourCreation">Informations de la demande de remise a créer.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place "sur le parc" ou non.</param>
        /// <param name="cleLigne">Clé unique de la ligne.</param>
        /// <param name="cleOffre">Clé unique de l'offre.</param>
        private void AjouterDemandeRemise(Identite identite, DemandeRemisePourCreation demandeRemisePourCreation, bool estSurParc, long cleLigne, int cleOffre)
        {
            demandeRemisePourCreation.Valider(nameof(demandeRemisePourCreation)).NonNul();
            demandeRemisePourCreation.TypeDemandeRemise.Valider<Enum>(nameof(demandeRemisePourCreation.TypeDemandeRemise)).NonAttribuee();

            long cle = this.GenerateurCles.ObtenirCleLongue<AbstractDemandeRemise>();

            string descriptif = string.Empty;
            AbstractDemandeRemise demande = null;
            switch (demandeRemisePourCreation.TypeDemandeRemise)
            {
                case TypeDemandeRemise.RemiseSurForfait:
                    demande = new DemandeRemiseForfait(identite, cle, demandeRemisePourCreation.DetailRemiseForfaitPourCreation,
                        estSurParc, this.serviceTechnique);

                    // Récupération du libellé de l'offre
                    OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, cleOffre);
                    offre.Valider(nameof(offre)).NonNul();
                    descriptif = offre.LibelleRemiseAuto;
                    break;

                case TypeDemandeRemise.RemisePromotionSurOffre:
                    demande = new DemandeRemisePromotionSurOffre(identite, cle, demandeRemisePourCreation.PromotionPourDetail,
                        estSurParc, this.serviceTechnique, this.servicesExternes);

                    // Récupération du libellé de la promo
                    descriptif = demandeRemisePourCreation.PromotionPourDetail.Descriptif;
                    break;

                case TypeDemandeRemise.RemisePromotionSurFrais:
                    demande = new DemandeRemisePromotionSurFrais(identite, cle, demandeRemisePourCreation.PromotionPourDetail,
                        estSurParc, this.serviceTechnique, this.servicesExternes);

                    // Récupération du libellé de la promo
                    descriptif = demandeRemisePourCreation.PromotionPourDetail.Descriptif;
                    break;
            }
            this.ListeDemandesRemises.Add(demande);

            HistoriquePourCreation informationsHistorique = new HistoriquePourCreation()
            {
                CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                CleMetier2 = TypeHistoriqueMetierNiveau2.RemisesEtAvantages,
                Commentaire = $"Application : '{descriptif}'",
                CleOrigine = null,
                ReferenceExterne = this.RefExterne
            };

            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite, cleLigne, informationsHistorique);
        }

        /// <summary>
        /// Met en place une nouvelle demande de remise de type promotion au statut "activee" sur la ligne associée au gestionnaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="demandeRemisePourCreation">Informations de la demande de remise a créer.</param>
        /// <param name="cleLigne">Clé unique de la ligne.</param>
        /// <param name="cleOffre">Clé unique de l'offre.</param>
        public virtual void CreerEtActiverDemandeRemisePromotion(Identite identite, DemandeRemisePourCreation demandeRemisePourCreation, long cleLigne, int cleOffre)
        {
            this.AjouterDemandeRemise(identite, demandeRemisePourCreation, true, cleLigne, cleOffre);
            this.AppliquerModificationsEnValorisation(identite);
        }

        /// <summary>
        /// Résilie une demande de remise associée au gestionnaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleDemandeRemise">Identifiant de la demande de remise.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        public virtual void ResilierDemandeRemiseParCle(Identite identite, long cleDemandeRemise, long cleLigne, int cleOffre)
        {
            //Validations des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeRemise.Valider(nameof(cleDemandeRemise)).StrictementPositif();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

            AbstractDemandeRemise demandeRemise = this.ListeDemandesRemises.FirstOrDefault(x => x.Cle == cleDemandeRemise);
            demandeRemise.Valider(nameof(demandeRemise)).NonNul();

            demandeRemise.Resilier(identite, cleOffre);

            this.AppliquerModificationsEnValorisation(identite);

            PromotionPourDetail promo = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionParCle(identite, demandeRemise.ClePromotion(), cleOffre);
            promo.Valider(nameof(promo)).NonNul();

            HistoriquePourCreation informationsHistorique = new HistoriquePourCreation()
            {
                CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                CleMetier2 = TypeHistoriqueMetierNiveau2.RemisesEtAvantages,
                Commentaire = $"Suppression: '{promo.Descriptif}'",
                CleOrigine = null,
                ReferenceExterne = this.RefExterne
            };


            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite, cleLigne, informationsHistorique);

        }

        /// <summary>
        /// Expire une demande de remise associée au gestionnaire.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleDemandeRemise">Identifiant de la demande de remise.</param>
        public virtual void ExpirerDemandeRemiseParCle(Identite identite, long cleDemandeRemise)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeRemise.Valider(nameof(cleDemandeRemise)).StrictementPositif();

            AbstractDemandeRemise demandeRemise = this.ListeDemandesRemises.FirstOrDefault(demande => demande.Cle == cleDemandeRemise);
            demandeRemise.Valider(nameof(demandeRemise)).NonNul();

            demandeRemise.Expirer(identite);
        }

        /// <summary>
        /// Retourne la liste des promotions actives sur la ligne.
        /// </summary>
        /// <returns>La liste des promotions actives sur la ligne.</returns>
        public virtual IList<DemandeRemisePromotion> ListerPromotionsActives()
        {
            List<AbstractDemandeRemise> liste = this.ListeDemandesRemises.Where(l => l.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurOffre && l.EstActive()).ToList();
            List<DemandeRemisePromotion> listeARetourner = new List<DemandeRemisePromotion>();
            foreach (var demande in liste)
            {
                if (demande is DemandeRemisePromotion)
                {
                    listeARetourner.Add((DemandeRemisePromotion)demande);
                }
            }
            return listeARetourner;
        }

        /// <summary>
        /// Retourne la liste des promotions a expirer sur la ligne.
        /// </summary>
        /// <returns>La liste des promotions a expirer sur la ligne.</returns>
        public virtual IList<AbstractDemandeRemise> ListerPromotionsAExpirer()
        {
            DateTime demain = DateTime.Now.AddDays(1);
            IList<AbstractDemandeRemise> listePromotionsAExpirer = new List<AbstractDemandeRemise>();

            foreach (var demande in this.ListeDemandesRemises)
            {
                if (demande.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurOffre
                    && demande.ValeurEtat == EtatDemandeRemise.Activee
                    && demande.DateFin != null
                    && demain.Date >= demande.DateFin.GetValueOrDefault().Date)
                {
                    listePromotionsAExpirer.Add(demande);
                }
            }

            return listePromotionsAExpirer;
        }

        /// <summary>
        /// Retourne la liste des promotions actives sur la ligne mais obsolete.
        /// </summary>
        /// <returns>La liste des promotions actives sur la ligne mais obsolete.</returns>
        public virtual IList<DemandeRemisePromotion> ListerPromotionsObsoletes()
        {
            List<AbstractDemandeRemise> liste = this.ListeDemandesRemises
                .Where(l => (l.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurFrais || l.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurOffre) && l.EstObsolete()).ToList();
            List<DemandeRemisePromotion> listeARetourner = new List<DemandeRemisePromotion>();
            foreach (var demande in liste)
            {
                if (demande is DemandeRemisePromotion)
                {
                    listeARetourner.Add((DemandeRemisePromotion)demande);
                }
            }
            return listeARetourner;
        }

        /// <summary>
        /// Met à jour toutes les remises en place sur la ligne via la brique valorisation.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        public virtual void AppliquerModificationsEnValorisation(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            List<RemisePourValorisation> listRemisePourValorisation = new List<RemisePourValorisation>();

            Ligne.Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(this.RefExterne);

            foreach (var demandeRemise in this.ListeDemandesRemises)
            {
                if (demandeRemise.TypeDemandeRemise == TypeDemandeRemise.RemiseSurForfait)
                {
                    OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);
                    offre.Valider(nameof(offre)).NonNul();

                    listRemisePourValorisation.Add(new RemisePourValorisation()
                    {
                        ReferenceRemise = offre.LibelleRemiseAuto,
                        MontantHT = demandeRemise.MontantHT,
                        Pourcentage = 0,
                        TypeValeur = TypeValeurRemise.EnMontant,
                        DateDebut = demandeRemise.SuiviDateCreation,
                        DateFin = demandeRemise.DateFin ?? DateTime.MaxValue
                    });
                }
                else if (demandeRemise.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurOffre &&
                         demandeRemise.Etat.Valeur == EtatDemandeRemise.Activee)
                {
                    PromotionPourDetail promo = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionParCle(identite, demandeRemise.ClePromotion(), ligne.CleOffre);
                    promo.Valider(nameof(promo)).NonNul();

                    listRemisePourValorisation.Add(new RemisePourValorisation()
                    {
                        ReferenceRemise = promo.CodePromo,
                        MontantHT = demandeRemise.MontantHT,
                        Pourcentage = 0,
                        TypeValeur = TypeValeurRemise.EnMontant,
                        DateDebut = demandeRemise.SuiviDateCreation,
                        DateFin = demandeRemise.DateFin ?? DateTime.MaxValue
                    });
                }
            }

            // Appel de la méthode ChangerRemises du service externe Valorisation.
            this.briquesServicesExternes.ValorisationServiceExterne.ChangerRemise(identite, this.RefExterne, listRemisePourValorisation);
        }
    }

    #endregion Méthodes
}