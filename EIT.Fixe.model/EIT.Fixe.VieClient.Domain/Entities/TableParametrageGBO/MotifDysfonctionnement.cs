﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using System;
using System.ComponentModel.DataAnnotations;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO
{
    /// <summary>
    /// Classe métier du Motif du dysfonctionnement.
    /// </summary>
    [CustomTableName("T_GBO_FRL_N2DI_MOTIF")]
    public class MotifDysfonctionnement : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé unique du Motif du dysfonctionnement.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Libellé du Motif du dysfonctionnement.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected MotifDysfonctionnement()
        {
        }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identite de l'agent qui fait l'action.</param>
        /// <param name="cle">Clé unique du Motif de Dysfonctionnement dans le SI Vie Client.</param>
        /// <param name="libelle">Libellé du Motif de Dysfonctionnement.</param>
        public MotifDysfonctionnement(Identite identite, long cle, string libelle)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            libelle.Valider(nameof(libelle)).NonNul();

            // Assignation des valeurs.
            this.Cle = cle;
            this.Libelle = libelle;
        }

        #endregion Constructeurs
    }
}
