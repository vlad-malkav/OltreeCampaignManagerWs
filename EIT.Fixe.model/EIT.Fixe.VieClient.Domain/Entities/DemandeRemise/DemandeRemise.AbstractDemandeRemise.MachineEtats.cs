﻿using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe métier d'une AbstractDemandeRemiseAEtats.
    /// </summary>
    public partial class AbstractDemandeRemise 
    {
        /// <summary>
        /// Represente la machine à états de AbstractDemandeRemiseAEtats.
        /// </summary>
        public class AbstractDemandeRemiseMachineEtats : MachineEtats<AbstractDemandeRemise, EtatDemandeRemise, DemandeRemiseAbstractEtat>
        {
            #region Constructeurs

            /// <summary>
            /// Constructeur sans paramètre nécessaire pour l'accès aux données.
            /// </summary>
            private AbstractDemandeRemiseMachineEtats()
            {
            }

            /// <summary>
            /// Construit une machine à état pour une ligne à partir de l'état initial.
            /// </summary>
            /// <param name="etatInitial">Etat initial de la commande.</param>
            public AbstractDemandeRemiseMachineEtats(DemandeRemiseAbstractEtat etatInitial) : base(etatInitial)
            {
            }

            #endregion Constructeurs
        }
    }
}