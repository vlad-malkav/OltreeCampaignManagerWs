﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de demande de remise par promotion.
    /// </summary>
    [CustomTableName("T_DMDREMPRM")]
    public class DemandeRemisePromotion : AbstractDemandeRemise
    {
        #region Champs

        /// <summary>
        /// Interface de service externes
        /// </summary>
        private readonly IServicesExternes serviceExterne;

        #endregion Champs

        #region Membres

        /// <summary>
        /// Interface du service externe Réferentiel.
        /// </summary>
        public IReferentielServiceExterne ReferentielServiceExterne {
            get
            {
                return this.serviceExterne.ReferentielServiceExterne;
            }
        }

        #endregion Membres
        
        #region Constructeurs

        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected DemandeRemisePromotion() { }

        /// <summary>
        /// Constructeur spécifique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cle">Clé unique de la demande de remise.</param>
        /// <param name="promotion">Informations pour la création.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place sur "le parc".</param>
        /// <param name="serviceTechnique">Interface du service technique.</param>
        /// <param name="serviceExterne">Interface des services externes.</param>
        public DemandeRemisePromotion(Identite identite, long cle, PromotionPourDetail promotion, bool estSurParc, IServicesTechniques serviceTechnique, IServicesExternes serviceExterne)
            : base(identite, cle, estSurParc, serviceTechnique)
        {
            promotion.Valider(nameof(promotion)).NonNul();
            serviceExterne.Valider(nameof(serviceExterne)).NonNul();

            this.serviceExterne = serviceExterne;

            this.MontantHT = promotion.MontantHT;
            this.ClePromotionInterne = promotion.Cle;
            this.DureeValidite = promotion.Duree;
            this.DateFin = promotion.Duree != null ? (DateTime?)DateTime.Now.AddMonths(promotion.Duree.Value) : null;
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Clé unique de la promotion.
        /// </summary>
        public override int ClePromotion()
        {
            return this.ClePromotionInterne.GetValueOrDefault();
        }

        /// <summary>
        /// Indique si la demande de remise est automatique ou non.
        /// </summary>
        /// <param name="identite">Informations d'identifiaction de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Indique si la demande de remise est automatique ou non.</returns>
        public override bool? EstAutomatique(Identite identite, int cleOffre)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

            PromotionPourDetail promotion = this.ReferentielServiceExterne.ObtenirPromotionParCle(identite, this.ClePromotion(), cleOffre);
            promotion.Valider(nameof(promotion)).NonNul();

            return promotion.EstAutomatique;
        }

        #endregion Méthodes
    }
}