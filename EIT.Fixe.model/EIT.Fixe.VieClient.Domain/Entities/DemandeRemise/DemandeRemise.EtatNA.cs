﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe métier d'une AbstractDemandeRemiseAEtats.
    /// </summary>
    public partial class AbstractDemandeRemise
    {
        /// <summary>
        /// Représente l'état NA d'une demande de remise.
        /// </summary>
        public class DemandeRemiseEtatNa : DemandeRemiseAbstractEtat
        {
            #region DemandeRemiseAbstractEtat

            /// <summary>
            /// Valeur de l'état.
            /// </summary>
            public override EtatDemandeRemise Valeur
            {
                get
                {
                    return EtatDemandeRemise.NA;
                }
            }

            #endregion DemandeRemiseAbstractEtat

            #region Constructeur

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="entite">Entité de la demande de remise.</param>
            public DemandeRemiseEtatNa(Identite identite, AbstractDemandeRemise entite) : base(identite, entite)
            {
            }

            #endregion Constructeur
        }
    }
}