﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe métier d'une AbstractDemandeRemiseAEtats.
    /// </summary>
    public partial class AbstractDemandeRemise
    {
        /// <summary>
        /// Représente l'état Resiliée d'une demande de remise.
        /// </summary>
        public class DemandeRemiseEtatResiliee : DemandeRemiseAbstractEtat
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Valeur de l'état.
            /// </summary>
            public override EtatDemandeRemise Valeur
            {
                get
                {
                    return EtatDemandeRemise.Resiliee;
                }
            }

            /// <summary>
            /// Indique si la demande de remise est activée ou non.
            /// </summary>
            public override bool EstActive
            {
                get
                {
                    return false;
                }
            }

            /// <summary>
            /// Indique si la demande de remise est obsolète ou non.
            /// </summary>
            public override bool EstObsolete
            {
                get
                {
                    return true;
                }
            }

            #endregion Propriétés dynamiques

            #region Constructeur

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="entite">Entité de la demande de remise.</param>
            public DemandeRemiseEtatResiliee(Identite identite, AbstractDemandeRemise entite) : base(identite, entite)
            {
            }

            #endregion Constructeur
        }
    }
}