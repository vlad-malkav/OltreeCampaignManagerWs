﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de demande de remise par promotion sur frais.
    /// </summary>
    [CustomTableName("T_DMDREMPRMFRA")]
    public class DemandeRemisePromotionSurFrais : DemandeRemisePromotion
    {
        #region Constructeurs
        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected DemandeRemisePromotionSurFrais() { }

        /// <summary>
        /// Constructeur spécifique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cle">Clé unique de la demande de remise.</param>
        /// <param name="promotion">Informations pour la création.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place sur "le parc".</param>
        /// <param name="serviceTechnique">Interface du service technique.</param>
        /// <param name="serviceExterne">Interface du service regroupant les services externes.</param>
        public DemandeRemisePromotionSurFrais(Identite identite, long cle, PromotionPourDetail promotion, bool estSurParc, IServicesTechniques serviceTechnique, IServicesExternes serviceExterne)
            : base(identite, cle, promotion, estSurParc, serviceTechnique, serviceExterne)
        {
            this.TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurFrais;
            this.Etat = new AbstractDemandeRemiseMachineEtats(new DemandeRemiseEtatExpiree(identite, this));
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Indique si la promotion peut être résiliée ou non.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        public override bool EstResiliable(Identite identite, int cleOffre)
        {
            return false;
        }

        #endregion Méthodes
    }
}