﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EIT.Fixe.Systeme.Entites;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe abstraite d'une demande de remise.
    /// </summary>
    [AccesConcurrent]
    [CustomTableName("T_DMDREM")]
    public abstract partial class AbstractDemandeRemise : Entity
    {
        #region Champs

        /// <summary>
        /// Interface du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        #endregion Champs

        #region Membres

        /// <summary>
        /// Etat courant de la ligne fixe.
        /// </summary>
        protected virtual DemandeRemiseAbstractEtat EtatCourant
        {
            get { return this.Etat.Obtenir(this); }
            set { this.Etat.Definir(value); }
        }
        
        /// <summary>
        /// Clé unique de la demande de remise.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; protected set; }

        /// <summary>
        /// Type de demande remise.
        /// </summary>
        [CustomColumnName("TYPE")]
        public virtual TypeDemandeRemise TypeDemandeRemise { get; protected set; }

        /// <summary>
        /// Cle unique de la promotions issue du referentiel.
        /// </summary>
        [CustomColumnName("CLEPROMOTION")]
        public virtual int? ClePromotionInterne { get; protected set; }

        /// <summary>
        /// Duree de validite exprimee en mois.
        /// Si null alors la promotions est illimitee.
        /// </summary>
        [CustomColumnName("DUREEVALIDITE")]
        public virtual int? DureeValidite { get; protected set; }

        /// <summary>
        /// Montant HT.
        /// </summary>
        [CustomColumnName("MONTANTHT")]
        public virtual decimal MontantHT { get; protected set; }

        /// <summary>
        /// Date de fin de la demande de remise.
        /// </summary>
        [CustomColumnName("DATEFIN")]
        public virtual DateTime? DateFin { get; protected set; }

        /// <summary>
        /// Indique si la demande de remise est mise en place "sur le parc" ou non.
        /// </summary>
        [CustomColumnName("ESTSURPARC")]
        public virtual bool EstSurParc { get; protected set; }

        /// <summary>
        /// Date de creation.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; protected set; }

        /// <summary>
        /// Agent de creation.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; protected set; }

        /// <summary>
        /// Date de derniere modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModifition { get; protected set; }

        /// <summary>
        /// Agent ayant effectue la derniere modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; protected set; }
        
        /// <summary>
        /// Etat de la demande de remise.
        /// </summary>
        [CustomColumnName("ETAT")]
        public virtual AbstractDemandeRemiseMachineEtats Etat { get; protected set; }

        /// <summary>
        /// Valeur de l'état
        /// </summary>
        [NotMapped]
        public virtual EtatDemandeRemise ValeurEtat
        {
            get
            {
                return this.Etat.Valeur;
            }
        }

        /// <summary>
        /// Historique des états de la demande de remise
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLEDEMANDEREMISE")]
        public virtual ICollection<HistoriqueEtatDemandeRemise> ListeHistoriquesEtats { get; protected set; }

        /// <summary>
        /// Générateur de clés techniques.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get
            {
                return this.serviceTechnique.GenerateurCles;
            }
        }
        #endregion Membres
        
        #region Constructeurs

        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected AbstractDemandeRemise()
        {

        }

        /// <summary>
        /// Constructeur specifique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cle">Cle unique de la demande de remise.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place sur "le parc".</param>
        /// <param name="serviceTechnique">Interface du service technique.</param>
        protected AbstractDemandeRemise(Identite identite, long cle, bool estSurParc, IServicesTechniques serviceTechnique)
        {
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            this.serviceTechnique = serviceTechnique;

            this.ListeHistoriquesEtats = new List<HistoriqueEtatDemandeRemise>();

            this.Cle = cle;
            this.EstSurParc = estSurParc;
            this.SuiviDateCreation = DateTime.Now;
            this.SuiviDateModifition = DateTime.Now;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviAgentModification = identite.Memoid;
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Cle unique de la promotion.
        /// </summary>
        public virtual int ClePromotion()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Indique si la demande de remise est activée ou non.
        /// </summary>
        public virtual bool EstActive()
        {
            return this.EtatCourant.EstActive;
        }

        /// <summary>
        /// Indique si la demande de remise est obsolete ou non.
        /// </summary>
        public bool EstObsolete()
        {
            return this.EtatCourant.EstObsolete;
        }

        /// <summary>
        /// Indique si la demande de remise est automatique ou non.
        /// </summary>
        /// <param name="identite">Informations d'identifiaction de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Indique si la demande de remise est automatique ou non.</returns>
        public virtual bool? EstAutomatique(Identite identite, int cleOffre)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Indique si la promotion peut être résiliée ou non.
        /// </summary>
        /// <param name="identite">Informations d'identifiaction de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Indique si la demande de remise peut êtr résiliée ou non.</returns>
        public virtual bool EstResiliable(Identite identite, int cleOffre)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Expiration de la demande de remise.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        public void Expirer(Identite identite)
        {
            this.EtatCourant.Expirer(identite);
        }

        /// <summary>
        /// Resiliation de la demande de remise.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        public void Resilier(Identite identite, int cleOffre)
        {
            this.EtatCourant.Resilier(identite, cleOffre);
        }

        #endregion Méthodes
    }
}