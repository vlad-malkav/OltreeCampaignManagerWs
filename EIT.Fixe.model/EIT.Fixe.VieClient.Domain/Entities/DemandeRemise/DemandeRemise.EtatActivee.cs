﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe métier d'une AbstractDemandeRemiseAEtats.
    /// </summary>
    public partial class AbstractDemandeRemise
    {
        /// <summary>
        /// Représente l'état Activee d'une demande de remise.
        /// </summary>
        public class DemandeRemiseEtatActivee : DemandeRemiseAbstractEtat
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la demande de remise est activée ou non.
            /// </summary>
            public override bool EstActive
            {
                get
                {
                    return true;
                }
            }

            /// <summary>
            /// Indique si la demande de remise est obsolète ou non.
            /// </summary>
            public override bool EstObsolete
            {
                get
                {
                    return false;
                }
            }

            #region DemandeRemiseAbstractEtat

            /// <summary>
            /// Valeur de l'état.
            /// </summary>
            public override EtatDemandeRemise Valeur
            {
                get
                {
                    return EtatDemandeRemise.Activee;
                }
            }

            #endregion DemandeRemiseAbstractEtat

            #endregion Propriétés dynamiques

            #region Constructeur

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="entite">Entité de la demande de remise.</param>
            public DemandeRemiseEtatActivee(Identite identite, AbstractDemandeRemise entite) : base(identite, entite)
            {
            }

            #endregion Constructeur

            #region Méthodes

            /// <summary>
            /// Résiliation de la demande de remise.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="cleOffre">Clé de l'offre.</param>
            public override void Resilier(Identite identite, int cleOffre)
            {
                identite.Valider(nameof(identite)).NonNul();
                cleOffre.Valider(nameof(cleOffre)).StrictementPositif();

                bool? estAutomatique = this.Entite.EstAutomatique(identite, cleOffre);
                if (estAutomatique.HasValue && estAutomatique.Value)
                {
                    throw new InvalidOperationException(
                        $"Impossible de modifier le statut de la demande de remise '{this.Entite.Cle}' dans l'état '{this.Valeur}' vers l'état 'Résiliée' car c'est une promotion automatique."
                    );
                }

                this.Entite.DateFin = DateTime.Now;
                this.Entite.EtatCourant = new DemandeRemiseEtatResiliee(identite, this.Entite);
            }

            /// <summary>
            /// Expiration de la demande de remise.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            public override void Expirer(Identite identite)
            {
                this.Entite.DateFin = DateTime.Now;
                this.Entite.EtatCourant = new DemandeRemiseEtatExpiree(identite, this.Entite);
            }

            #endregion Méthodes
        }
    }
}