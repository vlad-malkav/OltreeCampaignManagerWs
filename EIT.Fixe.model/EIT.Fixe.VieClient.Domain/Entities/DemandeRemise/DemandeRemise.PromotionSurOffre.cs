﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de demande de remise par promotion sur offre.
    /// </summary>
    [CustomTableName("T_DMDREMPRMOFF")]
    public class DemandeRemisePromotionSurOffre : DemandeRemisePromotion
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected DemandeRemisePromotionSurOffre()
        { }

        /// <summary>
        /// Constructeur spécifique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cle">Clé unique de la demande de remise.</param>
        /// <param name="promotion">Informations pour la creation.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place sur "le parc".</param>
        /// <param name="serviceTechnique">Interface du service technique.</param>
        public DemandeRemisePromotionSurOffre(Identite identite, long cle, PromotionPourDetail promotion, bool estSurParc, IServicesTechniques serviceTechnique, IServicesExternes serviceExterne)
            : base(identite, cle, promotion, estSurParc, serviceTechnique, serviceExterne)
        {
            this.TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurOffre;
            this.Etat = new AbstractDemandeRemiseMachineEtats(new DemandeRemiseEtatActivee(identite, this));
        }

        #endregion Constructeurs

        #region Méthodes
        
        /// <summary>
        /// Indique si la promotion peut être résiliée ou non.
        /// </summary>
        /// <param name="identite">Informations d'identifiaction de l'appelant.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Indique si la demande de remise peut êtr résiliée ou non.</returns>
        public override bool EstResiliable(Identite identite, int cleOffre)
        {
            return !this.EstAutomatique(identite, cleOffre).GetValueOrDefault();
        }

        #endregion Méthodes
    }
}