﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe métier d'une AbstractDemandeRemiseAEtats.
    /// </summary>
    public partial class AbstractDemandeRemise
    {
        /// <summary>
        /// Représente l'état d'une AbstractDemandeRemiseAEtats.
        /// </summary>
        public abstract class DemandeRemiseAbstractEtat : Etat<AbstractDemandeRemise, EtatDemandeRemise>
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la demande de remise est active ou non.
            /// </summary>
            public virtual bool EstActive
            {
                get
                {
                    return false;
                }
            }

            /// <summary>
            /// Indique si la demande de remise est obsolete ou non.
            /// </summary>
            public virtual bool EstObsolete
            {
                get
                {
                    return false;
                }
            }

            #endregion Propriétés dynamiques

            #region Constructeurs

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
            /// <param name="entite">Objet métier ciblé par la machine état.</param>
            public DemandeRemiseAbstractEtat(Identite identite, AbstractDemandeRemise entite) : base(entite)
            {
                identite.Valider(nameof(identite)).NonNul();
                
                if (this.Valeur != EtatDemandeRemise.NA)
                {
                    this.Entite.SuiviDateModifition = DateTime.Now;
                    this.Entite.SuiviAgentModification = identite.Memoid;

                    long cle = this.Entite.GenerateurCles.ObtenirCleLongue<HistoriqueEtatDemandeRemise>();

                    this.Entite.ListeHistoriquesEtats.Add(new HistoriqueEtatDemandeRemise(identite, cle, this.Valeur));
                }
            }

            #endregion Constructeurs

            #region Méthodes

            /// <summary>
            /// Expiration de la demande de remise.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            public virtual void Expirer(Identite identite)
            {
                throw new InvalidOperationException($"Impossible d'expirer la demande de remise '{this.Entite.Cle}' dans l'état '{this.Valeur}'.");
            }

            /// <summary>
            /// Résiliation de la demande de remise.
            /// </summary>
            /// <param name="identite">Identité de l'appelant.</param>
            /// <param name="cleOffre">Clé de l'offre.</param>
            public virtual void Resilier(Identite identite, int cleOffre)
            {
                throw new InvalidOperationException($"Impossible de résilier la demande de remise '{this.Entite.Cle}' dans l'état '{this.Valeur}'.");
            }

            #endregion Méthodes
        }
    }
}
