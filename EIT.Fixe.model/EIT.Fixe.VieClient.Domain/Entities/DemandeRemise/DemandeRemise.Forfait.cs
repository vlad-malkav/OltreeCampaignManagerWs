﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de demande de remise par forfait.
    /// </summary>
    [CustomTableName("T_DMDREMFOR")]
    public class DemandeRemiseForfait : AbstractDemandeRemise
    {
        #region Constructeurs

        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected DemandeRemiseForfait()
        { }
        
        /// <summary>
        /// Constructeur spécifique.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cle">Clé unique de la demande de remise.</param>
        /// <param name="demandeRemiseForfaitPourCreation">Informations pour la création.</param>
        /// <param name="estSurParc">Indique si la demande de remise est mise en place sur "le parc".</param>
        /// <param name="serviceTechnique">Interface du service technique.</param>
        public DemandeRemiseForfait(Identite identite, long cle, DemandeRemiseForfaitPourCreation demandeRemiseForfaitPourCreation, bool estSurParc, IServicesTechniques serviceTechnique)
            : base(identite, cle, estSurParc, serviceTechnique)
        {
            demandeRemiseForfaitPourCreation.Valider(nameof(demandeRemiseForfaitPourCreation)).NonNul();

            this.TypeDemandeRemise = TypeDemandeRemise.RemiseSurForfait;
            this.MontantHT = demandeRemiseForfaitPourCreation.MontantHT;
            this.DureeValidite = null;

            this.Etat = new AbstractDemandeRemiseMachineEtats(new DemandeRemiseEtatNa(identite, this));
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Indique si la demande est activée ou non.
        /// </summary>
        public override bool EstActive()
        {
            return true;
        }

        #endregion Méthodes
    }
}
