﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier décrivant un mode de retour équipement.
    /// </summary>
    [CustomTableName("T_MODRETEQU")]
    public class ModeRetourEquipement : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire du mode de retour équipement.
        /// </summary>
        [CustomColumnName("CLE")]
        [Key]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Libellé du mode de retour équipement.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        /// <summary>
        /// Indique si le mode de retour équipement est coché par défaut.
        /// </summary>
        [CustomColumnName("ESTCOCHEPARDEFAUT")]
        public virtual bool EstCocheParDefaut { get; set; }

        /// <summary>
        /// Indique si une étiquette est prépayée.
        /// </summary>
        [CustomColumnName("ESTENVOIETIQUETTEPREPAYEE")]
        public virtual bool EstEnvoiEtiquettePrepayee { get; set; }

        /// <summary>
        /// Type de prise en charge.
        /// </summary>
        [CustomColumnName("TYPEPRISEENCHARGE")]
        public virtual TypePriseEnCharge TypePriseEnCharge { get; set; }

        /// <summary>
        /// Type de l'envoi du retour équipement.
        /// </summary>
        [CustomColumnName("TYPEENVOI")]
        public virtual TypeEnvoi TypeEnvoi { get; set; }

        /// <summary>
        /// Date de création du mode de retour équipement.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'initiative de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de dernière modification du mode de retour équipement.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        /// <summary>
        /// Agent à l'initiative de la dernière modification du mode de retour équipement.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        #endregion Attributs
    }
}