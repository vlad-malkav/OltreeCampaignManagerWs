﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des profils Ptf.
    /// </summary>
    [CustomTableName("T_PRIPTF")]
    public class ProfilPtf : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Code du profil.
        /// </summary>
        [CustomColumnName("CODE")]
        public virtual string Code { get; set; }

        /// <summary>
        /// Libellé du profil.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        /// <summary>
        /// Description du profil.
        /// </summary>
        [CustomColumnName("DESCRIPTION")]
        public virtual string Description { get; set; }

        /// <summary>
        /// Ressource SAS associée.
        /// </summary>
        [CustomColumnName("RESSOURCESAS")]
        public virtual string RessourceSas { get; set; }

        /// <summary>
        /// Indique si le profil est actif.
        /// </summary>
        [CustomColumnName("ESTACTIF")]
        public virtual bool EstActif { get; set; }

        /// <summary>
        /// Groupes de fonctionnalité associés à ce profil.
        /// </summary>
        [CustomAssociationTable("T_PRIPTF_GRPFCT", "CLEPROFILPTF", "CLEGROUPEFONCTIONNALITE")]
        public virtual ICollection<GroupeFonctionnalites> ListeGroupesFonctionnalites { get; set; }

        /// <summary>
        /// Agent à l'origine de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'origine de la modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        /// <summary>
        /// Date de modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected ProfilPtf()
        {

        }

        /// <summary>
        /// Constructeur pour l'instanciation d'un profil.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreProfilPtfPourCreation">Paramètres pour la création du profil.</param>
        /// <param name="groupes">Liste de GroupeFonctionnalites.</param>
        public ProfilPtf(Identite identite, ParametreProfilPtfPourCreation parametreProfilPtfPourCreation, List<GroupeFonctionnalites> groupes)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametreProfilPtfPourCreation.Valider(nameof(parametreProfilPtfPourCreation)).NonNul();
            parametreProfilPtfPourCreation.Code.Valider(nameof(parametreProfilPtfPourCreation.Code)).LongueurMax(40);
            parametreProfilPtfPourCreation.Libelle.Valider(nameof(parametreProfilPtfPourCreation.Libelle)).LongueurMax(40);
            parametreProfilPtfPourCreation.Description.Valider(nameof(parametreProfilPtfPourCreation.Description)).LongueurMax(100);
            parametreProfilPtfPourCreation.RessourceSas.Valider(nameof(parametreProfilPtfPourCreation.RessourceSas)).LongueurMax(40);

            // Affectation des données.
            this.Cle = parametreProfilPtfPourCreation.Cle;
            this.Code = parametreProfilPtfPourCreation.Code;
            this.Libelle = parametreProfilPtfPourCreation.Libelle;
            this.Description = parametreProfilPtfPourCreation.Description;
            this.RessourceSas = parametreProfilPtfPourCreation.RessourceSas;
            this.SuiviDateCreation = parametreProfilPtfPourCreation.SuiviDateCreation;
            this.SuiviDateModification = parametreProfilPtfPourCreation.SuiviDateCreation;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviAgentModification = identite.Memoid;
            this.EstActif = parametreProfilPtfPourCreation.EstActif;

            if (groupes != null)
            {
                this.ListeGroupesFonctionnalites = groupes;
            }
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Méthode qui permet d'ajouter un groupe de fonctionnalités au profil.
        /// </summary>
        /// <param name="groupeDeFonctionnalites">Groupe de fonctionnalités à ajouter.</param>
        public void AjouterGroupeFonctionnalites(GroupeFonctionnalites groupeDeFonctionnalites)
        {
            // Vérification des entrées.
            groupeDeFonctionnalites.Valider(nameof(groupeDeFonctionnalites)).NonNul();

            if (this.ListeGroupesFonctionnalites == null)
            {
                this.ListeGroupesFonctionnalites = new List<GroupeFonctionnalites>();
            }

            this.ListeGroupesFonctionnalites.Add(groupeDeFonctionnalites);
        }

        /// <summary>
        /// Méthode qui permet de désactiver un profil.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public void Desactiver(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.EstActif = false;
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        #endregion Méthodes
    }
}
