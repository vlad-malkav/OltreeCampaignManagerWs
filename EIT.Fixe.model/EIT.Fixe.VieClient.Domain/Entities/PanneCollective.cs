﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des pannes collectives.
    /// </summary>
    [CustomTableName("T_LIG_PNNCTV")]
    public class PanneCollective : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé unique de la panne dans le SI Vie Client.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Date de début de la panne collective.
        /// </summary>
        [CustomColumnName("DATEDEBUT")]
        public virtual DateTime DateDebut { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected PanneCollective()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identite de l'agnet qui fait l'action.</param>
        /// <param name="cle">Clé unique de la panne dans le SI Vie Client.</param>
        /// <param name="dateDebut">Date de début de la panne collective.</param>
        public PanneCollective(Identite identite, long cle, DateTime dateDebut)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            dateDebut.Valider(nameof(dateDebut)).NonNul();

            // Assignation des valeurs.
            this.Cle = cle;
            this.DateDebut = dateDebut;
        }




        #endregion Constructeurs
    }
}