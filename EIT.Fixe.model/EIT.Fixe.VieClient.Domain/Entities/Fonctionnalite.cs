﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des fonctionnalités.
    /// </summary>
    [CustomTableName("T_FCT")]
    public class Fonctionnalite : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Code de la fonctionnalité.
        /// </summary>
        [CustomColumnName("CODE")]
        public virtual string Code { get; set; }

        /// <summary>
        /// Description de la fonctionnalité.
        /// </summary>
        [CustomColumnName("DESCRIPTION")]
        public virtual string Description { get; set; }

        /// <summary>
        /// Indique si cette fonctionnalité est active.
        /// </summary>
        [CustomColumnName("ESTACTIF")]
        public virtual bool EstActif { get; set; }

        /// <summary>
        /// Agent à l'origine de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de la création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'origine de la modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        /// <summary>
        /// Date de modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected Fonctionnalite()
        {

        }

        /// <summary>
        /// Constructeur pour l'instanciation d'une fonctionnalité.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreFonctionnalitePourCreation">Paramètres pour la création d'une fonctionnalité.</param>
        public Fonctionnalite(Identite identite, ParametreFonctionnalitePourCreation parametreFonctionnalitePourCreation)
        {
            // Vérification des données.
            identite.Valider(nameof(identite)).NonNul();
            parametreFonctionnalitePourCreation.Valider(nameof(parametreFonctionnalitePourCreation)).NonNul();
            parametreFonctionnalitePourCreation.Code.Valider(nameof(parametreFonctionnalitePourCreation.Code)).LongueurMax(40);
            parametreFonctionnalitePourCreation.Description.Valider(nameof(parametreFonctionnalitePourCreation.Description)).LongueurMax(100);

            // Affectation des données.
            this.Cle = parametreFonctionnalitePourCreation.Cle;
            this.Code = parametreFonctionnalitePourCreation.Code;
            this.Description = parametreFonctionnalitePourCreation.Description;
            this.SuiviDateCreation = parametreFonctionnalitePourCreation.SuiviDateCreation;
            this.SuiviDateModification = parametreFonctionnalitePourCreation.SuiviDateCreation;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviAgentModification = identite.Memoid;
            this.EstActif = parametreFonctionnalitePourCreation.EstActif;
        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Méthode qui permet de désactiver la fonctionnalité.
        /// </summary>
        public void Desactiver(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.EstActif = false;
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        #endregion Méthodes

    }
}
