﻿using EIT.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    public partial class DemandeResiliation : Entity
    {
        /// <summary>
        /// Machine à états de la demande de résiliation.
        /// </summary>
        public class DemandeResiliationMachineEtats : Systeme.Entites.MachineEtats<DemandeResiliation, EtatDemandeResiliation, AbstractEtat>
        {
            /// <summary>
            /// Constructeur sans paramètres.
            /// </summary>
            protected DemandeResiliationMachineEtats()
            {

            }

            /// <summary>
            /// Constructeur de la machine à états à partir de l'état initial.
            /// </summary>
            /// <param name="etatInitial">Etat initial.</param>
            public DemandeResiliationMachineEtats(AbstractEtat etatInitial) : base(etatInitial)
            {

            }
        }
    }
}
