﻿using EIT.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    public partial class DemandeResiliation : Entity
    {
        /// <summary>
        /// Classe interne de l'état Annulée.
        /// </summary>
        public sealed class EtatAnnulee : AbstractEtat
        {
            #region Propriétés

            /// <summary>
            /// Valeur de l'état de la commande.
            /// </summary>
            public override EtatDemandeResiliation Valeur
            {
                get
                {
                    return EtatDemandeResiliation.Annulee;
                }
            }

            #endregion Propriétés

            #region Constructeurs

            /// <summary>
            /// Constructeur.
            /// </summary>
            /// <param name="demandeResiliation">Demande de résiliation.</param>
            /// <param name="memoId">Memo Id de l'agent à l'initiative de l'action.</param>
            public EtatAnnulee(DemandeResiliation demandeResiliation, string memoId) : base(demandeResiliation, memoId)
            {
                
            }

            #endregion Constructeurs
        }
    }
}
