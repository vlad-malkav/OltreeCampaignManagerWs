﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Constantes;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    public partial class DemandeResiliation : Entity
    {
        /// <summary>
        /// Classe interne pour l'état traitée.
        /// </summary>
        public sealed class EtatTraitee : AbstractEtat
        {
            #region Propriétés

            /// <summary>
            /// Valeur de l'état de la commande.
            /// </summary>
            public override EtatDemandeResiliation Valeur
            {
                get
                {
                    return EtatDemandeResiliation.Traitee;
                }
            }

            #endregion Propriétés

            #region Constructeurs

            /// <summary>
            /// Constructeur.
            /// </summary>
            /// <param name="demandeResiliation">Demande de résiliation.</param>
            /// <param name="memoId">Memo Id de l'agent à l'initiative de l'action.</param>
            public EtatTraitee(DemandeResiliation demandeResiliation, string memoId) : base(demandeResiliation, memoId)
            {

            }

            #endregion Constructeurs

            #region Méthodes

            /// <summary>
            /// Méthode qui permet de gérer les traitements liés au retour équipement.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void GererRetourEquipement(Identite identite)
            {
                // Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();

                // Obtention du mode de retour.
                ModeRetourEquipement modeRetour = this.Entite.repositories.ModeRetourEquipementRepository.ObtenirDepuisCle(this.Entite.CleModeRetourEquipement);

                // Obtention de l'objet ligne afin de récuperer la clé marque et la référence externe.
                Marque marque = this.Entite.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, this.Entite.Ligne.CleMarque);
                TiersPourDetail tiers = this.Entite.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, this.Entite.Ligne.CleTiers);
                OffrePourDetail offrePourDetail = this.Entite.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, this.Entite.Ligne.CleOffre);

                // Si EstEnvoiEtiquettePrepayee est vrai.
                if (modeRetour.EstEnvoiEtiquettePrepayee)
                {
                    // Appel de la méthode GererRetourEquipementInterne.
                    this.Entite.GererRetourEquipementInterne(identite);

                    // Envoi d'un email de confirmation de résiliation avec étiquette et enregistrement de l'historique.
                    this.Entite.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmerResiliationAvecEtiquette(identite,
                        new ParametresEmailConfirmerResiliationAvecEtiquette()
                        {
                            CleMarque = this.Entite.Ligne.CleMarque,
                            EmailContact = this.Entite.Email,
                            ReferenceExterne = this.Entite.Ligne.ReferenceExterne,
                            HeureFermetureSC = marque.HeureFermetureSc,
                            HeureOuvertureSC = marque.HeureFermetureSc,
                            LibelleMarque = marque.Libelle,
                            NumeroLigne = this.Entite.Ligne.Numero,
                            TelephoneFixeSC = marque.TelephoneFixeSc,
                            TelephoneMobileContact = tiers.NumeroMobileDeContact,
                            TelephoneMobileSC = marque.TelephoneMobileSc,
                            UrlAssistance = marque.UrlAssistance,
                            DateResiliationEffective = this.Entite.DateResiliationProgrammee.Value.ToShortDateString(),
                            LibelleOffre = offrePourDetail.Descriptif,
                            CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                            NomTitulaire = tiers.Nom,
                            DelaiEnvoiMaterielSuiteResiliation = ConstantesDemandeResiliation.DELAI_ENVOI_MATERIEL_SUITE_RESILIATION,
                            NumeroRetourColis = this.Entite.NumeroRetourEquipement
                        });
                }
                else
                {
                    // Envoi d'un email de confirmation de résiliation sans étiquette et enregistrement de l'historique.
                    this.Entite.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmerResiliationSansEtiquette(identite,
                        new ParametresEmailConfirmerResiliationSansEtiquette()
                        {
                            CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                            NomTitulaire = tiers.Nom,
                            CleMarque = this.Entite.Ligne.CleMarque,
                            EmailContact = this.Entite.Email,
                            ReferenceExterne = this.Entite.Ligne.ReferenceExterne,
                            HeureFermetureSC = marque.HeureFermetureSc,
                            HeureOuvertureSC = marque.HeureFermetureSc,
                            LibelleMarque = marque.Libelle,
                            NumeroLigne = this.Entite.Ligne.Numero,
                            TelephoneFixeSC = marque.TelephoneFixeSc,
                            TelephoneMobileContact = tiers.NumeroMobileDeContact,
                            TelephoneMobileSC = marque.TelephoneMobileSc,
                            UrlAssistance = marque.UrlAssistance,
                            DateResiliationEffective = this.Entite.DateResiliationProgrammee.Value.ToShortDateString(),
                            LibelleOffre = offrePourDetail.Descriptif,
                            DelaiEnvoiMaterielSuiteResiliation = ConstantesDemandeResiliation.DELAI_ENVOI_MATERIEL_SUITE_RESILIATION
                        });

                    // Si le tiers possède une nouvelle adresse, on récupère les informations du bon retour.
                    AdresseCourrier adresseCourrier;
                    if (this.Entite.EstNouveauTiersBonRetour)
                    {
                        adresseCourrier = new AdresseCourrier()
                        {
                            Civilite = EnumExtension.GetEnumDescription(this.Entite.CiviliteTiersBonRetour),
                            CodePostal = this.Entite.CodePostalTiersBonRetour,
                            Complement = this.Entite.ComplementVoieTiersBonRetour,
                            Nom = this.Entite.NomTiersBonRetour,
                            Prenom = this.Entite.PrenomTiersBonRetour,
                            Ville = this.Entite.VilleTiersBonRetour,
                            Voie = this.Entite.VoieTiersBonRetour,
                            Pays = ConstantesDemandeResiliation.PAYS_ADRESSE_COURRIER
                        };
                    }
                    else // Sinon, on récupère les informations de la brique tiers.
                    {
                        adresseCourrier = new AdresseCourrier()
                        {
                            Civilite = EnumExtension.GetEnumDescription(tiers.CiviliteEnum),
                            Nom = tiers.Nom,
                            Prenom = tiers.Prenom,
                            CodePostal = tiers.ListeAdresses.SingleOrDefault(t => t.EstPrincipale).CodePostal,
                            Complement = tiers.ListeAdresses.SingleOrDefault(t => t.EstPrincipale).ComplementIdentification,
                            Ville = tiers.ListeAdresses.SingleOrDefault(t => t.EstPrincipale).Ville,
                            Voie = tiers.ListeAdresses.SingleOrDefault(t => t.EstPrincipale).Voie,
                            Pays = ConstantesDemandeResiliation.PAYS_ADRESSE_COURRIER
                        };
                    }

                    // Envoi d'un courrier de confirmation de résiliation sans étiquette et enregistrement de l'historique.
                    this.Entite.briquesExternes.CommunicationClientServiceExterne.EnvoyerCourrierConfirmerResiliationSansEtiquette(identite,
                        new ParametresCourrierConfirmerResiliationSansEtiquette()
                        {
                            CleMarque = this.Entite.Ligne.CleMarque,
                            ReferenceExterne = this.Entite.Ligne.ReferenceExterne,
                            AdresseCourrier = adresseCourrier,
                            Refdoc = ConstantesDemandeResiliation.REFDOC_COURRIER_CONFIRMER_RESILIATION_SANS_ETIQUETTE,
                            HeureFermetureSC = marque.HeureFermetureSc,
                            HeureOuvertureSC = marque.HeureFermetureSc,
                            LibelleMarque = marque.Libelle,
                            NumeroLigne = this.Entite.Ligne.Numero,
                            TelephoneFixeSC = marque.TelephoneFixeSc,
                            TelephoneMobileContact = tiers.NumeroMobileDeContact,
                            TelephoneMobileSC = marque.TelephoneMobileSc,
                            UrlAssistance = marque.UrlAssistance,
                            DateResiliationEffective = this.Entite.DateResiliationProgrammee.Value.ToShortDateString(),
                            LibelleOffre = offrePourDetail.Descriptif,
                            DelaiEnvoiMaterielSuiteResiliation = ConstantesDemandeResiliation.DELAI_ENVOI_MATERIEL_SUITE_RESILIATION
                        });
                }

                // Suivi de modification.
                this.Entite.SuiviAgentModification = identite.Memoid;
                this.Entite.SuiviDateModification = DateTime.Now;
            }

            /// <summary>
            /// Méthode qui permet d'enregistrer la demande de retour sur la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="cleDemandeRetourEquipement">Clé de la demande de retour équipement.</param>
            /// <param name="numeroRetourEquipement">Numéro de la demande de retour équipement.</param>
            public override void DefinirNumeroRetourEquipement(Identite identite, long cleDemandeRetourEquipement, string numeroRetourEquipement)
            {
                this.DefinirNumeroRetourEquipementInterne(identite, cleDemandeRetourEquipement, numeroRetourEquipement);
            }

            #endregion Méthodes
        }
    }
}
