﻿using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    public partial class DemandeResiliation : Entity
    {
        /// <summary>
        /// Classe abstraite de l'Etat de la demande de résiliation.
        /// </summary>
        public abstract class AbstractEtat : Etat<DemandeResiliation, EtatDemandeResiliation>
        {
            #region Propriétés dynamiques

            /// <summary>
            /// Indique si la demande de résiliation peut être annulée. 
            /// </summary>
            public virtual bool EstAnnulable
            {
                get
                {
                    return false;
                }
            }

            #endregion Propriétés dynamiques

            #region Constructeurs

            /// <summary>
            /// Constructeur d'initialisation.
            /// </summary>
            /// <param name="demandeResiliation">Demande de résiliation.</param>
            /// <param name="memoId">Memo Id de l'agent à l'initiative de l'action.</param>
            protected AbstractEtat(DemandeResiliation demandeResiliation, string memoId) : base(demandeResiliation)
            { }

            #endregion Constructeurs

            #region Méthodes

            /// <summary>
            /// Méthode qui permet d'annuler une demande de résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void Annuler(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible d'annuler la demande de résiliation {this.Entite.Cle} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }


            /// <summary>
            /// Méthode qui permet d'enregistrer la demande de retour sur la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="cleDemandeRetourEquipement">Clé de la demande de retour équipement.</param>
            /// <param name="numeroRetourEquipement">Numéro de la demande de retour équipement.</param>
            public virtual void DefinirNumeroRetourEquipement(Identite identite, long cleDemandeRetourEquipement, string numeroRetourEquipement)
            {
                throw new InvalidOperationException
                    ($"Impossible de définir le numéro de retour équipement pour la demande de résiliation {this.Entite.Cle} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Indique si la demande de résiliation de la ligne peut être annulée selon l'état de la ligne.
            /// </summary>
            /// <returns>Résultat du contrôle.</returns>
            protected bool EstAnnulableInterne()
            {
                // Si la ligne n'est pas résilié.
                return this.Entite.Ligne.Etat.Valeur != EtatLigne.Resiliee;
            }

            /// <summary>
            /// Méthode qui permet de gérer les traitements liés au retour équipement.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void GererRetourEquipement(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible de gérer le retour équipement pour la demande de résiliation {this.Entite.Cle} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Méthode qui permet de traiter la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public virtual void Traiter(Identite identite)
            {
                throw new InvalidOperationException
                    ($"Impossible de traiter la demande de résiliation {this.Entite.Cle} dans l'état {this.Entite.EtatCourant.Valeur.GetEnumDescription()}.");
            }

            /// <summary>
            /// Méthode qui permet d'enregistrer la demande de retour sur la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="cleDemandeRetourEquipement">Clé de la demande de retour équipement.</param>
            /// <param name="numeroRetourEquipement">Numéro de la demande de retour équipement.</param>
            protected void DefinirNumeroRetourEquipementInterne(Identite identite, long cleDemandeRetourEquipement, string numeroRetourEquipement)
            {
                // Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();
                cleDemandeRetourEquipement.Valider(nameof(cleDemandeRetourEquipement)).StrictementPositif();
                numeroRetourEquipement.Valider(nameof(numeroRetourEquipement)).NonNul().Obligatoire();

                // Affectation des valeurs.
                this.Entite.CleDemandeRetourEquipement = cleDemandeRetourEquipement;
                this.Entite.NumeroRetourEquipement = numeroRetourEquipement;

                // Suivi de modification.
                this.Entite.SuiviAgentModification = identite.Memoid;
                this.Entite.SuiviDateModification = DateTime.Now;
            }

            #endregion Méthodes
        }
    }
}


