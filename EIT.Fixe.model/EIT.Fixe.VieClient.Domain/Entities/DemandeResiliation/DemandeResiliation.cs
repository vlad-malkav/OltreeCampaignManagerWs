﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Entites;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    /// <summary>
    /// Entité de la demande de résiliation.
    /// </summary>
    [AccesConcurrent]
    [CustomTableName("T_DMDRSL")]
    public partial class DemandeResiliation : Entity
    {
        #region Champs

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private readonly IServicesTechniques servicesTechniques;

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesExternes;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Clé primaire de la demande de résiliation.
        /// </summary>
        [CustomColumnName("CLE")]
        [Key]
        public virtual long Cle { get; protected set; }

        /// <summary>
        /// La ligne à laquelle est associée la demande de résiliation.
        /// </summary>
        [CustomColumnName("CLELIGNE")]
        public virtual Ligne.Ligne Ligne { get; protected set; }

        /// <summary>
        /// Clé de la demande de retour équipement.
        /// </summary>
        [CustomColumnName("CLEDEMANDERETOUREQUIPEMENT")]
        public virtual long? CleDemandeRetourEquipement { get; protected set; }

        /// <summary>
        /// Clé du mode de retour équipement.
        /// </summary>
        [CustomColumnName("CLEMODERETOUREQUIPEMENT")]
        public virtual long CleModeRetourEquipement { get; protected set; }

        /// <summary>
        /// Clé du motif de résiliation.
        /// </summary>
        [CustomColumnName("CLEMOTIFRESILIATION")]
        public virtual long CleMotifResiliation { get; protected set; }

        /// <summary>
        /// Date d'annulation de la demande.
        /// </summary>
        [CustomColumnName("DATEANNULATION")]
        public virtual DateTime? DateAnnulation { get; protected set; }

        /// <summary>
        /// Date de réception du courrier avec accusé de réception.
        /// </summary>
        [CustomColumnName("DATERECEPTIONCOURRIERAR")]
        public virtual DateTime DateReceptionCourrierAr { get; protected set; }

        /// <summary>
        /// Date de résiliation programmée.
        /// </summary>
        [CustomColumnName("DATERESILIATIONPROGRAMMEE")]
        public virtual DateTime? DateResiliationProgrammee { get; protected set; }

        /// <summary>
        /// Etat de la demande de résiliation.
        /// </summary>
        [CustomColumnName("ETAT")]
        public virtual DemandeResiliationMachineEtats Etat { get; protected set; }

        /// <summary>
        /// Numéro de la demande de retour équipement.
        /// </summary>
        [CustomColumnName("NUMERORETOUREQUIPEMENT")]
        public virtual string NumeroRetourEquipement { get; protected set; }

        /// <summary>
        /// Adresse email du tiers.
        /// </summary>
        [CustomColumnName("EMAIL")]
        public virtual string Email { get; protected set; }

        /// <summary>
        /// Indique si un nouveau tiers a été saisi pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("ESTNOUVEAUTIERSBONRETOUR")]
        public virtual bool EstNouveauTiersBonRetour { get; protected set; }

        /// <summary>
        /// Civilité du tiers pour l'envoi du bon retour.
        /// </summary>
        [CustomColumnName("CIVILITETIERSBONRETOUR")]
        public virtual Civilite CiviliteTiersBonRetour { get; protected set; }

        /// <summary>
        /// Prénom du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("PRENOMTIERSBONRETOUR")]
        public virtual string PrenomTiersBonRetour { get; protected set; }

        /// <summary>
        /// Nom du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("NOMTIERSBONRETOUR")]
        public virtual string NomTiersBonRetour { get; protected set; }

        /// <summary>
        /// Nom de voie de l'adresse du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("VOIETIERSBONRETOUR")]
        public virtual string VoieTiersBonRetour { get; protected set; }

        /// <summary>
        /// Complément de voie de l'adresse du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("COMPLEMENTVOIETIERSBONRETOUR")]
        public virtual string ComplementVoieTiersBonRetour { get; protected set; }

        /// <summary>
        /// Code postal de l'adresse du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("CODEPOSTALTIERSBONRETOUR")]
        public virtual string CodePostalTiersBonRetour { get; protected set; }

        /// <summary>
        /// Ville de l'adresse du tiers pour l'envoi du bon de retour.
        /// </summary>
        [CustomColumnName("VILLETIERSBONRETOUR")]
        public virtual string VilleTiersBonRetour { get; protected set; }

        /// <summary>
        /// Identifiant de transaction avec l'opérateur.
        /// </summary>
        [CustomColumnName("IDENTIFIANTTRAOPERATEUR")]
        public virtual int IdentifiantTransactionOperateur { get; protected set; }

        /// <summary>
        /// Date de création de la demande de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; protected set; }

        /// <summary>
        /// Agent à l'initiative de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; protected set; }

        /// <summary>
        /// Date de la dernière modification de la demande de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; protected set; }

        /// <summary>
        /// Agent à l'initiative de la dernière modification de la demande de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; protected set; }

        #endregion Propriétés

        #region Propriétés Dynamiques

        /// <summary>
        /// Etat courant de la demande de résiliation.
        /// </summary>
        protected virtual AbstractEtat EtatCourant
        {
            get
            {
                return this.Etat.Obtenir(this);
            }

            private set
            {
                this.Etat.Definir(value);
            }
        }

        /// <summary>
        /// Indique si la demande de résiliation peut être annulée.
        /// </summary>
        public virtual bool EstAnnulable
        {
            get
            {
                return this.EtatCourant.EstAnnulable;
            }
        }

        #endregion Propriétés Dynamiques

        #region Constucteurs

        /// <summary>
        /// Constructeur par défaut. Vide pour Entity.
        /// </summary>
        protected DemandeResiliation()
        {
        }

        /// <summary>
        /// Constructeur d'instanciation qui initialise l'objet DemandeResiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cle">Clé primaire de l'objet DemandeResiliation.</param>
        /// <param name="cleLigne">Clé de la ligne associée.</param>
        /// <param name="informationsDemandeResiliation">Informations de la demande de résiliation.</param>
        /// <param name="repositories">Interface des repositories.</param>
        /// <param name="servicesExternes">Interface des services externes.</param>
        /// <param name="servicesTechniques">Interface des services techniques.</param>
        /// <param name="briquesExternes">Interface des briques externes.</param>
        public DemandeResiliation(
            Identite identite,
            long cle,
            long cleLigne,
            DemandeResiliationPourCreation informationsDemandeResiliation,
            IRepositories repositories,
            IServicesExternes servicesExternes,
            IServicesTechniques servicesTechniques,
            IBriquesServicesExternes briquesExternes)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            informationsDemandeResiliation.Valider(nameof(informationsDemandeResiliation)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            servicesTechniques.Valider(nameof(servicesTechniques)).NonNul();
            briquesExternes.Valider(nameof(briquesExternes)).NonNul();

            // Initialisation des champs.
            this.repositories = repositories;
            this.servicesExternes = servicesExternes;
            this.servicesTechniques = servicesTechniques;
            this.briquesExternes = briquesExternes;

            // Affectation de la clé.
            this.Cle = cle;

            // Affectation de la ligne.
            this.Ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Affectation des informations de la demande de résiliation.
            this.DateResiliationProgrammee = informationsDemandeResiliation.DateResiliationProgrammee;
            this.CleModeRetourEquipement = informationsDemandeResiliation.CleModeRetourEquipement;
            this.CleMotifResiliation = informationsDemandeResiliation.CleMotifResiliation;
            this.CleMotifResiliation = informationsDemandeResiliation.CleMotifResiliation;
            this.DateReceptionCourrierAr = informationsDemandeResiliation.DateReceptionCourrierAr;
            this.EstNouveauTiersBonRetour = informationsDemandeResiliation.EstNouveauTiersEnvoiBonRetour;
            this.Email = informationsDemandeResiliation.Email;

            if (informationsDemandeResiliation.TiersEnvoiBonRetour != null)
            {
                this.CiviliteTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Civilite;
                this.CodePostalTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Adresse.CodePostal;
                this.ComplementVoieTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Adresse.Complement;
                this.NomTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Nom;
                this.PrenomTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Prenom;
                this.VilleTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Adresse.Ville;
                this.VoieTiersBonRetour = informationsDemandeResiliation.TiersEnvoiBonRetour.Adresse.Voie;
            }

            // Obtention d'un numéro de séquence pour les transactions avec l'opérateur.
            this.IdentifiantTransactionOperateur = servicesTechniques.GenerateurSequences.ObtenirEntier(IdentifiantsSequences.IDENTIFIANT_TRANSACTION_IO);

            // Affectation de l'état.
            this.Etat = new DemandeResiliationMachineEtats(new EtatEnCours(this, identite.Memoid));

            // Suivi de création.
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateCreation = DateTime.Now;
            this.SuiviDateModification = DateTime.Now;
        }

        #endregion Constucteurs

        #region Méthodes

        /// <summary>
        /// Méthode qui permet d'annuler une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void Annuler(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Appel de la méthode.
            this.EtatCourant.Annuler(identite);
        }

        /// <summary>
        /// Méthode d'implémentation pour l'annulation d'une demande de résiliation de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        protected void AnnulerInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Affectation d'une date d'annulation.
            this.DateAnnulation = DateTime.Now;

            // Modification de l'état.
            this.Etat = new DemandeResiliationMachineEtats(new EtatAnnulee(this, identite.Memoid));

            // Création de l'objet permettant la création d'un historique.
            HistoriquePourCreation parametresHistoriquePourCreation = new HistoriquePourCreation()
            {
                ReferenceExterne = this.Ligne.ReferenceExterne,
                CleMetier1 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau1.ActeDeGestion,
                CleMetier2 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau2.Resiliation,
                Commentaire = "Annulation de la demande de résiliation",
                CleOrigine = null
            };

            // Appel de la méthode CreerHistoriqueFonctionnel.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite, this.Ligne.Cle, parametresHistoriquePourCreation);

            // Récupération des informations pour envoyer un mail de résiliation.
            Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, this.Ligne.CleMarque);
            TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, this.Ligne.CleTiers);

            // Appel de la méthode EnvoyerMail et ajout de l'historique. 
            this.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailAnnulerResiliation(identite,
                new ParametresEmailAnnulerResiliation()
                {
                    CleMarque = this.Ligne.CleMarque,
                    EmailContact = this.Email,
                    ReferenceExterne = this.Ligne.ReferenceExterne,
                    HeureFermetureSC = marque.HeureFermetureSc,
                    HeureOuvertureSC = marque.HeureFermetureSc,
                    LibelleMarque = marque.Libelle,
                    NumeroLigne = this.Ligne.Numero,
                    TelephoneFixeSC = marque.TelephoneFixeSc,
                    TelephoneMobileContact = tiers.NumeroMobileDeContact,
                    TelephoneMobileSC = marque.TelephoneMobileSc,
                    UrlAssistance = marque.UrlAssistance,
                    CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                    NomTitulaire = tiers.Nom

                });

            // Suivi de modification.
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        /// <summary>
        /// Méthode qui permet d'enregistrer la demande de retour sur la demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeRetourEquipement">Clé de la demande de retour d'équipement.</param>
        /// <param name="numeroRetourEquipement">Numéro de la demande de retour d'équipement.</param>
        public virtual void DefinirNumeroRetourEquipement(Identite identite, long cleDemandeRetourEquipement, string numeroRetourEquipement)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeRetourEquipement.Valider(nameof(cleDemandeRetourEquipement)).StrictementPositif();
            numeroRetourEquipement.Valider(nameof(numeroRetourEquipement)).Obligatoire();

            // Appel de la méthode.
            this.EtatCourant.DefinirNumeroRetourEquipement(identite, cleDemandeRetourEquipement, numeroRetourEquipement);
        }

        /// <summary>
        /// Méthode qui permet de gérer les traitements liés au retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void GererRetourEquipement(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Appel de la méthode.
            this.EtatCourant.GererRetourEquipement(identite);
        }

        /// <summary>
        /// Méthode d'implémentation pour gérer les traitements liés au retour équipement.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        protected void GererRetourEquipementInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Rechercher le tiers.
            TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, this.Ligne.CleTiers);

            // Rechercher la marque de la ligne.
            Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, this.Ligne.CleMarque);

            // Création du tiers pour envoi bon retour.
            TiersPourEnvoiBonRetour tiersPourEnvoi = new TiersPourEnvoiBonRetour();
            tiersPourEnvoi.TelephoneMobileTiers = tiers.NumeroMobileDeContact;

            // Si le bon retour du tiers est nouveau, on récupère les informations du bon retour.
            if (this.EstNouveauTiersBonRetour)
            {
                tiersPourEnvoi.Civilite = this.CiviliteTiersBonRetour;
                tiersPourEnvoi.Nom = this.NomTiersBonRetour;
                tiersPourEnvoi.Prenom = this.PrenomTiersBonRetour;
                tiersPourEnvoi.EmailTiers = this.Email;
                tiersPourEnvoi.Adresse = new AdressePourSaisie()
                {
                    CodePostal = this.CodePostalTiersBonRetour,
                    Complement = this.ComplementVoieTiersBonRetour,
                    Ville = this.VilleTiersBonRetour,
                    Voie = this.VoieTiersBonRetour
                };
            }
            else // Sinon, on récupère les informations de l'adresse principale du tiers.
            {
                tiersPourEnvoi.Civilite = tiers.CiviliteEnum;
                tiersPourEnvoi.EmailTiers = tiers.EmailContact;
                tiersPourEnvoi.Nom = tiers.Nom;
                tiersPourEnvoi.Prenom = tiers.Prenom;
                AdresseTiers adresseTiers = tiers.ListeAdresses.FirstOrDefault();

                if (adresseTiers != null)
                {
                    tiersPourEnvoi.Adresse = new AdressePourSaisie()
                    {
                        CodePostal = adresseTiers.CodePostal,
                        Complement = adresseTiers.ComplementIdentification,
                        Ville = adresseTiers.Ville,
                        Voie = adresseTiers.Voie
                    };
                }
            }

            // Obtention de la date de résiliation.
            DateTime dateResiliation = this.Ligne.ListeHistoriqueEtats.FirstOrDefault(h => h.NouvelEtat == EtatLigne.Resiliee).DateChangementEtat;

            // Obtention de l'offre.
            OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, this.Ligne.CleOffre);

            // Obtention du code article à fournir pour le courrier de résiliation/retour colis.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliation);
            motifResiliation.CodeArticle.Valider(nameof(motifResiliation.CodeArticle)).Obligatoire();

            // Instanciation de CommandeRetourEquipementPourCreation.
            CommandeRetourEquipementPourCreation retourEquipement = new CommandeRetourEquipementPourCreation()
            {
                Tiers = tiersPourEnvoi,
                CleMarque = this.Ligne.CleMarque,
                LibelleOffre = offre.Nom,
                NumeroRetourEquipement = this.NumeroRetourEquipement,
                DateResiliation = dateResiliation,
                TelephoneFixeSc = marque.TelephoneFixeSc,
                CleImprimeCourrierResiliationRetourColis = marque.CleImprimeCourrierResiliationRetourColis,
                CodeArticleCourrierResiliationRetourColis = motifResiliation.CodeArticle
            };

            // Appel de la méthode GererCommandeRetourEquipement.
            this.servicesExternes.LogistiqueServiceExterne.GererCommandeRetourEquipement(identite, this.Ligne.ReferenceExterne, retourEquipement);

            // Suivi de modification.
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        /// <summary>
        /// Méthode qui permet de traiter la demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public virtual void Traiter(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Appel de la méthode.
            this.EtatCourant.Traiter(identite);
        }

        /// <summary>
        /// Méthode d'implémentation qui permet de traiter la demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        protected void TraiterInterne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Si la date de résiliation programmée est inférieure ou égale à la date du jour => Résiliation immédiate.
            if (this.DateResiliationProgrammee.HasValue && this.DateResiliationProgrammee.Value.Date <= DateTime.Now.Date)
            {
                // Appel de la méthode Resilier.
                this.Ligne.Resilier(identite);

                // Modification de l'état de la demande à traitée.
                this.Etat = new DemandeResiliationMachineEtats(new EtatTraitee(this, identite.Memoid));

                // Appel de la méthode GererRetourEquipement.
                this.GererRetourEquipement(identite);

                // Suivi de modification.
                this.SuiviAgentModification = identite.Memoid;
                this.SuiviDateModification = DateTime.Now;
            }
        }

        #endregion Méthodes
    }
}
