﻿using EIT.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Events;
using EIT.Fixe.Infrastructure.Helpers;

namespace EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation
{
    public partial class DemandeResiliation : Entity
    {
        /// <summary>
        /// Classe interne pour l'état EnCours.
        /// </summary>
        public sealed class EtatEnCours : AbstractEtat
        {
            #region Propriétés

            /// <summary>
            /// Valeur de l'état de la demande de résiliation.
            /// </summary>
            public override EtatDemandeResiliation Valeur
            {
                get
                {
                    return EtatDemandeResiliation.EnCours;
                }
            }

            /// <summary>
            /// Indique si la demande de résiliation peut être annulée.
            /// </summary>
            public override bool EstAnnulable
            {
                get
                {
                    return base.EstAnnulableInterne();
                }
            }

            #endregion Propriétés

            #region Constructeurs

            /// <summary>
            /// Constructeur
            /// </summary>
            /// <param name="demandeResiliation">Demande de résiliation.</param>
            /// <param name="memoId">Memo Id de l'agent à l'initiative de l'action.</param>
            public EtatEnCours(DemandeResiliation demandeResiliation, string memoId) : base(demandeResiliation, memoId)
            {

            }

            #endregion Constructeurs

            #region Méthodes

            /// <summary>
            /// Méthode qui permet d'annuler une demande de résiliation de la ligne.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void Annuler(Identite identite)
            {
                // Vérification des entrées.
                identite.Valider(nameof(identite)).NonNul();

                this.Entite.AnnulerInterne(identite);
            }

            /// <summary>
            /// Méthode qui permet d'enregistrer la demande de retour sur la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            /// <param name="cleDemandeRetourEquipement">Clé de la demande de retour équipement.</param>
            /// <param name="numeroRetourEquipement">Numéro de la demande de retour équipement.</param>
            public override void DefinirNumeroRetourEquipement(Identite identite, long cleDemandeRetourEquipement, string numeroRetourEquipement)
            {
                this.DefinirNumeroRetourEquipementInterne(identite, cleDemandeRetourEquipement, numeroRetourEquipement);
            }

            /// <summary>
            /// Méthode qui permet de traiter la demande de résiliation.
            /// </summary>
            /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
            public override void Traiter(Identite identite)
            {
                identite.Valider(nameof(identite)).NonNul();

                this.Entite.TraiterInterne(identite);
            }

            #endregion Méthodes
        }
    }
}
