﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des documents d'une ligne.
    /// </summary>
    [CustomTableName("T_DOCLIG")]
    public class DocumentLigne : Entity
    {
        #region Attributs

        /// <summary>
        /// RefDoc du document.
        /// </summary>
        [Key]
        [CustomColumnName("REFDOC")]
        public virtual string RefDoc { get; set; } 

        /// <summary>
        /// Libellé du document.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected DocumentLigne()
        {

        }

        #endregion Constructeurs

    }
}
