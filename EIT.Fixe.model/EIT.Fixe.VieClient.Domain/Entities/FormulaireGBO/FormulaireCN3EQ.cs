﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de niveau 3 d'engagement qualité.
    /// </summary>
    [CustomTableName("T_FRM_GBO_CN3EQ")]
    public class FormulaireCN3EQ : FormulaireGBO
    {
        #region Attributs

        /// <summary>
        /// Numero de suivi du dossier concerné.
        /// </summary>
        [CustomColumnName("NUMEROSUIVIDOSSIER")]
        public virtual string NumeroSuiviDossier  { get; set; }

        /// <summary>
        /// Date de réponse cellule N2.
        /// </summary>
        [CustomColumnName("DATEREPONSECELLULEN2")]
        public virtual DateTime DateReponseCelluleN2 { get; set; }

        /// <summary>
        /// nature de la demande d'intervention.
        /// </summary>
        [CustomColumnName("CLENATUREDEMANDEINTERVENTION")]
        public virtual NatureDemandeIntervention NatureDemandeIntervention { get; set; }

        /// <summary>
        /// Raison de la contestation.
        /// </summary>
        [CustomColumnName("RAISONCONTESTATION")]
        public virtual string RaisonContestation { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        [CustomColumnName("DEMANDECLIENT")]
        public virtual string DemandeClient { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        [CustomColumnName("SOLUTIONSDEJAAPPORTEES")]
        public virtual string SolutionsDejaApportees { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected FormulaireCN3EQ()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire de niveau 2 de demande d'intervention.</param>
        public FormulaireCN3EQ(Identite identite, ParametresCreationFormulaireCN3EQ parametresCreation, List<PieceJointeFormulaireGbo> listePiecesJointes)
            : base(identite, parametresCreation, listePiecesJointes)
        {
            // Vérification des paramètres entrants.
            parametresCreation.InformationsSupplementairesCN3EqPourCreation
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation)).NonNull();
            parametresCreation.NatureDemandeIntervention
                .Valider(nameof(parametresCreation.NatureDemandeIntervention)).NonNull();
            parametresCreation.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier)).Obligatoire();
            parametresCreation.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2)).NonNul();
            parametresCreation.InformationsSupplementairesCN3EqPourCreation.RaisonContestation
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation.RaisonContestation)).Obligatoire();
            parametresCreation.InformationsSupplementairesCN3EqPourCreation.DemandeClient
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation.DemandeClient)).Obligatoire();
            parametresCreation.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees)).Obligatoire();

            // Assignation des valeurs.
            this.NumeroSuiviDossier = parametresCreation.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier;
            this.DateReponseCelluleN2 = parametresCreation.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2;
            this.NatureDemandeIntervention = parametresCreation.NatureDemandeIntervention;
            this.RaisonContestation = parametresCreation.InformationsSupplementairesCN3EqPourCreation.RaisonContestation;
            this.DemandeClient = parametresCreation.InformationsSupplementairesCN3EqPourCreation.DemandeClient;
            this.SolutionsDejaApportees = parametresCreation.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees;
            this.TypeFormulaireGbo = TypeFormulaireGBO.FormulaireCN3EQ;
        }

        #endregion Constructeurs

    }
}