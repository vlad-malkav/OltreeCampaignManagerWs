﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de modification de profil surconsommation.
    /// </summary>
    [CustomTableName("T_FRM_GBO_MPS")]
    public class FormulaireMPS : FormulaireGBO
    {
        #region Attributs

        /// <summary>
        /// Nom client.
        /// </summary>
        [CustomColumnName("NOMCLIENT")]
        public virtual string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [CustomColumnName("PRENOMCLIENT")]
        public virtual string PrenomClient  { get; set; }

        /// <summary>
        /// Date d'effet de la demande.
        /// </summary>
        [CustomColumnName("DATEEFFETDEMANDE")]
        public virtual DateTime DateEffetDemande  { get; set; }

        /// <summary>
        /// Profil de surconsommation demandé.
        /// </summary>
        [CustomColumnName("PROFILSURCONSODEMANDE")]
        public virtual ProfilSurconsommation ProfilSurconsoDemande  { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        [CustomColumnName("COMMENTAIRE")]
        public virtual string Commentaire  { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected FormulaireMPS()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire de niveau 2 de demande d'intervention.</param>
        public FormulaireMPS(Identite identite, ParametresCreationFormulaireMPS parametresCreation)
            : base(identite, parametresCreation)
        {
            // Vérification des paramètres entrants.
            parametresCreation.InformationsClientPourCreation.Valider(nameof(parametresCreation.InformationsClientPourCreation)).NonNull();
            parametresCreation.DateEffetDemande.Valider(nameof(parametresCreation.DateEffetDemande)).NonNul();
            parametresCreation.ProfilSurconsoDemande.Valider(nameof(parametresCreation.ProfilSurconsoDemande)).NonNul();
            parametresCreation.Commentaire.Valider(nameof(parametresCreation.Commentaire)).Obligatoire();

            // Assignation des valeurs.
            this.NomClient = parametresCreation.InformationsClientPourCreation.NomClient;
            this.PrenomClient = parametresCreation.InformationsClientPourCreation.PrenomClient;
            this.DateEffetDemande = parametresCreation.DateEffetDemande;
            this.ProfilSurconsoDemande = parametresCreation.ProfilSurconsoDemande;
            this.Commentaire = parametresCreation.Commentaire;
            this.TypeFormulaireGbo = TypeFormulaireGBO.FormulaireMPS;
        }

        #endregion Constructeurs

    }
}