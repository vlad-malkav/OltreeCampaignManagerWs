﻿using System;
using System.Runtime.Serialization;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de modification de profil surconsommation.
    /// </summary>
    public class ParametresCreationFormulaireMPS : ParametresCreationFormulaireGbo
    {
        #region Attributs

        /// <summary>
        /// Informations d’un Client pour création (Formulaire GBO).
        /// </summary>
        public virtual InformationsClientPourCreation InformationsClientPourCreation { get; set; }

        /// <summary>
        /// Date d'effet de la demande.
        /// </summary>
        public virtual DateTime DateEffetDemande  { get; set; }

        /// <summary>
        /// Profil de surconsommation demandé.
        /// </summary>
        public virtual ProfilSurconsommation ProfilSurconsoDemande  { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        public virtual string Commentaire  { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametresCreationFormulaireGBO">Paramètres de création du formulaire GBO.</param>
        /// <param name="informationsClientPourCreation">Informations d’un Client pour création (Formulaire GBO).</param>
        /// <param name="dateEffetDemande">Date d'effet de la demande.</param>
        /// <param name="profilSurconsoDemande">Profil de surconsommation demandé.</param>
        /// <param name="commentaire">Commentaire.</param>
        public ParametresCreationFormulaireMPS(
            ParametresCreationFormulaireGbo parametresCreationFormulaireGBO,
            InformationsClientPourCreation informationsClientPourCreation,
            DateTime dateEffetDemande,
            ProfilSurconsommation profilSurconsoDemande,
            string commentaire)
            : base(
                parametresCreationFormulaireGBO.Cle,
                parametresCreationFormulaireGBO.CleDossierGbo,
                parametresCreationFormulaireGBO.RegionCdc,
                parametresCreationFormulaireGBO.InformationsCdcPourCreation,
                parametresCreationFormulaireGBO.ReferenceExterne)
        {
            // Vérification des paramètres entrants.
            parametresCreationFormulaireGBO.Valider(nameof(parametresCreationFormulaireGBO)).NonNull();
            informationsClientPourCreation.Valider(nameof(informationsClientPourCreation)).NonNull();
            dateEffetDemande.Valider(nameof(dateEffetDemande)).NonNul();
            profilSurconsoDemande.Valider(nameof(profilSurconsoDemande)).NonNul();
            commentaire.Valider(nameof(commentaire)).Obligatoire();

            // Assignation des valeurs.
            this.InformationsClientPourCreation = informationsClientPourCreation;
            this.DateEffetDemande = dateEffetDemande;
            this.ProfilSurconsoDemande = profilSurconsoDemande;
            this.Commentaire = commentaire;
        }

        #endregion Constructeurs

    }
}