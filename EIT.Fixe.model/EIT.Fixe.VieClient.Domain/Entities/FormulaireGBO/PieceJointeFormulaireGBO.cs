﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier d'une Pièce Jointe de Formulaire GBO.
    /// </summary>
    [CustomTableName("T_FRM_GBO_PJ")]
    public class PieceJointeFormulaireGbo : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé technique d'une Pièce Jointe de Formulaire GBO.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// GUDOCID.
        /// </summary>
        [CustomColumnName("GUDOCID")]
        public virtual string GuDocId { get; set; }

        /// <summary>
        /// Nom du fichier.
        /// </summary>
        [CustomColumnName("NOMFICHIER")]
        public virtual string NomFichier { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected PieceJointeFormulaireGbo()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création de la Pièce Jointe de Formulaire GBO.</param>
        public PieceJointeFormulaireGbo(Identite identite, ParametresCreationPieceJointeFormulaireGbo parametresCreation)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            parametresCreation.Cle.Valider(nameof(parametresCreation.Cle)).StrictementPositif();
            parametresCreation.GuDocId.Valider(nameof(parametresCreation.GuDocId)).Obligatoire();
            parametresCreation.NomFichier.Valider(nameof(parametresCreation.NomFichier)).Obligatoire();

            // Assignation des valeurs.
            this.Cle = parametresCreation.Cle;
            this.GuDocId = parametresCreation.GuDocId;
            this.NomFichier = parametresCreation.NomFichier;
        }

        #endregion Constructeurs

    }
}