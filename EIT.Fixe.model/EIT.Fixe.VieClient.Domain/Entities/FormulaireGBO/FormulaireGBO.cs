﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire GBO de base.
    /// </summary>
    [CustomTableName("T_FRM_GBO")]
    public class FormulaireGBO : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé technique du Formulaire GBO de base.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Clé du Dossier GBO.
        /// </summary>
        [CustomColumnName("CLEDOSSIERGBO")]
        public virtual long CleDossierGbo { get; set; }

        /// <summary>
        /// Adresse mail du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCADRESSEMAIL")]
        public virtual string CdcAdresseMail { get; set; }

        /// <summary>
        /// Code banque du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCCODEBANQUE")]
        public virtual string CdcCodeBanque { get; set; }

        /// <summary>
        /// Code branche du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCCODEBRANCHE")]
        public virtual string CdcCodeBranche { get; set; }

        /// <summary>
        /// Ligne directe du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCLIGNEDIRECTE")]
        public virtual string CdcLigneDirecte { get; set; }

        /// <summary>
        /// Nom et prenom concaténés du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCNOMPRENOM")]
        public virtual string CdcNomPrenom { get; set; }

        /// <summary>
        /// Région du Chargé de Clientèle.
        /// </summary>
        [CustomColumnName("CDCCLEREGION")]
        public virtual RegionCDC RegionCdc { get; set; }

        /// <summary>
        /// Référence Externe client.
        /// </summary>
        [CustomColumnName("REFERENCEEXTERNE")]
        public virtual string ReferenceExterne { get; set; }

        /// <summary>
        /// Type technique du Formulaire GBO, servant de discriminant notamment dans les canaux
        /// N'est pas exposé
        /// </summary>
        [CustomColumnName("TYPEFORMULAIREGBO")]
        public virtual TypeFormulaireGBO TypeFormulaireGbo { get; set; }

        /// <summary>
        /// Pièces jointes associées à ce Formulaire GBO.
        /// </summary>
        [CustomAssociationTable("T_FRM_GBO_PJ_FRM", "CLEFORMULAIREGBO", "CLEPIECEJOINTE")]
        public virtual ICollection<PieceJointeFormulaireGbo> ListePiecesJointes { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected FormulaireGBO()
        { }



        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire GBO de base.</param>
        public FormulaireGBO(Identite identite, ParametresCreationFormulaireGbo parametresCreation) 
            : this(identite, parametresCreation, null)
        {

        }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire GBO de base.</param>
        public FormulaireGBO(Identite identite, ParametresCreationFormulaireGbo parametresCreation, List<PieceJointeFormulaireGbo> listePiecesJointes)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            parametresCreation.InformationsCdcPourCreation.Valider(nameof(parametresCreation.InformationsCdcPourCreation)).NonNull();
            parametresCreation.Cle.Valider(nameof(parametresCreation.Cle)).StrictementPositif();
            parametresCreation.CleDossierGbo.Valider(nameof(parametresCreation.CleDossierGbo)).StrictementPositif();
            parametresCreation.InformationsCdcPourCreation.CdcAdresseMail
                .Valider(nameof(parametresCreation.InformationsCdcPourCreation.CdcAdresseMail)).Obligatoire();
            parametresCreation.InformationsCdcPourCreation.CdcCodeBanque
                .Valider(nameof(parametresCreation.InformationsCdcPourCreation.CdcCodeBanque)).Obligatoire().Longueur(5);
            parametresCreation.InformationsCdcPourCreation.CdcCodeBranche
                .Valider(nameof(parametresCreation.InformationsCdcPourCreation.CdcCodeBranche)).Obligatoire().Longueur(5);
            parametresCreation.InformationsCdcPourCreation.CdcLigneDirecte
                .Valider(nameof(parametresCreation.InformationsCdcPourCreation.CdcLigneDirecte)).Obligatoire().Longueur(10);
            parametresCreation.InformationsCdcPourCreation.CdcNomPrenom
                .Valider(nameof(parametresCreation.InformationsCdcPourCreation.CdcNomPrenom)).Obligatoire();
            parametresCreation.RegionCdc
                .Valider(nameof(parametresCreation.RegionCdc)).NonNull();
            parametresCreation.ReferenceExterne
                .Valider(nameof(parametresCreation.ReferenceExterne)).Obligatoire();

            // Assignation des valeurs.
            this.Cle = parametresCreation.Cle;
            this.CleDossierGbo = parametresCreation.CleDossierGbo;
            this.CdcAdresseMail = parametresCreation.InformationsCdcPourCreation.CdcAdresseMail;
            this.CdcCodeBanque = parametresCreation.InformationsCdcPourCreation.CdcCodeBanque;
            this.CdcCodeBranche = parametresCreation.InformationsCdcPourCreation.CdcCodeBranche;
            this.CdcLigneDirecte = parametresCreation.InformationsCdcPourCreation.CdcLigneDirecte;
            this.CdcNomPrenom = parametresCreation.InformationsCdcPourCreation.CdcNomPrenom;
            this.RegionCdc = parametresCreation.RegionCdc;
            this.ReferenceExterne = parametresCreation.ReferenceExterne;
            this.TypeFormulaireGbo = TypeFormulaireGBO.NonDefini;

            if (listePiecesJointes != null)
            {
                ListePiecesJointes = listePiecesJointes;
            }
        }

        #endregion Constructeurs

    }
}