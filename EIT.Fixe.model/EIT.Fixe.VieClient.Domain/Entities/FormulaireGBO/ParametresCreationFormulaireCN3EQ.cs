﻿using System;
using System.Runtime.Serialization;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de niveau 3 d'engagement qualité.
    /// </summary>
    public class ParametresCreationFormulaireCN3EQ : ParametresCreationFormulaireGbo
    {
        #region Attributs

        /// <summary>
        /// Nature de la demande d'intervention.
        /// </summary>
        public virtual NatureDemandeIntervention NatureDemandeIntervention { get; set; }

        /// <summary>
        /// Informations supplémentaires d'un Formulaire de niveau 3 d'engagement qualité pour sa création.
        /// </summary>
        public virtual InformationsSupplementairesCN3EqPourCreation InformationsSupplementairesCN3EqPourCreation { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametresCreationFormulaireGBO">Paramètres de création du formulaire GBO.</param>
        /// <param name="informationsSupplementairesCN3EqPourCreation">Informations supplémentaires d'un Formulaire de niveau 3 d'engagement qualité pour sa création.</param>
        /// <param name="natureDemandeIntervention">Nature de la demande d'intervention.</param>
        public ParametresCreationFormulaireCN3EQ(
            ParametresCreationFormulaireGbo parametresCreationFormulaireGBO,
            InformationsSupplementairesCN3EqPourCreation informationsSupplementairesCN3EqPourCreation,
            NatureDemandeIntervention natureDemandeIntervention)
            : base(
                parametresCreationFormulaireGBO.Cle,
                parametresCreationFormulaireGBO.CleDossierGbo,
                parametresCreationFormulaireGBO.RegionCdc,
                parametresCreationFormulaireGBO.InformationsCdcPourCreation,
                parametresCreationFormulaireGBO.ReferenceExterne)
        {
            // Vérification des paramètres entrants.
            parametresCreationFormulaireGBO.Valider(nameof(parametresCreationFormulaireGBO)).NonNull();
            informationsSupplementairesCN3EqPourCreation.Valider(nameof(informationsSupplementairesCN3EqPourCreation)).NonNull();
            natureDemandeIntervention.Valider(nameof(natureDemandeIntervention)).NonNull();
            informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier.Valider(nameof(informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier)).Obligatoire();
            informationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2.Valider(nameof(informationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2)).NonNul();
            informationsSupplementairesCN3EqPourCreation.RaisonContestation.Valider(nameof(informationsSupplementairesCN3EqPourCreation.RaisonContestation)).Obligatoire();
            informationsSupplementairesCN3EqPourCreation.DemandeClient.Valider(nameof(informationsSupplementairesCN3EqPourCreation.DemandeClient)).Obligatoire();
            informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees.Valider(nameof(informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees)).Obligatoire();

            // Assignation des valeurs.
            this.InformationsSupplementairesCN3EqPourCreation = informationsSupplementairesCN3EqPourCreation;
            this.NatureDemandeIntervention = natureDemandeIntervention;
        }

        #endregion Constructeurs

    }
}