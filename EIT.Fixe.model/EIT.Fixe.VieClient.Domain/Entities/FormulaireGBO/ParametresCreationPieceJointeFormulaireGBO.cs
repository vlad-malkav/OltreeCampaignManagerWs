﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Paramètres de création d'une Pièce Jointe de Formulaire GBO.
    /// </summary>
    public class ParametresCreationPieceJointeFormulaireGbo
    {
        #region Attributs
        /// <summary>
        /// Clé technique d'une Pièce Jointe de Formulaire GBO.
        /// </summary>
        public virtual long Cle { get; set; }

        /// <summary>
        /// GUDOCID.
        /// </summary>
        public virtual string GuDocId { get; set; }

        /// <summary>
        /// Nom du fichier.
        /// </summary>
        public virtual string NomFichier { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cle">Clé technique d'une Pièce Jointe de Formulaire GBO.</param>
        /// <param name="guDocId">GUDOCID.</param>
        /// <param name="nomFichier">Nom du fichie.</param>
        public ParametresCreationPieceJointeFormulaireGbo(long cle, string guDocId, string nomFichier)
        {
            // Vérification des paramètres entrants.
            cle.Valider(nameof(cle)).StrictementPositif();
            guDocId.Valider(nameof(guDocId)).Obligatoire();
            nomFichier.Valider(nameof(nomFichier)).Obligatoire();

            // Assignation des valeurs.
            this.Cle = cle;
            this.GuDocId = guDocId;
            this.NomFichier = nomFichier;
        }

        #endregion Constructeurs
    }
}