﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Paramètres de création du Formulaire GBO.
    /// </summary>
    public class ParametresCreationFormulaireGbo
    {
        #region Attributs

        /// <summary>
        /// Clé technique du Formulaire GBO.
        /// </summary>
        public virtual long Cle { get; set; }

        /// <summary>
        /// Clé technique du Dossier GBO associé au Formulaire.
        /// </summary>
        public virtual long CleDossierGbo { get; set; }

        /// <summary>
        /// Région du Chargé de Clientèle.
        /// </summary>
        public virtual RegionCDC RegionCdc { get; set; }

        /// <summary>
        /// Informations d’un CDC pour création (Formulaire GBO).
        /// </summary>
        public virtual InformationsCdcPourCreation InformationsCdcPourCreation { get; set; }

        /// <summary>
        /// Référence Externe client.
        /// </summary>
        public string ReferenceExterne { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO.</param>
        /// <param name="cleDossierGBO">Clé technique du Dossier GBO associé au Formulaire.</param>
        /// <param name="informationsCDCPourCreation">Informations d’un CDC pour création (Formulaire GBO).</param>
        public ParametresCreationFormulaireGbo(long cle, long cleDossierGbo, RegionCDC regionCDC, InformationsCdcPourCreation informationsCdcPourCreation, string referenceExterne)
        {
            // Vérification des paramètres entrants.
            cle.Valider(nameof(cle)).StrictementPositif();
            cleDossierGbo.Valider(nameof(cleDossierGbo)).StrictementPositif();
            regionCDC.Valider(nameof(regionCDC)).NonNull();
            informationsCdcPourCreation.Valider(nameof(informationsCdcPourCreation)).NonNull();
            informationsCdcPourCreation.CdcAdresseMail.Valider(nameof(informationsCdcPourCreation.CdcAdresseMail)).Obligatoire();
            informationsCdcPourCreation.CdcCodeBanque.Valider(nameof(informationsCdcPourCreation.CdcCodeBanque)).Obligatoire().Longueur(5);
            informationsCdcPourCreation.CdcCodeBranche.Valider(nameof(informationsCdcPourCreation.CdcCodeBranche)).Obligatoire().Longueur(5);
            informationsCdcPourCreation.CdcLigneDirecte.Valider(nameof(informationsCdcPourCreation.CdcLigneDirecte)).Obligatoire().Longueur(10);
            informationsCdcPourCreation.CdcNomPrenom.Valider(nameof(informationsCdcPourCreation.CdcNomPrenom)).Obligatoire();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Assignation des valeurs.
            this.Cle = cle;
            this.CleDossierGbo = cleDossierGbo;
            this.RegionCdc = regionCDC;
            this.InformationsCdcPourCreation = informationsCdcPourCreation;
            this.ReferenceExterne = referenceExterne;
        }

        #endregion Constructeurs
    }
}