﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de niveau 2 de demande d'intervention.
    /// </summary>
    [CustomTableName("T_FRM_GBO_CN2DI")]
    public class FormulaireCN2DI : FormulaireGBO
    {
        #region Attributs

        /// <summary>
        /// Nom client.
        /// </summary>
        [CustomColumnName("NOMCLIENT")]
        public virtual string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [CustomColumnName("PRENOMCLIENT")]
        public virtual string PrenomClient { get; set; }

        /// <summary>
        /// Numéro commande client.
        /// </summary>
        [CustomColumnName("NUMEROCOMMANDECLIENT")]
        public virtual string NumeroCommandeClient { get; set; }

        /// <summary>
        /// Motif du dysfonctionnement.
        /// </summary>
        [CustomColumnName("CLEMOTIFDYSFONCTIONNEMENT")]
        public virtual MotifDysfonctionnement MotifDysfonctionnement { get; set; }

        /// <summary>
        /// Origine du dysfonctionnement.
        /// </summary>
        [CustomColumnName("CLEORIGINEDYSFONCTIONNEMENT")]
        public virtual OrigineDysfonctionnement OrigineDysfonctionnement { get; set; }

        /// <summary>
        /// Date approximative d'appel du service client.
        /// </summary>
        [CustomColumnName("DATEAPPROXAPPELSERVICECLIENT")]
        public virtual DateTime DateApproxAppelServiceClient { get; set; }

        /// <summary>
        /// Raisons du dysfonctionnement.
        /// </summary>
        [CustomColumnName("RAISONSDYSFONCTIONNEMENT")]
        public virtual string RaisonsDysfonctionnement  { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        [CustomColumnName("DEMANDECLIENT")]
        public virtual string DemandeClient  { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        [CustomColumnName("SOLUTIONSDEJAAPPORTEES")]
        public virtual string SolutionsDejaApportees  { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected FormulaireCN2DI()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire de niveau 2 de demande d'intervention.</param>
        public FormulaireCN2DI(Identite identite, ParametresCreationFormulaireCN2DI parametresCreation, List<PieceJointeFormulaireGbo> listePiecesJointes)
            : base(identite, parametresCreation, listePiecesJointes)
        {
            // Vérification des paramètres entrants.
            parametresCreation.InformationsClientPourCreation
                .Valider(nameof(parametresCreation.InformationsClientPourCreation)).NonNull();
            parametresCreation.InformationsSupplementairesCN2DiPourCreation
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN2DiPourCreation)).NonNull();
            parametresCreation.MotifDysfonctionnement
                .Valider(nameof(parametresCreation.MotifDysfonctionnement)).NonNull();
            parametresCreation.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient)).NonNul();
            parametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement)).Obligatoire();
            parametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient)).Obligatoire();
            parametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees
                .Valider(nameof(parametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees)).Obligatoire();

            // Assignation des valeurs.
            this.NomClient = parametresCreation.InformationsClientPourCreation.NomClient;
            this.PrenomClient = parametresCreation.InformationsClientPourCreation.PrenomClient;
            this.NumeroCommandeClient = parametresCreation.InformationsSupplementairesCN2DiPourCreation.NumeroCommandeClient;
            this.MotifDysfonctionnement = parametresCreation.MotifDysfonctionnement;
            this.OrigineDysfonctionnement = parametresCreation.OrigineDysfonctionnement;
            this.DateApproxAppelServiceClient = parametresCreation.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient;
            this.RaisonsDysfonctionnement = parametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement;
            this.DemandeClient = parametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient;
            this.SolutionsDejaApportees = parametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees;
            this.TypeFormulaireGbo = TypeFormulaireGBO.FormulaireCN2DI;
        }

        #endregion Constructeurs

    }
}