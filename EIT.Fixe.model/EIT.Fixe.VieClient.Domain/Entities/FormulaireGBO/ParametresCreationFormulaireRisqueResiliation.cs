﻿using System;
using System.Runtime.Serialization;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de risque de résiliation.
    /// </summary>
    public class ParametresCreationFormulaireRisqueResiliation : ParametresCreationFormulaireGbo
    {
        #region Attributs

        /// <summary>
        /// Informations d’un Client pour création (Formulaire GBO).
        /// </summary>
        public virtual InformationsClientPourCreation InformationsClientPourCreation { get; set; }

        /// <summary>
        /// Offre client.
        /// </summary>
        public virtual string OffreClient { get; set; }

        /// <summary>
        /// Motif de risque de résiliation.
        /// </summary>
        public virtual MotifQualification MotifQualification { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        public virtual string Commentaire  { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametresCreationFormulaireGBO">Paramètres de création du formulaire GBO.</param>
        /// <param name="informationsClientPourCreation">Informations d’un Client pour création (Formulaire GBO).</param>
        /// <param name="offreClient">Offre client.</param>
        /// <param name="motifQualification">Motif de risque de résiliation.</param>
        /// <param name="commentaire"Commentaire.</param>
        public ParametresCreationFormulaireRisqueResiliation(
            ParametresCreationFormulaireGbo parametresCreationFormulaireGBO,
            InformationsClientPourCreation informationsClientPourCreation,
             string offreClient,
             MotifQualification motifQualification,
             string commentaire)
            : base(
                parametresCreationFormulaireGBO.Cle,
                parametresCreationFormulaireGBO.CleDossierGbo,
                parametresCreationFormulaireGBO.RegionCdc,
                parametresCreationFormulaireGBO.InformationsCdcPourCreation,
                parametresCreationFormulaireGBO.ReferenceExterne)
        {
            // Vérification des paramètres entrants.
            parametresCreationFormulaireGBO.Valider(nameof(parametresCreationFormulaireGBO)).NonNull();
            informationsClientPourCreation.Valider(nameof(informationsClientPourCreation)).NonNull();
            motifQualification.Valider(nameof(motifQualification)).NonNull();
            commentaire.Valider(nameof(commentaire)).Obligatoire();

            // Assignation des valeurs.
            this.InformationsClientPourCreation = informationsClientPourCreation;
            this.OffreClient = offreClient;
            this.MotifQualification = motifQualification;
            this.Commentaire = commentaire;
        }

        #endregion Constructeurs

    }
}