﻿using System;
using System.Runtime.Serialization;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de niveau 2 de demande d'intervention.
    /// </summary>
    public class ParametresCreationFormulaireCN2DI : ParametresCreationFormulaireGbo
    {
        #region Attributs

        /// <summary>
        /// Informations d’un Client pour création (Formulaire GBO).
        /// </summary>
        public virtual InformationsClientPourCreation InformationsClientPourCreation { get; set; }

        /// <summary>
        /// Informations supplémentaires d'un Formulaire de niveau 2 de demande d'intervention pour sa création.
        /// </summary>
        public virtual InformationsSupplementairesCN2DiPourCreation InformationsSupplementairesCN2DiPourCreation { get; set; }

        /// <summary>
        /// Motif du dysfonctionnement.
        /// </summary>
        public virtual MotifDysfonctionnement MotifDysfonctionnement { get; set; }

        /// <summary>
        /// Origine du dysfonctionnement.
        /// </summary>
        public virtual OrigineDysfonctionnement OrigineDysfonctionnement { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="parametresCreationFormulaireGBO">Paramètres de création du formulaire GBO.</param>
        /// <param name="informationsClientPourCreation">Informations d’un Client pour création (Formulaire GBO).</param>
        /// <param name="informationsSupplementairesCN2DiPourCreation">Informations supplémentaires d'un Formulaire de niveau 2 de demande d'intervention pour sa création.</param>
        /// <param name="motifDysfonctionnement">Motif du dysfonctionnement.</param>
        /// <param name="origineDysfonctionnement">Origine du dysfonctionnement.</param>
        public ParametresCreationFormulaireCN2DI(
            ParametresCreationFormulaireGbo parametresCreationFormulaireGBO,
            InformationsClientPourCreation informationsClientPourCreation,
            InformationsSupplementairesCN2DiPourCreation informationsSupplementairesCN2DiPourCreation,
            MotifDysfonctionnement motifDysfonctionnement,
            OrigineDysfonctionnement origineDysfonctionnement)
            : base(
                parametresCreationFormulaireGBO.Cle,
                parametresCreationFormulaireGBO.CleDossierGbo,
                parametresCreationFormulaireGBO.RegionCdc,
                parametresCreationFormulaireGBO.InformationsCdcPourCreation,
                parametresCreationFormulaireGBO.ReferenceExterne)
        {
            // Vérification des paramètres entrants.
            parametresCreationFormulaireGBO.Valider(nameof(parametresCreationFormulaireGBO)).NonNull();
            informationsClientPourCreation.Valider(nameof(informationsClientPourCreation)).NonNull();
            informationsSupplementairesCN2DiPourCreation.Valider(nameof(informationsSupplementairesCN2DiPourCreation)).NonNull();
            motifDysfonctionnement.Valider(nameof(motifDysfonctionnement)).NonNull();
            informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement.Valider(nameof(informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement)).Obligatoire();
            informationsSupplementairesCN2DiPourCreation.DemandeClient.Valider(nameof(informationsSupplementairesCN2DiPourCreation.DemandeClient)).Obligatoire();
            informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees.Valider(nameof(informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees)).Obligatoire();

            // Assignation des valeurs.
            this.InformationsClientPourCreation = informationsClientPourCreation;
            this.InformationsSupplementairesCN2DiPourCreation = informationsSupplementairesCN2DiPourCreation;
            this.MotifDysfonctionnement = motifDysfonctionnement;
            this.OrigineDysfonctionnement = origineDysfonctionnement;
        }

        #endregion Constructeurs
    }
}