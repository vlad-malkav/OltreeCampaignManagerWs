﻿using System;
using System.Runtime.Serialization;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe métier du Formulaire de risque de résiliation.
    /// </summary>
    [CustomTableName("T_FRM_GBO_RIS_RSL")]
    public class FormulaireRisqueResiliation : FormulaireGBO
    {
        #region Attributs

        /// <summary>
        /// Nom client.
        /// </summary>
        [CustomColumnName("NOMCLIENT")]
        public virtual string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [CustomColumnName("PRENOMCLIENT")]
        public virtual string PrenomClient { get; set; }

        /// <summary>
        /// Offre client.
        /// </summary>
        [CustomColumnName("OFFRECLIENT")]
        public virtual string OffreClient { get; set; }

        /// <summary>
        /// Motif de risque de résiliation.
        /// </summary>
        [CustomColumnName("CLEMOTIFRISQUERESILIATION")]
        public virtual MotifQualification MotifQualification { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        [CustomColumnName("COMMENTAIRE")]
        public virtual string Commentaire  { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected FormulaireRisqueResiliation()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="parametresCreation">Paramètres de création du Formulaire de niveau 2 de demande d'intervention.</param>
        public FormulaireRisqueResiliation(Identite identite, ParametresCreationFormulaireRisqueResiliation parametresCreation)
            : base(identite, parametresCreation)
        {
            // Vérification des paramètres entrants.
            parametresCreation.InformationsClientPourCreation.Valider(nameof(parametresCreation.InformationsClientPourCreation)).NonNull();
            parametresCreation.MotifQualification.Valider(nameof(parametresCreation.MotifQualification)).NonNull();
            parametresCreation.Commentaire.Valider(nameof(parametresCreation.Commentaire)).Obligatoire();

            // Assignation des valeurs.
            this.NomClient = parametresCreation.InformationsClientPourCreation.NomClient;
            this.PrenomClient = parametresCreation.InformationsClientPourCreation.PrenomClient;
            this.OffreClient = parametresCreation.OffreClient;
            this.MotifQualification = parametresCreation.MotifQualification;
            this.Commentaire = parametresCreation.Commentaire;
            this.TypeFormulaireGbo = TypeFormulaireGBO.FormulaireRisqueResiliation;
        }

        #endregion Constructeurs

    }
}