﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe des historiques d'états de la demande de remise.
    /// </summary>
    [CustomTableName("T_DMDREM_HISETA")]
    public class HistoriqueEtatDemandeRemise : Entity
    {
        #region Membres

        /// <summary>
        /// Clé unique de l'historique de l'état.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; protected set; }

        /// <summary>
        /// Nouvel état.
        /// </summary>
        [CustomColumnName("ETAT")]
        public virtual EtatDemandeRemise NouvelEtat { get; protected set; }

        /// <summary>
        /// Canal par lequel a été effectué le changement d'état.
        /// </summary>
        [CustomColumnName("CANAL")]
        public virtual Canal Canal { get; protected set; }

        /// <summary>
        /// Date de création de l'hitorique.
        /// </summary>
        [CustomColumnName("DATECHANGEMENTETAT")]
        public virtual DateTime DateChangementEtat { get; protected set; }

        /// <summary>
        /// Agent à l'origine du changement d'état.
        /// </summary>
        [CustomColumnName("AGENTMODIFICATION")]
        public virtual string AgentModification { get; protected set; }

        #endregion Membres

        #region Constructeurs

        /// <summary>
        /// Constructeur par defaut.
        /// </summary>
        protected HistoriqueEtatDemandeRemise()
        { }

        /// <summary>
        /// Constructeur d'initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cle">Clé de l'entité.</param>
        /// <param name="nouvelEtat">Nouvel état de l'entité.</param>
        public HistoriqueEtatDemandeRemise(Identite identite, long cle, EtatDemandeRemise nouvelEtat)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            nouvelEtat.Valider<Enum>(nameof(nouvelEtat)).NonAttribuee();

            // Affectation des valeurs.
            this.Cle = cle;
            this.NouvelEtat = nouvelEtat;
            this.DateChangementEtat = DateTime.Now;
            this.AgentModification = identite.Memoid;
            this.Canal = identite.Canal;
        }

        #endregion Constructeurs
    }
}