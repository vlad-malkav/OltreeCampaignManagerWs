﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe des KitBox.
    /// </summary>
    [CustomTableName("T_LIG_KITBOX")]
    public class KitBox : Entity
    {
        #region Attributs
        /// <summary>
        /// Cle.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Cle du KitBox.
        /// </summary>
        [CustomColumnName("CLEKITBOX")]
        public virtual long CleKitBox { get; set; }

        /// <summary>
        /// Le KitBox est-il actif.
        /// </summary>
        [CustomColumnName("ESTACTIF")]
        public virtual bool EstActif { get; set; }

        /// <summary>
        /// Date de creation.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent de creation.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de la derniere modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        /// <summary>
        /// Agent de la derniere modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }
        #endregion Attributs

        #region Constructeurs
        /// <summary>
        /// Constructeurs par defaut.
        /// </summary>
        protected KitBox() { }

        /// <summary>
        /// Constructeur
        /// </summary>
        /// <param name="identite">Identite de l'appelant.</param>
        /// <param name="cle">Cle.</param>
        /// <param name="cleKitBox">Cle du KitBox.</param>
        public KitBox(Identite identite, long cle, long cleKitBox)
        {
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            cleKitBox.Valider(nameof(cleKitBox)).StrictementPositif();

            this.Cle = cle;
            this.CleKitBox = cleKitBox;
            this.EstActif = true;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviDateCreation = DateTime.Now;
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }
        #endregion Constructeurs
    }
}
