﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier d'un historique d'état d'une ligne fixe.
    /// </summary>
    [CustomTableName("T_LIG_HISETA")]
    public class HistoriqueEtatLigne : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé de l’historique.
        /// </summary>
        [CustomColumnName("CLE")]
        [Key]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Etat de la ligne avant modification.
        /// </summary>
        [CustomColumnName("ANCIENTETATLIGNE")]
        public virtual EtatLigne AncienEtat { get; set; }

        /// <summary>
        /// Nouvel état de la ligne.
        /// </summary>
        [CustomColumnName("NOUVELETATLIGNE")]
        public virtual EtatLigne NouvelEtat { get; set; }

        /// <summary>
        /// Canal par lequel a été effectué le changement d’état.
        /// </summary>
        [CustomColumnName("CANAL")]
        public virtual  Canal Canal { get; set; }

        /// <summary>
        /// Date de création de cet état.
        /// </summary>
        [CustomColumnName("DATECHANGEMENTETAT")]
        public virtual DateTime DateChangementEtat { get; set; }

        /// <summary>
        /// Agent de création.
        /// </summary>
        [CustomColumnName("AGENTMODIFICATION")]
        public virtual string AgentModification { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected HistoriqueEtatLigne()
        { }

        /// <summary>
        /// Constructeur d’initialisation.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="cle">Clé technique de l'historique d'état.</param>
        /// <param name="ancienEtat">Ancien état de la ligne fixe.</param>
        /// <param name="nouvelEtat">Nouvel état de la ligne fixe.</param>
        public HistoriqueEtatLigne(Identite identite, long cle, EtatLigne ancienEtat, EtatLigne nouvelEtat)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();
            nouvelEtat.Valider<Enum>(nameof(nouvelEtat)).NonAttribuee();

            // Assignation des valeurs.
            this.Cle = cle;
            this.AncienEtat = ancienEtat;
            this.NouvelEtat = nouvelEtat;
            this.Canal = identite.Canal;
            this.DateChangementEtat = DateTime.Now;
            this.AgentModification = identite.Memoid;
        }

        #endregion Constructeurs
    }
}