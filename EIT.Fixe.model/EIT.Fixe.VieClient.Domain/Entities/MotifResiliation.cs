﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier décrivant un motif de résiliation.
    /// </summary>
    [CustomTableName("T_MTFRSL")]
    public class MotifResiliation : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire du motif de résiliation.
        /// </summary>
        [CustomColumnName("CLE")]
        [Key]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Libellé du motif de résiliation.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        /// <summary>
        /// Ordre d'affichage des motifs de résiliation.
        /// </summary>
        [CustomColumnName("ORDRE")]
        public virtual int Ordre { get; set; }

        /// <summary>
        /// Origine de la résiliation.
        /// </summary>
        [CustomColumnName("ORIGINERESILIATION")]
        public virtual OrigineResiliation OrigineResiliation { get; set; }

        /// <summary>
        /// Type de la résiliation.
        /// </summary>
        [CustomColumnName("TYPERESILIATION")]
        public virtual TypeResiliation TypeResiliation { get; set; }

        /// <summary>
        /// Liste des modes de retour équipement liés au motif de résiliation.
        /// </summary>
        [OneToMany]
        [CustomColumnName("CLEMOTIFRESILIATION")]
        public virtual ICollection<ModeRetourEquipement> ListeModeRetourEquipement { get; set; }

        /// <summary>
        /// Délai de résiliation.
        /// </summary>
        [CustomColumnName("DELAIRESILIATION")]
        public virtual int DelaiResiliation { get; set; }

        /// <summary>
        /// Indique si des frais de résiliation sont appliqués.
        /// </summary>
        [CustomColumnName("ESTFRAISRESILIATIONAPPLIQUES")]
        public virtual bool EstFraisResiliationAppliques { get; set; }

        /// <summary>
        /// Indique si l'ouverture du retour colis est nécessaire.
        /// </summary>
        [CustomColumnName("ESTOUVERTURERETCOLNECESSAIRE")]
        public virtual bool EstOuvertureRetourColisNecessaire { get; set; }

        /// <summary>
        /// Code article.
        /// </summary>
        [CustomColumnName("CODEARTICLE")]
        public virtual string CodeArticle { get; set; }

        /// <summary>
        /// Date de création du motif de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'initiative de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de dernière modification du motif de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        /// <summary>
        /// Agent à l'initiative de la dernière modification du motif de résiliation.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        #endregion Attributs
    }
}