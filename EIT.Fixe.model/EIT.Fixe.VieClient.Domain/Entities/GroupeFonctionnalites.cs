﻿using EIT.DataAccess.EntityFramework.AutoMapping.Attributes;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EIT.Fixe.VieClient.Domain.Entities
{
    /// <summary>
    /// Classe métier des groupes de fonctionnalités.
    /// </summary>
    [CustomTableName("T_GRPFCT")]
    public class GroupeFonctionnalites : Entity
    {
        #region Attributs

        /// <summary>
        /// Clé primaire.
        /// </summary>
        [Key]
        [CustomColumnName("CLE")]
        public virtual long Cle { get; set; }

        /// <summary>
        /// Code du groupe de fonctionnalités.
        /// </summary>
        [CustomColumnName("CODE")]
        public virtual string Code { get; set; }

        /// <summary>
        /// Libellé du groupe de fonctionnalités.
        /// </summary>
        [CustomColumnName("LIBELLE")]
        public virtual string Libelle { get; set; }

        /// <summary>
        /// Description du groupe de fonctionnalités.
        /// </summary>
        [CustomColumnName("DESCRIPTION")]
        public virtual string Description { get; set; }

        /// <summary>
        /// Indique si le groupe de fonctionnalités est actif.
        /// </summary>
        [CustomColumnName("ESTACTIF")]
        public virtual bool EstActif { get; set; }

        /// <summary>
        /// Fonctionnalités associées à ce groupe de fonctionnalités.
        /// </summary>
        [CustomAssociationTable("T_GRPFCT_FCT", "CLEGROUPEFONCTIONNALITE", "CLEFONCTIONNALITE")]
        public virtual ICollection<Fonctionnalite> ListeFonctionnalites { get; set; }

        /// <summary>
        /// Agent à l'origine de la création.
        /// </summary>
        [CustomColumnName("SUIVIAGENTCREATION")]
        public virtual string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de la création.
        /// </summary>
        [CustomColumnName("SUIVIDATECREATION")]
        public virtual DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent à l'origine de la modification.
        /// </summary>
        [CustomColumnName("SUIVIAGENTMODIFICATION")]
        public virtual string SuiviAgentModification { get; set; }

        /// <summary>
        /// Date de modification.
        /// </summary>
        [CustomColumnName("SUIVIDATEMODIFICATION")]
        public virtual DateTime SuiviDateModification { get; set; }

        #endregion Attributs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected GroupeFonctionnalites()
        {

        }

        /// <summary>
        /// Constructeur pour l'instanciation d'un groupe de fonctionnalités.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreGroupeFonctionnalitesPourCreation">Paramètres pour la création d'un groupe de fonctionnalités.</param>
        /// <param name="fonctionnalites">Liste de fonctionnalités.</param>
        public GroupeFonctionnalites(Identite identite, ParametreGroupeFonctionnalitesPourCreation parametreGroupeFonctionnalitesPourCreation, List<Fonctionnalite> fonctionnalites)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametreGroupeFonctionnalitesPourCreation.Valider(nameof(parametreGroupeFonctionnalitesPourCreation)).NonNul();
            parametreGroupeFonctionnalitesPourCreation.Code.Valider(nameof(parametreGroupeFonctionnalitesPourCreation.Code)).LongueurMax(40);
            parametreGroupeFonctionnalitesPourCreation.Libelle.Valider(nameof(parametreGroupeFonctionnalitesPourCreation.Libelle)).LongueurMax(40);
            parametreGroupeFonctionnalitesPourCreation.Description.Valider(nameof(parametreGroupeFonctionnalitesPourCreation.Description)).LongueurMax(100);

            // Affectation des données.
            this.Cle = parametreGroupeFonctionnalitesPourCreation.Cle;
            this.Code = parametreGroupeFonctionnalitesPourCreation.Code;
            this.Libelle = parametreGroupeFonctionnalitesPourCreation.Libelle;
            this.Description = parametreGroupeFonctionnalitesPourCreation.Description;
            this.SuiviDateCreation = parametreGroupeFonctionnalitesPourCreation.SuiviDateCreation;
            this.SuiviDateModification = parametreGroupeFonctionnalitesPourCreation.SuiviDateCreation;
            this.SuiviAgentCreation = identite.Memoid;
            this.SuiviAgentModification = identite.Memoid;
            this.EstActif = parametreGroupeFonctionnalitesPourCreation.EstActif;

            if (fonctionnalites != null)
            {
                this.ListeFonctionnalites = fonctionnalites;
            }

        }

        #endregion Constructeurs

        #region Méthodes

        /// <summary>
        /// Méthode qui permet d'ajouter une fonctionnalité au groupe de fonctionnalités.
        /// </summary>
        /// <param name="fonctionnalite">Fonctionnalité à ajouter.</param>
        public void AjouterFonctionnalite(Fonctionnalite fonctionnalite)
        {
            //Vérification des entrées.
            fonctionnalite.Valider(nameof(fonctionnalite)).NonNul();

            if(this.ListeFonctionnalites == null)
            {
                this.ListeFonctionnalites = new List<Fonctionnalite>();
            }

            this.ListeFonctionnalites.Add(fonctionnalite);
        }

        /// <summary>
        /// Méthode qui permet de désactiver le groupe de fonctionnalités.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        public void Desactiver(Identite identite)
        {
            identite.Valider(nameof(identite)).NonNul();

            this.EstActif = false;
            this.SuiviAgentModification = identite.Memoid;
            this.SuiviDateModification = DateTime.Now;
        }

        #endregion Méthodes
    }
}
