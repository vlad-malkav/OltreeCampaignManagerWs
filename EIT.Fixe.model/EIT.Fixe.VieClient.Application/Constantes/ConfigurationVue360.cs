﻿namespace EIT.Fixe.VieClient.Application.Constantes
{
    /// <summary>
    /// Valeurs de configuration de la Vue 360.
    /// </summary>
    internal static class ConfigurationVue360
    {
        /// <summary>
        /// Nombre de lignes maximum à charger dans un compte client mobile de la Vue 360.
        /// </summary>
        /// <remarks>Au delà de ce nombre, les lignes seront à charger sur demande de l'utilisateur.</remarks>
        internal const int NOMBRE_LIGNES_MAXIMUM_COMPTE_CLIENT_MOBILE = 10;
    }
}