﻿using EIT.Fixe.Domain.Historique;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversion d'historique, pour création.
    /// </summary>
    public static class HistoriquePourCreationMapper
    {
        /// <summary>
        /// Conversion d'un historique de type Appel pour création.
        /// </summary>
        /// <param name="historiquePourCreation">Informations à convertir (partagé).</param>
        /// <returns>Informations de l'historique Appel, propre à Vie Client.</returns>
        public static HistoriqueAppelPourCreation Convertir(Interface.DTO.HistoriquePourCreation historiquePourCreation)
        {
            if (historiquePourCreation == null)
            {
                return null;
            }

            HistoriqueFonctionnelPourCreation historiqueFonctionnel = new HistoriqueFonctionnelPourCreation
            {
                CleMetier1 = (TypeHistoriqueMetierNiveau1)historiquePourCreation.CleMetier1,
                CleMetier2 = (TypeHistoriqueMetierNiveau2)historiquePourCreation.CleMetier2,
                Commentaire = historiquePourCreation.Commentaire,
                CleOrigine = historiquePourCreation.CleOrigine
            };

            return new HistoriqueAppelPourCreation()
            {
                HistoriqueFonctionnel = historiqueFonctionnel,
                CleCanalMedia = historiquePourCreation.CleCanalMedia,
                CleQualificationAppelNiveau1 = historiquePourCreation.CleQualificationAppelNiveau1,
                CleQualificationAppelNiveau2 = historiquePourCreation.CleQualificationAppelNiveau2,
                DateAppel = historiquePourCreation.DateAppel,
                DureeAppel = historiquePourCreation.DureeAppel,
                NomTiers = historiquePourCreation.NomTiers,
                NumeroTelephoneAppelant = historiquePourCreation.NumeroTelephoneAppelant,
                NumeroTelephoneAppele = historiquePourCreation.NumeroTelephoneAppele,
                PointDeVenteCmi = historiquePourCreation.PointDeVenteCmi,
                PrenomTiers = historiquePourCreation.PrenomTiers
            };
        }
    }
}