﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Conversion de pannes collectives.
    /// </summary>
    public static class PanneCollectiveMapper
    {
        /// <summary>
        /// Convertit une PanneCollecxtive en PanneCollectivePourLister.
        /// </summary>
        /// <param name="panne">Une panne collective.</param>
        /// <returns>Une PanneCollectivePourLister.</returns>
        public static PanneCollectivePourLister ConvertirPourLister(PanneCollective panne)
        {
            if (panne == null)
            {
                return null;
            }

            return new PanneCollectivePourLister
            {
                Cle = panne.Cle,
                DateDebut = panne.DateDebut
            };
        }
    }
}