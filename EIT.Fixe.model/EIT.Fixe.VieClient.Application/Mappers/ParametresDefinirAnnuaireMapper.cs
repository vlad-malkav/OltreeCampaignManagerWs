﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversions d'objet de service externe ParametresDefinirAnnuaire.
    /// </summary>
    public static class ParametresDefinirAnnuaireMapper
    {
        /// <summary>
        /// Converti l'objet de présentation InformationsParutionAnnuaireUniverselPourEnregistrement en un objet de présentation de service externe ParametresDefinirAnnuaire.
        /// </summary>
        /// <param name="InformationAnnuaireAConvertir">Objet à convertir.</param>
        /// <returns>Informations du tiers en TiersPourDetail.</returns>
        public static ParametresDefinirAnnuaire Convertir(InformationsParutionAnnuaireUniverselPourEnregistrement InformationAnnuaireAConvertir)
        {
            if (InformationAnnuaireAConvertir == null)
            {
                return null;
            }

            // Validation des entrées
            InformationAnnuaireAConvertir.ChoixParutionAnnuaire.Valider(nameof(InformationAnnuaireAConvertir.ChoixParutionAnnuaire)).NonNul();

            return new ParametresDefinirAnnuaire()
            {
                CleTiers = InformationAnnuaireAConvertir.CleTiers,
                Profession = ProfessionMapper.Convertir(InformationAnnuaireAConvertir.ChoixParutionAnnuaire.Profession),
                DiffusionEmail = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstEmailDiffuse,
                DiffusionPrenom = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstPrenomDiffuse,
                DiffusionProfession = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstProfessionDiffusee,
                InscriptionAnnuaireInverse = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstInscritAnnuaireInverse,
                LimiterDiffusionAdresseVille = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstAdresseLimiteeAVille,
                UtilisationMarketing = InformationAnnuaireAConvertir.ChoixParutionAnnuaire.EstUtilisationCoordoneesAutoriseePourMarketing               
            };
        }
    }
}