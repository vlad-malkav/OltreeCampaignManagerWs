﻿using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique de conversion des demandes de résiliation.
    /// </summary>
    public static class DemandeResiliationMapper
    {
        public static Domain.CommonTypes.DTO.DemandeResiliationPourCreation Convertir(Interface.DTO.DemandeResiliationPourCreation demande)
        {
            if (demande == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = demande.CleModeRetourEquipement,
                CleMotifResiliation = demande.CleMotifResiliation,
                DateReceptionCourrierAr = demande.DateReceptionCourrierAr,
                EstNouveauTiersEnvoiBonRetour = demande.EstNouveauTiersEnvoiBonRetour,
                Email = demande.Email,
                TiersEnvoiBonRetour = TiersEnvoiBonRetourMapper.Convertir(demande.TiersEnvoiBonRetour),
                DateResiliationProgrammee = demande.DateResiliationProgrammee
            };
        }
    }
}
