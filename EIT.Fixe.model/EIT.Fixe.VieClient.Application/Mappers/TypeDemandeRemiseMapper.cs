﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion vers l'énumération TypeDemandeRemise.
    /// </summary>
    public static class TypeDemandeRemiseMapper
    {
        /// <summary>
        /// Convertit l'énumération de service externe 'EffetPromotion' en énumération de présentation 'TypeDemandeRemise'.
        /// </summary>
        /// <param name="effetPromotion">Enumération à convertir.</param>
        /// <returns>Une énumération TypeDemandeRemise.</returns>
        public static TypeDemandeRemise Convertir(Fixe.Domain.CommonTypes.Enumerations.EffetPromotion effetPromotion)
        {
            switch (effetPromotion)
            {
                case Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.NA:
                    return TypeDemandeRemise.NA;
                case Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurOffre:
                    return TypeDemandeRemise.RemisePromotionSurOffre;
                case Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurPrestation:
                    return TypeDemandeRemise.RemisePromotionSurFrais;
                default:
                    throw new InvalidOperationException($"Impossible de convertir la valeur EffetPromotion.{effetPromotion} en une valeur d'énumération TypeDemandeRemise");
            }

        }
    }
}
