﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique pour la conversion de EquipementPourLister.
    /// </summary>
    public static class EquipementLignePourListerMapper
    {
        /// <summary>
        /// Méthode statique pour convertir equipementLigne en EquipementPourLister.
        /// </summary>
        /// <param name="equipementAConvertir"></param>
        /// <returns></returns>
        public static EquipementLignePourLister Convertir(EquipementLigne equipementAConvertir)
        {
            if (equipementAConvertir == null)
            {
                return null;
            }

            return new EquipementLignePourLister()
            {
                Cle = equipementAConvertir.CleEquipement,
                CodeRefCom = equipementAConvertir.CodeRefCom                
            };
        }
    }
}
