﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversions d'objet de service externe Profession.
    /// </summary>
    public static class ProfessionMapper
    {
        /// <summary>
        /// Converti l'objet de présentation ProfessionPourLister en un objet de présentation de service externe Profession.
        /// </summary>
        /// <param name="professionPourListerAConvertir">Objet à convertir.</param>
        /// <returns>Informations du tiers en TiersPourDetail.</returns>
        public static ParamProfession Convertir(ProfessionPourLister professionPourListerAConvertir)
        {
            if (professionPourListerAConvertir == null)
            {
                return null;
            }
            
            return new ParamProfession()
            {
                Cle = professionPourListerAConvertir.Cle,
                Libelle = professionPourListerAConvertir.Libelle
            };
        }
    }
}