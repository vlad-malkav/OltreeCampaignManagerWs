﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en CommandePourLister.
    /// </summary>
    public static class CommandePourListerMapper
    {
        /// <summary>
        /// Convertit l'objet de présentation de service externe CommandeSouscriptionPourDetail en un objet de présentation CommandePourLister.
        /// </summary>
        /// <param name="commandeAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation CommandePourLister</returns>
        public static CommandePourLister Convertir(CommandeSouscriptionPourDetail commandeAConvertir)
        {
            if (commandeAConvertir == null)
            {
                return null;
            }
            
            return new CommandePourLister
            {
                Cle = commandeAConvertir.Cle,
                Date = commandeAConvertir.DateCreation,
                EstSyntheseOsafAccessible = true,
                Etat = commandeAConvertir.Etat,
                Numero = commandeAConvertir.Numero,
                TypeCommande = TypeCommande.Souscription
            };
        }
    }
}