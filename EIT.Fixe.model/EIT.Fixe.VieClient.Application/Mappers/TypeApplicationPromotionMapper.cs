﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion vers l'énumération TypeApplicationPromotion.
    /// </summary>
    public static class TypeApplicationPromotionMapper
    {
        /// <summary>
        /// Convertit l'énumération de service externe 'EffetPromotion' en énumération de présentation 'TypeApplicationPromotion'.
        /// </summary>
        /// <param name="effetPromotion">Enumération à convertir.</param>
        /// <returns>Une énumération TypeApplicationPromotion.</returns>
        public static TypeApplicationPromotion Convertir(EffetPromotion effetPromotion)
        {
            switch (effetPromotion)
            {
                case EffetPromotion.NA:
                    return TypeApplicationPromotion.NA;
                case EffetPromotion.SurOffre:
                    return TypeApplicationPromotion.SurOffre;
                case EffetPromotion.SurPrestation:
                    return TypeApplicationPromotion.SurFrais;
                default:
                    throw new InvalidOperationException($"Impossible de convertir la valeur EffetPromotion {effetPromotion} en une valeur d'énumération TypeApplicationPromotion");
            }
        }
    }
}