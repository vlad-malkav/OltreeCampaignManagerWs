﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion de lignes mobiles.
    /// </summary>
    public static class LigneCompteClientMobilePourListerMapper
    {
        /// <summary>
        /// Convertir et enrichi les informations principales d'une ligne mobile de compte client.
        /// </summary>
        /// <param name="ligne">Informations de la ligne.</param>
        /// <param name="login">Login.</param>
        /// <param name="seuil">Seuil de surconsommation.</param>
        /// <param name="niveauAcces">Niveau accès espace client mobile.</param>
        /// <param name="estReseauFull">Est réseau full ou light.</param>
        /// <returns>Informations principales d'une ligne mobile de compte client.</returns>
        public static LigneCompteClientMobilePourLister Convertir(LigneMobilePourLister ligne, string login,
            decimal seuil, string niveauAcces, bool estReseauFull)
        {
            if (ligne == null)
            {
                return null;
            }

            return new LigneCompteClientMobilePourLister()
            {
                Cle = ligne.Cle,
                ScoreChurn = ligne.ScoreChurn,
                Statut = ligne.Statut,
                Numero = ligne.Numero,
                Offre = ligne.LibelleOffre,
                EstSyntheseCrmMobileAccessible = true,
                SeuilSurconsommation = seuil,
                Utilisateur = login,
                EstReseauFull = estReseauFull,
                NiveauAccessEspaceClientMobile = niveauAcces
            };
        }
    }
}