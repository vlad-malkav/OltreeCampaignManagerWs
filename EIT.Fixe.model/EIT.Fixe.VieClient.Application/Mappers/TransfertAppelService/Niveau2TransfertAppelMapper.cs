﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Application.Mappers.TransfertAppelService
{
    /// <summary>
    /// Classe statique pour la convertir des Niveau2.
    /// </summary>
    public static class Niveau2TransfertAppelMapper
    {
        /// <summary>
        /// Méthode statique de convertion du niveau 2.
        /// </summary>
        /// <param name="niveau2">Niveau 2 récupéré d'historique.</param>
        /// <returns>Niveau 2 objet de présentation.</returns>
        public static Niveau2TransfertAppel Convertir(Niveau2QualificationAppel niveau2)
        {
            if (niveau2 == null)
            {
                return null;
            }

            return new Niveau2TransfertAppel()
            {
                Cle = niveau2.Cle,
                Libelle = niveau2.Libelle
            };
        }
    }
}
