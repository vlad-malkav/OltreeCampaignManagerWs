﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Application.Mappers.TransfertAppelService
{
    /// <summary>
    /// Classe de conversion vers l'objet de présentation Niveau1QualificationAppel.
    /// </summary>
    public static class Niveau1TransfertAppelMapper
    {
        /// <summary>
        /// Convertit un objet de présentation de service externe 'Niveau1QualificationAppel' en objet de présentation 'Niveau1QualificationAppel'.
        /// </summary>
        /// <param name="niveau1QualificationAppel">Objet à convertir.</param>
        /// <returns>Niveau 1 objet de présentation.</returns>
        public static Niveau1TransfertAppel Convertir(Niveau1QualificationAppel niveau1QualificationAppel)
        {
            if (niveau1QualificationAppel == null)
            {
                return null;
            }

            return new Niveau1TransfertAppel()
            {
                Cle = niveau1QualificationAppel.Cle,
                Libelle = niveau1QualificationAppel.Libelle
            };

        }
    }
}
