﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Application.Mappers.TransfertAppelService
{
    /// <summary>
    /// Classe de conversion vers l'objet de présentation ThemeTransfertAppel.
    /// </summary>
    public static class ThemeTransfertAppelMapper
    {
        /// <summary>
        /// Convertit un objet de présentation de service externe 'ThemeQualificationAppel' en objet de présentation 'ThemeTransfertAppel'.
        /// </summary>
        /// <param name="themeQualificationAppel">Objet à convertir.</param>
        /// <returns>Un objet de présentation ThemeTransfertAppel.</returns>
        public static ThemeTransfertAppel Convertir(ThemeQualificationAppel themeQualificationAppel)
        {
            if (themeQualificationAppel == null)
            {
                return null;
            }

            return new ThemeTransfertAppel()
            {
                Cle = themeQualificationAppel.Cle,
                Libelle = themeQualificationAppel.Libelle
            };
        }
    }
}