﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en AdresseInstallationPourDetail.
    /// </summary>
    public static class AdresseInstallationPourDetailMapper
    {
        /// <summary>
        /// Converti l'objet de présentation  AdresseInstallationPourDetail en un objet de présentation AdresseInstallationPourDetail.
        /// </summary>
        /// <param name="adresseAConvertir">Objet à convertir.</param>
        /// <returns>AdresseInstallationPourDetail.</returns>
        public static AdresseInstallationPourDetail Convertir(Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseAConvertir)
        {
            if(adresseAConvertir == null)
            {
                return null;
            }
            return new AdresseInstallationPourDetail()
            {
                Cle = adresseAConvertir.Cle,
                CodePostal = adresseAConvertir.CodePostal,
                Numero = adresseAConvertir.Numero,
                Rue = adresseAConvertir.Rue,
                Ville = adresseAConvertir.Ville,
                Complement = adresseAConvertir.Complement,
                Batiment = adresseAConvertir.Batiment,
                Escalier = adresseAConvertir.Escalier,
                Appartement = adresseAConvertir.Appartement,
                Etage = adresseAConvertir.Etage
            };
        }
    }
}
