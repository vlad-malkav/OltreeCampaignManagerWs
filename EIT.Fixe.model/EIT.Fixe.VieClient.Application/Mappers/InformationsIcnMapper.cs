﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversions de l'ICN.
    /// </summary>
    public static class InformationsIcnMapper
    {
        /// <summary>
        /// Converti l'objet de présentation de service externe Icn en un objet de présentation InformationsIcn.
        /// </summary>
        /// <param name="icnAConvertir">Objet à convertir.</param>
        /// <returns>Informations de l'ICN.</returns>
        public static InformationsIcn Convertir(EIT.Fixe.Domain.CommonTypes.Icn icnAConvertir)
        {
            if (icnAConvertir == null)
            {
                return null;
            }

            return new InformationsIcn()
            {
                CodeBanque = icnAConvertir.TiersBanque,
                CodeBureau = icnAConvertir.TiersBureau,
                CodeGuichet = icnAConvertir.TiersCaisse
            };
        }
    }
}