﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en AdressePourDetail.
    /// </summary>
    public static class AdressePourDetailMapper
    {
        /// <summary>
        /// Converti l'objet AdressePourDetail de la brique tiers en AdressePourDetail du domaine Vie Client.
        /// </summary>
        /// <param name="adresseAConvertir">Objet à convertir.</param>
        /// <returns>AdressePourDetail.</returns>
        public static AdressePourDetail Convertir(this Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers adresseAConvertir)
        {
            if(adresseAConvertir == null)
            {
                return null;
            }
            return new AdressePourDetail()
            {
                CodePostal = adresseAConvertir.CodePostal,
                Complement = adresseAConvertir.ComplementIdentification,
                Ville = adresseAConvertir.Ville,
                Voie = adresseAConvertir.Voie
            };
        }
    }
}
