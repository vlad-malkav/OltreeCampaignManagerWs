﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique de conversion des ModeRetourEquipement.
    /// </summary>
    public static class ModeRetourEquipementMapper
    {
        /// <summary>
        /// Méthode statique de conversion de l'entité en objet de présentation.
        /// </summary>
        /// <param name="mode">Mode de retour entité.</param>
        /// <returns>Mode de retour présentation.</returns>
        public static ModeRetourEquipementPourLister Convertir(ModeRetourEquipement mode)
        {
            if (mode == null)
            {
                return null;
            }
            return new ModeRetourEquipementPourLister()
            {
                Cle = mode.Cle,
                EstCocheParDefaut = mode.EstCocheParDefaut,
                EstEnvoiEtiquettePrepayee = mode.EstEnvoiEtiquettePrepayee,
                Libelle = mode.Libelle,
                TypePriseEnCharge = mode.TypePriseEnCharge,
                TypeEnvoi = mode.TypeEnvoi
            };
        }
    }
}
