﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en objet de présentation de type PromotionPourLister.
    /// </summary>
    public static class PromotionPourListerMapper
    {
        /// <summary>
        /// Convertit l'objet de présentation  PromotionPourDetail en un objet de présentation PromotionPourLister.
        /// </summary>
        /// <param name="promotionAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation PromotionPourLister.</returns>
        public static PromotionPourLister Convertir(Domain.CommonTypes.DTO.ReferentielServiceExterne.PromotionPourDetail promotionAConvertir)
        {
            if (promotionAConvertir == null)
            {
                return null;
            }

            return new PromotionPourLister()
            {
                Cle = promotionAConvertir.Cle,
                Descriptif = promotionAConvertir.Descriptif,
                PrixTtc = promotionAConvertir.MontantTtc,
                DureeValiditeEnMois = promotionAConvertir.Duree
            };
        }
    }
}
