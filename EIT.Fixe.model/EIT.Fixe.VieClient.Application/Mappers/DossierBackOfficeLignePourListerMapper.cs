﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion en dossierGBO.
    /// </summary>
    public static class DossierBackOfficeLignePourListerMapper
    {
        /// <summary>
        /// Convertit l'objet de présentation de service externe DossierGboPourLister en un objet de présentation DossierBackOfficeLignePourLister.
        /// </summary>
        /// <param name="dossierGbo">Objet à convertir.</param>
        /// <param name="historiqueDossierGbo">Historique du dossier GBO</param>
        /// <returns>DossierBackOfficeLignePourLister.</returns>
        public static DossierBackOfficeLignePourLister Convertir(DossierGboPourLister dossierGbo, HistoriquePourLister historiqueDossierGbo)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            DossierBackOfficeLignePourLister ret = new DossierBackOfficeLignePourLister()
            {
                Cle = dossierGbo.Cle,
                Activite = dossierGbo.NomActivite,
                Proprietaire = dossierGbo.Proprietaire,
                CommentaireOuverture = dossierGbo.Commentaire,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.Etat,
                EstDetailAccessible = true
            };

            if (historiqueDossierGbo == null)
            {
                return ret;
            }

            ret.Type = historiqueDossierGbo.Type;
            ret.Historique = historiqueDossierGbo.Historique;

            return ret;
        }
    }
}