﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique pour convertir PromotionOffrePourLister.
    /// </summary>
    public static class PromotionOffrePourListerMapper
    {
        /// <summary>
        /// Méthode pour convertir les promotions.
        /// </summary>
        /// <param name="promotion">Promotions du referentiel.</param>
        /// <returns>Promotion à retourner pour VieClient.</returns>
        public static PromotionOffrePourLister Convertir(PromotionPourDetail promotion)
        {
            if (promotion == null)
            {
                return null;
            }

            return new PromotionOffrePourLister()
            {
                Duree = promotion.Duree,
                EstAutomatique = promotion.EstAutomatique.GetValueOrDefault(),
                Libelle = promotion.Descriptif,
                Montant = promotion.MontantTtc
            };
        }
    }
}
