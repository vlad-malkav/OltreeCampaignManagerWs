﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.Entities;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique de conversion des motifs de résiliation.
    /// </summary>
    public static class MotifResiliationMapper
    {
        /// <summary>
        /// Méthode statique pour convertir le motif de résiliation entité en motif de résiliation de présentation.
        /// </summary>
        /// <param name="motif">Motif de résiliation entitée.</param>
        /// <returns>Motif de résiliation DTO.</returns>
        public static MotifResiliationPourLister Convertir(MotifResiliation motif)
        {
            if (motif == null)
            {
                return null;
            }
            List<ModeRetourEquipementPourLister> listeModeRetour = new List<ModeRetourEquipementPourLister>();
            motif.ListeModeRetourEquipement.ToList().ForEach(m => listeModeRetour.Add(ModeRetourEquipementMapper.Convertir(m)));
            return new MotifResiliationPourLister()
            {
                Cle = motif.Cle,
                DelaiResiliation = motif.DelaiResiliation,
                EstFraisResiliationAppliques = motif.EstFraisResiliationAppliques,
                Libelle = motif.Libelle,
                Ordre = motif.Ordre,
                OrigineResiliation = motif.OrigineResiliation,
                TypeResiliation = motif.TypeResiliation,
                ListeModeRetourEquipement = listeModeRetour.ToArray()
            };
        }
    }
}
