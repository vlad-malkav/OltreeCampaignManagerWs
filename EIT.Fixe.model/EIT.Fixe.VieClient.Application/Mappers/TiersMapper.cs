﻿using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversions de tiers.
    /// </summary>
    public static class TiersMapper
    {
        /// <summary>
        /// Converti l'objet de présentation de service externe TiersPourDetail en un objet de présentation TiersPourDetail.
        /// </summary>
        /// <param name="tiers">Objet à convertir.</param>
        /// <returns>Informations du tiers en TiersPourDetail.</returns>
        public static TiersPourDetail Convertir(Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers)
        {
            if (tiers == null)
            {
                return null;
            }

            return new TiersPourDetail()
            {
                AgeCalcule = tiers.DateNaissance.Age(),
                Cle = tiers.Cle,
                Civilite = tiers.CiviliteEnum,
                DateNaissance = tiers.DateNaissance,
                DepartementNaissance = tiers.NumeroDepartementNaissance,
                Email = tiers.EmailContact,
                Nom = tiers.Nom,
                NumeroTelephoneContact = tiers.NumeroMobileDeContact,
                NumeroTelephoneFixeContact = tiers.NumeroFixeDeContact,
                Prenom = tiers.Prenom,
                AdressePrincipale = tiers.ListeAdresses.FirstOrDefault(x => x.EstPrincipale).Convertir(),
                EstContactCourrierPossible = tiers.EstContactCourrierPossible,
                EstContactEmailPossible = tiers.EstContactEmailPossible,
                EstContactMessageVocalPossible = tiers.EstContactMessageVocalPossible,
                EstContactSmsPossible = tiers.EstContactSmsPossible,
                EstContactTeleventePossible = tiers.EstContactTeleventePossible
            };
        }
    }
}