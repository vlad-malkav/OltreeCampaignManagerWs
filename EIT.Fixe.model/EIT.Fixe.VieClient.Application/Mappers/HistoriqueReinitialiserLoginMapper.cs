﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion en objet HistoriqueReinitialiserLogin.
    /// </summary>
    public static class HistoriqueReinitialiserLoginMapper
    {
        /// <summary>
        /// Méthode de conversion de HistoriqueReinitialiserLogin en HistoriqueReinitialiserLoginPourLister.
        /// </summary>
        /// <param name="historiqueAConvertir">HistoriqueReinitialiserLogin à convertir.</param>
        /// <returns>HistoriqueReinitialiserLoginPourLister résultat de la conversion.</returns>
        public static HistoriqueReinitialiserLoginPourLister Convertir(this Domain.Entities.HistoriqueReinitialiserLogin historiqueAConvertir)
        {
            if(historiqueAConvertir == null)
            {
                return null;
            }
            return new HistoriqueReinitialiserLoginPourLister()
            {
                Canal = historiqueAConvertir.Canal,
                DateDemande = historiqueAConvertir.DateDemande,
                Destinataire = historiqueAConvertir.Destinataire,
                Identifiant = historiqueAConvertir.Identifiant,
                ModeEnvoi = historiqueAConvertir.ModeEnvoi,
                Type = historiqueAConvertir.Type,
                MemoId = historiqueAConvertir.SuiviAgentCreation
            };
        }
    }
}
