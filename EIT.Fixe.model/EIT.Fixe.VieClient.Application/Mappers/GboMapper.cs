﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion en dossierGBO.
    /// </summary>
    internal static class GboMapper
    {
        /// <summary>
        /// Converti l'objet de présentation de service externe DossierGboPourLister en un objet de présentation DossierBackOfficeLignePourLister.
        /// </summary>
        /// <param name="dossierGbo">Objet à convertir.</param>
        /// <returns>DossierBackOfficeLignePourLister.</returns>
        /// <remarks>Ne lève pas d'exception en cas de paramètre entrant nul.</remarks>
        internal static DossierBackOfficeLignePourLister Convertir(Domain.CommonTypes.DTO.DossierGboPourLister dossierGbo, HistoriquePourLister historiqueDossierGbo)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            DossierBackOfficeLignePourLister ret = new DossierBackOfficeLignePourLister()
            {
                Cle = dossierGbo.Cle,
                Activite = dossierGbo.NomActivite,
                CommentaireOuverture = dossierGbo.Commentaire,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.Etat,
                EstDetailAccessible = true,
                Proprietaire = dossierGbo.PrenomAgentProprietaire + " " + dossierGbo.NomAgentProprietaire
            };

            if (historiqueDossierGbo == null)
            {
                return ret;
            }

            ret.Type = historiqueDossierGbo.Type;
            ret.Historique = historiqueDossierGbo.Historique;

            return ret;
        }

        /// <summary>
        /// Conversion de dossiers GBO pour lister.
        /// </summary>
        /// <param name="listeDossiersGbo">Liste de dossiers à convertir.</param>
        /// <returns>Liste de dossiers GBO.</returns>
        internal static Interface.DTO.DossierGboPourLister[] Convertir(Domain.CommonTypes.DTO.DossierGboPourLister[] listeDossiersGbo)
        {
            if (listeDossiersGbo == null)
            {
                return null;
            }

            IList<Interface.DTO.DossierGboPourLister> ret = new List<Interface.DTO.DossierGboPourLister>();

            foreach (var dossier in listeDossiersGbo)
            {
                ret.Add(Convertir(dossier));
            }

            if (!ret.Any())
            {
                return null;
            }

            return ret.ToArray();
        }

        /// <summary>
        /// Conversion d'un dossier GBO.
        /// </summary>
        /// <param name="listeDossiersGbo">Dossier GBO à convertir.</param>
        /// <returns>Informations du dossier GBO pour lister.</returns>
        internal static Interface.DTO.DossierGboPourLister Convertir(Domain.CommonTypes.DTO.DossierGboPourLister dossierGbo)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            return new Interface.DTO.DossierGboPourLister
            {
                Cle = dossierGbo.Cle,
                CleActivite = dossierGbo.CleActivite,
                Commentaire = dossierGbo.Commentaire,
                DateCreation = dossierGbo.DateCreation,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.LibelleEtat,
                NomActivite = dossierGbo.NomActivite,
                MemoIdAgentProprietaire = dossierGbo.MemoIdAgentProprietaire,
                CleAgentProprietaire = dossierGbo.CleAgentProprietaire,
                PrenomAgentProprietaire = dossierGbo.PrenomAgentProprietaire,
                NomAgentProprietaire = dossierGbo.NomAgentProprietaire,
                CleTypeMetierNiveau1 = dossierGbo.CleTypeMetierNiveau1,
                LibelleTypeMetierNiveau1 = dossierGbo.LibelleTypeMetierNiveau1
            };
        }

        /// <summary>
        /// Conversion de dossiers GBO pour lister.
        /// </summary>
        /// <param name="listeDossiersGbo">Liste de dossiers à convertir.</param>
        /// <returns>Liste de dossiers GBO.</returns>
        internal static Interface.DTO.DossierGboPourLister[] Convertir(Fixe.Domain.Gbo.DossierGboPourLister[] listeDossiersGbo)
        {
            if (listeDossiersGbo == null)
            {
                return null;
            }

            IList<Interface.DTO.DossierGboPourLister> ret = new List<Interface.DTO.DossierGboPourLister>();

            foreach (var dossier in listeDossiersGbo)
            {
                ret.Add(Convertir(dossier));
            }

            if (!ret.Any())
            {
                return null;
            }

            return ret.ToArray();
        }

        /// <summary>
        /// Conversion d'un dossier GBO.
        /// </summary>
        /// <param name="listeDossiersGbo">Dossier GBO à convertir.</param>
        /// <returns>Informations du dossier GBO pour lister.</returns>
        internal static Interface.DTO.DossierGboPourLister Convertir(Fixe.Domain.Gbo.DossierGboPourLister dossierGbo)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            return new Interface.DTO.DossierGboPourLister
            {
                Cle = dossierGbo.Cle,
                CleActivite = dossierGbo.CleActivite,
                Commentaire = dossierGbo.Commentaire,
                DateCreation = dossierGbo.DateCreation,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.LibelleEtat,
                NomActivite = dossierGbo.NomActivite,
                MemoIdAgentProprietaire = dossierGbo.MemoIdAgentProprietaire,
                CleAgentProprietaire = dossierGbo.CleAgentProprietaire,
                PrenomAgentProprietaire = dossierGbo.PrenomAgentProprietaire,
                NomAgentProprietaire = dossierGbo.NomAgentProprietaire
            };
        }

        /// <summary>
        /// Conversion de dossiers GBO pour lister.
        /// </summary>
        /// <param name="listeDossiersGbo">Liste de dossiers à convertir.</param>
        /// <returns>Liste de dossiers GBO.</returns>
        internal static Domain.CommonTypes.DTO.DossierGboPourLister[] ConvertirPourDomaine(Fixe.Domain.Gbo.DossierGboPourLister[] listeDossiersGbo)
        {
            if (listeDossiersGbo == null)
            {
                return null;
            }

            IList<Domain.CommonTypes.DTO.DossierGboPourLister> ret = new List<Domain.CommonTypes.DTO.DossierGboPourLister>();

            foreach (var dossier in listeDossiersGbo)
            {
                ret.Add(ConvertirPourDomaine(dossier));
            }

            if (!ret.Any())
            {
                return null;
            }

            return ret.ToArray();
        }

        /// <summary>
        /// Conversion d'un dossier GBO.
        /// </summary>
        /// <param name="listeDossiersGbo">Dossier GBO à convertir.</param>
        /// <returns>Informations du dossier GBO pour lister.</returns>
        internal static Domain.CommonTypes.DTO.DossierGboPourLister ConvertirPourDomaine(Fixe.Domain.Gbo.DossierGboPourLister dossierGbo)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.DossierGboPourLister
            {
                Cle = dossierGbo.Cle,
                CleActivite = dossierGbo.CleActivite,
                Commentaire = dossierGbo.Commentaire,
                DateCreation = dossierGbo.DateCreation,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.Etat,
                NomActivite = dossierGbo.NomActivite,
                MemoIdAgentProprietaire = dossierGbo.MemoIdAgentProprietaire,
                CleAgentProprietaire = dossierGbo.CleAgentProprietaire,
                PrenomAgentProprietaire = dossierGbo.PrenomAgentProprietaire,
                NomAgentProprietaire = dossierGbo.NomAgentProprietaire
            };
        }

        /// <summary>
        /// Conversion des informations d'un dossier GBO et enrichissement 
        /// avec les informations de l'historique associé.
        /// </summary>
        /// <param name="dossierGbo">Informations du dossier GBO à convertir.</param>
        /// <param name="historique">Informations de l'historique associé.</param>
        /// <returns>Informations du dossier GBO enrichi.</returns>
        internal static Interface.DTO.DossierGboPourLister Convertir(Fixe.Domain.Gbo.DossierGboPourLister dossierGbo, Domain.CommonTypes.DTO.HistoriqueAppelPourLister historique)
        {
            if (dossierGbo == null)
            {
                return null;
            }

            Interface.DTO.DossierGboPourLister ret = new Interface.DTO.DossierGboPourLister
            {
                Cle = dossierGbo.Cle,
                CleActivite = dossierGbo.CleActivite,
                Commentaire = dossierGbo.Commentaire,
                DateCreation = dossierGbo.DateCreation,
                DateEcheance = dossierGbo.DateEcheance,
                Etat = dossierGbo.LibelleEtat,
                NomActivite = dossierGbo.NomActivite,
                MemoIdAgentProprietaire = dossierGbo.MemoIdAgentProprietaire,
                CleAgentProprietaire = dossierGbo.CleAgentProprietaire,
                PrenomAgentProprietaire = dossierGbo.PrenomAgentProprietaire,
                NomAgentProprietaire = dossierGbo.NomAgentProprietaire
            };

            if (historique != null)
            {
                ret.Historique = new Interface.DTO.HistoriqueAppelPourLister
                {
                    CleQualificationAppelNiveau1 = historique.QualificationAppelNiveau1.Cle,
                    LibelleQualificationAppelNiveau1 = historique.QualificationAppelNiveau1.Libelle,
                    CleQualificationAppelNiveau2 = historique.QualificationAppelNiveau2.Cle,
                    LibelleQualificationAppelNiveau2 = historique.QualificationAppelNiveau2.Libelle,

                    CleTypeMetierNiveau1 = historique.CleTypeMetierNiveau1,
                    LibelleTypeMetierNiveau1 = historique.LibelleTypeMetierNiveau1,
                    CleTypeMetierNiveau2 = historique.CleTypeMetierNiveau2,
                    LibelleTypeMetierNiveau2 = historique.LibelleTypeMetierNiveau2
                };
            }

            return ret;
        }
    }
}