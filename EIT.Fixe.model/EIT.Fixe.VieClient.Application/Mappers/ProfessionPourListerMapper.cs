﻿
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de mappage de l'objet de paramètre de service externe Profession vers l'objet de présentation ProfessionPourLister.
    /// </summary>
    public static class ProfessionPourListerMapper
    {
        public static ProfessionPourLister Convertir(ParamProfession professionAConvertir)
        {
            if (professionAConvertir == null)
            {
                return null;
            }
           

            return new ProfessionPourLister()
            {
                Cle = professionAConvertir.Cle,
                Libelle = professionAConvertir.Libelle
            };
        }
    }
}
