﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe statique de conversion de TiersEnvoiBonRetour.
    /// </summary>
    public static class TiersEnvoiBonRetourMapper
    {
        /// <summary>
        /// Méthode statique pour convertir le tiers.
        /// </summary>
        /// <param name="tiers">Tiers reçu/</param>
        /// <returns>Tiers du domaine.</returns>
        public static Domain.CommonTypes.DTO.TiersPourEnvoiBonRetour Convertir(TiersPourEnvoiBonRetour tiers)
        {
            if (tiers == null)
            {
                return null;
            }

            return new Domain.CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new Domain.CommonTypes.DTO.AdressePourSaisie()
                {
                    CodePostal = tiers.Adresse.CodePostal,
                    Complement = tiers.Adresse.Complement,
                    Ville = tiers.Adresse.Ville,
                    Voie = tiers.Adresse.Voie
                },
                Civilite = tiers.Civilite,
                Nom = tiers.Nom,
                Prenom = tiers.Prenom
            };
        }
    }
}
