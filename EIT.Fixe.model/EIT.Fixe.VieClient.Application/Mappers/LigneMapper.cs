﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Convertisseur entre l'entité et les DTOs des services
    /// </summary>
    public static class LigneMapper
    {
        /// <summary>
        /// Convertir l'entité <see cref="Ligne"/> vers le DTO <see cref="InformationLigne"/>
        /// </summary>
        /// <param name="entite"></param>
        /// <returns></returns>
        public static InformationLigne Convertir(Ligne entite)
        {
            if (entite == null)
            {
                return null;
            }

            return new InformationLigne
            {
                Cle = entite.Cle,
                Etat = entite.ValeurEtat,
                CleTechnologie = entite.CleTechnologie,
                ReferenceExterne = entite.ReferenceExterne,
                Numero = entite.Numero,
                CleAdresseInstallation = entite.CleAdresseInstallation,
                CleCompteFacturation = entite.CleCompteFacturation,
                CleGestionnaireOptions = entite.CleGestionnaireOptions,
                NumeroContratOperateur = entite.NumeroContratOperateur,
                IdentifiantTransactionOperateur = entite.IdentifiantTransactionOperateur,
                CleMarque = entite.CleMarque,
                StatutSurconsommation = entite.StatutSurconsommation,
                DateFinEngagement = entite.DateFinEngagement,
                CleOffre = entite.CleOffre,
                CleTiers = entite.CleTiers,
                CleIcn = entite.CleIcn,
                Rio = entite.Rio,
                SuiviDateCreation = entite.SuiviDateCreation,
                SuiviAgentCreation = entite.SuiviAgentCreation,
                SuiviDateModification = entite.SuiviDateModification,
                SuiviAgentModification = entite.SuiviAgentModification
            };
        }
    }
}
