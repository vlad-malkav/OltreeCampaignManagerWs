﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en CommandePourLister.
    /// </summary>
    public static class DemandesRemisesLignePourExpirationMapper
    {
        /// <summary>
        /// Convertit une ligne du dictionnaire en DemandesRemisesLignePourExpiration.
        /// </summary>
        /// <param name="ligneAConvertir">La ligne du dictionnaire a convertir.</param>
        /// <returns>Un objet de présentation DemandesRemisesLignePourExpiration.</returns>
        public static DemandesRemisesLignePourExpiration Convertir(KeyValuePair<long, List<long>> ligneAConvertir)
        {
            if (ligneAConvertir.Key <= 0 && !ligneAConvertir.Value.Any())
            {
                return null;
            }

            return new DemandesRemisesLignePourExpiration()
            {
                CleLigne = ligneAConvertir.Key,
                ListeClesDemandeRemise = ligneAConvertir.Value
            };
        }
    }
}
