﻿using EIT.Fixe.VieClient.Application.Interface.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en DossierGboPourCreation.
    /// </summary>
    public static class DossierGBOPourCreationMapper
    {
        /// <summary>
        /// Converti l'objet de présentation  DossierGBOPourCreation en un objet de présentation DossierGBOPourCreation.
        /// </summary>
        /// <param name="dossierGBOPourCreation">Objet à convertir.</param>
        /// <returns>DossierGboPourCreation.</returns>
        public static Domain.CommonTypes.DTO.DossierGboPourCreation Convertir (DossierGBOPourCreation dossierGBOPourCreation)
        {
            return new Domain.CommonTypes.DTO.DossierGboPourCreation()
            {
                Commentaire = dossierGBOPourCreation.Commentaire,
                AgentProprietaire = dossierGBOPourCreation.AgentProprietaire,
                CleActivite = dossierGBOPourCreation.CleActivite,
                Delai = dossierGBOPourCreation.Delai,
                EstConfidentiel = dossierGBOPourCreation.EstConfidentiel
            };
        }
    }
}