﻿using System.Linq;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion des Formulaires GBO & Tables de Paramétrage GBO (Domaine == Metier) vers leurs équivalents IHM (Interface == Présentation)
    /// </summary>
    public static class FormulaireGBOMapper
    {
        #region Tables de Paramétrage

        /// <summary>
        /// Convertit l'objet Domaine MotifDysfonctionnement en un objet de présentation MotifDysfonctionnement.
        /// </summary>
        /// <param name="motifDysfonctionnementAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation MotifDysfonctionnement</returns>
        public static MotifDysfonctionnement Convertir(Domain.Entities.TableParametrageGBO.MotifDysfonctionnement motifDysfonctionnementAConvertir)
        {
            if (motifDysfonctionnementAConvertir == null)
            {
                return null;
            }

            return new MotifDysfonctionnement
            {
                Cle = motifDysfonctionnementAConvertir.Cle,
                Libelle = motifDysfonctionnementAConvertir.Libelle
            };
        }

        /// <summary>
        /// Convertit l'objet Domaine MotifQualification en un objet de présentation MotifQualification.
        /// </summary>
        /// <param name="motifQualificationAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation MotifQualification</returns>
        public static MotifQualification Convertir(Domain.Entities.TableParametrageGBO.MotifQualification motifQualificationAConvertir)
        {
            if (motifQualificationAConvertir == null)
            {
                return null;
            }

            return new MotifQualification
            {
                Cle = motifQualificationAConvertir.Cle,
                Libelle = motifQualificationAConvertir.Libelle
            };
        }

        /// <summary>
        /// Convertit l'objet Domaine NatureDemandeIntervention en un objet de présentation NatureDemandeIntervention.
        /// </summary>
        /// <param name="natureDemandeInterventionAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation NatureDemandeIntervention</returns>
        public static NatureDemandeIntervention Convertir(Domain.Entities.TableParametrageGBO.NatureDemandeIntervention natureDemandeInterventionAConvertir)
        {
            if (natureDemandeInterventionAConvertir == null)
            {
                return null;
            }

            return new NatureDemandeIntervention
            {
                Cle = natureDemandeInterventionAConvertir.Cle,
                Libelle = natureDemandeInterventionAConvertir.Libelle
            };
        }

        /// <summary>
        /// Convertit l'objet Domaine OrigineDysfonctionnement en un objet de présentation OrigineDysfonctionnement.
        /// </summary>
        /// <param name="origineDysfonctionnementAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation OrigineDysfonctionnement</returns>
        public static OrigineDysfonctionnement Convertir(Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement origineDysfonctionnementAConvertir)
        {
            if (origineDysfonctionnementAConvertir == null)
            {
                return null;
            }

            return new OrigineDysfonctionnement
            {
                Cle = origineDysfonctionnementAConvertir.Cle,
                Libelle = origineDysfonctionnementAConvertir.Libelle
            };
        }

        /// <summary>
        /// Convertit l'objet Domaine RegionCDC en un objet de présentation RegionCDC.
        /// </summary>
        /// <param name="regionCDCAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation RegionCDC</returns>
        public static RegionCDC Convertir(Domain.Entities.TableParametrageGBO.RegionCDC regionCDCAConvertir)
        {
            if (regionCDCAConvertir == null)
            {
                return null;
            }

            return new RegionCDC
            {
                Cle = regionCDCAConvertir.Cle,
                Libelle = regionCDCAConvertir.Libelle
            };
        }

        #endregion Tables de Paramétrage

        #region Formulaires

        /// <summary>
        /// Convertit l'objet Domaine FormulaireGBO en un objet de présentation FormulaireGBO.
        /// </summary>
        /// <param name="formulaireAConvertir">Objet à convertir.</param>
        /// <returns>Un objet de présentation RegionCDC</returns>
        public static FormulaireGBO Convertir(Domain.Entities.FormulaireGBO.FormulaireGBO formulaireAConvertir)
        {
            if (formulaireAConvertir == null)
            {
                return null;
            }

            switch (formulaireAConvertir.TypeFormulaireGbo)
            {
                case Domain.CommonTypes.Enumerations.TypeFormulaireGBO.FormulaireCN2DI:
                    return Convertir((Domain.Entities.FormulaireGBO.FormulaireCN2DI) formulaireAConvertir);
                case Domain.CommonTypes.Enumerations.TypeFormulaireGBO.FormulaireCN3EQ:
                    return Convertir((Domain.Entities.FormulaireGBO.FormulaireCN3EQ) formulaireAConvertir);
                case Domain.CommonTypes.Enumerations.TypeFormulaireGBO.FormulaireMPS:
                    return Convertir((Domain.Entities.FormulaireGBO.FormulaireMPS) formulaireAConvertir);
                case Domain.CommonTypes.Enumerations.TypeFormulaireGBO.FormulaireRisqueResiliation:
                    return Convertir((Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation) formulaireAConvertir);
            }

            return new FormulaireGBO
            {
                Cle = formulaireAConvertir.Cle,
                CleDossierGbo = formulaireAConvertir.CleDossierGbo,
                CdcAdresseMail = formulaireAConvertir.CdcAdresseMail,
                CdcCodeBanque = formulaireAConvertir.CdcCodeBanque,
                CdcCodeBranche = formulaireAConvertir.CdcCodeBranche,
                CdcLigneDirecte = formulaireAConvertir.CdcLigneDirecte,
                CdcNomPrenom = formulaireAConvertir.CdcNomPrenom,
                RegionCdc = Convertir(formulaireAConvertir.RegionCdc),
                ReferenceExterne = formulaireAConvertir.ReferenceExterne,
                TypeFormulaireGbo = formulaireAConvertir.TypeFormulaireGbo
            };
        }

        public static FormulaireCN2DI Convertir(Domain.Entities.FormulaireGBO.FormulaireCN2DI formulaireAConvertir)
        {
            if (formulaireAConvertir == null)
            {
                return null;
            }

            return new FormulaireCN2DI
            {
                Cle = formulaireAConvertir.Cle,
                CleDossierGbo = formulaireAConvertir.CleDossierGbo,
                CdcAdresseMail = formulaireAConvertir.CdcAdresseMail,
                CdcCodeBanque = formulaireAConvertir.CdcCodeBanque,
                CdcCodeBranche = formulaireAConvertir.CdcCodeBranche,
                CdcLigneDirecte = formulaireAConvertir.CdcLigneDirecte,
                CdcNomPrenom = formulaireAConvertir.CdcNomPrenom,
                RegionCdc = Convertir(formulaireAConvertir.RegionCdc),
                ListePiecesJointes = formulaireAConvertir.ListePiecesJointes != null ?
                    formulaireAConvertir.ListePiecesJointes.Select(x => Convertir(x)).ToArray()
                    : null,
                TypeFormulaireGbo = formulaireAConvertir.TypeFormulaireGbo,
                ReferenceExterne = formulaireAConvertir.ReferenceExterne,
                NomClient = formulaireAConvertir.NomClient,
                PrenomClient = formulaireAConvertir.PrenomClient,
                NumeroCommandeClient = formulaireAConvertir.NumeroCommandeClient,
                MotifDysfonctionnement = Convertir(formulaireAConvertir.MotifDysfonctionnement),
                OrigineDysfonctionnement = Convertir(formulaireAConvertir.OrigineDysfonctionnement),
                DateApproxAppelServiceClient = formulaireAConvertir.DateApproxAppelServiceClient,
                RaisonsDysfonctionnement = formulaireAConvertir.RaisonsDysfonctionnement,
                DemandeClient = formulaireAConvertir.DemandeClient,
                SolutionsDejaApportees = formulaireAConvertir.SolutionsDejaApportees
            };
        }

        public static FormulaireCN3EQ Convertir(Domain.Entities.FormulaireGBO.FormulaireCN3EQ formulaireAConvertir)
        {
            if (formulaireAConvertir == null)
            {
                return null;
            }

            return new FormulaireCN3EQ
            {
                Cle = formulaireAConvertir.Cle,
                CleDossierGbo = formulaireAConvertir.CleDossierGbo,
                CdcAdresseMail = formulaireAConvertir.CdcAdresseMail,
                CdcCodeBanque = formulaireAConvertir.CdcCodeBanque,
                CdcCodeBranche = formulaireAConvertir.CdcCodeBranche,
                CdcLigneDirecte = formulaireAConvertir.CdcLigneDirecte,
                CdcNomPrenom = formulaireAConvertir.CdcNomPrenom,
                RegionCdc = Convertir(formulaireAConvertir.RegionCdc),
                ListePiecesJointes = formulaireAConvertir.ListePiecesJointes != null ?
                    formulaireAConvertir.ListePiecesJointes.Select(x => Convertir(x)).ToArray()
                    : null,
                TypeFormulaireGbo = formulaireAConvertir.TypeFormulaireGbo,
                NumeroSuiviDossier = formulaireAConvertir.NumeroSuiviDossier,
                DateReponseCelluleN2 = formulaireAConvertir.DateReponseCelluleN2,
                ReferenceExterne = formulaireAConvertir.ReferenceExterne,
                NatureDemandeIntervention =Convertir(formulaireAConvertir.NatureDemandeIntervention),
                RaisonContestation = formulaireAConvertir.RaisonContestation,
                DemandeClient = formulaireAConvertir.DemandeClient,
                SolutionsDejaApportees = formulaireAConvertir.SolutionsDejaApportees
            };
        }

        public static FormulaireMPS Convertir(Domain.Entities.FormulaireGBO.FormulaireMPS formulaireAConvertir)
        {
            if (formulaireAConvertir == null)
            {
                return null;
            }

            return new FormulaireMPS
            {
                Cle = formulaireAConvertir.Cle,
                CleDossierGbo = formulaireAConvertir.CleDossierGbo,
                CdcAdresseMail = formulaireAConvertir.CdcAdresseMail,
                CdcCodeBanque = formulaireAConvertir.CdcCodeBanque,
                CdcCodeBranche = formulaireAConvertir.CdcCodeBranche,
                CdcLigneDirecte = formulaireAConvertir.CdcLigneDirecte,
                CdcNomPrenom = formulaireAConvertir.CdcNomPrenom,
                RegionCdc = Convertir(formulaireAConvertir.RegionCdc),
                TypeFormulaireGbo = formulaireAConvertir.TypeFormulaireGbo,
                ReferenceExterne = formulaireAConvertir.ReferenceExterne,
                NomClient = formulaireAConvertir.NomClient,
                PrenomClient = formulaireAConvertir.PrenomClient,
                DateEffetDemande = formulaireAConvertir.DateEffetDemande,
                ProfilSurconsoDemande = formulaireAConvertir.ProfilSurconsoDemande,
                Commentaire = formulaireAConvertir.Commentaire
            };
        }

        public static FormulaireRisqueResiliation Convertir(Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation formulaireAConvertir)
        {
            if (formulaireAConvertir == null)
            {
                return null;
            }

            return new FormulaireRisqueResiliation
            {
                Cle = formulaireAConvertir.Cle,
                CleDossierGbo = formulaireAConvertir.CleDossierGbo,
                CdcAdresseMail = formulaireAConvertir.CdcAdresseMail,
                CdcCodeBanque = formulaireAConvertir.CdcCodeBanque,
                CdcCodeBranche = formulaireAConvertir.CdcCodeBranche,
                CdcLigneDirecte = formulaireAConvertir.CdcLigneDirecte,
                CdcNomPrenom = formulaireAConvertir.CdcNomPrenom,
                RegionCdc = Convertir(formulaireAConvertir.RegionCdc),
                TypeFormulaireGbo = formulaireAConvertir.TypeFormulaireGbo,
                ReferenceExterne = formulaireAConvertir.ReferenceExterne,
                NomClient = formulaireAConvertir.NomClient,
                PrenomClient = formulaireAConvertir.PrenomClient,
                OffreClient = formulaireAConvertir.OffreClient,
                MotifQualification = Convertir(formulaireAConvertir.MotifQualification),
                Commentaire = formulaireAConvertir.Commentaire,
            };
        }

        public static PieceJointeFormulaireGbo Convertir(Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo pieceJointeAConvertir)
        {
            if (pieceJointeAConvertir == null)
            {
                return null;
            }

            return new PieceJointeFormulaireGbo
            {
                Cle = pieceJointeAConvertir.Cle,
                GuDocId = pieceJointeAConvertir.GuDocId,
                NomFichier = pieceJointeAConvertir.NomFichier
            };
        }


        #endregion Formulaires
    }
}