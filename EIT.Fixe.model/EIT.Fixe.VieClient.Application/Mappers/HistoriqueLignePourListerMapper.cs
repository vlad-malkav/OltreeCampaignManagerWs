﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes génériques de conversions des historiques.
    /// </summary>
    public static class HistoriqueLignePourListerMapper
    {
        /// <summary>
        /// Convertit l'objet de présentation de service externe HistoriquePourLister en un objet de présentation HistoriqueLignePourLister.
        /// </summary>
        /// <param name="historique">Objet à convertir.</param>
        /// <returns>Un objet de présentation HistoriqueLignePourLister.</returns>
        public static HistoriqueLignePourLister Convertir(HistoriquePourLister historique)
        {
            if (historique == null)
            {
                return null;
            }

            return new HistoriqueLignePourLister()
            {
                Cle = historique.Cle,
                Date = historique.DateCreation,
                Historique = historique.Historique,
                Type = historique.Type,
                Agent = historique.Agent,
                Canal = historique.Canal,
                EstDetailAccessible = true
            };
        }
    }
}