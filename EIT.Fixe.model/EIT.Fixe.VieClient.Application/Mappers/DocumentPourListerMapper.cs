﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Classe de conversion en objet DocumentPourLister.
    /// </summary>
    public static class DocumentPourListerMapper
    {
        /// <summary>
        /// Méthode de conversion de DocumentLigne en DocumentPourLister.
        /// </summary>
        /// <param name="documentAConvertir">DocumentLigne à convertir.</param>
        /// <returns>DocumentPourLister résultat de la conversion.</returns>
        public static DocumentPourLister Convertir(Domain.Entities.DocumentLigne documentAConvertir)
        {
            if(documentAConvertir == null)
            {
                return null;
            }
            return new DocumentPourLister()
            {
                RefDoc = documentAConvertir.RefDoc,
                Libelle = documentAConvertir.Libelle
            };
        }
    }
}
