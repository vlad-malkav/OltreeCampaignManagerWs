﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;

namespace EIT.Fixe.VieClient.Application.Mappers
{
    /// <summary>
    /// Méthodes de conversion en objet de présentation de type ChoixParutionAnnuaire.
    /// </summary>
    public static class ChoixParutionAnnuaireMapper
    {
        /// <summary>
        /// Convertit l'objet de présentation de service externe  informationAnnuaireAConvertir en un objet de présentation ChoixParutionAnnuaire.
        /// </summary>
        /// <param name="informationAnnuaireAConvertir">Objet à convertir.</param>
        /// <returns>Objet de présentation ChoixParutionAnnuaire.</returns>
        public static ChoixParutionAnnuaire Convertir(InformationsAnnuaireUniversel informationAnnuaireAConvertir)
        {
            if (informationAnnuaireAConvertir == null)
            {
                return null;
            }

            return new ChoixParutionAnnuaire()
            {
                EstPrenomDiffuse = informationAnnuaireAConvertir.DiffusionPrenom,
                EstProfessionDiffusee = informationAnnuaireAConvertir.DiffusionProfession,
                Profession = ProfessionPourListerMapper.Convertir(informationAnnuaireAConvertir.Profession),
                EstEmailDiffuse = informationAnnuaireAConvertir.DiffusionEmail,
                EstInscritAnnuaireInverse = informationAnnuaireAConvertir.InscriptionAnnuaireInverse,
                EstAdresseLimiteeAVille = informationAnnuaireAConvertir.LimiterDiffusionAdresseVille,
                EstUtilisationCoordoneesAutoriseePourMarketing = informationAnnuaireAConvertir.UtilisationMarketing

            };
        }
    }
}
