﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.Services;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes
        
        /// <summary>
        /// Permet de modifier le mot de passe du compte MyPartnerTv
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne </param>
        /// <param name="motDePasse">Mot de passe du compte My Partner TV</param>
        public void ModifierMotDePasseMyPartnerTv(Identite identite, string referenceExterne, string motDePasse)
        {
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            motDePasse.Valider(nameof(motDePasse)).Obligatoire();

            this.briquesServicesExternes.SfrFixeCompteTvServiceExterne.ModifierMotDePasseMyPartnerTv(identite, referenceExterne, motDePasse);
        }

        /// <summary>
        /// Permet de créer un compte MyPartnerTv
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne </param>
        /// <param name="identifiant">Identifiant du compte My Partner TV</param>
        public void CreerCompteMyPartnerTv(Identite identite, string referenceExterne, string identifiant)
        {
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            identifiant.Valider(nameof(identifiant)).Obligatoire();

            this.briquesServicesExternes.SfrFixeCompteTvServiceExterne.CreerCompteMyPartnerTv(identite, referenceExterne, identifiant);
        }

        #endregion
    }
}