﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// <summary>
    public sealed partial class LigneService : ILigneService
    {
        /// <summary>
        /// Permet de creér une demande de rétractation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action;</param>
        /// <param name="cleLigne">Clé de la ligne concernée.</param>
        /// <param name="informationsDemandeRetractation">Informations nécessaire à la création d'une demande de rétractation.</param>
        public void CreerDemandeRetractation(Identite identite, long cleLigne, Interface.DTO.DemandeRetractationPourCreation informationsDemandeRetractation)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            informationsDemandeRetractation.Valider(nameof(informationsDemandeRetractation)).NonNul();

            // Obtention de la Ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Convertion des informations.
            Domain.CommonTypes.DTO.DemandeRetractationPourCreation informationsRetractation = new Domain.CommonTypes.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = informationsDemandeRetractation.DateReceptionCourierAr,
                Email = informationsDemandeRetractation.Email,
                EstNouveauTiersEnvoiBonRetour = informationsDemandeRetractation.EstNouveauTiersEnvoiBonRetour,
                TiersEnvoiBonRetour = TiersEnvoiBonRetourMapper.Convertir(informationsDemandeRetractation.TiersEnvoiBonRetour)
            };

            //Appel à la méthode de création d'une demande de rétractation.
            ligne.CreerDemandeRetractation(identite, informationsRetractation);
        }
    }
}