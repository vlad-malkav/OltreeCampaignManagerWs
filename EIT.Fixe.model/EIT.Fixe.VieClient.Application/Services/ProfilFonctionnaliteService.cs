﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des fonctionnalités des profils.
    /// </summary>
    public class ProfilFonctionnaliteService : IProfilFonctionnaliteService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        #endregion Champs

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="briquesServices">L'interface de la brique de service externes.</param>
        /// <param name="servicesExternes">L'interface du service externe.</param>
        /// <param name="repositories">L'interface des repositories.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        public ProfilFonctionnaliteService(IRepositories repositories, IServicesTechniques serviceTechnique)
        {
            // Vérification des paramètres.
            repositories.Valider(nameof(repositories)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            // Assignation des valeurs.
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
        }

        #endregion Constructeur

        #region IProfilFonctionnaliteService

        /// <summary>
        /// Méthode qui permet de vérifier la composition du fichier de mise à jour CRM.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="lignesFichier">Lignes du fichier CSV uploadé.</param>
        /// <returns>Retour de la vérification concernant le fichier de mise à jour CRM.</returns>
        public RetourVerificationFichierMiseAJourCrm VerifierFichierMiseAJourCrm(Identite identite, string[] lignesFichier)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            lignesFichier.Valider(nameof(lignesFichier)).NonNul();

            RetourVerificationFichierMiseAJourCrm retour = new RetourVerificationFichierMiseAJourCrm()
            {
                EstFichierValide = true,
                NombreLignesTraitees = 0
            };

            List<ErreurFichierMiseAJourCrmPourLister> erreurs = new List<ErreurFichierMiseAJourCrmPourLister>();

            List<string[]> lignesDecoupees = new List<string[]>();

            for (int ligne = 0; ligne < lignesFichier.Count(); ligne++)
            {
                retour.NombreLignesTraitees++;

                string[] ligneDecoupee = lignesFichier[ligne].Split(';');


                // Vérification du nombre d'élément dans la ligne.
                if (ligneDecoupee.Count() != 9)
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = ligne + 1,
                        NumeroColonne = 0,
                        Erreur = "La ligne n'a pas exactement 9 éléments séparés par un point-virgule ';'."
                    });
                    retour.EstFichierValide = false;
                    continue;
                }

                // Vérification des tailles des éléments.
                VerifierTaillesElements(retour, erreurs, ligne, ligneDecoupee);
                lignesDecoupees.Add(ligneDecoupee);
            }

            VerifierProfilLigne(retour, erreurs, lignesDecoupees);
            VerifierGroupeLigne(retour, erreurs, lignesDecoupees);
            VerifierFonctionnaliteLigne(retour, erreurs, lignesDecoupees);

            retour.Erreurs = erreurs.ToArray();
            return retour;
        }

        /// <summary>
        /// Méthode qui permet de modifier les fonctionnalités de droits CRM.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="lignesFichier">Lignes du fichier CSV uploadé.</param>
        public void ModifierDroitsCrm(Identite identite, string[] lignesFichier)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            lignesFichier.Valider(nameof(lignesFichier)).NonNul();

            ProfilPtf[] listeProfilsActifs = this.repositories.ProfilRepository.ListerProfilsActifs();
            if (listeProfilsActifs != null)
            {
                listeProfilsActifs.ToList().ForEach(p => p.Desactiver(identite));
            }

            GroupeFonctionnalites[] listeGroupesActifs = this.repositories.GroupeFonctionnalitesRepository.ListerGroupesFonctionnalitesActifs();
            if (listeGroupesActifs != null)
            {
                listeGroupesActifs.ToList().ForEach(p => p.Desactiver(identite));
            }

            Fonctionnalite[] listeFonctionnalitesActives = this.repositories.FonctionnaliteRepository.ListerFonctionnalitesActives();
            if (listeFonctionnalitesActives != null)
            {
                listeFonctionnalitesActives.ToList().ForEach(p => p.Desactiver(identite));
            }
            
            DateTime dateImport = DateTime.Now;

            List<string[]> lignesDecoupees = lignesFichier.Select(l => l.Split(';')).ToList();

            // Ajout des fonctionnalites.
            List<ParametreFonctionnalitePourCreation> fonctionnalitesDifferentesParams = lignesDecoupees.Where(l => !string.IsNullOrWhiteSpace(l[7]))
                                                                              .GroupBy(l => l[7])
                                                                              .Select(f => f.First())
                                                                              .Select(l => new ParametreFonctionnalitePourCreation()
                                                                              {
                                                                                  Code = l[7],
                                                                                  Description = l[8],
                                                                                  EstActif = true,
                                                                                  SuiviDateCreation = dateImport
                                                                              }).ToList();
            List<Fonctionnalite> fonctionnalitesCreees = new List<Fonctionnalite>();

            foreach(var fonctionnalite in fonctionnalitesDifferentesParams)
            {
                fonctionnalite.Cle = this.serviceTechnique.GenerateurCles.ObtenirCleLongue<Fonctionnalite>();
                Fonctionnalite nouvelleFonctionnalite = new Fonctionnalite(identite, fonctionnalite);
                this.repositories.FonctionnaliteRepository.Ajouter(nouvelleFonctionnalite);
                fonctionnalitesCreees.Add(nouvelleFonctionnalite);
            }


            // Ajout des groupes.
            List<ParametreGroupeFonctionnalitesPourCreation> groupesDifferents = lignesDecoupees.Where(l => !string.IsNullOrWhiteSpace(l[4]))
                                                                              .GroupBy(l => l[4])
                                                                              .Select(f => f.First())
                                                                              .Select(l => new ParametreGroupeFonctionnalitesPourCreation()
                                                                              {
                                                                                  Code = l[4],
                                                                                  Libelle = l[5],
                                                                                  Description = l[6],
                                                                                  EstActif = true,
                                                                                  SuiviDateCreation = dateImport
                                                                              }).ToList();

            IEnumerable<IGrouping<string, string>> fonctionnalitesGroupes = lignesDecoupees.GroupBy(l => l[4], l => l[7]);

            List<GroupeFonctionnalites> groupesFonctionnalitesCrees = new List<GroupeFonctionnalites>();

            foreach (var groupe in groupesDifferents)
            {
                groupe.Cle = this.serviceTechnique.GenerateurCles.ObtenirCleLongue<GroupeFonctionnalites>();
                IGrouping<string, string> fonctionnalitesGroupe = fonctionnalitesGroupes.Single(fg => fg.Key == groupe.Code);

                List<Fonctionnalite> fonctionnalitesDuGroupe = fonctionnalitesCreees.Where(f => fonctionnalitesGroupe.Contains(f.Code)).ToList();
                GroupeFonctionnalites nouveauGroupeFonctionnalites = new GroupeFonctionnalites(identite, groupe, fonctionnalitesDuGroupe);
                this.repositories.GroupeFonctionnalitesRepository.Ajouter(nouveauGroupeFonctionnalites);
                groupesFonctionnalitesCrees.Add(nouveauGroupeFonctionnalites);
            }

            // Ajout des profils.
            List<ParametreProfilPtfPourCreation> profilsDifferents = lignesDecoupees.Where(l => !string.IsNullOrWhiteSpace(l[4]))
                                                                              .GroupBy(l => l[0])
                                                                              .Select(f => f.First())
                                                                              .Select(l => new ParametreProfilPtfPourCreation()
                                                                              {
                                                                                  Code = l[0],
                                                                                  Libelle = l[1],
                                                                                  Description = l[2],
                                                                                  RessourceSas = l[3],
                                                                                  EstActif = true,
                                                                                  SuiviDateCreation = dateImport
                                                                              }).ToList();

            IEnumerable<IGrouping<string, string>> groupesProfils = lignesDecoupees.GroupBy(l => l[0], l => l[4]);
            
            foreach (var profil in profilsDifferents)
            {
                profil.Cle = this.serviceTechnique.GenerateurCles.ObtenirCleLongue<ProfilPtf>();
                IGrouping<string, string> groupesProfil = groupesProfils.Single(gp => gp.Key == profil.Code);

                List<GroupeFonctionnalites> groupesDuProfil = groupesFonctionnalitesCrees.Where(g => groupesProfil.Contains(g.Code)).ToList();
                ProfilPtf nouveauProfil = new ProfilPtf(identite, profil, groupesDuProfil);
                this.repositories.ProfilRepository.Ajouter(nouveauProfil);
            }

            //Suppression des enregistrements trop anciens.
            List<DateTime> datesImport = this.repositories.ProfilRepository.ListerDatesSuiviCreation().ToList();
            if(datesImport.Count > 3)
            {
                datesImport.RemoveRange(datesImport.Count - 3, 3);
                foreach(var date in datesImport)
                {
                    this.repositories.FonctionnaliteRepository.SupprimerDepuisDate(date);
                    this.repositories.GroupeFonctionnalitesRepository.SupprimerDepuisDate(date);
                    this.repositories.ProfilRepository.SupprimerDepuisDate(date);
                }
            }
        }

        /// <summary>
        /// Méthode qui permet de lister les fonctionnalités autorisées à partir de ressources SAS.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="ressourcesSas">Liste des ressources SAS.</param>
        /// <returns>Fonctionnalités autorisées.</returns>
        public string[] ObtenirFonctionnalitesDepuisListeProfils(Identite identite, string[] ressourcesSas)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            ressourcesSas.Valider(nameof(ressourcesSas)).NonNul();

            // Instanciation de la liste.
            List<string> listeFonctionnalite = new List<string>();

            // Pour chaque ressourcesSas.
            foreach (var ressourceSas in ressourcesSas)
            {
                // On recherche le profilPtf qui lui est lié.
                ProfilPtf profilPtf = this.repositories.ProfilRepository.RechercherProfilActifDepuisRessourceSas(ressourceSas);

                // S'il est non null et actif, on ajoute le code des fonctionnalité dans la liste des fonctionnalités.
                if (profilPtf != null && profilPtf.EstActif)
                {
                    listeFonctionnalite.AddRange(profilPtf.ListeGroupesFonctionnalites.SelectMany(x => x.ListeFonctionnalites.Select(f=>f.Code)));
                }
            }

            return listeFonctionnalite.ToArray();
        }

        /// <summary>
        /// Méthode qui permet de lister les ressources SAS actives des profils existants.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <returns>Ressources SAS actives.</returns>
        public string[] ListerProfilsExistants(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Récupération des profils.
            ProfilPtf[] listeProfils = this.repositories.ProfilRepository.ListerProfilsActifs();

            return listeProfils.Select(p => p.RessourceSas).ToArray();
        }

        #endregion IProfilFonctionnaliteService

        #region Méthodes privées

        /// <summary>
        /// Vérifie la taille des champs de la ligne.
        /// </summary>
        /// <param name="retour">Retour de la méthode.</param>
        /// <param name="erreurs">Erreurs relevées.</param>
        /// <param name="ligne">Numéro de la ligne.</param>
        /// <param name="ligneDecoupee">Ligne testée.</param>
        private static void VerifierTaillesElements(RetourVerificationFichierMiseAJourCrm retour, List<ErreurFichierMiseAJourCrmPourLister> erreurs, int ligne, string[] ligneDecoupee)
        {
            for (int colonne = 0; colonne < 9; colonne++)
            {
                switch (colonne)
                {
                    case 2:
                    case 6:
                    case 8:
                        if (ligneDecoupee[colonne].Length > 100)
                        {
                            erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                            {
                                NumeroLigne = ligne + 1,
                                NumeroColonne = colonne + 1,
                                Erreur = "Taille maximale autorisée de 100 caractères."
                            });
                            retour.EstFichierValide = false;
                        }
                        break;
                    default:
                        if (ligneDecoupee[colonne].Length > 40)
                        {
                            erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                            {
                                NumeroLigne = ligne + 1,
                                NumeroColonne = colonne + 1,
                                Erreur = "Taille maximale autorisée de 40 caractères."
                            });
                            retour.EstFichierValide = false;
                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Vérifie la cohérence entre les fonctionnalités.
        /// </summary>
        /// <param name="retour">Retour de la méthode.</param>
        /// <param name="erreurs">Erreurs relevées.</param>
        /// <param name="lignesDecoupees">Lignes à vérifier.</param>
        private static void VerifierFonctionnaliteLigne(RetourVerificationFichierMiseAJourCrm retour, List<ErreurFichierMiseAJourCrmPourLister> erreurs, List<string[]> lignesDecoupees)
        {

            //1 code fonctionnalité = 1 libellé.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementFonctionnalitePourLibelle = lignesDecoupees.GroupBy(l => l[7], l => l[8]);
            foreach (var groupe in groupementFonctionnalitePourLibelle)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code fonctionnalité {groupe.Key}, le libellé associé doit être le même."
                    });
                    retour.EstFichierValide = false;
                }
            }
        }

        /// <summary>
        /// Vérifie la cohérence entre les groupes de fonctionnalités.
        /// </summary>
        /// <param name="retour">Retour de la méthode.</param>
        /// <param name="erreurs">Erreurs relevées.</param>
        /// <param name="lignesDecoupees">Lignes à vérifier.</param>
        private static void VerifierGroupeLigne(RetourVerificationFichierMiseAJourCrm retour, List<ErreurFichierMiseAJourCrmPourLister> erreurs, List<string[]> lignesDecoupees)
        {
            //1 code groupe = 1 libellé.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementGroupePourLibelle = lignesDecoupees.GroupBy(l => l[4], l => l[5]);
            foreach (var groupe in groupementGroupePourLibelle)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code groupe {groupe.Key}, le libellé associé doit être le même."
                    });
                    retour.EstFichierValide = false;
                }
            }

            //1 code groupe = 1 description.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementGroupePourDescription = lignesDecoupees.GroupBy(l => l[4], l => l[6]);
            foreach (var groupe in groupementGroupePourDescription)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code groupe {groupe.Key}, la description associée doit être la même."
                    });
                    retour.EstFichierValide = false;
                }
            }
        }

        /// <summary>
        /// Vérifie la cohérence entre les profils.
        /// </summary>
        /// <param name="retour">Retour de la méthode.</param>
        /// <param name="erreurs">Erreurs relevées.</param>
        /// <param name="lignesDecoupees">Lignes à vérifier.</param>
        private static void VerifierProfilLigne(RetourVerificationFichierMiseAJourCrm retour, List<ErreurFichierMiseAJourCrmPourLister> erreurs, List<string[]> lignesDecoupees)
        {
            //1 code profil = 1 ressource SAS.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementProfilPourSas = lignesDecoupees.GroupBy(l => l[0], l => l[3]);
            foreach (var groupe in groupementProfilPourSas)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code profil {groupe.Key}, la ressource SAS associée doit être la même."
                    });
                    retour.EstFichierValide = false;
                }
            }

            //1 ressource SAS = 1 code profil.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementSasPourProfil = lignesDecoupees.GroupBy(l => l[3], l => l[0]);
            foreach (var groupe in groupementSasPourProfil)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour une même ressource SAS {groupe.Key}, le code profil associé doit être le même."
                    });
                    retour.EstFichierValide = false;
                }
            }

            //1 code profil = 1 libellé.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementProfilPourLibelle = lignesDecoupees.GroupBy(l => l[0], l => l[1]);
            foreach (var groupe in groupementProfilPourLibelle)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code profil {groupe.Key}, le libellé associé doit être le même."
                    });
                    retour.EstFichierValide = false;
                }
            }

            //1 code profil = 1 description.
            IEnumerable<System.Linq.IGrouping<string, string>> groupementProfilPourDescription = lignesDecoupees.GroupBy(l => l[0], l => l[2]);
            foreach (var groupe in groupementProfilPourDescription)
            {
                if (groupe.Any(g => g != groupe.ElementAt(0)))
                {
                    erreurs.Add(new ErreurFichierMiseAJourCrmPourLister()
                    {
                        NumeroLigne = 0,
                        NumeroColonne = 0,
                        Erreur = $"Pour un même code profil {groupe.Key}, la description associée doit être la même."
                    });
                    retour.EstFichierValide = false;
                }
            }
        }

        #endregion Méthodes privées
    }
}
