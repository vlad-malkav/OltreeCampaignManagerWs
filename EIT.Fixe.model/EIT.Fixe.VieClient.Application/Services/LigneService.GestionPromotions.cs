﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Obtention de la liste des promotions éligibles pour l'offre.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="cleLigne">Clé de la ligne fixe.</param>
        /// <returns>Liste des promotions éligibles.</returns>
        public PromotionPourLister[] ObtenirPromotionsEligiblesParCleLigne(Identite identite, long cleLigne)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            PromotionPourDetail[] promotions = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionsEligiblesParCleOffre(identite, ligne.CleOffre);

            return promotions.Select(c => PromotionPourListerMapper.Convertir(c)).ToArray();
        }

        /// <summary>
        /// Retourne la liste des demandes de remise - de type Promotion - éligibles à expiration, associées à leurs lignes.
        /// </summary>
        /// <param name="identite">Identite de l'agent qui fait l'action.</param>
        /// <returns>La liste des promotions appliquées éligibles à expiration.</returns>
        /// <remarks>Méthode utilisée par les batchs.</remarks>
        public DemandesRemisesLignePourExpiration[] ListerPromotionsAExpirer(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            Dictionary<long, List<long>> listePromotionAExpirer = this.DemandeRemiseRepository.ListerPromotionsAExpirer();

            return listePromotionAExpirer.Select(s => DemandesRemisesLignePourExpirationMapper.Convertir(s)).ToArray();
        }

        /// <summary>
        /// Passe un ensemble de demandes de remise associées à une ligne à l'état "Expirée".
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="demandesRemisesLignePourExpiration">Liste de clés de demandes de remise en place sur une ligne et éligibles à expiration + clé de la ligne associée.</param>
        public void TraiterExpirationDemandeRemiseParCle(Identite identite, DemandesRemisesLignePourExpiration demandesRemisesLignePourExpiration)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            demandesRemisesLignePourExpiration.Valider(nameof(demandesRemisesLignePourExpiration)).NonNul();
            demandesRemisesLignePourExpiration.CleLigne.Valider(nameof(demandesRemisesLignePourExpiration.CleLigne)).StrictementPositif();
            demandesRemisesLignePourExpiration.ListeClesDemandeRemise.Valider(nameof(demandesRemisesLignePourExpiration.ListeClesDemandeRemise))
                .NonNul().Si(demandesRemisesLignePourExpiration.ListeClesDemandeRemise.Any());

            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(demandesRemisesLignePourExpiration.CleLigne);

            foreach (var cle in demandesRemisesLignePourExpiration.ListeClesDemandeRemise)
            {
                ligne.GestionnaireDemandeRemises.ExpirerDemandeRemiseParCle(identite, cle);
            }
        }

        /// <summary>
        /// Récupère le détail des promotions associées à une ligne ainsi que les informations minimales de la ligne.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé de la ligne fixe.</param>
        /// <returns>Détail des promotions associées à une ligne fixe + informations minimales de la ligne.</returns>
        public PromotionsLignePourDetail ObtenirPromotionsLignePourDetailParCleLigne(Identite identite, long cleLigne)
        {
            // Verification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            PromotionsLignePourDetail promotionsARetourner = new PromotionsLignePourDetail();

            // Appel à la méthode ObtenirParCle du registre ILigneRepository.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Renseigner les propriétés de l'objet de retour.
            promotionsARetourner.CleLigne = ligne.Cle;
            promotionsARetourner.NumeroLigne = ligne.Numero;
            promotionsARetourner.RefExterne = ligne.ReferenceExterne;

            // Récupération de la date d’activation de la ligne. 
            DateTime dateActivationLigne = this.ObtenirDateActivationLigne(ligne);

            // Récupération de la date de confirmation de la commande de souscription. 
            // Appel à la méthode RechercherCommandeSouscriptionParReferenceExterne du service externe SouscriptionServiceExterne.
            CommandeSouscriptionPourDetail commandeDeSouscription = this.servicesExternes.SouscriptionServiceExterne
                                                                                         .RechercherCommandeSouscriptionParReferenceExterne(identite, ligne.ReferenceExterne);
            DateTime? dateConfirmationCommandeSouscription = commandeDeSouscription.DateConfirmation;


            // Appeler la méthode ListerPromotionsActives de l’objet métier ligne.GestionnaireDemandesRemises.
            IList<DemandeRemisePromotion> listePromotionsActives = ligne.GestionnaireDemandeRemises.ListerPromotionsActives();

            // Appeler la méthode ListerPromotionsObsoletes  de l’objet métier ligne.GestionnaireDemandesRemises.
            IList<DemandeRemisePromotion> listePromotionsObsoletes = ligne.GestionnaireDemandeRemises.ListerPromotionsObsoletes();

            // Extraire des listes précédentes les ClePromotion de chaque objet .
            List<int> listeClePromotionsTemporaire = new List<int>();
            listePromotionsActives.ToList().ForEach(p => listeClePromotionsTemporaire.Add(p.ClePromotion()));
            listePromotionsObsoletes.ToList().ForEach(p => listeClePromotionsTemporaire.Add(p.ClePromotion()));
            int[] listeClePromotions = listeClePromotionsTemporaire.ToArray();

            // Récupération des promotions depuis Referentiel.
            PromotionPourDetail[] listePromotionPourDetail = this.servicesExternes.ReferentielServiceExterne.RechercherPromotionsDepuisListeCles(identite, listeClePromotions);
            PromotionLignePourLister promotionLignePourLister;

            List<PromotionLignePourLister> listeTemporairePromotionsActives = new List<PromotionLignePourLister>();
            // Liste des promotions actives.
            foreach (var promoActive in listePromotionsActives)
            {
                // Création de l’objet de présentation.
                promotionLignePourLister = ConstruirePromotionLignePourLister(identite, promoActive, listePromotionPourDetail, dateActivationLigne,
                    dateConfirmationCommandeSouscription, ligne.CleOffre);

                // Ajout de l'objet dans la collection ListePromotionsActives de l'objet de retour.
                listeTemporairePromotionsActives.Add(promotionLignePourLister);
            }
            // ListePromotionsActives doit être triée par date d’application – de la plus récente à la plus ancienne.
            promotionsARetourner.ListePromotionsActives = listeTemporairePromotionsActives.OrderByDescending(x => x.DateApplication).ToArray();

            List<PromotionLignePourLister> listeTemporairePromotionObsoletes = new List<PromotionLignePourLister>();

            // Liste des promotions obsolétes.
            foreach (var promoObsolete in listePromotionsObsoletes)
            {
                // Création de l’objet de présentation. 
                promotionLignePourLister = ConstruirePromotionLignePourLister(identite, promoObsolete, listePromotionPourDetail, dateActivationLigne,
                    dateConfirmationCommandeSouscription, ligne.CleOffre);

                // Ajout de l'objet dans la collection ListePromotionsObsoletes de l'objet de retour.
                listeTemporairePromotionObsoletes.Add(promotionLignePourLister);
            }
            // ListePromotionsObsoletes doit être triée par date d’application – de la plus récente à la plus ancienne.
            promotionsARetourner.ListePromotionsObsoletes = listeTemporairePromotionObsoletes.OrderByDescending(x => x.DateApplication).ToArray();

            return promotionsARetourner;
        }

        /// <summary>
        /// Applique une promotion à une ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="clePromotion">Clé de la promotion.</param>
        /// <param name="cleLigne">Clé de ligne fixe.</param>
        public void AppliquerPromotionSurLigne(Identite identite, int clePromotion, long cleLigne)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            clePromotion.Valider(nameof(clePromotion)).StrictementPositif();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Appel de la méthode ObtenirParCle du registre ILigneRepository.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Vérification de l'éligibilité de la promo pour cette ligne.
            bool estEligible = this.servicesExternes.ReferentielServiceExterne.TesterEligibiliteCodePromo(identite, ligne.CleOffre, clePromotion);
            if (estEligible)
            {
                // Appel de la méthode ObtenirPromotionParCle du service externe IReferentielServiceExterne.
                PromotionPourDetail promotion = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionParCle(identite, clePromotion, ligne.CleOffre);

                // Vérification du retour.
                promotion.Valider(nameof(promotion)).NonNul();
                if (promotion.EffetPromotion != Fixe.Domain.CommonTypes.Enumerations.EffetPromotion.SurOffre)
                {
                    throw new InvalidOperationException($"La promotion à appliquer (clePromotion={clePromotion}) n'est pas une promotion 'sur offre'.");
                }

                // Construction de l'objet de paramètres.
                DemandeRemisePourCreation demandeRemisePourCreation = new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurOffre,
                    PromotionPourDetail = promotion,
                    DetailRemiseForfaitPourCreation = null
                };

                // Appel de la méthode CreerEtActiverDemandeRemisePromotion du GestionnaireDemandesRemises de la ligne.
                ligne.GestionnaireDemandeRemises.CreerEtActiverDemandeRemisePromotion(identite, demandeRemisePourCreation, cleLigne, ligne.CleOffre);

            }
            else
            {
                throw new InvalidOperationException($"La promotion saisie n'est pas valide.");
            }
        }
        /// <summary>
        /// Résiliation d'une demande de remise - de type promotion - en place sur une ligne.
        /// </summary>
        /// <param name="identite">Informations d'identifications de l'appelant.</param>
        /// <param name="cleLigne">Clé de la ligne sur laquelle on veut résilier la demande de remise.</param>
        /// <param name="cleDemandeRemisePromotion">Clé de la demande de remise - de type promotion - à résilier.</param>
        public void ResilierPromotion(Identite identite, long cleLigne, long cleDemandeRemisePromotion)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            cleDemandeRemisePromotion.Valider(nameof(cleDemandeRemisePromotion)).StrictementPositif();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.GestionnaireDemandeRemises.ResilierDemandeRemiseParCle(identite, cleDemandeRemisePromotion, cleLigne, ligne.CleOffre);
        }

        /// <summary>
        /// Création de l’objet de présentation PromotionLignePourLister.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="promotion">Objet à convertir.</param>
        /// <param name="listePromotionsReferentiel">Données référentielles permettant de récupérer les informations relatives à la promotion.</param>
        /// <param name="dateActivationLigne">Date d'activation de la ligne.</param>
        /// <param name="dateConfirmationCommandeSouscription">Date de confirmation de la commande de souscription.</param>
        /// <param name="cleOffre">Clé de l'offre.</param>
        /// <returns>Objet de présentation.</returns>
        private PromotionLignePourLister ConstruirePromotionLignePourLister(Identite identite, DemandeRemisePromotion promotion,
                                                                    PromotionPourDetail[] listePromotionsReferentiel,
                                                                    DateTime dateActivationLigne,
                                                                    DateTime? dateConfirmationCommandeSouscription,
                                                                    int cleOffre)
        {
            // Extraire de la liste ‘listePromotionsReferentiel’ l’objet dont la cle = promo.ClePromotion.
            PromotionPourDetail promoPourDetail = listePromotionsReferentiel.FirstOrDefault(x => x.Cle == promotion.ClePromotion());
            promoPourDetail.Valider(nameof(promoPourDetail)).NonNul();

            // Création de l’objet de présentation.
            PromotionLignePourLister promotionLignePourLister = new PromotionLignePourLister()
            {
                Cle = promotion.Cle,
                Descriptif = promoPourDetail.Descriptif,
                CodePromo = promoPourDetail.CodePromo,
                DureeValiditeEnMois = promotion.DureeValidite,
                TypeApplication = TypeApplicationPromotionMapper.Convertir(promoPourDetail.EffetPromotion),
                EstSuppressionPossible = promotion.EstResiliable(identite, cleOffre),
                MemoID = promotion.ListeHistoriquesEtats
                                .OrderByDescending(x => x.DateChangementEtat)
                                .Select(x => x.AgentModification)
                                .FirstOrDefault(),
                Etat = promotion.ValeurEtat
            };

            switch (promotion.TypeDemandeRemise)
            {
                case TypeDemandeRemise.RemisePromotionSurFrais:

                    // MontantPromotionSurCommande.
                    promotionLignePourLister.MontantPromotionSurCommande = promoPourDetail.MontantTtc;

                    // DateApplication = date de confirmation de la commande de souscription (prendre date de passage au statut ‘à recouvrer’).
                    promotionLignePourLister.DateApplication = dateConfirmationCommandeSouscription.Value;

                    // DateFin = date de confirmation de la commande de souscription.
                    promotionLignePourLister.DateFin = dateConfirmationCommandeSouscription;

                    break;

                case TypeDemandeRemise.RemisePromotionSurOffre:

                    // MontantPromotionSurOffre.
                    promotionLignePourLister.MontantPromotionSurOffre = promoPourDetail.MontantTtc;

                    if (promotion.EstSurParc)
                    {
                        // DateApplication = date de passage de la promotion à l’état « activée ». A récupérer via ListeHistoriquesEtat.
                        promotionLignePourLister.DateApplication = promotion.ListeHistoriquesEtats
                                                                        .OrderByDescending(x => x.DateChangementEtat)
                                                                        .Where(x => x.NouvelEtat == EtatDemandeRemise.Activee)
                                                                        .Select(x => x.DateChangementEtat)
                                                                        .First();
                        // DateFin.
                        promotionLignePourLister.DateFin = promotion.DateFin;
                    }
                    else
                    {
                        // DateApplication = date d'activation de la ligne.
                        promotionLignePourLister.DateApplication = dateActivationLigne;

                        // DateFin.
                        promotionLignePourLister.DateFin = null;
                    }
                    break;
            }

            return promotionLignePourLister;
        }

        #endregion Méthodes
    }
}