﻿using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Obtention du détail des options de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Détail des options de la ligne.</returns>
        public OptionsLignePourDetail ObtenirDetailOptionsLigneParCleLigne(Identite identite, long cleLigne)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Instanciation de l'objet OptionsLignePourDetail.
            OptionsLignePourDetail optionLignePourDetail = new OptionsLignePourDetail();

            // Obtient une ligne par sa clé.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Obtient une offre par sa clé.
            OffrePourDetail offrePourDetail = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Obtient une technologie par sa clé.
            TechnologiePourDetail technologiePourDetail = this.servicesExternes.ReferentielServiceExterne.ObtenirTechnologieParCle(identite, ligne.CleTechnologie);

            // Obtient la date d'activation de la ligne.
            DateTime dateActivation = this.ObtenirDateActivationLigne(ligne);

            // Obtention de la liste des ListeCategorieOptions.
            optionLignePourDetail.ListeCategorieOptions = this.ObtenirListeCategorieOptions(identite, ligne);

            // Affectation du montant total des options valorisées récurrentes.
            // On fait la somme du PrixTtc pour toute les options à l'état activée et pour un mode facturation récurrent (inclus les options valorisées et les options FCT).
            optionLignePourDetail.MontantTotalOptionsValoriseesRecurrentes = optionLignePourDetail.ListeCategorieOptions.Sum(
                x => x.ListeRegroupementOptions.Sum(
                    y => y.Options.Where(
                        z => z.Etat == EtatOption.Activee
                             && z.PrixTtc != null
                             && z.ModeFacturation == ModeFacturation.Recurrent).Sum(z => z.PrixTtc))).Value;

            // Affectation des informations de la ligne.
            optionLignePourDetail.InformationsLigne = new LignePourDetail()
            {
                Numero = ligne.Numero,
                Etat = ligne.ValeurEtat,
                Offre = offrePourDetail.Descriptif,
                Technologie = technologiePourDetail.Libelle,
                DateActivation = dateActivation,
            };

            return optionLignePourDetail;
        }

        /// <summary>
        /// Enregistrement des modifications des options de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="clesOptionsAAjouter">Clés des options à ajouter.</param>
        /// <param name="clesOptionsASupprimer">Clés des options à supprimer.</param>
        public void EnregistrerOptionsLigne(Identite identite, long cleLigne, int[] clesOptionsAAjouter, int[] clesOptionsASupprimer)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            clesOptionsAAjouter.Valider(nameof(clesOptionsAAjouter)).Si(clesOptionsAAjouter.Any());
            clesOptionsASupprimer.Valider(nameof(clesOptionsASupprimer)).Si(clesOptionsASupprimer.Any());

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            List<int> listeClesOptions = new List<int>();
            listeClesOptions.AddRange(clesOptionsAAjouter);
            listeClesOptions.AddRange(clesOptionsASupprimer);
            ReponseListeOptions reponseListeOptions = this.briquesServicesExternes.OptionsServiceExterne
                .RechercherOptionsParCleGestionnaire(identite, ligne.CleGestionnaireOptions, listeClesOptions.ToArray());

            // Appel de la méthode modifier option gestionnaire.
            this.briquesServicesExternes.OptionsServiceExterne.ModifierOptionsGestionnaire(identite, ligne.CleGestionnaireOptions, clesOptionsAAjouter.ToList(), clesOptionsASupprimer.ToList());

            // Ajout de l'historique VIECLIENT_ACTE_CHGTOPTIONS.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                ligne.Cle,
                new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.EnvoiEmail,
                    CleOrigine = null,
                    Commentaire = "Envoi d'un e-mail de confirmation du changement d'option(s)",
                    ReferenceExterne = ligne.ReferenceExterne
                });

            // Envoi du mail de confirmation du changement d'email et création de l'historique.
            this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementOptions(identite,
                new ParametresEmailConfirmerChangementOptions()
                {
                    CleMarque = ligne.CleMarque,
                    EmailContact = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers).EmailContact,
                    ReferenceExterne = ligne.ReferenceExterne,
                    HeureFermetureSC = marque.HeureFermetureSc,
                    HeureOuvertureSC = marque.HeureFermetureSc,
                    LibelleMarque = marque.Libelle,
                    NumeroLigne = ligne.Numero,
                    TelephoneFixeSC = marque.TelephoneFixeSc,
                    TelephoneMobileContact = tiers.NumeroMobileDeContact,
                    TelephoneMobileSC = marque.TelephoneMobileSc,
                    UrlAssistance = marque.UrlAssistance,
                    NomTitulaire = tiers.Nom,
                    CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                    NomsOptionsResiliees = reponseListeOptions.Options.Where(x => clesOptionsASupprimer.Contains(x.Cle)).Select(x => x.Libelle).ToList(),
                    NomsOptionsSouscrites = reponseListeOptions.Options.Where(x => clesOptionsAAjouter.Contains(x.Cle)).Select(x => x.Libelle).ToList(),
                    TarifsMensuelOptions = reponseListeOptions.Options.Where(x => clesOptionsAAjouter.Contains(x.Cle)).Select(x => x.Cout.MontantTtc.ToString()).ToList()
                });
        }

        /// <summary>
        /// Obtenir la ligne qui correspond.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleGestionnaireOptions">Clé du gestionnaire d'option.</param>
        /// <returns>Ligne.</returns>
        public InformationLigne ObtenirLigneDepuisCleGestionnaireOptions(Identite identite, string cleGestionnaireOptions)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleGestionnaireOptions.Valider(nameof(cleGestionnaireOptions)).NonNul();

            Ligne ligne = this.LigneRepository.ObtenirDepuisCleGestionnaireOptions(cleGestionnaireOptions);
            ligne.Valider(nameof(ligne)).NonNull();

            return LigneMapper.Convertir(ligne);
        }

        #endregion Méthodes
    }
}