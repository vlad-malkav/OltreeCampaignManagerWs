﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Méthode qui permet de récupérer les informations de RIO pour une ligne fixe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <returns>Informations du RIO.</returns>
        public InformationsRioPourDetail ObtenirInformationsRioDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Obtention de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // On vérifie si le RIO est disponible.
            bool estRioDisponible;
            if (ligne.ListeHistoriqueEtats.Any(x => x.NouvelEtat == EtatLigne.Resiliee))
            {
                estRioDisponible = ligne.ListeHistoriqueEtats.Single(x => x.NouvelEtat == EtatLigne.Resiliee).DateChangementEtat > DateTime.Now.AddDays(-40);
            }
            else
            {
                estRioDisponible = true;
            }

            // Création de l'historique VIECLIENT_HISTO_ACTE_DEMANDERIO.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                ligne.Cle,
                new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.Rio,
                    CleOrigine = null,
                    Commentaire = "Restitution RIO au client",
                    ReferenceExterne = ligne.ReferenceExterne
                });

            // Instanciation de l'objet InformationsRioPourDetail.
            return new InformationsRioPourDetail()
            {
                EstRioDisponible = estRioDisponible,
                NumeroLigne = ligne.Numero,
                Rio = ligne.Rio
            };
        }
        /// <summary>
        /// Méthode qui permet d'envoyer le RIO par mail au client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void EnvoyerRioParMail(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Obtention de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Obtention du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Obtention de la marque.
            Marque marque = ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Envoi du mail Rio.
            this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerEmailRio(identite, new ParametresEmailRio()
            {
                CleMarque = ligne.CleMarque,
                DateFinEngagement = ligne.DateFinEngagement,
                EmailContact = tiers.EmailContact,
                HeureFermetureSc = marque.HeureFermetureSc,
                HeureOuvertureSc = marque.HeureOuvertureSc,
                LibelleMarque = marque.Libelle,
                MentionsLegalesMarque = marque.MentionLegales,
                ReferenceExterne = ligne.ReferenceExterne,
                Rio = ligne.Rio,
                TelephoneFixeContact = tiers.NumeroFixeDeContact,
                TelephoneFixeSc = marque.TelephoneFixeSc,
                TelephoneMobileContact = tiers.NumeroMobileDeContact,
                TelephoneMobileSc = marque.TelephoneMobileSc,
                NomTitulaire = tiers.Nom,
                CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                UrlAssistance = marque.UrlAssistance
            });
        }

        /// <summary>
        /// Méthode qui permet d'envoyer le RIO par courrier au client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void EnvoyerRioParCourrier(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Obtention de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Obtention du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Obtention de la marque.
            Marque marque = ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Envoi du mail Rio.
            this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerCourrierRio(identite, new ParametresCourrierRio()
            {
                CleMarque = ligne.CleMarque,
                DateFinEngagement = ligne.DateFinEngagement,
                HeureFermetureSc = marque.HeureFermetureSc,
                HeureOuvertureSc = marque.HeureOuvertureSc,
                LibelleMarque = marque.Libelle,
                MentionsLegalesMarque = marque.MentionLegales,
                ReferenceExterne = ligne.ReferenceExterne,
                Rio = ligne.Rio,
                TelephoneFixeContact = tiers.NumeroFixeDeContact,
                TelephoneFixeSc = marque.TelephoneFixeSc,
                TelephoneMobileContact = tiers.NumeroMobileDeContact,
                TelephoneMobileSc = marque.TelephoneMobileSc,
                UrlAssistance = marque.UrlAssistance,
                AdresseTiers1 = tiers.ListeAdresses.SingleOrDefault(x => x.EstPrincipale).Voie,
                AdresseTiers2 = tiers.ListeAdresses.SingleOrDefault(x => x.EstPrincipale).ComplementIdentification,
                CiviliteTiers = tiers.Civilite.ToString(),
                CodePostalTiers = tiers.ListeAdresses.SingleOrDefault(x => x.EstPrincipale).CodePostal,
                NomTiers = tiers.Nom,
                PrenomTiers = tiers.Prenom,
                VilleTiers = tiers.ListeAdresses.SingleOrDefault(x => x.EstPrincipale).Ville,
                ComplementIdentification = tiers.ListeAdresses.SingleOrDefault(x => x.EstPrincipale).ComplementIdentification
            });
        }

        #endregion
    }

}
