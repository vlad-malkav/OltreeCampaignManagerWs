﻿using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.Events;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service de réception et traitement des évènements dans le cadre des demandes de résiliation.
    /// </summary>
    public sealed class DemandeResiliationEventService : IDemandeResiliationEventService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        #region Champs

        #endregion Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="repositories">L'interface des repositories.</param>
        public DemandeResiliationEventService(IRepositories repositories)
        {
            // Vérification des paramètres.
            repositories.Valider(nameof(repositories)).NonNul();

            // Assignation des valeurs.
            this.repositories = repositories;
        }

        #endregion Constructeur

        #region Méthodes exposées : IDemandeResiliationEventService

        /// <summary>
        /// Sur réception de la création d'une demande de retour d'équipement.
        /// </summary>
        /// <param name="eventDemandeRetourEquipementCreee">Evènement.</param>
        /// <remarks>Cet évènement est levé par le domaine Vie Client.</remarks>
        public void SurCreationDemandeRetourEquipement(DemandeRetourEquipementCreee eventDemandeRetourEquipementCreee)
        {
            // Vérification des paramètres entrants.
            eventDemandeRetourEquipementCreee.Valider(nameof(eventDemandeRetourEquipementCreee)).NonNul();
            eventDemandeRetourEquipementCreee.NumeroRetour.Valider(nameof(eventDemandeRetourEquipementCreee.NumeroRetour)).Obligatoire();
            eventDemandeRetourEquipementCreee.CleDemandeResiliation.Valider(nameof(eventDemandeRetourEquipementCreee.CleDemandeResiliation)).StrictementPositif();
            eventDemandeRetourEquipementCreee.CleDemandeRetour.Valider(nameof(eventDemandeRetourEquipementCreee.CleDemandeRetour)).StrictementPositif();

            // Obtention de la demande de résiliation concernée.
            DemandeResiliation demandeResiliation = this.repositories.DemandeResiliationRepository
                .ObtenirDepuisCle(eventDemandeRetourEquipementCreee.CleDemandeResiliation);

            // Appel métier.
            demandeResiliation.DefinirNumeroRetourEquipement(eventDemandeRetourEquipementCreee.ObtenirIdentite(),
                eventDemandeRetourEquipementCreee.CleDemandeRetour, eventDemandeRetourEquipementCreee.NumeroRetour);
        }

        #endregion Méthodes exposées : IDemandeResiliationEventService
    }
}