﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.Gbo;
using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Tiers.Domain.SharedKernel.Event.Tiers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesServicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        /// <summary>
        /// Code erreur pour un ancien mot de passe erroné.
        /// </summary>
        private const int CODE_ERREUR_ANCIEN_MOT_DE_PASSE_ERRONE = 200;

        /// <summary>
        /// Message d'erreur pour un ancien mot de passe erroné.
        /// </summary>
        private const string MESSAGE_ERREUR_ANCIEN_MOT_DE_PASSE_ERRONE = "Votre ancien mot de passe est erroné.";

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Repository qui permet d'accéder à la persistance de LigneRepository.
        /// </summary>
        public ILigneRepository LigneRepository
        {
            get { return this.repositories.LigneRepository; }
        }

        /// <summary>
        /// Repository qui permet d'accéder à la persistance de DemandeRemiseRepository.
        /// </summary>
        public IDemandeRemiseRepository DemandeRemiseRepository
        {
            get { return this.repositories.DemandeRemiseRepository; }
        }

        /// <summary>
        /// Interface de service externe TiersServiceExterne.
        /// </summary>
        public ITiersServiceExterne TiersServiceExterne
        {
            get { return briquesServicesExternes.TiersServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe HistoriqueServiceExterne.
        /// </summary>
        public IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get { return servicesExternes.HistoriqueServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GBOServiceExterne.
        /// </summary>
        public EIT.Fixe.Domain.ExternalServices.IGboServiceExterne GboServiceExterne
        {
            get { return servicesExternes.GboServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe OptionServiceExterne.
        /// </summary>
        public IOptionsServiceExterne OptionsServiceExterne
        {
            get { return briquesServicesExternes.OptionsServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe ReferentielServiceExterne.
        /// </summary>
        public IReferentielServiceExterne ReferentielServiceExterne
        {
            get { return this.servicesExternes.ReferentielServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe ComptesClientServiceExterne.
        /// </summary>
        public IComptesClientServiceExterne ComptesClientServiceExterne
        {
            get { return this.briquesServicesExternes.ComptesClientServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GestionSurconsommationAboServiceExterne.
        /// </summary>
        public IGestionSurconsommationAboServiceExterne GestionSurconsommationAboServiceExterne
        {
            get { return this.briquesServicesExternes.GestionSurconsommationAboServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe LoginServiceExterne.
        /// </summary>
        public IAuthentificationServiceExterne LoginServiceExterne
        {
            get { return this.briquesServicesExternes.AuthentificationServiceExterne; }
        }

        /// <summary>
        /// Interface du génerateur de cles.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get { return this.serviceTechnique.GenerateurCles; }
        }

        /// <summary>
        /// Interface de service externe SouscriptionServiceExterne.
        /// </summary>
        public ISouscriptionServiceExterne SouscriptionServiceExterne
        {
            get { return servicesExternes.SouscriptionServiceExterne; }
        }
        /// <summary>
        /// Repository des historiques des dossiers GBO
        /// </summary>
        public IHistoriqueDossierGboLigneRepository HistoriqueDossierGboLigneRepository
        {
            get { return this.repositories.HistoriqueDossierGboLigneRepository; }
        }

        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="briquesServices">L'interface de la brique de service externes.</param>
        /// <param name="servicesExternes">L'interface du service externe.</param>
        /// <param name="repositories">L'interface des repositories.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        public LigneService(IBriquesServicesExternes briquesServices, IServicesExternes servicesExternes,
            IRepositories repositories, IServicesTechniques serviceTechnique)
        {
            // Vérification des paramètres.
            briquesServices.Valider(nameof(briquesServices)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            // Assignation des valeurs.
            this.briquesServicesExternes = briquesServices;
            this.servicesExternes = servicesExternes;
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
        }

        #endregion Constructeur

        #region Méthodes privées

        /// <summary>
        /// Permet de récupérer la date d'activation d'une ligne.
        /// </summary>
        /// <param name="ligne">Ligne.</param>
        /// <returns>Date d'activation de la ligne.</returns>
        private DateTime ObtenirDateActivationLigne(Ligne ligne)
        {
            return ligne.ListeHistoriqueEtats.OrderByDescending(x => x.DateChangementEtat)
                                                                   .Where(x => x.NouvelEtat == EtatLigne.Activee)
                                                                   .Select(x => x.DateChangementEtat)
                                                                   .First();
        }

        /// <summary>
        /// Obtient la liste des CategorieOptionsPourLister.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action.</param>
        /// <param name="ligne">Ligne.</param>
        /// <returns>Un tableau de CategorieOptionsPourLister.</returns>
        private CategorieOptionsPourLister[] ObtenirListeCategorieOptions(Identite identite, Ligne ligne)
        {
            // Obtient l'objet ReponseListeOptions.
            ReponseListeOptions reponseListeOptions = this.briquesServicesExternes.OptionsServiceExterne
                .RechercherOptionsParCleGestionnaire(identite, ligne.CleGestionnaireOptions, new int[] { });

            // Conversion des catégories.
            return reponseListeOptions.Categories.Select(c => new CategorieOptionsPourLister()
            {
                Cle = c.Cle,
                Libelle = c.Libelle,
                Ordre = c.Ordre,
                // Conversion de chacun des regroupement lié à la catégorie en RegroupementOptionsPourLister.
                ListeRegroupementOptions = reponseListeOptions.Regroupements.Where(r => r.CleCategorie == c.Cle)
                                                                             .Select(r => ConvertirRegroupementEnRegroupementOptionsPourLister(r, reponseListeOptions.Options, ligne.ValeurEtat))
                                                                             .ToArray()
            }).ToArray();
        }

        /// <summary>
        /// Convertit un regroupement en un RegroupementOptionsPourLister
        /// </summary>
        /// <param name="regroupement">Regroupement à convertir.</param>
        /// <param name="options">Liste d'options.</param>
        /// <param name="valeurEtatLigne">Valeur de l'état de la ligne.</param>
        /// <returns>Un RegroupementOptionsPourLister.</returns>
        private RegroupementOptionsPourLister ConvertirRegroupementEnRegroupementOptionsPourLister(Regroupement regroupement, List<Option> options, EtatLigne valeurEtatLigne)
        {
            return new RegroupementOptionsPourLister()
            {
                Cle = regroupement.Cle,
                Libelle = regroupement.Libelle,
                TypeExclusion = regroupement.TypeExclusion,
                Ordre = regroupement.Ordre,
                EstModifiable = valeurEtatLigne != EtatLigne.Resiliee
                                    && options.Where(o => o.CleRegroupement == regroupement.Cle).Any(o => o.EstModifiable),
                EstAcuneOptionActive = options.Where(o => o.CleRegroupement == regroupement.Cle).All(o => !o.EstSouscrite),
                // Conversion de chacune des options liée au regroupement en une OptionPourLister.
                Options = options.Where(o => o.CleRegroupement == regroupement.Cle).Select(o => ConvertirOptionEnOptionPourLister(o)).ToArray()
            };
        }

        /// <summary>
        /// Convertir une option en une OptionPourLister
        /// </summary>
        /// <param name="option">Option à convertir.</param>
        /// <returns>Un objet OptionPourLister</returns>
        private OptionPourLister ConvertirOptionEnOptionPourLister(Option option)
        {
            // Affectation des informations de l'option.
            OptionPourLister optionPourLister = new OptionPourLister()
            {
                Cle = option.Cle,
                Libelle = option.Libelle,
                Descriptif = option.Descriptif,
                Ordre = option.Ordre,
                PrixTtc = option.Cout.MontantTtc,
                PrixHt = option.Cout.MontantHt,
                ModeFacturation = option.ModeFacturation,
                EstModifiable = option.EstModifiable,
                EstSouscrite = option.EstSouscrite
            };

            // Affectation de l'état, des dates, des memoIds et des canaux en fonction de l'option.
            if (option.EstSouscrite)
            {
                optionPourLister.DateSouscription = option.DerniereModification.DateCreation;
                if (option.DerniereModification.EstEnCours)
                {
                    optionPourLister.Etat = EtatOption.ActivationEnCours;
                    optionPourLister.MemoIdSouscription = option.DerniereModification.Utilisateur;
                    optionPourLister.CanalSouscription = option.DerniereModification.Canal;
                }
                else
                {
                    optionPourLister.Etat = EtatOption.Activee;
                    optionPourLister.DateActivation = option.DerniereModification.DateTraitement;
                }
            }
            else
            {
                if (option.DerniereModification != null)
                {
                    optionPourLister.DateResiliation = option.DerniereModification.DateCreation;
                    if (option.DerniereModification.EstEnCours)
                    {
                        optionPourLister.Etat = EtatOption.DesactivationEnCours;
                        optionPourLister.MemoIdResiliation = option.DerniereModification.Utilisateur;
                        optionPourLister.CanalResiliation = option.DerniereModification.Canal;
                    }
                    else
                    {
                        optionPourLister.Etat = EtatOption.Desactivee;
                        optionPourLister.DateDesactivation = option.DerniereModification.DateTraitement;
                    }
                }
                else
                {
                    optionPourLister.Etat = EtatOption.Desactivee;
                }
            }

            return optionPourLister;
        }



        /// <summary>
        /// Creer une ligne pour detail.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="ligne">Ligne.</param>
        /// <returns>La ligne pour detail.</returns>
        private LignePourDetail ObtenirLigne(Identite identite, Ligne ligne)
        {
            // Récupération de l'offre de la ligne.
            OffrePourDetail offre = this.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Récupération de la technologie de la ligne.
            TechnologiePourDetail technologie = this.ReferentielServiceExterne.ObtenirTechnologieParCle(identite, ligne.CleTechnologie);

            // Récupération du tiers titulaire de la ligne fixe.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            // Récupération de l'adresse d'installation.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation = this.SouscriptionServiceExterne
                .ObtenirAdresseInstallationParCleEligibilite(identite, ligne.CleAdresseInstallation);

            // Obtient la date d'activation de la ligne.
            DateTime dateActivation = this.ObtenirDateActivationLigne(ligne);

            // Obtention de la marque.
            Marque marque = this.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);

            // Initialisation de l'objet de retour.
            LignePourDetail lignePourDetail = new LignePourDetail()
            {
                AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                Cle = ligne.Cle,
                DateFinEngagement = ligne.DateFinEngagement,
                Etat = ligne.ValeurEtat,
                Numero = ligne.Numero,
                Offre = offre.Nom,
                ReferenceExterne = ligne.ReferenceExterne,
                Technologie = technologie.Libelle,
                Tiers = TiersMapper.Convertir(tiers),
                CleMarque = ligne.CleMarque,
                NumeroContrat = ligne.NumeroContratOperateur,
                DateActivation = dateActivation,
                LibelleMarque = marque.Libelle
            };

            return lignePourDetail;
        }

        #endregion Méthodes privées

        #region ILigneService

        /// <summary>
        /// Création et activation d’une ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="informationsLigne">Informations de la ligne fixe à créer.</param>
        /// <returns>Clé technique de la ligne créée.</returns>
        public long CreerEtActiverLigne(Identite identite, InformationsLignePourCreationEtActivation informationsLigne)
        {
            // Vérification globale des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            informationsLigne.Valider(nameof(informationsLigne)).NonNul();

            // Vérification des informations de la ligne fournies en entrée.
            informationsLigne.CleMarque.Valider(nameof(informationsLigne.CleMarque)).StrictementPositif();
            informationsLigne.CleOffre.Valider(nameof(informationsLigne.CleOffre)).StrictementPositif();
            informationsLigne.CleTiers.Valider(nameof(informationsLigne.CleTiers)).StrictementPositif();
            informationsLigne.CleTechnologie.Valider(nameof(informationsLigne.CleTechnologie)).StrictementPositif();
            informationsLigne.ReferenceExterne.Valider(nameof(informationsLigne.ReferenceExterne)).Si(string.IsNullOrWhiteSpace(informationsLigne.ReferenceExterne));
            informationsLigne.Numero.Valider(nameof(informationsLigne.Numero)).Si(string.IsNullOrWhiteSpace(informationsLigne.Numero));
            informationsLigne.CleCompteFacturation.Valider(nameof(informationsLigne.CleCompteFacturation)).StrictementPositif();
            informationsLigne.CleGestionnaireOptions.Valider(nameof(informationsLigne.CleGestionnaireOptions)).Obligatoire();
            informationsLigne.CleAdresseInstallation.Valider(nameof(informationsLigne.CleAdresseInstallation)).StrictementPositif();
            informationsLigne.DateFinEngagement.Valider(nameof(informationsLigne.DateFinEngagement)).Si(informationsLigne.DateFinEngagement > DateTime.MinValue);
            informationsLigne.Rio.Valider(nameof(informationsLigne.Rio)).Si(string.IsNullOrWhiteSpace(informationsLigne.Rio));
            informationsLigne.IdentifiantTransactionOperateur.Valider(nameof(informationsLigne.IdentifiantTransactionOperateur)).StrictementPositif();
            informationsLigne.CleKitBox.Valider(nameof(informationsLigne.CleKitBox)).StrictementPositif();
            informationsLigne.CleCommandeExpedition.Valider(nameof(informationsLigne.CleCommandeExpedition)).StrictementPositif();

            OffrePourDetail offrePourDetail = this.ReferentielServiceExterne.ObtenirOffreParCle(identite, informationsLigne.CleOffre);

            List<DemandeRemisePourCreation> listeDemandeRemise = new List<DemandeRemisePourCreation>();

            if (offrePourDetail.MontantRemiseAutoHt.HasValue)
            {
                // Instanciation d'un objet DeamndeRemisePourCreation et ajout dans la liste de demandes de remise.
                listeDemandeRemise.Add(new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemise.RemiseSurForfait,
                    PromotionPourDetail = null,
                    DetailRemiseForfaitPourCreation = new DemandeRemiseForfaitPourCreation()
                    {
                        MontantHT = offrePourDetail.MontantRemiseAutoHt.Value
                    }
                });
            }

            // Récupération des promotions depuis le Referentiel.
            PromotionPourDetail[] listePromotionPourDetail = this.ReferentielServiceExterne.RechercherPromotionsDepuisListeClesEtCleOffre(identite,
                informationsLigne.CleOffre,
                informationsLigne.ListeClesPromotions.Select(x => (int)x).ToArray());

            // Pour toutes les promotions on ajoute une demande de remise dans la liste.
            if (listePromotionPourDetail != null && listePromotionPourDetail.Any())
            {
                listePromotionPourDetail.ToList().ForEach(promoPourDetail => listeDemandeRemise.Add(new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemiseMapper.Convertir(promoPourDetail.EffetPromotion),
                    PromotionPourDetail = promoPourDetail,
                    DetailRemiseForfaitPourCreation = null
                }));
            }

            // Génération de la clé technique de la ligne fixe.
            long cleLigne = this.GenerateurCles.ObtenirCleLongue<Ligne>();

            // Initialisation de l'objet de paramètres d'initialisation de la ligne.
            DetailLignePourCreation detailLignePourCreation = new DetailLignePourCreation()
            {
                Cle = cleLigne,
                CleCompteFacturation = informationsLigne.CleCompteFacturation,
                CleAdresseInstallation = informationsLigne.CleAdresseInstallation,
                CleGestionnaireOptions = informationsLigne.CleGestionnaireOptions,
                CleIcn = informationsLigne.CleIcn,
                CleMarque = informationsLigne.CleMarque,
                CleOffre = informationsLigne.CleOffre,
                CleTechnologie = informationsLigne.CleTechnologie,
                CleTiers = informationsLigne.CleTiers,
                CleCommandeExpedition = informationsLigne.CleCommandeExpedition,
                DateFinEngagement = informationsLigne.DateFinEngagement,
                IdentifiantTransactionOperateur = informationsLigne.IdentifiantTransactionOperateur,
                Numero = informationsLigne.Numero,
                NumeroContratOperateur = informationsLigne.NumeroContratOperateur,
                ReferenceExterne = informationsLigne.ReferenceExterne,
                Rio = informationsLigne.Rio,
                ListeDemandeRemisePourCreation = listeDemandeRemise,
                CleKitBox = informationsLigne.CleKitBox
            };

            // Instanciation de la ligne fixe.
            Ligne ligne = new Ligne(identite, detailLignePourCreation, this.serviceTechnique, this.servicesExternes, this.briquesServicesExternes, this.repositories);

            // Récupération de la liste des CommandeExpeditionReferenceCommercialePourLister du domaine Logistique.
            List<CommandeExpeditionReferenceCommercialePourLister> listeCommandeExpedition =
                this.servicesExternes.LogistiqueServiceExterne.ObtenirCommandeExpeditionParCle(identite, informationsLigne.CleCommandeExpedition);

            // Ajout d'un EquipementLigne pour chaque CommandeExpeditionReferenceCommercialePourLister récupéré précédemment.
            foreach (var referenceCommercialeCommandeExpedition in listeCommandeExpedition)
            {
                referenceCommercialeCommandeExpedition.CleEquipement.Valider(nameof(referenceCommercialeCommandeExpedition.CleEquipement)).NonNul();
                referenceCommercialeCommandeExpedition.CleEquipement.Value.Valider(nameof(referenceCommercialeCommandeExpedition.CleEquipement)).StrictementPositif();

                ligne.ListeEquipement.Add(new EquipementLigne(
                    identite,
                    this.serviceTechnique.GenerateurCles.ObtenirCleLongue<EquipementLigne>(),
                    ligne,
                    referenceCommercialeCommandeExpedition.CleEquipement.Value,
                    referenceCommercialeCommandeExpedition.CodeRefCom));
            }

            // Ajout de la ligne à la persistance.
            this.LigneRepository.AjouterLigne(ligne);

            // Retourne la clé technique de la ligne fixe créée.
            return ligne.Cle;
        }

        /// <summary>
        /// Liste l’ensemble des commandes passées dans le cadre d’une ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe pour laquelle récupérer les commandes.</param>
        /// <returns>Commandes de la ligne fixe.</returns>
        public CommandePourLister[] ObtenirListeCommandesParCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Appel à la méthode ObtenirReferenceExterneParCle du registre ILigneRepository en fournissant en entrée la clé de la ligne reçue en paramètre.
            string cleExterne = LigneRepository.ObtenirReferenceExterneDepuisCle(cleLigne);

            // Appel à la méthode RechercherCommandeSouscriptionParReferenceExterne du service externe SouscriptionServiceExterne.
            CommandeSouscriptionPourDetail commandeDeSouscription = this.servicesExternes.SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(identite, cleExterne);

            // Instanciation d’un tableau d’objets de présentation de type CommandePourLister
            CommandePourLister[] listeCommandePourLister = new CommandePourLister[] {
                CommandePourListerMapper.Convertir(commandeDeSouscription)
            };

            return listeCommandePourLister;
        }
        
        /// <summary>
        /// Obtention de la liste de toutes les lignes mobiles associées à un compte client.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé unique du compte client.</param>
        /// <returns>Liste des lignes de ce compte client mobile.</returns>
        public LigneCompteClientMobilePourLister[] ListerLignesCompteClientMobileParCle(Identite identite, long cle)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();

            // Récupération des informations du compte client.
            CompteClientPourDetail compteClientPourDetail = this.ComptesClientServiceExterne.ObtenirCompteClientParCle(identite, cle);

            // Instanciation de la variable de retour.
            List<LigneCompteClientMobilePourLister> tableauLigneCompteClient = new List<LigneCompteClientMobilePourLister>();

            // Initialisation des variables utilisées dans la boucle (en dehors de la boucle pour des raisons de performance).
            string codeOperateur = this.serviceTechnique.Parametrage.CodeOperateurReseauFull;
            decimal seuil;
            string login;
            string niveauAcces;

            // Pour chaque ligne du compte client, on ajoute les informations de la ligne mobile à la variable de retour.
            foreach (var ligne in compteClientPourDetail.ListeLignes)
            {
                // Récupération des informations d'enrichissement des données de la ligne.
                seuil = this.GestionSurconsommationAboServiceExterne.ObtenirSeuilParCleLigne(identite, ligne.Cle);
                login = this.LoginServiceExterne.ObtenirLoginLigneParCleLigne(identite, ligne.Cle);
                niveauAcces = this.LoginServiceExterne.ObtenirLoginLigneParCleLigne(identite, ligne.Cle);

                // Conversion + enrichissement des infos de la ligne.
                LigneCompteClientMobilePourLister ligneCompteClientMobile = LigneCompteClientMobileMapper.Convertir(
                    ligne, login, seuil, niveauAcces, ligne.CodeOperateur == codeOperateur);

                // Ajout de la ligne à la variable de retour.
                tableauLigneCompteClient.Add(ligneCompteClientMobile);
            }

            // Retour du tableau.
            return tableauLigneCompteClient.ToArray();
        }

        /// <summary>
        /// Obtention d'une ligne par sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Reference externe de la ligne.</param>
        /// <returns>Ligne correspondant à la clé.</returns>
        public LignePourDetail ObtenirLigneDepuisReferenceExterne(Identite identite, string referenceExterne)
        {
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            
            Ligne ligne = this.LigneRepository.ObtenirDepuisReferenceExterne(referenceExterne);

            return ObtenirLigne(identite, ligne);
        }

        /// <summary>
        /// Modification du statut de surconsommation d’une ligne fixe existante.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe pour laquelle mettre à jour le statut de surconso.</param>
        /// <param name="statutSurconsommation">Nouveau statut de surconsommation de la ligne fixe.</param>
        public void ModifierStatutSurconsommationLigne(Identite identite, long cleLigne, ProfilSurconsommation statutSurconsommation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            statutSurconsommation.Valider<Enum>(nameof(statutSurconsommation)).NonAttribuee();

            // Obtention de la ligne fixe.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Vérification de l'objet Ligne obtenu. 
            ligne.Valider(nameof(ligne)).NonNul();

            // Modification du statut de surconsommation de la ligne.
            ligne.ModifierStatutSurconsommation(identite, statutSurconsommation);
        }

        /// <summary>
        /// Création d'une qualification d'appel, avec ou sans création de dossier GBO.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <param name="informationsDossierGBO">Informations du dossier GBO à créer. Facultatif.</param>
        /// <param name="informationsHistorique">Informations de l'historique à créer. Requis.</param>
        /// <returns>Clés des éléments créés.</returns>
        /// <remarks>L'historique est créé dans tous les cas, le dossier GBO uniquement si le paramètre entrant n'est pas nul.</remarks>
        public ReponseCreationQualificationAppel CreerQualificationAppel(Identite identite, string referenceExterne,
            DossierGBOPourCreation informationsDossierGBO, HistoriquePourCreation informationsHistorique)
        {
            // Vérification des paramètres d'entrée.
            identite.Valider(nameof(identite)).NonNul();
            informationsHistorique.Valider(nameof(informationsHistorique)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Vérification du détail des paramètres entrants (Historique).
            informationsHistorique.CleMetier1.Valider(nameof(informationsHistorique.CleMetier1)).StrictementPositif();
            informationsHistorique.CleMetier2.Valider(nameof(informationsHistorique.CleMetier2)).StrictementPositif();
            informationsHistorique.Commentaire.Valider(nameof(informationsHistorique.Commentaire)).Obligatoire();
            if (informationsHistorique.CleOrigine.HasValue)
            {
                informationsHistorique.CleOrigine.Value.Valider(nameof(informationsHistorique.CleOrigine)).StrictementPositif();
            }

            // Création d'un objet de type HistoriquePourCreation, venant du CommonTypes.
            HistoriqueAppelPourCreation historiquePourCreation = HistoriquePourCreationMapper.Convertir(informationsHistorique);
            historiquePourCreation.HistoriqueFonctionnel.ReferenceExterne = referenceExterne;

            // Création de l'historique.
            long cleHistoriqueCree = this.HistoriqueServiceExterne.CreerHistoriqueAppel(identite, historiquePourCreation);

            // En cas de création de dossier GBO non-demandée, on arrête l'exécution de cette méthode.
            if (informationsDossierGBO == null)
            {
                return new ReponseCreationQualificationAppel
                {
                    CleHistorique = cleHistoriqueCree
                };
            }

            // Vérification du détail des paramètres entrants fournis pour la dossier GBO.
            informationsDossierGBO.Commentaire.Valider(nameof(informationsDossierGBO.Commentaire)).Obligatoire();
            informationsDossierGBO.CleActivite.Valider(nameof(informationsDossierGBO.CleActivite)).StrictementPositif();
            informationsDossierGBO.Delai.Valider(nameof(informationsDossierGBO.Delai)).StrictementPositif();

            // Création du dossier GBO avec historique d'association à la ligne.
            ReponseCreationDossierGbo reponseCreationDossierGbo = this.briquesServicesExternes.BriqueGboServiceExterne.CreerDossier(identite,
                referenceExterne, informationsDossierGBO.Commentaire, informationsDossierGBO.CleActivite, informationsDossierGBO.Delai);

            // Création de l'association historique/historique de création de dossier GBO.
            this.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(identite, cleHistoriqueCree, reponseCreationDossierGbo.CleHistoriqueAssociationDossierGboLigne);

            // Réponse
            return new ReponseCreationQualificationAppel
            {
                CleHistorique = cleHistoriqueCree,
                CleDossierGbo = reponseCreationDossierGbo.CleDossierGbo
            };
        }

        /// <summary>
        /// Méthode qui permet de modifier les informations de contact d'un tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreInformationsContact">Informations de contact à modifier.</param>
        public void ModifierInformationsContactTiers(Identite identite, ParametreInformationsContact parametreInformationsContact)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            parametreInformationsContact.Valider(nameof(parametreInformationsContact)).NonNul();

            // Création du message ModifierPreferencesDeContactTiersEvent de la brique Tiers.
            ModifierPreferencesDeContactTiersEvent eventModifierPreferencesTiersEvent = new ModifierPreferencesDeContactTiersEvent()
            {
                CleTiers = (int)parametreInformationsContact.CleTiers,
                ContactCourrier = parametreInformationsContact.ContactCourrier,
                ContactEmail = parametreInformationsContact.ContactMail,
                ContactMessageVocal = parametreInformationsContact.ContactMessageVocal,
                ContactSMS = parametreInformationsContact.ContactSms,
                ContactTelevente = parametreInformationsContact.ContactTelevente
            };

            // Envoi du message ModifierPreferencesDeContactTiersEvent.
            this.serviceTechnique.MessagingSystem.Publish(Environment.MachineName, Guid.NewGuid().ToString(), eventModifierPreferencesTiersEvent);

            // Obtention d'un objet ligne afin de récupérer la référence externe.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCleTiers(parametreInformationsContact.CleTiers);
            ligne.Valider(nameof(ligne)).NonNul();

            // Création d'un historique VIECLIENT_HISTO_ACTE_MODIFOPTINOPTOUT.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                ligne.Cle,
                new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.DonneesPersonnelles,
                    CleOrigine = null,
                    Commentaire = "Modification des options Opt-in/Opt-out",
                    ReferenceExterne = ligne.ReferenceExterne
                });
        }
        
        /// <summary>
        /// Méthode qui permet de réinitialiser le code confidentiel de l'espace client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="canalEnvoiMotDePasse">Canal de communication du mot de passe.</param>
        /// <param name="canalDemande">Canal de la demande (CRM ou WEB).</param>
        public void ReinitialiserCodeConfidentielSelfCare(Identite identite, long cleLigne, CanalCommunication canalEnvoiMotDePasse, string canalDemande)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            canalEnvoiMotDePasse.Valider(nameof(canalEnvoiMotDePasse)).NonNul();
            canalDemande.Valider(nameof(canalDemande)).Obligatoire();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Récupération de la marque.
            Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Réinitialisation du mot de passe.
            string motDePasseTemporaire = this.briquesServicesExternes.AuthentificationServiceExterne.ReinitialiserMotDePasseSfc(identite, tiers.EmailContact);

            // Transmission de la réponse.
            string destinataire = "";
            if (canalEnvoiMotDePasse == CanalCommunication.Sms)
            {
                ParametreSMSConfirmationReinitialisationCodeSelfCare paramSMS = new ParametreSMSConfirmationReinitialisationCodeSelfCare()
                {
                    CleMarque = ligne.CleMarque,
                    MotDePasseTemporaire = motDePasseTemporaire,
                    ReferenceExterne = ligne.ReferenceExterne,
                    TelephoneMobileContact = tiers.NumeroMobileDeContact
                };
                this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerSmsConfirmationReinitialisationCodeSelfCare(identite, paramSMS);

                destinataire = tiers.NumeroMobileDeContact;
            }

            if (canalEnvoiMotDePasse == CanalCommunication.Email)
            {
                ParametreEmailConfirmationReinitialisationCodeSelfCare paramEmail = new ParametreEmailConfirmationReinitialisationCodeSelfCare()
                {
                    CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                    NomTitulaire = tiers.Nom,
                    CleMarque = ligne.CleMarque,
                    MotDePasseTemporaire = motDePasseTemporaire,
                    ReferenceExterne = ligne.ReferenceExterne,
                    EmailContact = tiers.EmailContact,
                    HeureFermetureSc = marque.HeureFermetureSc,
                    HeureOuvertureSc = marque.HeureOuvertureSc,
                    LibelleMarque = marque.Libelle,
                    MentionsLegalesMarque = marque.MentionLegales,
                    TelephoneFixeSc = marque.TelephoneFixeSc,
                    TelephoneMobileSc = marque.TelephoneMobileSc,
                    UrlAssistance = marque.UrlAssistance
                };
                this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerEmailConfirmationReinitialisationCodeSelfCare(identite, paramEmail);

                destinataire = tiers.EmailContact;
            }
            if (canalEnvoiMotDePasse != CanalCommunication.NA)
            {
                // Création d'un historique VIECLIENT_HISTO_ACTE_REINITCODESFC.
                this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                    ligne.Cle,
                    new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                    {
                        CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                        CleMetier2 = TypeHistoriqueMetierNiveau2.CodeConfidentielEspaceClient,
                        CleOrigine = null,
                        Commentaire = "Réinitialisation du code confidentiel Espace Client envoyé par " + EnumExtension.GetEnumDescription(canalEnvoiMotDePasse) + ".",
                        ReferenceExterne = ligne.ReferenceExterne
                    });

                long cleHistoriqueReinitLigne = this.GenerateurCles.ObtenirCleLongue<HistoriqueReinitialiserLogin>();
                ParametreHistoriqueReinitialiserLoginPourCreation param = new ParametreHistoriqueReinitialiserLoginPourCreation()
                {
                    Cle = cleHistoriqueReinitLigne,
                    CleLigne = ligne.Cle,
                    Destinataire = destinataire,
                    Identifiant = tiers.EmailContact,
                    ModeEnvoi = canalEnvoiMotDePasse,
                    CanalDemande = canalDemande
                };
                HistoriqueReinitialiserLogin historique = new HistoriqueReinitialiserLogin(identite, param);
                this.repositories.HistoriqueReinitialiserLoginRepository.Ajouter(historique);
            }
        }

        /// <summary>
        /// Méthode qui permet de débloquer le compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne pour laquelle il faut débloquer le compte.</param>
        public void DebloquerCompteMyPartnerTv(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Obtention de la Ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Appel de la WM Debloquer du service SfrFixeCompteTv.
            this.briquesServicesExternes.SfrFixeCompteTvServiceExterne.Debloquer(identite, ligne.ReferenceExterne);

            // Génération d'un historique VIECLIENT_HISTO_ACTE_DEBLOCAGEMYPARTNERTV.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                ligne.Cle,
                new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.DeblocageCompteMyPartnerTv,
                    Commentaire = "Déblocage compte MyPartner TV",
                    CleOrigine = null,
                    ReferenceExterne = ligne.ReferenceExterne
                });
        }

        /// <summary>
        /// Méthode qui permet de lister des réinitialisations de login depuis une clé ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Historiques.</returns>
        public HistoriqueReinitialiserLoginPourLister[] ListerHistoriqueReinitialisationLoginDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Lister les HistoriqueReinitialiserLogin et conversion en HistoriqueReinitialiserLoginPourLister.
            HistoriqueReinitialiserLoginPourLister[] listeHistoriqueReinitialiserLogin = this.repositories
                .HistoriqueReinitialiserLoginRepository
                .ListerDepuisCleLigne(cleLigne).Select(x => x.Convertir()).ToArray();

            // Triage des historiques du plus récents aux plus anciens.
            return listeHistoriqueReinitialiserLogin.OrderByDescending(x => x.DateDemande).ToArray();
        }

        /// <summary>
        /// Envoi d'un SMS au client avec son RIO.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void EnvoyerRioParSms(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Récupération de la marque.
            Marque marque = ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Envoi du SMS de confirmation du RIO.
            this.briquesServicesExternes.CommunicationClientServiceExterne.EnvoyerSmsConfirmationRio(identite, new ParametresSmsRio
            {
                ReferenceExterne = ligne.ReferenceExterne,
                CleMarque = ligne.CleMarque,
                DateFinEngagement = ligne.DateFinEngagement,
                LibelleMarque = marque.Libelle,
                Rio = ligne.Rio,
                TelephoneMobileContact = tiers.NumeroMobileDeContact
            });
        }

        /// <summary>
        /// Retourne les informations de la ligne à partir de la clé tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Le détail de la ligne.</returns>
        public LignePourDetail ObtenirLigneDepuisCleTiers(Identite identite, long cleTiers)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();
            
            Ligne ligne = this.LigneRepository.ObtenirDepuisCleTiers(cleTiers);
            
            return ObtenirLigne(identite, ligne);
        }
        
        /// <summary>
        /// Obtention de la référence externe depuis le numéro de contrat opérateur.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        /// <returns>Référence externe associée au numéro de contrat opérateur.</returns>
        /// <remarks>Lève une exception en cas de valeur nulle.</remarks>
        public string ObtenirReferenceExterneDepuisCleContratOperateur(Identite identite, string numeroContratOperateur)
        {
            identite.Valider(nameof(identite)).NonNul();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            string referenceExterne = this.RechercherReferenceExterneParCleContratOperateur(identite, numeroContratOperateur);
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();
            return referenceExterne;
        }

        /// <summary>
        /// Obtention de la référence externe depuis le numéro de contrat opérateur.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        /// <returns>Référence externe associée au numéro de contrat opérateur.</returns>
        /// <remarks>Ne lève pas d'exception en cas de valeur nulle.</remarks>
        public string RechercherReferenceExterneParCleContratOperateur(Identite identite, string numeroContratOperateur)
        {
            identite.Valider(nameof(identite)).NonNul();
            numeroContratOperateur.Valider(nameof(numeroContratOperateur)).Obligatoire();

            Ligne ligne = this.repositories.LigneRepository.RechercherParNumeroContrat(numeroContratOperateur);

            return ligne != null ? ligne.ReferenceExterne : string.Empty;
        }

        /// <summary>
        /// Obtention d'une liste de lignes par un tableau de clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Cles des lignes fixes.</param>
        /// <returns>Tableau de lignes.</returns>
        public LignePourDetail[] ListerLignesDepuisClesLignes(Identite identite, long[] cleLigne)
        {
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).NonNul();

            List<LignePourDetail> listeLignes = new List<LignePourDetail>();
            Ligne ligne;
            LignePourDetail detail;
            foreach (var item in cleLigne)
            {
                ligne = this.LigneRepository.ObtenirDepuisCle(item);
                detail = ObtenirLigne(identite, ligne);
                listeLignes.Add(detail);

            }

            return listeLignes.ToArray();
        }

        /// <summary>
        /// Recherche d'une ligne par sa référence externe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Reference externe de la ligne.</param>
        /// <returns>Clé de la ligne, si elle existe.</returns>
        public long? RechercherCleLigneDepuisReferenceExterne(Identite identite, string referenceExterne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.RechercherParReferenceExterne(referenceExterne);

            return ligne != null ? (long?)ligne.Cle : null;
        }

        #endregion ILigneService
    }
}