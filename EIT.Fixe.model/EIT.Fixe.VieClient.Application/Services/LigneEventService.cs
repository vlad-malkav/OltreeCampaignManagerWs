﻿using EIT.Domain;
using EIT.Fixe.Facturation.Domain.CommonTypes.Event;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using NrjMobile.InterfaceOperateur.Evenements.Fixe;
using NrjMobile.PiecesJustificatives.Evenements.GBO.Evenements;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service de gestion des events des lignes fixes.
    /// </summary>
    public sealed class LigneEventService : ILigneEventService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        /// <summary>
        /// Interface regroupant les interfaces des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Repository qui permet d'accéder à la persistance de LigneRepository.
        /// </summary>
        public ILigneRepository LigneRepository
        {
            get { return this.repositories.LigneRepository; }
        }

        /// <summary>
        /// Interface de service externe HistoriqueServiceExterne.
        /// </summary>
        public IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get { return servicesExternes.HistoriqueServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GBOServiceExterne.
        /// </summary>
        public EIT.Fixe.Domain.ExternalServices.IGboServiceExterne GboServiceExterne
        {
            get { return servicesExternes.GboServiceExterne; }
        }

        /// <summary>
        /// Interface du génerateur de cles.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get { return this.serviceTechnique.GenerateurCles; }
        }


        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="repositories">L'interface des repositories.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        /// <param name="servicesExternes">L'interface des services externes.</param>
        public LigneEventService(IRepositories repositories, IServicesTechniques serviceTechnique, IServicesExternes servicesExternes)
        {
            // Vérification des paramètres.
            repositories.Valider(nameof(repositories)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            // Assignation des valeurs.
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
            this.servicesExternes = servicesExternes;
        }

        #endregion Constructeur

        #region ILigneEventService

        /// <summary>
        /// Méthode qui permet d'effectuer une résiliation automatique suite à la notification de portabilité sortante envoyée par la brique Interface Opérateur.
        /// </summary>
        /// <param name="eventPortabiliteSortante">Evénement envoyé par la brique IO.</param>
        public void SurPortabiliteSortante(PortabiliteSortante eventPortabiliteSortante)
        {
            // Vérification des entrées.
            eventPortabiliteSortante.Valider(nameof(eventPortabiliteSortante)).NonNul();
            eventPortabiliteSortante.CleContrat.Valider(nameof(eventPortabiliteSortante.CleContrat)).Obligatoire();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisNumeroContrat(eventPortabiliteSortante.CleContrat);

            // Récupération de la clé du motif de résiliation d'une portabilité sortante.
            long cleMotifResiliationPortabiliteSortante = this.serviceTechnique.Parametrage.CleMotifResiliationPortabiliteSortante;
            cleMotifResiliationPortabiliteSortante.Valider(nameof(cleMotifResiliationPortabiliteSortante)).StrictementPositif();

            // Récupération du motif de résiliation.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(cleMotifResiliationPortabiliteSortante);

            Domain.CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = this.RecupererInformationsDemandeResiliation(ligne, motifResiliation);

            // Appel de la méthode CreerDemandeResiliation de la ligne.
            ligne.CreerDemandeResiliation(eventPortabiliteSortante.ObtenirIdentite(), informationsDemandeResiliation);
        }

        /// <summary>
        /// Méthode qui permet d'effectuer une résiliation automatique suite à la notification d'impayés envoyée par le domaine Facturation.
        /// </summary>
        /// <param name="eventImpayes">Evénement envoyé par le domaine Facturation.</param>
        public void ResilierLigneSurImpayes(ResilierLigneEvent eventImpayes)
        {
            // Vérification des entrées.
            eventImpayes.Valider(nameof(eventImpayes)).NonNul();
            eventImpayes.CleLigne.Valider(nameof(eventImpayes.CleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(eventImpayes.CleLigne);

            // Récupération de la CleMotifResiliationImpayes de paramétrage.
            long cleMotifResiliationImpayes = this.serviceTechnique.Parametrage.CleMotifResiliationImpayes;
            cleMotifResiliationImpayes.Valider(nameof(cleMotifResiliationImpayes)).StrictementPositif();

            // Récupérer le motif de résiliation.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(cleMotifResiliationImpayes);

            Domain.CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = this.RecupererInformationsDemandeResiliation(ligne, motifResiliation);

            // Appel de la méthode CreerDemandeResiliation de la ligne.
            ligne.CreerDemandeResiliation(eventImpayes.ObtenirIdentite(), informationsDemandeResiliation);
        }

        /// <summary>
        /// Evenement levé par la brique PJ lors de l'ouverture d'un dossier GBO par un dossier PJ
        /// </summary>
        /// <param name="eventDossierGboCreeParDossierPj">Evenement levé par la brique PJ</param>
        public void SurDossierGboCreeParDossierPj(DossierGBOCreeParDPJ eventDossierGboCreeParDossierPj)
        {
            eventDossierGboCreeParDossierPj.Valider(nameof(eventDossierGboCreeParDossierPj)).NonNul();
            eventDossierGboCreeParDossierPj.RefExterne.Valider(nameof(eventDossierGboCreeParDossierPj.RefExterne)).Obligatoire();
            
            Ligne ligne = this.LigneRepository.RechercherParReferenceExterne(eventDossierGboCreeParDossierPj.RefExterne);

            if (ligne != null)
            {
                HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation();
                historiquePourCreation.CleMetier1 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau1.ActeDeGestion;
                historiquePourCreation.CleMetier2 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau2.DossierPj;
                historiquePourCreation.ReferenceExterne = eventDossierGboCreeParDossierPj.RefExterne;
                historiquePourCreation.Commentaire = "Ouverture d'un dossier PJ " + Environment.NewLine +
                                                     "Date de création : " + DateTime.Now.ToShortDateString() + Environment.NewLine +
                                                     "Heure de création : " + DateTime.Now.ToShortTimeString();

                long cleHistoriqueCree = this.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(eventDossierGboCreeParDossierPj.ObtenirIdentite(), ligne.Cle, historiquePourCreation);
                this.GboServiceExterne.CreerHistoriqueDossierGboLigne(eventDossierGboCreeParDossierPj.ObtenirIdentite(),
                    eventDossierGboCreeParDossierPj.RefExterne,
                    eventDossierGboCreeParDossierPj.CleDossierGBO);
                this.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(eventDossierGboCreeParDossierPj.ObtenirIdentite(), cleHistoriqueCree, eventDossierGboCreeParDossierPj.CleDossierGBO);
            }
        }

        /// <summary>
        /// Evenement levé par la brique PJ lors de la numérisation d'un PJ non attendue
        /// </summary>
        /// <param name="eventDossierGboCreeParNumerisation">Evenement levé par la brique PJ</param>
        public void SurDossierGboCreeParNumerisation(DossierGBOCreeParNumerisation eventDossierGboCreeParNumerisation)
        {
            eventDossierGboCreeParNumerisation.Valider(nameof(eventDossierGboCreeParNumerisation)).NonNul();
            eventDossierGboCreeParNumerisation.RefExterne.Valider(nameof(eventDossierGboCreeParNumerisation.RefExterne)).Obligatoire();

            Ligne ligne = this.LigneRepository.RechercherParReferenceExterne(eventDossierGboCreeParNumerisation.RefExterne);

            if (ligne != null)
            {
                HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation();
                historiquePourCreation.CleMetier1 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau1.ActeDeGestion;
                historiquePourCreation.CleMetier2 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau2.Ged;
                historiquePourCreation.ReferenceExterne = eventDossierGboCreeParNumerisation.RefExterne;
                historiquePourCreation.Commentaire = "Numérisation hors dossier PJ " + Environment.NewLine +
                                                     "Date de création : " + DateTime.Now.ToShortDateString() +
                                                     Environment.NewLine +
                                                     "Heure de création : " + DateTime.Now.ToShortTimeString();

                long cleHistoriqueCree =
                    this.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(
                        eventDossierGboCreeParNumerisation.ObtenirIdentite(), ligne.Cle, historiquePourCreation);
                this.GboServiceExterne.CreerHistoriqueDossierGboLigne(
                    eventDossierGboCreeParNumerisation.ObtenirIdentite(),
                    eventDossierGboCreeParNumerisation.RefExterne,
                    eventDossierGboCreeParNumerisation.CleDossierGBO);
                this.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(
                    eventDossierGboCreeParNumerisation.ObtenirIdentite(), cleHistoriqueCree,
                    eventDossierGboCreeParNumerisation.CleDossierGBO);
            }
        }

        #endregion ILigneEventService

        #region Méthodes privées

        /// <summary>
        /// Permet de récupérer les informations de demande de résiliation.
        /// </summary>
        /// <param name="ligne">Ligne.</param>
        /// <param name="motifResiliation">Motif de résiliation.</param>
        /// <returns>Les information nécessaire à la demande de résiliation.</returns>
        private Domain.CommonTypes.DTO.DemandeResiliationPourCreation RecupererInformationsDemandeResiliation(Ligne ligne, MotifResiliation motifResiliation)
        {
            ModeRetourEquipement modeRetourEquipement = new ModeRetourEquipement();
            // Si la cleIcn de la ligne est nulle.
            if (!ligne.CleIcn.HasValue)
            {
                // Si la liste des modes de retour d'équipements du motif resiliation n'est pas null et contient au moins un élément.
                if (motifResiliation.ListeModeRetourEquipement != null && motifResiliation.ListeModeRetourEquipement.Any())
                {
                    modeRetourEquipement = motifResiliation.ListeModeRetourEquipement.FirstOrDefault(m => m.TypeEnvoi == TypeEnvoi.EnvoiParLaPoste);
                    if (modeRetourEquipement == null)
                    {
                        modeRetourEquipement = new ModeRetourEquipement();
                    }
                }
            }
            else
            {
                if (motifResiliation.ListeModeRetourEquipement != null && motifResiliation.ListeModeRetourEquipement.Any())
                {
                    modeRetourEquipement = motifResiliation.ListeModeRetourEquipement.FirstOrDefault(m => m.EstCocheParDefaut);
                }
            }

            // Création de l'objet de paramètre pour création d'une demande de résiliation.
            return new Domain.CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = modeRetourEquipement.Cle,
                CleMotifResiliation = motifResiliation.Cle,
                DateReceptionCourrierAr = DateTime.Now,
                DateResiliationProgrammee = DateTime.Now.AddDays(motifResiliation.DelaiResiliation),
                Email = null,
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = null
            };
        }

        #endregion Méthodes privées
    }
}