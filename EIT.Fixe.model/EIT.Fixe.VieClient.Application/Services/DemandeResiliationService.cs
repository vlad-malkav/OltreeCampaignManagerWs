﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Implémentation du service DemandeResiliation du domaine VieClient.
    /// </summary>
    public class DemandeResiliationService : IDemandeResiliationService
    {
        #region Champs

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesExternes;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected DemandeResiliationService()
        {

        }

        /// <summary>
        /// Constructeur d'instanciation.
        /// </summary>
        /// <param name="repositories">Interface des repositories.</param>
        /// <param name="servicesExternes">Interface des services techniques.</param>
        /// <param name="briquesExternes">Interfaces des briques externes.</param>
        public DemandeResiliationService(IRepositories repositories, IServicesExternes servicesExternes, IBriquesServicesExternes briquesExternes)
        {
            // Vérification des entrées.
            repositories.Valider(nameof(repositories)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            briquesExternes.Valider(nameof(briquesExternes)).NonNul();

            this.repositories = repositories;
            this.servicesExternes = servicesExternes;
            this.briquesExternes = briquesExternes;
        }

        #endregion Constructeurs

        #region IDemandeResiliationService

        /// <summary>
        /// Méthode qui permet d'annuler une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation à annuler.</param>
        public void AnnulerDemandeResiliation(Identite identite, long cleDemandeResiliation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeResiliation.Valider(nameof(cleDemandeResiliation)).StrictementPositif();

            // Obtention de la demande de résiliation.
            DemandeResiliation demandeResiliation = this.repositories.DemandeResiliationRepository.ObtenirDepuisCle(cleDemandeResiliation);

            // Appel de la méthode Annuler.
            demandeResiliation.Annuler(identite);
        }

        /// <summary>
        /// Méthode qui permet de lister les demandes de résiliations différées.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <returns>Liste des clés des demandes de résiliations à traiter.</returns>
        public long[] ListerDemandesResiliationATraiter(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Appel de la méthode RechercheDemandesResiliationATraiter.
            List<DemandeResiliation> listeDemandesResiliationATraiter = this.repositories.DemandeResiliationRepository.RechercherDemandesResiliationATraiter();
            if (listeDemandesResiliationATraiter == null || !listeDemandesResiliationATraiter.Any())
            {
                return null;
            }

            // Retourne le résultat.
            return listeDemandesResiliationATraiter.Select(d => d.Cle).ToArray();
        }

        /// <summary>
        /// Méthode qui permet d'obtenir le détail d'une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation.</param>
        /// <returns>Détail de la demande de résiliation.</returns>
        public DemandeResiliationPourDetail ObtenirDetailDemandeResiliationParCle(Identite identite, long cleDemandeResiliation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeResiliation.Valider(nameof(cleDemandeResiliation)).StrictementPositif();

            // Obtenir la demande de résiliation.
            DemandeResiliation demandeResiliation = this.repositories.DemandeResiliationRepository.ObtenirDepuisCle(cleDemandeResiliation);

            // Obtenir le motif de résiliation.
            MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(demandeResiliation.CleMotifResiliation);

            // Obtenir le mode de retour équipement.
            ModeRetourEquipement modeRetourEquipement = this.repositories.ModeRetourEquipementRepository.ObtenirDepuisCle(demandeResiliation.CleModeRetourEquipement);

            // Recherche et affectation de l'adresse d'installation.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation =
                this.servicesExternes.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(identite, demandeResiliation.Ligne.CleAdresseInstallation);

            // Création d'une ligne pour détail.
            LignePourDetail lignePourDetail = new LignePourDetail();
            lignePourDetail.Numero = demandeResiliation.Ligne.Numero;
            lignePourDetail.Etat = demandeResiliation.Ligne.ValeurEtat;
            lignePourDetail.Cle = demandeResiliation.Ligne.Cle;
            lignePourDetail.CleMarque = demandeResiliation.Ligne.CleMarque;
            lignePourDetail.DateFinEngagement = demandeResiliation.Ligne.DateFinEngagement;
            lignePourDetail.ReferenceExterne = demandeResiliation.Ligne.ReferenceExterne;
            lignePourDetail.AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation);

            // Instanciation de l'objet de présentation.
            DemandeResiliationPourDetail demandeResiliationPourDetail = new DemandeResiliationPourDetail() {
                DateReceptionCourrierAr = demandeResiliation.DateReceptionCourrierAr,
                DateDemandeResiliation = demandeResiliation.SuiviDateCreation,
                DateResiliationProgrammee = demandeResiliation.DateResiliationProgrammee.Value,
                EstAnnulable = demandeResiliation.EstAnnulable,
                LibelleModeRetourEquipement = modeRetourEquipement.Libelle,
                LibelleMotifResiliation = motifResiliation.Libelle,
                NumeroRetourEquipement = demandeResiliation.NumeroRetourEquipement,
                TypePriseEnCharge = modeRetourEquipement.TypePriseEnCharge,
                TypeResiliation = motifResiliation.TypeResiliation,
                InformationsLigne = lignePourDetail,
                DateFinEngagement = lignePourDetail.DateFinEngagement,
                Email = demandeResiliation.Email,
                OrigineDemandeResiliation = motifResiliation.OrigineResiliation
            };

            string codePostalBonRetour;
            string complementVoieBonRetour;
            string villeBonRetour;
            string voieBonRetour;
            Fixe.Domain.CommonTypes.Civilite civiliteBonRetour;
            string nomBonRetour;
            string prenomBonRetour;

            //Si EstNouveauTiersBonRetour == True alors on renseigne la nouvelle adresse avec la demande resiliation.
            if (demandeResiliation.EstNouveauTiersBonRetour)
            {
                codePostalBonRetour = demandeResiliation.CodePostalTiersBonRetour;
                complementVoieBonRetour = demandeResiliation.ComplementVoieTiersBonRetour;
                villeBonRetour = demandeResiliation.VilleTiersBonRetour;
                voieBonRetour = demandeResiliation.VoieTiersBonRetour;
                civiliteBonRetour = demandeResiliation.CiviliteTiersBonRetour;
                nomBonRetour = demandeResiliation.NomTiersBonRetour;
                prenomBonRetour = demandeResiliation.PrenomTiersBonRetour;
            }
            //Sinon, avec les services externes.
            else
            {
                Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, demandeResiliation.Ligne.CleTiers);
                Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers adresseTiers = tiers.ListeAdresses.FirstOrDefault(a => a.EstPrincipale);
                codePostalBonRetour = adresseTiers.CodePostal;
                complementVoieBonRetour = adresseTiers.ComplementIdentification;
                villeBonRetour = adresseTiers.Ville;
                voieBonRetour = adresseTiers.Voie;
                civiliteBonRetour = tiers.Civilite;
                nomBonRetour = tiers.Nom;
                prenomBonRetour = tiers.Prenom;
            }

            demandeResiliationPourDetail.AdresseBonRetour = new TiersPourEnvoiBonRetour()
            {
                Adresse = new AdressePourDetail()
                {
                    CodePostal = codePostalBonRetour,
                    Complement = complementVoieBonRetour,
                    Ville = villeBonRetour,
                    Voie = voieBonRetour
                },
                Civilite = civiliteBonRetour,
                Nom = nomBonRetour,
                Prenom = prenomBonRetour
            };

            if (demandeResiliation.CleDemandeRetourEquipement.HasValue)
            {
                demandeResiliationPourDetail.CleDemandeRetourEquipement = demandeResiliation.CleDemandeRetourEquipement.Value;
            }
            if (demandeResiliation.DateAnnulation.HasValue)
            {
                demandeResiliationPourDetail.DateAnnulationDemandeResiliation = demandeResiliation.DateAnnulation.Value;
            }
            
            return demandeResiliationPourDetail;
        }

        /// <summary>
        /// Méthode qui permet de traiter une demande de résiliation différée.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation.</param>
        public void TraiterDemandeResiliationDifferee(Identite identite, long cleDemandeResiliation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleDemandeResiliation.Valider(nameof(cleDemandeResiliation)).StrictementPositif();

            // Recherche de la demande de résiliation.
            DemandeResiliation demandeResiliation = this.repositories.DemandeResiliationRepository.ObtenirDepuisCle(cleDemandeResiliation);

            // Appel de la méthode Traiter.
            demandeResiliation.Traiter(identite);
        }

        #endregion IDemandeResiliationService
    }
}
