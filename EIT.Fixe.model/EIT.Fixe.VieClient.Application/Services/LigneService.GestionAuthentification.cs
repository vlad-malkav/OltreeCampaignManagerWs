﻿using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Permet de changer le mot de passe d'accès au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login.</param>
        /// <param name="ancienMotDePasse">Ancien mot de passe.</param>
        /// <param name="nouveauMotDePasse">Nouveau mot de passe.</param>
        public void ChangerMotDePasseSelfcare(Identite identite, string login, string ancienMotDePasse, string nouveauMotDePasse)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            ancienMotDePasse.Valider(nameof(ancienMotDePasse)).Obligatoire();
            nouveauMotDePasse.Valider(nameof(nouveauMotDePasse)).Obligatoire();

            // Changement du mot de passe Selfcare.
            ReponseModificationMotDePasse reponse = this.LoginServiceExterne.ChangerMotDePasseSelfcare(identite, login, ancienMotDePasse, nouveauMotDePasse);

            if (!reponse.EstModifie)
            {
                if (reponse.CodeErreur == CODE_ERREUR_ANCIEN_MOT_DE_PASSE_ERRONE)
                {
                    throw new Exception(MESSAGE_ERREUR_ANCIEN_MOT_DE_PASSE_ERRONE);
                }
                else
                {
                    throw new Exception($"{reponse.MessageErreur}, Code erreur : {reponse.CodeErreur}");
                }
            }
        }

        /// <summary>
        /// Génère un OTP envoyé au client par email.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void DemanderOtp(Identite identite, string login, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Demande de l'OTP.
            this.LoginServiceExterne.DemanderOtp(identite, login, ligne.CleMarque);
        }

        /// <summary>
        /// Retourne un booléen pour indiquer s'il s'agit de la première connexion au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login.</param>
        /// <param name="codeOtp">Code OTP.</param>
        /// <returns>Résultat de la validation.</returns>
        public bool ValiderOtp(Identite identite, string login, int codeOtp)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            codeOtp.Valider(nameof(codeOtp)).StrictementPositif();

            ReponseValidationOtp reponse = this.LoginServiceExterne.ValiderOtp(identite, login, codeOtp);

            if (!reponse.EstValide)
            {
                throw new Exception($"{reponse.MessageErreur}");
            }

            return reponse.EstValide;
        }

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        public void ValiderCguFixe(Identite identite, string login)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            this.briquesServicesExternes.AuthentificationServiceExterne.ValiderCguFixe(identite, login);
        }

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Mobile.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        public void ValiderCguMobile(Identite identite, string login)
        {
            // Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();

            this.briquesServicesExternes.AuthentificationServiceExterne.ValiderCguMobile(identite, login);
        }

        /// <summary>
        /// Permet de valider le parcours de bienvenue sur le Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        public void ValiderParcoursBienvenue(Identite identite, string login, string referenceExterne)
        {
            // Validation des entrées
            identite.Valider(nameof(identite)).NonNul();
            login.Valider(nameof(login)).Obligatoire();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Obtention d'un objet ligne afin de récupérer la référence externe.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(referenceExterne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Création d'un historique VIECLIENT_HISTO_ACTE_PARCOURSBIENVENUESFC.
            this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                ligne.Cle,
                new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                {
                    CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                    CleMetier2 = TypeHistoriqueMetierNiveau2.ParcoursBienvenue,
                    CleOrigine = null,
                    Commentaire = "Validation du parcours de bienvenue",
                    ReferenceExterne = ligne.ReferenceExterne
                });
            
            this.briquesServicesExternes.AuthentificationServiceExterne.ValiderParcoursBienvenue(identite, login);
        }

        #endregion Méthodes
    }
}