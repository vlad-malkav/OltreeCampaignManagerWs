﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des pannes collectives.
    /// </summary>
    public sealed class PanneCollectiveService : IPanneCollectiveService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        /// <summary>
        /// Interface du service ligne.
        /// </summary>
        private readonly ILigneService ligneService;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Repository qui permet d'accéder à la persistance de PanneCollectiveRepository.
        /// </summary>
        public IPanneCollectiveRepository PanneCollectiveRepository
        {
            get { return this.repositories.PanneCollectiveRepository; }
        }

        /// <summary>
        /// Interface de service externe LoginServiceExterne.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get { return this.serviceTechnique.GenerateurCles; }
        }

        /// <summary>
        /// Interface de service LigneService.
        /// </summary>
        public ILigneService LigneService
        {
            get { return this.ligneService; }
        }

        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="repositories">L'interface du repositorie.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        /// <param name="ligneService">L'interface du service ligne.</param>
        public PanneCollectiveService(IRepositories repositories, IServicesTechniques serviceTechnique, ILigneService ligneService)
        {
            // Vérification des paramètres entrants.
            repositories.Valider(nameof(repositories)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();
            ligneService.Valider(nameof(serviceTechnique)).NonNul();

            // Assignation des valeurs.
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
            this.ligneService = ligneService;
        }

        #endregion Constructeur

        #region IPanneCollectiveService

        /// <summary>
        /// Indique si la ligne est oui ou non, impactée par une panne locale.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé unique de la ligne à tester.</param>
        /// <returns>Indique si la ligne est oui ou non, impactée par une panne locale.</returns>
        public bool EstLigneAffecteeParPanneCollective(Identite identite, long cleLigne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // On vérifie que la ligne existe (une exception est levée par la méthode Obtenir si le résultat est null).
           this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
           

            // On récupère du paramétrage la durée de validité des données.
            int dureeValidite = this.serviceTechnique.Parametrage.DureeValiditeDonneesPannesCollectives;

            // Récupération des pannes collectives.
            IEnumerable<PanneCollective> pannes = this.repositories.PanneCollectiveRepository.ListerPannesCollectivesParCleLigne(identite, cleLigne, dureeValidite);

            if (pannes == null || !pannes.Any())
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Création d'une panne collective.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="informationsPanneCollective">Informations de la panne collective à créer.</param>
        /// <returns>Clé de la panne collective créée.</returns>
        public bool CreerPanneCollective(Identite identite, InformationsPanneCollectivePourCreation informationsPanneCollective)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            informationsPanneCollective.Valider(nameof(informationsPanneCollective)).NonNul();
            informationsPanneCollective.CleLigne.Valider(nameof(informationsPanneCollective.CleLigne)).StrictementPositif();
            informationsPanneCollective.DateDebut.Valider(nameof(informationsPanneCollective.DateDebut)).NonNul();

            // On vérifie que la ligne existe (une exception est levée par la méthode Obtenir si le résultat est null).
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(informationsPanneCollective.CleLigne);
            
            // Génération d'une clé pour PanneCollective
            long clePanneCollective = this.serviceTechnique.GenerateurCles.ObtenirCleLongue<PanneCollective>();

            // Construction de l'objet métier PanneCollective
            PanneCollective panneCollective = new PanneCollective(identite, clePanneCollective, informationsPanneCollective.DateDebut);

            // Ajout de la PanneCollective sur la Ligne
            ligne.ListePannesCollectives.Add(panneCollective);


            return true;
        }

        /// <summary>
        /// Liste les pannes collectives impactant une ligne fixe par clé ligne.
        /// </summary>
        /// <param name="identite">Identité.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe.</param>
        /// <param name="dureeValidite">Durée de validité des données, en minutes.</param>
        /// <returns>Liste des pannes collectives impactant la ligne fixe.</returns>
        public PanneCollectivePourLister[] ListerPannesCollectivesParCleLigne(Identite identite, long cleLigne, int dureeValidite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            dureeValidite.Valider(nameof(dureeValidite)).StrictementPositif();

            // Récupération des pannes.
            IEnumerable<PanneCollective> pannes = this.repositories.PanneCollectiveRepository.ListerPannesCollectivesParCleLigne(identite, cleLigne, dureeValidite);

            // Contruction du retour.
            return pannes.Select(c => PanneCollectiveMapper.ConvertirPourLister(c)).ToArray();
        }

        #endregion IPanneCollectiveService
    }
}