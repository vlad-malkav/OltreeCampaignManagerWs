﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Mappers.TransfertAppelService;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.Linq;
using EIT.Fixe.VieClient.Application.Interface.Services;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Implémente le service applicatif de gestion de transfert d'appels.
    /// </summary>
    public sealed class TransfertAppelService : ITransfertAppelService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesServicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des briques externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces des services techniques.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;


        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Interface de service externe TiersServiceExterne.
        /// </summary>
        public ITiersServiceExterne TiersServiceExterne
        {
            get { return briquesServicesExternes.TiersServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe HistoriqueServiceExterne.
        /// </summary>
        public Domain.ServiceExterne.IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get { return this.servicesExternes.HistoriqueServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GBOServiceExterne.
        /// </summary>
        public IGboServiceExterne GboServiceExterne
        {
            get { return this.servicesExternes.GboServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe ReferentielServiceExterne.
        /// </summary>
        public Domain.ServiceExterne.IReferentielServiceExterne ReferentielServiceExterne
        {
            get { return this.servicesExternes.ReferentielServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe ComptesClientServiceExterne.
        /// </summary>
        public IComptesClientServiceExterne ComptesClientServiceExterne
        {
            get { return this.briquesServicesExternes.ComptesClientServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GestionSurconsommationAboServiceExterne.
        /// </summary>
        public IGestionSurconsommationAboServiceExterne GestionSurconsommationAboServiceExterne
        {
            get { return this.briquesServicesExternes.GestionSurconsommationAboServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe AuthentificationServiceExterne.
        /// </summary>
        public IAuthentificationServiceExterne AuthentificationServiceExterne
        {
            get { return this.briquesServicesExternes.AuthentificationServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe LoginServiceExterne.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get { return this.serviceTechnique.GenerateurCles; }
        }

        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="briquesServices">L'interface de la brique de service externes.</param>
        /// <param name="servicesExternes">L'interface du service externe.</param>
        /// <param name="repositories">L'interface du repositorie.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        public TransfertAppelService(IBriquesServicesExternes briquesServices, IServicesExternes servicesExternes, IRepositories repositories, IServicesTechniques serviceTechnique)
        {
            // Vérification des paramètres
            briquesServices.Valider(nameof(briquesServices)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNul();

            this.briquesServicesExternes = briquesServices;
            this.servicesExternes = servicesExternes;
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
        }

        #endregion Constructeur

        #region ITransfertAppelService

        /// <summary>
        /// Retourne les informations nécessaires à l’initialisation de l’écran de transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Cle unique de la ligne.</param>
        /// <returns>Informations nécessaires à l’initialisation de l’écran de transfert des appels.</returns>
        public InformationsInitialisationEcranTransfertAppel ObtenirInformationsInitialisationEcranTransfertAppel(Identite identite, long cleLigne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Récupérer la valeur DelaiTransfertAppel depuis le service de paramétrage.
            int delaiTransfertAppel = this.serviceTechnique.Parametrage.DelaiTransfertAppel;

            // Récupérer la valeur LibelleActiviteTransfertAppel depuis le service de paramétrage.
            string libelleActiviteTransfertAppel = this.serviceTechnique.Parametrage.LibelleActiviteTransfertAppel;

            // Appel de la méthode ObtenirThemesTransfertAppel du service externe IHistoriqueServiceExterne.
            ThemeQualificationAppel[] listeThemesQualificationAppel = this.servicesExternes.HistoriqueServiceExterne.ObtenirThemesTransfertAppel(identite);

            listeThemesQualificationAppel.Valider(nameof(listeThemesQualificationAppel)).NonNul();

            // Conversion du résultat en une liste d'objets de présentation.
            ThemeTransfertAppel[] listeThemes = listeThemesQualificationAppel.Select(x => ThemeTransfertAppelMapper.Convertir(x)).ToArray();

            // Instancier un objet de présentation de type InformationsInitialisationEcranTransfertAppel.
            InformationsInitialisationEcranTransfertAppel information = new InformationsInitialisationEcranTransfertAppel()
            {
                NumeroLigneFixe = ligne.Numero,
                Delai = delaiTransfertAppel,
                LibelleActivite = libelleActiviteTransfertAppel,
                ListeThemeTransfertAppel = listeThemes
            };

            return information;
        }

        /// <summary>
        /// Retourne la liste des types de « Niveau 2 » associés à un type « Niveau 1 » passé en paramètre.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleNiveau1">Clé de type niveau 1.</param>
        /// <returns>Tableau de Niveau 2.</returns>
        public Niveau2TransfertAppel[] ListerNiveau2TransfertDesAppelsParCleNiveau1(Identite identite, int cleNiveau1)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleNiveau1.Valider(nameof(cleNiveau1)).StrictementPositif();

            //Récupération des niveau2.
            Niveau2QualificationAppel[] tableauNiveau2 = this.HistoriqueServiceExterne.ObtenirNiveau2TransfertAppelParCleNiveau1(identite, cleNiveau1);

            //Instantiaiton de la liste à retourner.
            List<Niveau2TransfertAppel> listeNiveau2 = new List<Niveau2TransfertAppel>();

            //Vérification du retour.
            if (tableauNiveau2 != null && tableauNiveau2.Length > 0)
            {
                foreach (var niveau2 in tableauNiveau2)
                {
                    listeNiveau2.Add(Niveau2TransfertAppelMapper.Convertir(niveau2));
                }
            }

            return listeNiveau2.ToArray();
        }

        /// <summary>
        /// Retourne la liste des types de « Niveau 1 » associées à un « Thème » passé en paramètre.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleTheme">Clé du thème.</param>
        /// <returns>Tableau de "Niveau 1".</returns>
        public Niveau1TransfertAppel[] ListerNiveau1TransfertDesAppelsParCleTheme(Identite identite, int cleTheme)
        {
            //Validation des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTheme.Valider(nameof(cleTheme)).StrictementPositif();

            // Récupération des niveau1.
            Niveau1QualificationAppel[] tableauNiveau1 = this.HistoriqueServiceExterne.ObtenirNiveau1TransfertAppelParCleTheme(identite, cleTheme);

            //Instantiaiton de la liste à retourner.
            List<Niveau1TransfertAppel> listeNiveau1 = new List<Niveau1TransfertAppel>();
            //Vérification du retour.
            if (tableauNiveau1 != null && tableauNiveau1.Length > 0)
            {
                foreach (var niveau1 in tableauNiveau1)
                {
                    listeNiveau1.Add(Niveau1TransfertAppelMapper.Convertir(niveau1));
                }
            }
            return listeNiveau1.ToArray();
        }

        /// <summary>
        /// Transfère l'appel du service technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="parametresTransfertAppel">Ensemble d'informations saisies par l'utilisateur.</param>
        public void TransfererAppelServiceTechnique(Identite identite, ParametresTransfertAppelVersLeSupportTechnique parametresTransfertAppel)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            parametresTransfertAppel.Valider(nameof(parametresTransfertAppel)).NonNul();
            parametresTransfertAppel.ReferenceExterne.Valider(nameof(parametresTransfertAppel.ReferenceExterne)).Obligatoire();

            // Creation du dossier GBO, associé à la référence externe.
            int delai = 2; // En jours.
            int cleActivite = 67;
            this.briquesServicesExternes.BriqueGboServiceExterne
                .CreerDossier(identite, parametresTransfertAppel.ReferenceExterne, parametresTransfertAppel.Commentaire, cleActivite, delai);

            // Récupération de la ligne, pour récupérer le tiers.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(parametresTransfertAppel.ReferenceExterne);
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            // TODO En attente spécification : source de dureeAppel,numeroTelephoneAppelant et numeroTelephoneAppele ? 
            int dureeAppel = 1;                        // valeur bouchonnée
            string numeroTelephoneAppelant = "";      // valeur bouchonnée
            string numeroTelephoneAppele = "";        // valeur bouchonnée

            // Création de l'historique d'appel.
            HistoriqueAppelPourCreation historiqueAppel = new HistoriqueAppelPourCreation()
            {
                CleQualificationAppelNiveau1 = parametresTransfertAppel.CleNiveau1,
                CleQualificationAppelNiveau2 = parametresTransfertAppel.CleNiveau2,
                HistoriqueFonctionnel = new HistoriqueFonctionnelPourCreation()
                {
                    Commentaire = parametresTransfertAppel.Commentaire,
                    CleOrigine = null,
                    ReferenceExterne = parametresTransfertAppel.ReferenceExterne,
                    CleMetier1 = Fixe.Domain.Historique.TypeHistoriqueMetierNiveau1.QualificationServiceClient,
                    CleMetier2 = (Fixe.Domain.Historique.TypeHistoriqueMetierNiveau2)parametresTransfertAppel.CleTheme
                },
                DateAppel = DateTime.Now,
                NomTiers = tiers.Nom,
                PrenomTiers = tiers.Prenom,
                PointDeVenteCmi = identite.PointDeVente,
                CleCanalMedia = 9,
                DureeAppel = dureeAppel,
                NumeroTelephoneAppelant = numeroTelephoneAppelant,
                NumeroTelephoneAppele = numeroTelephoneAppele
            };
            this.HistoriqueServiceExterne.CreerHistoriqueAppel(identite, historiqueAppel);
        }

        #endregion ITransfertAppelService
    }
}