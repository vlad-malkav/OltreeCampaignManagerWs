﻿using EIT.Fixe.Domain.Historique;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Linq;
using TiersPourDetail = EIT.Fixe.VieClient.Application.Interface.DTO.TiersPourDetail;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Implémentation du service tiers du domaine VieClient.
    /// </summary>
    public class TiersService : ITiersService
    {
        #region Champs

        /// <summary>
        /// Interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesExternes;

        /// <summary>
        /// Interfaces de services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        #endregion Champs

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        protected TiersService()
        {

        }

        /// <summary>
        /// Constructeur d'instanciation.
        /// </summary>
        /// <param name="briquesExternes">Interface des briques externes.</param>
        /// <param name="servicesExternes">Interface des services externes.</param>
        /// <param name="repositories">Interface des repositories.</param>
        public TiersService(IBriquesServicesExternes briquesExternes, IServicesExternes servicesExternes,  IRepositories repositories)
        {
            // Vérification des entrées.
            briquesExternes.Valider(nameof(briquesExternes)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();

            // Initialisation des champs.
            this.briquesExternes = briquesExternes;
            this.servicesExternes = servicesExternes;
            this.repositories = repositories;
        }

        #endregion Constructeurs

        #region ITiersService

        /// <summary>
        /// Méthode qui permet d'enregistrer les modifications apportées sur l'email et/ou les numéros de téléphone du titulaire de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers de la ligne.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="informationsTitulaireLigne">Informations du titulaire à modifier.</param>
        public void EnregistrerInformationsTitulaireLigne(Identite identite, long cleTiers, long cleLigne, InformationsTitulaireLignePourModification informationsTitulaireLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            informationsTitulaireLigne.Valider(nameof(informationsTitulaireLigne)).NonNul();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            Domain.CommonTypes.DTO.Marque marque = this.servicesExternes.ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, cleTiers);

            bool EstNumeroFixeDifferent = tiers.NumeroFixeDeContact == null 
                                                           || !tiers.NumeroFixeDeContact.Equals(informationsTitulaireLigne.TelephoneFixe);

            bool EstNumeroMobileRenseigneEtDifferent = !string.IsNullOrWhiteSpace(informationsTitulaireLigne.TelephoneMobile)
                                                  && (tiers.NumeroMobileDeContact == null
                                                           || !tiers.NumeroMobileDeContact.Equals(informationsTitulaireLigne.TelephoneMobile));

            bool EstEmailRenseigneEtDifferent = !string.IsNullOrWhiteSpace(informationsTitulaireLigne.Email)
                                             && (tiers.EmailContact == null
                                                           || !tiers.EmailContact.Equals(informationsTitulaireLigne.Email));


            // Si le mail est renseigné et est différent du mail actuel.
            if (EstEmailRenseigneEtDifferent)
            {
                // Appel de la méthode ModifierEmailContactTiers de TiersServiceExterne.
                this.briquesExternes.TiersServiceExterne.ModifierEmailContactTiers(identite, cleTiers, informationsTitulaireLigne.Email);

                // Ajout de l'historique VIECLIENT_HISTO_ACTE_MODIFEMAIL.
                this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                    ligne.Cle,
                    new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                    {
                        CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                        CleMetier2 = TypeHistoriqueMetierNiveau2.DonneesPersonnelles,
                        CleOrigine = null,
                        Commentaire = "Changement d'e-mail titulaire. Nouvel e-mail titulaire : " + informationsTitulaireLigne.Email,
                        ReferenceExterne = ligne.ReferenceExterne
                    });

                // Envoi du mail de confirmation du changement d'email et création de l'historique.
                this.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementEmail(identite,
                    new Domain.CommonTypes.DTO.CommunicationClientServiceExterne.ParametresChangement()
                    {
                        CleMarque = ligne.CleMarque,
                        EmailContact = informationsTitulaireLigne.Email,
                        ReferenceExterne = ligne.ReferenceExterne,
                        HeureFermetureSC = marque.HeureFermetureSc,
                        HeureOuvertureSC = marque.HeureFermetureSc,
                        LibelleMarque = marque.Libelle,
                        NumeroLigne = ligne.Numero,
                        TelephoneFixeSC = marque.TelephoneFixeSc,
                        TelephoneMobileContact = EstNumeroMobileRenseigneEtDifferent ? informationsTitulaireLigne.TelephoneMobile : tiers.NumeroMobileDeContact,
                        TelephoneMobileSC = marque.TelephoneMobileSc,
                        NomTitulaire = tiers.Nom,
                        CiviliteTitulaire = tiers.Civilite.GetEnumDescription(),
                        UrlAssistance = marque.UrlAssistance
                    });
            }

            // Si l'un des numéros de téléphone ou les deux ont été modifiés.
            if (EstNumeroMobileRenseigneEtDifferent || EstNumeroFixeDifferent)
            {
                // Appel de la méthode ModifierTelephonesContactTiers de TiersServiceExterne.
                this.briquesExternes.TiersServiceExterne.ModifierTelephonesContactTiers(identite, 
                    cleTiers,
                    EstNumeroMobileRenseigneEtDifferent ? informationsTitulaireLigne.TelephoneMobile : tiers.NumeroMobileDeContact,
                    EstNumeroFixeDifferent ? informationsTitulaireLigne.TelephoneFixe : tiers.NumeroFixeDeContact);

                // Si le numéro de téléphone fixe du titulaire a été modifié.
                if (EstNumeroFixeDifferent)
                {
                    // Ajout de l'historique VIECLIENT_HISTO_ACTE_MODIFTEL pour le téléphone fixe.
                    this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                        ligne.Cle,
                        new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                        {
                            CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                            CleMetier2 = TypeHistoriqueMetierNiveau2.DonneesPersonnelles,
                            CleOrigine = null,
                            Commentaire = "Changement numéro téléphone contact. Nouveau numéro téléphone fixe de contact : " + informationsTitulaireLigne.TelephoneFixe,
                            ReferenceExterne = ligne.ReferenceExterne
                        });
                }

                // Si le numéro de téléphone mobile du titulaire a été modifié.
                if (EstNumeroMobileRenseigneEtDifferent)
                {
                    // Ajout de l'historique VIECLIENT_HISTO_ACTE_MODIFTEL pour le téléphone mobile.
                    this.servicesExternes.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(identite,
                        ligne.Cle,
                        new Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation()
                        {
                            CleMetier1 = TypeHistoriqueMetierNiveau1.ActeDeGestion,
                            CleMetier2 = TypeHistoriqueMetierNiveau2.DonneesPersonnelles,
                            CleOrigine = null,
                            Commentaire = "Changement numéro téléphone contact. Nouveau numéro téléphone mobile de contact : " + informationsTitulaireLigne.TelephoneMobile,
                            ReferenceExterne = ligne.ReferenceExterne
                        });
                }

                // Envoi du mail de confirmation du changement d'email et création de l'historique.
                this.briquesExternes.CommunicationClientServiceExterne.EnvoyerMailConfirmerChangementTelephone(identite,
                    new Domain.CommonTypes.DTO.CommunicationClientServiceExterne.ParametresEmailConfirmerChangementTelephone()
                    {
                        CleMarque = ligne.CleMarque,
                        EmailContact = EstEmailRenseigneEtDifferent ? informationsTitulaireLigne.Email : tiers.EmailContact,
                        ReferenceExterne = ligne.ReferenceExterne,
                        HeureFermetureSC = marque.HeureFermetureSc,
                        HeureOuvertureSC = marque.HeureFermetureSc,
                        LibelleMarque = marque.Libelle,
                        NumeroLigne = ligne.Numero,
                        TelephoneFixeSC = marque.TelephoneFixeSc,
                        TelephoneMobileSC = marque.TelephoneMobileSc,
                        TelephoneFixeContact = EstNumeroFixeDifferent ? informationsTitulaireLigne.TelephoneFixe : tiers.NumeroFixeDeContact,
                        TelephoneMobileContact = EstNumeroMobileRenseigneEtDifferent ? informationsTitulaireLigne.TelephoneMobile : tiers.NumeroMobileDeContact,
                        UrlAssistance = marque.UrlAssistance,
                        NomTitulaire = tiers.Nom,
                        CiviliteTitulaire = tiers.CiviliteEnum.GetEnumDescription()
                    });
            }
        }

        /// <summary>
        /// Méthode qui permet d'obtenir le détail du titulaire de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Détail du titulaire de la ligne.</returns>
        public TiersPourDetail ObtenirDetailTitulaireLigneParCleTiers(Identite identite, long cleTiers)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesExternes.TiersServiceExterne.ObtenirParCle(identite, cleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Parcours de la liste des adresses pour obtenir l'adresse pour laquelle la propriété EstPrincipale est à true.
            Domain.CommonTypes.DTO.TiersServiceExterne.AdresseTiers adresse = tiers.ListeAdresses.SingleOrDefault(t => t.EstPrincipale);

            // Affectation des informations du tiers à l'objet de présentation.
            return new TiersPourDetail()
            {
                AdressePrincipale = new AdressePourDetail()
                {
                    CodePostal = adresse.CodePostal,
                    Complement = adresse.ComplementIdentification,
                    Ville = adresse.Ville,
                    Voie = adresse.Voie
                },
                Civilite = tiers.CiviliteEnum,
                Cle = cleTiers,
                DateNaissance = tiers.DateNaissance,
                DepartementNaissance = tiers.NumeroDepartementNaissance,
                Email = tiers.EmailContact,
                EstContactCourrierPossible = tiers.EstContactCourrierPossible,
                EstContactEmailPossible = tiers.EstContactEmailPossible,
                EstContactMessageVocalPossible = tiers.EstContactMessageVocalPossible,
                EstContactSmsPossible = tiers.EstContactSmsPossible,
                EstContactTeleventePossible = tiers.EstContactTeleventePossible,
                Nom = tiers.Nom,
                NumeroTelephoneContact = tiers.NumeroMobileDeContact,
                NumeroTelephoneFixeContact = tiers.NumeroFixeDeContact,
                Prenom = tiers.Prenom,
                AgeCalcule = (DateTime.Now.Year - tiers.DateNaissance.Year -
                                ((DateTime.Now.Month < tiers.DateNaissance.Month) ? 1 :
                                    (DateTime.Now.Month == tiers.DateNaissance.Month && DateTime.Now.Day < tiers.DateNaissance.Day) ? 1 : 0))
            };
        }

        /// <summary>
        /// Méthode qui permet de vérifier si le tiers est associé à un tiers Mobile.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Booléen indiquant si le tiers est associé à un tiers mobile</returns>
        public TiersAssociePourDetail VerifierAssociationTiers(Identite identite, long cleTiers)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            TiersAssociePourDetail tiersAssocie = this.briquesExternes.TiersServiceExterne.ObtenirCleTiersMobileParCleTiersFixe(identite, (int)cleTiers);
            tiersAssocie.Valider(nameof(tiersAssocie)).NonNul();
            return tiersAssocie;
        }

        #endregion ITiersService
    }
}