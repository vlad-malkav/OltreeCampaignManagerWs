﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>

    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes
        /// <summary>
        /// Méthode qui permet de suspendre une ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void SuspendreLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            ligne.Suspendre(identite);
        }

        /// <summary>
        /// Méthode qui permet de remettre en service une ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        public void RemettreEnServiceLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            ligne.RemettreEnService(identite);
        }

        #endregion
    }
}
