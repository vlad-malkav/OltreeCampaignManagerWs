﻿using EIT.Fixe.Domain.Entities;
using EIT.Fixe.Domain.Gbo;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System.Collections.Generic;
using System.Linq;
using DtoExterne = EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes. Partie dédiée aux informations GBOs 
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        /// <summary>
        /// Web méthode permettant de récupérer les infos détaillées d'un dossier GBO
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDossier">La clé du dossier GBO pour laquelle il faut récupérer les informations.</param>
        /// <returns>Les informations détaillées du dossier GBO</returns>
        public InfoDossierGboPourDetail RechercherInfoDossierGboParCleDossier(Identite identite, int cleDossier)
        {
            identite.Valider(nameof(identite)).NonNull();
            cleDossier.Valider(nameof(cleDossier)).NonNul();

            HistoriqueDossierGboLigne historiqueDossier = HistoriqueDossierGboLigneRepository.RechercherParCleDossier(cleDossier);
            if (historiqueDossier == null)
            {
                return null;
            }

            DtoExterne.TiersPourDetail tiers = this.ObtenirTiersTitulaireLigne(identite, historiqueDossier.ReferenceExterneLigne);
            tiers.Valider(nameof(tiers)).NonNull();

            return new InfoDossierGboPourDetail()
            {
                LibellePorteur = historiqueDossier.ReferenceExterneLigne,
                ReferencePorteur = historiqueDossier.ReferenceExterneLigne,
                LibelleTitulaire = $"{tiers.Prenom} {tiers.Nom}"
            };
        }

        /// <summary>
        /// Web méthode permettant de récupérer les infos pour lister les dossiers GBO
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="clesDossiers">La liste des clés dossiers GBO qu'il faut lister</param>
        /// <returns>Les informations de listing des dossiers GBO passés en paramètres</returns>
        public List<InfoDossierGboPourListe> RechercherInfoDossierGboParListeCleDossier(Identite identite, List<int> clesDossiers)
        {
            identite.Valider(nameof(identite)).NonNull();
            clesDossiers.Valider(nameof(clesDossiers)).NonNull();

            var resultat = new List<InfoDossierGboPourListe>();

            foreach (var dossier in HistoriqueDossierGboLigneRepository.RechercherParListeCleDossier(clesDossiers))
            {

                DtoExterne.TiersPourDetail tiers = this.ObtenirTiersTitulaireLigne(identite, dossier.ReferenceExterneLigne);
                tiers.Valider(nameof(tiers)).NonNull();

                resultat.Add(new InfoDossierGboPourListe
                {
                    CleDossier = dossier.CleDossierGbo,
                    LibellePorteur = dossier.ReferenceExterneLigne,
                    ReferencePorteur = dossier.ReferenceExterneLigne,
                    LibelleTitulaire = $"{tiers.Prenom} {tiers.Nom}"
                });
            }

            return resultat;
        }

        private DtoExterne.TiersPourDetail ObtenirTiersTitulaireLigne(Identite identite, string referenceExterneLigne)
        {
            Ligne ligne = LigneRepository.RechercherParReferenceExterne(referenceExterneLigne);

            // La clé Tiers et dans l'objet ligne
            if (ligne != null)
            {
                return TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            }

            //Sinon la récupérer depuis la commande
            CommandeSouscriptionPourDetail commandeSouscription =
                SouscriptionServiceExterne.RechercherCommandeSouscriptionParReferenceExterne(identite, referenceExterneLigne);

            commandeSouscription.Valider(nameof(commandeSouscription)).NonNull();

            return TiersServiceExterne.ObtenirParCle(identite, commandeSouscription.CleTiers);
        }

        /// <summary>
        /// Liste les dossiers GBO créés dans le cadre d'une ligne fixe en fonction de la référence externe de cette dernière.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="nombreResultats">Nombre de résultats maximum à retourner (10 par défaut).</param>
        /// <returns>dossiers GBO créés dans le cadre de la ligne fixe.</returns>
        public Interface.DTO.DossierGboPourLister[] ListerDossiersGboParReferenceExterne(Identite identite, string referenceExterne, int? nombreResultats)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();

            int nombreResultatsMaximum = 10;
            if (nombreResultats.HasValue && nombreResultats.Value > 0)
            {
                nombreResultatsMaximum = nombreResultats.Value;
            }

            // Récupération des clés de dossiers.
            List<int> listeClesDossiers = this.GboServiceExterne.ListerClesDossiersDepuisReferenceExterne(identite, referenceExterne, nombreResultatsMaximum);

            // Si aucune clé de dossier, ça ne sert à rien de consulter le service externe. On retourne null.
            if (listeClesDossiers == null || !listeClesDossiers.Any())
            {
                return null;
            }

            // Récupération des dossiers GBO.
            Fixe.Domain.Gbo.DossierGboPourLister[] listeDossiers = this.briquesServicesExternes.BriqueGboServiceExterne
                 .RechercherDossiersParListeClesDossiers(identite, listeClesDossiers);

            // Si pas de dossiers, on renvoie null.
            if (listeDossiers == null || !listeDossiers.Any())
            {
                return null;
            }

            // Récupération des associations historiques/dossiers GBO.
            AssociationHistoriqueDossierGboPourLister[] listeAssociationsHistoriques = this.GboServiceExterne
                .ListerAssociationsHistoriquesDossiersGboParListeClesDossiersGbo(identite, listeClesDossiers.ToArray());

            // Récupération des historiques associés.
            Domain.CommonTypes.DTO.HistoriqueAppelPourLister[] listeHistoriques = this.servicesExternes.HistoriqueServiceExterne
                .ListerHistoriquesAppelsParListeCles(identite, listeAssociationsHistoriques?.Select(x => x.CleHistorique)?.ToArray());

            // Conversion des dossiers pour retour de méthode.
            IList<Interface.DTO.DossierGboPourLister> ret = new List<Interface.DTO.DossierGboPourLister>();
            if (listeHistoriques == null || !listeHistoriques.Any())
            {
                ret = GboMapper.Convertir(listeDossiers);
            }
            else
            {
                foreach (var dossier in listeDossiers)
                {
                    Domain.CommonTypes.DTO.HistoriqueAppelPourLister historiqueDossier = listeHistoriques.FirstOrDefault(his =>
                        his.Cle == listeAssociationsHistoriques
                        .Where(assoHis => assoHis.HistoriqueDossierGbo.CleDossierGbo == dossier.Cle)
                        .OrderByDescending(assoHis => assoHis.SuiviDateCreation)
                        .Select(assoHis => assoHis.CleHistorique)
                        .FirstOrDefault());

                    ret.Add(GboMapper.Convertir(dossier, historiqueDossier));
                }
            }

            return ret?.ToArray();
        }
    }
}