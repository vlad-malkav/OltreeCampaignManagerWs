﻿using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// <summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Obtention des informations d'une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Informations pour la demande de résiliation.</returns>
        public InformationsPourSaisieDemandeResiliation ObtenirInformationsPourSaisieDemandeResiliation(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Appel de la méthode ObtenirDateDerniereFactureParCleLigne de facturation pour la récupération de la date de la dernière facture.
            DateTime? dateDerniereFacture = this.servicesExternes.FacturationServiceExterne.RechercherDateDerniereFactureParCleLigne(identite, cleLigne);

            // Récupérer la liste des motifs de résiliation.
            List<MotifResiliation> listeMotifsResiliation = this.repositories.MotifResiliationRepository.ListerMotifsResiliation();
            listeMotifsResiliation.Valider(nameof(listeMotifsResiliation)).NonNul().Si(listeMotifsResiliation.Any());

            // Conversion des modes de retour équipement et des motifs de résiliation.
            List<MotifResiliationPourLister> listeMotifsARetourner = new List<MotifResiliationPourLister>();
            listeMotifsResiliation.ForEach(m => listeMotifsARetourner.Add(MotifResiliationMapper.Convertir(m)));

            // Récupération du tiers de la ligne.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            // Récupération de l'adresse principale du tiers et conversion.
            AdresseTiers adressePrincipale = tiers.ListeAdresses.FirstOrDefault(a => a.EstPrincipale);

            // Retourne un objet InformationsPourSaisieDemandeResiliation.
            return new InformationsPourSaisieDemandeResiliation()
            {
                Adresse = new AdressePourDetail()
                {
                    CodePostal = adressePrincipale.CodePostal,
                    Complement = adressePrincipale.ComplementIdentification,
                    Ville = adressePrincipale.Ville,
                    Voie = adressePrincipale.Voie
                },
                Civilite = tiers.CiviliteEnum,
                DateDerniereFacture = dateDerniereFacture.GetValueOrDefault(),
                DateFinEngagement = ligne.DateFinEngagement,
                Email = tiers.EmailContact,
                EstIcnActif = ligne.CleIcn.HasValue,
                ListeMotifResiliation = listeMotifsARetourner.ToArray(),
                Nom = tiers.Nom,
                NumeroLigne = ligne.Numero,
                Prenom = tiers.Prenom,
                ReferenceExterne = ligne.ReferenceExterne
            };
        }
        
        /// <summary>
        /// Création d'une demande de résiliation de ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne sur laquelle on crée une demande de résiliation.</param>
        /// <param name="informationsDemandeResiliation">Informations sur la résiliation.</param>
        public void CreerDemandeResiliation(Identite identite, long cleLigne, DemandeResiliationPourCreation informationsDemandeResiliation)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();
            informationsDemandeResiliation.Valider(nameof(informationsDemandeResiliation)).NonNul();

            // Recherche de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Conversion de l'objet de présentation.
            Domain.CommonTypes.DTO.DemandeResiliationPourCreation parametresCreationDemandeResiliation = DemandeResiliationMapper.Convertir(informationsDemandeResiliation);

            // Appel de la méthode CreerDemandeResiliation.
            ligne.CreerDemandeResiliation(identite, parametresCreationDemandeResiliation);
        }
        
        #endregion Méthodes
    }
}