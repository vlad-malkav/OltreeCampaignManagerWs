﻿using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Persistance;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System;
using System.Collections.Generic;
using System.Linq;
using FormulaireCN2DI = EIT.Fixe.VieClient.Application.Interface.DTO.FormulaireCN2DI;
using FormulaireCN3EQ = EIT.Fixe.VieClient.Application.Interface.DTO.FormulaireCN3EQ;
using FormulaireGBO = EIT.Fixe.VieClient.Application.Interface.DTO.FormulaireGBO;
using FormulaireMPS = EIT.Fixe.VieClient.Application.Interface.DTO.FormulaireMPS;
using FormulaireRisqueResiliation = EIT.Fixe.VieClient.Application.Interface.DTO.FormulaireRisqueResiliation;
using ParametresCreationFormulaireCN2DI = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationFormulaireCN2DI;
using ParametresCreationFormulaireCN3EQ = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationFormulaireCN3EQ;
using ParametresCreationFormulaireGbo = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationFormulaireGbo;
using ParametresCreationFormulaireMPS = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationFormulaireMPS;
using ParametresCreationFormulaireRisqueResiliation = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationFormulaireRisqueResiliation;
using ParametresCreationPieceJointeFormulaireGbo = EIT.Fixe.VieClient.Application.Interface.DTO.ParametresCreationPieceJointeFormulaireGbo;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des Formulaires GBO.
    /// </summary>
    public sealed class FormulaireGboService : IFormulaireGboService
    {
        #region Champs

        /// <summary>
        /// Interface regroupant les interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesServicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces du service technique.
        /// </summary>
        private readonly IServicesTechniques serviceTechnique;

        #endregion Champs

        #region Propriétés

        /// <summary>
        /// Repository qui permet d'accéder à la persistance de FormulaireGboRepository.
        /// </summary>
        public IFormulaireGboRepository FormulaireGboRepository
        {
            get { return this.repositories.FormulaireGboRepository; }
        }

        /// <summary>
        /// Interface de service externe HistoriqueServiceExterne.
        /// </summary>
        public Domain.ServiceExterne.IHistoriqueServiceExterne HistoriqueServiceExterne
        {
            get { return servicesExternes.HistoriqueServiceExterne; }
        }

        /// <summary>
        /// Interface de service externe GBOServiceExterne.
        /// </summary>
        public IGboServiceExterne GboServiceExterne
        {
            get { return servicesExternes.GboServiceExterne; }
        }

        /// <summary>
        /// Interface du génerateur de cles.
        /// </summary>
        public IGenerateurCles GenerateurCles
        {
            get { return this.serviceTechnique.GenerateurCles; }
        }

        #endregion Propriétés

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="briquesServices">L'interface de la brique de service externes.</param>
        /// <param name="servicesExternes">L'interface du service externe.</param>
        /// <param name="repositories">L'interface du repositorie.</param>
        /// <param name="serviceTechnique">L'interface du service technique.</param>
        public FormulaireGboService(IBriquesServicesExternes briquesServices, IServicesExternes servicesExternes,
            IRepositories repositories, IServicesTechniques serviceTechnique)
        {
            // Vérification des paramètres.
            briquesServices.Valider(nameof(briquesServices)).NonNull();
            servicesExternes.Valider(nameof(servicesExternes)).NonNull();
            repositories.Valider(nameof(repositories)).NonNull();
            serviceTechnique.Valider(nameof(serviceTechnique)).NonNull();

            // Assignation des valeurs.
            this.briquesServicesExternes = briquesServices;
            this.servicesExternes = servicesExternes;
            this.repositories = repositories;
            this.serviceTechnique = serviceTechnique;
        }

        #endregion Constructeur

        #region IFormulaireGboService

        #region Tables de Paramétrage

        #region MotifDysfonctionnement

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique du MotifDysfonctionnement.</param>
        /// <returns></returns>
        public MotifDysfonctionnement ObtenirMotifDysfonctionnementParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.TableParametrageGBO.MotifDysfonctionnement motifDysfonctionnement =
                FormulaireGboRepository.ObtenirMotifDysfonctionnementParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(motifDysfonctionnement);
        }

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifDysfonctionnement.</returns>
        public MotifDysfonctionnement[] ListerMotifDysfonctionnement(Identite identite)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();

            //Appel de la méthode.
            IEnumerable<Domain.Entities.TableParametrageGBO.MotifDysfonctionnement> listeMotifDysfonctionnement = FormulaireGboRepository.ListerMotifDysfonctionnement();

            //Retour.
            return listeMotifDysfonctionnement.Select(pro => FormulaireGBOMapper.Convertir(pro)).ToArray();
        }

        #endregion MotifDysfonctionnement

        #region MotifQualification

        /// <summary>
        /// Obtient un objet métier de type MotifQualification.
        /// </summary>
        /// <param name="cle">Clé technique du MotifQualification.</param>
        /// <returns></returns>
        public MotifQualification ObtenirMotifQualificationParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.TableParametrageGBO.MotifQualification motifQualification =
                FormulaireGboRepository.ObtenirMotifQualificationParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(motifQualification);
        }

        /// <summary>
        /// Recherche tous les MotifQualification.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifQualification.</returns>
        public MotifQualification[] ListerMotifQualification(Identite identite)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();

            //Appel de la méthode.
            IEnumerable<Domain.Entities.TableParametrageGBO.MotifQualification> listeMotifQualification = FormulaireGboRepository.ListerMotifQualification();

            //Retour.
            return listeMotifQualification.Select(pro => FormulaireGBOMapper.Convertir(pro)).ToArray();
        }

        #endregion MotifQualification

        #region NatureDemandeIntervention

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">Clé technique de la NatureDemandeIntervention.</param>
        /// <returns></returns>
        public NatureDemandeIntervention ObtenirNatureDemandeInterventionParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.TableParametrageGBO.NatureDemandeIntervention natureDemandeIntervention =
                FormulaireGboRepository.ObtenirNatureDemandeInterventionParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(natureDemandeIntervention);
        }

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention.
        /// </summary>
        /// <returns>Retourne la liste de tous les NatureDemandeIntervention.</returns>
        public NatureDemandeIntervention[] ListerNatureDemandeIntervention(Identite identite)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();

            //Appel de la méthode.
            IEnumerable<Domain.Entities.TableParametrageGBO.NatureDemandeIntervention> listeNatureDemandeIntervention = FormulaireGboRepository.ListerNatureDemandeIntervention();

            //Retour.
            return listeNatureDemandeIntervention.Select(pro => FormulaireGBOMapper.Convertir(pro)).ToArray();
        }

        #endregion NatureDemandeIntervention

        #region OrigineDysfonctionnement

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique de l'OrigineDysfonctionnement.</param>
        /// <returns></returns>
        public OrigineDysfonctionnement ObtenirOrigineDysfonctionnementParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement origineDysfonctionnement =
                FormulaireGboRepository.ObtenirOrigineDysfonctionnementParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(origineDysfonctionnement);
        }

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les OrigineDysfonctionnement.</returns>
        public OrigineDysfonctionnement[] ListerOrigineDysfonctionnement(Identite identite)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();

            //Appel de la méthode.
            IEnumerable<Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement> listeOrigineDysfonctionnement = FormulaireGboRepository.ListerOrigineDysfonctionnement();

            //Retour.
            return listeOrigineDysfonctionnement.Select(pro => FormulaireGBOMapper.Convertir(pro)).ToArray();
        }

        #endregion OrigineDysfonctionnement

        #region RegionCDC

        /// <summary>
        /// Obtient un objet métier de type RegionCDC.
        /// </summary>
        /// <param name="cle">Clé technique de la RegionCDC.</param>
        /// <returns></returns>
        public RegionCDC ObtenirRegionCdcParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.TableParametrageGBO.RegionCDC regionCDC =
                FormulaireGboRepository.ObtenirRegionCdcParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(regionCDC);
        }

        /// <summary>
        /// Recherche tous les RegionCDC.
        /// </summary>
        /// <returns>Retourne la liste de tous les RegionCDC.</returns>
        public RegionCDC[] ListerRegionCdc(Identite identite)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();

            //Appel de la méthode.
            IEnumerable<Domain.Entities.TableParametrageGBO.RegionCDC> listeRegionCDC = FormulaireGboRepository.ListerRegionCdc();

            //Retour.
            return listeRegionCDC.Select(pro => FormulaireGBOMapper.Convertir(pro)).ToArray();
        }

        #endregion RegionCDC

        #endregion Tables de Paramétrage

        #region Formulaires

        #region Utilitaire (private)

        private Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGbo(
            long cleDossierGbo,
            ParametresCreationFormulaireGbo parametresCreation)
        {
            // Génération de la clé technique.
            long cle = this.GenerateurCles.ObtenirCleLongue<Domain.Entities.FormulaireGBO.FormulaireGBO>();

            // Initialisation des Informations d’un CDC pour création.
            InformationsCdcPourCreation informationsCdcPourCreation = new InformationsCdcPourCreation
            {
                CdcAdresseMail = parametresCreation.CdcAdresseMail,
                CdcCodeBanque = parametresCreation.CdcCodeBanque,
                CdcCodeBranche = parametresCreation.CdcCodeBranche,
                CdcLigneDirecte = parametresCreation.CdcLigneDirecte,
                CdcNomPrenom = parametresCreation.CdcNomPrenom
            };

            Domain.Entities.TableParametrageGBO.RegionCDC regionCDC =
                FormulaireGboRepository.ObtenirRegionCdcParCle(parametresCreation.CdcCleRegion);

            // Initialisation de l'objet de paramètres de création de Formulaire GBO de base, côté Domaine.
            return new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(cle, cleDossierGbo, regionCDC, informationsCdcPourCreation, parametresCreation.ReferenceExterne);
        }

        /// <summary>
        /// Création d'une qualification d'appel.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <param name="informationsHistorique">Informations de l'historique.</param>
        public long CreerQualificationAppel(Identite identite, string referenceExterne, Interface.DTO.HistoriquePourCreation informationsHistorique)
        {
            // Vérification des paramètres d'entrée.
            identite.Valider(nameof(identite)).NonNul();
            informationsHistorique.Valider(nameof(informationsHistorique)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).Obligatoire();

            // Vérification du détail des paramètres entrants (Historique).
            informationsHistorique.CleMetier1.Valider(nameof(informationsHistorique.CleMetier1)).StrictementPositif();
            informationsHistorique.CleMetier2.Valider(nameof(informationsHistorique.CleMetier2)).StrictementPositif();
            informationsHistorique.Commentaire.Valider(nameof(informationsHistorique.Commentaire)).Obligatoire();
            if (informationsHistorique.CleOrigine.HasValue)
            {
                informationsHistorique.CleOrigine.Value.Valider(nameof(informationsHistorique.CleOrigine)).StrictementPositif();
            }

            // Création d'un objet de type  HistoriquePourCreation, venant du CommonTypes
            HistoriqueAppelPourCreation historiquePourCreation = HistoriquePourCreationMapper.Convertir(informationsHistorique);
            historiquePourCreation.HistoriqueFonctionnel.ReferenceExterne = referenceExterne;

            // Création de l'historique.
            long cleHistoriqueCree = this.HistoriqueServiceExterne.CreerHistoriqueAppel(identite, historiquePourCreation);

            return cleHistoriqueCree;
        }

        /// <summary>
        /// Création d'un Dossier GBO.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="informationsDossierGbo">Informations du dossier GBO.</param>
        public long CreerDossierGbo(Identite identite, DossierGBOPourCreation informationsDossierGbo)
        {
            // Vérification des paramètres d'entrée.
            identite.Valider(nameof(identite)).NonNul();
            informationsDossierGbo.Valider(nameof(informationsDossierGbo)).NonNul();

            // Vérification du détail des paramètres entrants (GBO).
            informationsDossierGbo.Commentaire.Valider(nameof(informationsDossierGbo.Commentaire)).Obligatoire();
            informationsDossierGbo.CleActivite.Valider(nameof(informationsDossierGbo.CleActivite)).StrictementPositif();
            informationsDossierGbo.Delai.Valider(nameof(informationsDossierGbo.Delai)).StrictementPositif();
            

            // Appel de la méthode CreerDossierGboPourLigne et stockage de la clé dans une variable locale.
            int cleDossierGboCree = this.briquesServicesExternes.BriqueGboServiceExterne.CreerDossier(
                identite, 
                informationsDossierGbo.Commentaire,
                informationsDossierGbo.CleActivite,
                informationsDossierGbo.Delai);

            return cleDossierGboCree;
        }

        private Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGbo(
            ParametresCreationPieceJointeFormulaireGbo parametresCreation)
        {
            // Génération de la clé technique.
            long cle = this.GenerateurCles.ObtenirCleLongue<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();

            // Initialisation de l'objet de paramètres de création de Pièce Jointe de Formulaire GBO, côté Domaine.
            return new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                cle,
                parametresCreation.GuDocId,
                parametresCreation.NomFichier);
        }

        #endregion Utilitaire (private)

        #region FormulaireGBO

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO de base.</param>
        /// <returns></returns>
        public FormulaireGBO ObtenirFormulaireGboParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.FormulaireGBO.FormulaireGBO formulaire =
            FormulaireGboRepository.ObtenirFormulaireGboParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(formulaire);
        }

        #endregion FormulaireGBO

        #region FormulaireCN2DI

        /// <summary>
        /// Création d'un Formulaire de niveau 2 de demande d'intervention.
        /// </summary>
        /// <param name="parametresCreation">Les paramètres de création du Formulaire à créer.</param>
        public long CreerFormulaireCN2DI(
            Identite identite,
            ParametresCreationFormulaireCN2DI parametresCreation,
            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo)
        {
            // Vérification globale des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            if (!this.briquesServicesExternes.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(identite,
                parametresCreation.ReferenceExterne))
            {
                throw new ArgumentException("La Référence Externe n'existe pas.");
            }

            // Vérification des paramètres de création fournis en entrée.
            parametresCreation.CleMotifDysfonctionnement.Valider(nameof(parametresCreation.CleMotifDysfonctionnement)).StrictementPositif();
            if (parametresCreation.CleOrigineDysfonctionnement != null)
            {
                parametresCreation.CleOrigineDysfonctionnement.Value.Valider(nameof(parametresCreation.CleOrigineDysfonctionnement.Value)).StrictementPositif();
            }
            parametresCreation.RaisonsDysfonctionnement.Valider(nameof(parametresCreation.RaisonsDysfonctionnement)).Obligatoire();
            parametresCreation.SolutionsDejaApportees.Valider(nameof(parametresCreation.SolutionsDejaApportees)).Obligatoire();

            //Création Dossier GBO
            DossierGBOPourCreation dossierGboPourCreation = new DossierGBOPourCreation
            {
                AgentProprietaire = null,
                CleActivite = 1,
                Delai = 2,
                EstConfidentiel = false,
                Commentaire = parametresCreation.DemandeClient
            };
            long cleDossierGbo = CreerDossierGbo(identite, dossierGboPourCreation);

            //Création Historique Qualification d'Appel
            HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation
            {
                CleMetier1 = 4,
                CleMetier2 = 35,
                Commentaire = parametresCreation.DemandeClient,
                CleOrigine = 3,
                NomTiers = parametresCreation.NomClient,
                PrenomTiers = parametresCreation.PrenomClient,
                NumeroTelephoneAppelant = "",
                NumeroTelephoneAppele = "",
                DateAppel = DateTime.Now,
                DureeAppel = 0,
                CleCanalMedia = 9,
                CleQualificationAppelNiveau1 = 124,
                CleQualificationAppelNiveau2 = 255,
                PointDeVenteCmi = identite.PointDeVente
            };

            CreerQualificationAppel(identite, "refexterne", historiquePourCreation);

            // Initialisation des objets de paramétrage de la création.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo parametresCreationFormulaireGboDomain =
                GenerateParametresCreationFormulaireGbo(cleDossierGbo, parametresCreation);

            var informationsClientPourCreation = new InformationsClientPourCreation
            {
                NomClient = parametresCreation.NomClient,
                PrenomClient = parametresCreation.PrenomClient
            };

            var informationsSupplementairesCN2DiPourCreation = new InformationsSupplementairesCN2DiPourCreation
            {
                SolutionsDejaApportees = parametresCreation.SolutionsDejaApportees,
                RaisonsDysfonctionnement = parametresCreation.RaisonsDysfonctionnement,
                DemandeClient = parametresCreation.DemandeClient,
                DateApproxAppelServiceClient = parametresCreation.DateApproxAppelServiceClient,
                NumeroCommandeClient = parametresCreation.NumeroCommandeClient
            };

            Domain.Entities.TableParametrageGBO.MotifDysfonctionnement motifDysfonctionnementDomain =
                FormulaireGboRepository.ObtenirMotifDysfonctionnementParCle(parametresCreation.CleMotifDysfonctionnement);

            Domain.Entities.TableParametrageGBO.OrigineDysfonctionnement origineDysfonctionnementDomain = parametresCreation.CleOrigineDysfonctionnement!= null ?
                FormulaireGboRepository.ObtenirOrigineDysfonctionnementParCle(parametresCreation.CleOrigineDysfonctionnement.Value) : null;

            // Initialisation de l'objet de paramètres de création côté Domaine.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DIDomaine =
                new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(
                    parametresCreationFormulaireGboDomain,
                    informationsClientPourCreation,
                    informationsSupplementairesCN2DiPourCreation,
                    motifDysfonctionnementDomain,
                    origineDysfonctionnementDomain
                );

            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePiecesJointesCrees =
                new List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();

            if(listeParametresCreationPieceJointeFormulaireGbo != null)
            {
                foreach (ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo
                    in listeParametresCreationPieceJointeFormulaireGbo)
                {
                    listePiecesJointesCrees.Add(new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                        identite,
                        GenerateParametresCreationPieceJointeFormulaireGbo(parametresCreationPieceJointeFormulaireGbo)));
                }
            }

            // Sauvegarde de l'entité
            this.FormulaireGboRepository.CreerFormulaireCN2DI(
                new Domain.Entities.FormulaireGBO.FormulaireCN2DI(
                    identite,
                    parametresCreationFormulaireCN2DIDomaine,
                    listePiecesJointesCrees));

            return parametresCreationFormulaireCN2DIDomaine.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 2 de demande d'intervention.</param>
        /// <returns></returns>
        public FormulaireCN2DI ObtenirFormulaireCN2DiParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.FormulaireGBO.FormulaireCN2DI formulaire =
            FormulaireGboRepository.ObtenirFormulaireCN2DiParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(formulaire);
        }

        #endregion FormulaireCN2DI

        #region FormulaireCN3EQ

        /// <summary>
        /// Création d'un Formulaire de niveau 3 d'engagement qualité.
        /// </summary>
        /// <param name="parametresCreation">Les paramètres de création du Formulaire à créer.</param>
        public long CreerFormulaireCN3EQ(
            Identite identite,
            ParametresCreationFormulaireCN3EQ parametresCreation,
            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo)
        {
            // Vérification globale des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            if (!this.briquesServicesExternes.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(identite,
                parametresCreation.ReferenceExterne))
            {
                throw new ArgumentException("La Référence Externe n'existe pas.");
            }

            // Vérification des paramètres de création fournis en entrée.
            parametresCreation.NumeroSuiviDossier.Valider(nameof(parametresCreation.NumeroSuiviDossier)).Obligatoire();
            parametresCreation.DateReponseCelluleN2.Valider(nameof(parametresCreation.DateReponseCelluleN2)).NonNul();
            parametresCreation.RaisonContestation.Valider(nameof(parametresCreation.RaisonContestation)).Obligatoire();
            parametresCreation.DemandeClient.Valider(nameof(parametresCreation.DemandeClient)).Obligatoire();
            parametresCreation.SolutionsDejaApportees.Valider(nameof(parametresCreation.SolutionsDejaApportees)).Obligatoire();
            parametresCreation.CleNatureDemandeIntervention.Valider(nameof(parametresCreation.CleNatureDemandeIntervention)).StrictementPositif();

            //Création Dossier GBO
            DossierGBOPourCreation dossierGboPourCreation = new DossierGBOPourCreation
            {
                AgentProprietaire = null,
                CleActivite = 1,
                Delai = 1,
                EstConfidentiel = false,
                Commentaire = parametresCreation.DemandeClient
            };
            long cleDossierGbo = CreerDossierGbo(identite, dossierGboPourCreation);

            //Création Historique Qualification d'Appel
            HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation
            {
                CleMetier1 = 4,
                CleMetier2 = 35,
                Commentaire = parametresCreation.DemandeClient,
                CleOrigine = 3,
                NomTiers = null,
                PrenomTiers = null,
                NumeroTelephoneAppelant = "",
                DateAppel = DateTime.Now,
                DureeAppel = 0,
                CleCanalMedia = 9,
                CleQualificationAppelNiveau1 = 124,
                CleQualificationAppelNiveau2 = 255,
                PointDeVenteCmi = identite.PointDeVente
            };

            CreerQualificationAppel(identite, "refexterne", historiquePourCreation);

            // Initialisation des objets de paramétrage de la création.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo parametresCreationFormulaireGBODomain =
                GenerateParametresCreationFormulaireGbo(cleDossierGbo, parametresCreation);

            var informationsSupplementairesCN3EqPourCreation = new InformationsSupplementairesCN3EqPourCreation
            {
                SolutionsDejaApportees = parametresCreation.SolutionsDejaApportees,
                DemandeClient = parametresCreation.DemandeClient,
                DateReponseCelluleN2 = parametresCreation.DateReponseCelluleN2,
                RaisonContestation = parametresCreation.RaisonContestation,
                NumeroSuiviDossier = parametresCreation.NumeroSuiviDossier
            };

            Domain.Entities.TableParametrageGBO.NatureDemandeIntervention natureDemandeInterventionDomain =
                FormulaireGboRepository.ObtenirNatureDemandeInterventionParCle(
                    parametresCreation.CleNatureDemandeIntervention);

            // Initialisation de l'objet de paramètres de création côté Domaine.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQDomaine =
                new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(
                    parametresCreationFormulaireGBODomain,
                    informationsSupplementairesCN3EqPourCreation,
                    natureDemandeInterventionDomain
                );

            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePiecesJointesCrees =
                new List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();

            if(listeParametresCreationPieceJointeFormulaireGbo != null)
            {
                foreach (ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo
                    in listeParametresCreationPieceJointeFormulaireGbo)
                {
                    listePiecesJointesCrees.Add(new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                        identite,
                        GenerateParametresCreationPieceJointeFormulaireGbo(parametresCreationPieceJointeFormulaireGbo)));
                }
            }

            // Sauvegarde de l'entité
            this.FormulaireGboRepository.CreerFormulaireCN3EQ(
                new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(
                    identite,
                    parametresCreationFormulaireCN3EQDomaine,
                    listePiecesJointesCrees));

            return parametresCreationFormulaireCN3EQDomaine.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 3 d'engagement qualité.</param>
        /// <returns></returns>
        public FormulaireCN3EQ ObtenirFormulaireCN3EqParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.FormulaireGBO.FormulaireCN3EQ formulaire =
            FormulaireGboRepository.ObtenirFormulaireCN3EqParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(formulaire);
        }

        #endregion FormulaireCN3EQ

        #region FormulaireMPS

        /// <summary>
        /// Création d'un Formulaire de modification de profil surconsommation.
        /// </summary>
        /// <param name="parametresCreation">Les paramètres de création du Formulaire à créer.</param>
        public long CreerFormulaireMps(Identite identite, ParametresCreationFormulaireMPS parametresCreation)
        {
            // Vérification globale des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            if (!this.briquesServicesExternes.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(identite,
                parametresCreation.ReferenceExterne))
            {
                throw new ArgumentException("La Référence Externe n'existe pas.");
            }

            // Vérification des paramètres de création fournis en entrée.
            parametresCreation.DateEffetDemande.Valider(nameof(parametresCreation.DateEffetDemande)).NonNul();
            parametresCreation.ProfilSurconsoDemande.Valider(nameof(parametresCreation.ProfilSurconsoDemande)).NonNul();
            parametresCreation.Commentaire.Valider(nameof(parametresCreation.Commentaire)).Obligatoire();

            //Création Dossier GBO
            DossierGBOPourCreation dossierGboPourCreation = new DossierGBOPourCreation
            {
                AgentProprietaire = null,
                CleActivite = 1,
                Delai = 2,
                EstConfidentiel = false,
                Commentaire = parametresCreation.Commentaire
            };
            long cleDossierGbo = CreerDossierGbo(identite, dossierGboPourCreation);

            //Création Historique Qualification d'Appel
            HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation
            {
                CleMetier1 = 4,
                CleMetier2 = 31,
                Commentaire = parametresCreation.Commentaire,
                CleOrigine = 3,
                NomTiers = parametresCreation.NomClient,
                PrenomTiers = parametresCreation.PrenomClient,
                NumeroTelephoneAppelant = "",
                NumeroTelephoneAppele = "",
                DateAppel = DateTime.Now,
                DureeAppel = 0,
                CleCanalMedia = 9,
                CleQualificationAppelNiveau1 = 17,
                CleQualificationAppelNiveau2 = 29,
                PointDeVenteCmi = identite.PointDeVente
            };

            CreerQualificationAppel(identite, "refexterne", historiquePourCreation);

            // Initialisation des objets de paramétrage de la création.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo parametresCreationFormulaireGBODomain =
                GenerateParametresCreationFormulaireGbo(cleDossierGbo, parametresCreation);

            var informationsClientPourCreation = new InformationsClientPourCreation
            {
                NomClient = parametresCreation.NomClient,
                PrenomClient = parametresCreation.PrenomClient
            };

            // Initialisation de l'objet de paramètres de création côté Domaine.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS parametresCreationFormulaireMPSDomaine =
                new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(
                    parametresCreationFormulaireGBODomain,
                    informationsClientPourCreation,
                    parametresCreation.DateEffetDemande,
                    parametresCreation.ProfilSurconsoDemande,
                    parametresCreation.Commentaire
                );

            // Sauvegarde de l'entité
            this.FormulaireGboRepository.CreerFormulaireMps(
                new Domain.Entities.FormulaireGBO.FormulaireMPS(
                    identite, parametresCreationFormulaireMPSDomaine));

            return parametresCreationFormulaireMPSDomaine.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de modification de profil surconsommation.</param>
        /// <returns></returns>
        public FormulaireMPS ObtenirFormulaireMpsParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.FormulaireGBO.FormulaireMPS formulaire =
            FormulaireGboRepository.ObtenirFormulaireMpsParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(formulaire);
        }

        #endregion FormulaireMPS

        #region FormulaireRisqueResiliation

        /// <summary>
        /// Création d'un Formulaire de risque de résiliation.
        /// </summary>
        /// <param name="parametresCreation">Les paramètres de création du Formulaire à créer.</param>
        public long CreerFormulaireRisqueResiliation(Identite identite, ParametresCreationFormulaireRisqueResiliation parametresCreation)
        {
            // Vérification globale des paramètres entrants.
            identite.Valider(nameof(identite)).NonNull();
            parametresCreation.Valider(nameof(parametresCreation)).NonNull();
            if (!this.briquesServicesExternes.BriqueDataMartLigneServiceExterne.EstReferenceExterneExistante(identite,
                parametresCreation.ReferenceExterne))
            {
                throw new ArgumentException("La Référence Externe n'existe pas.");
            }

            // Vérification des paramètres de création fournis en entrée.
            parametresCreation.CleMotifQualification.Valider(nameof(parametresCreation.CleMotifQualification)).StrictementPositif();

            //Création Dossier GBO
            DossierGBOPourCreation dossierGboPourCreation = new DossierGBOPourCreation
            {
                AgentProprietaire = null,
                CleActivite = 1,
                Delai = 30,
                EstConfidentiel = false,
                Commentaire = parametresCreation.Commentaire
            };
            long cleDossierGbo = CreerDossierGbo(identite, dossierGboPourCreation);

            //Création Historique Qualification d'Appel
            HistoriquePourCreation historiquePourCreation = new HistoriquePourCreation
            {
                CleMetier1 = 4,
                CleMetier2 = 34,
                Commentaire = parametresCreation.Commentaire,
                CleOrigine = 3,
                NomTiers = parametresCreation.NomClient,
                PrenomTiers = parametresCreation.PrenomClient,
                NumeroTelephoneAppelant = "",
                NumeroTelephoneAppele = "",
                DateAppel = DateTime.Now,
                DureeAppel = 0,
                CleCanalMedia = 9,
                CleQualificationAppelNiveau1 = 62,
                CleQualificationAppelNiveau2 = 110,
                PointDeVenteCmi = identite.PointDeVente
            };

            CreerQualificationAppel(identite, "refexterne", historiquePourCreation);

            // Initialisation des objets de paramétrage de la création.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo parametresCreationFormulaireGBODomain =
                GenerateParametresCreationFormulaireGbo(cleDossierGbo, parametresCreation);

            var informationsClientPourCreation = new InformationsClientPourCreation
            {
                NomClient = parametresCreation.NomClient,
                PrenomClient = parametresCreation.PrenomClient
            };

            Domain.Entities.TableParametrageGBO.MotifQualification motifQualificationDomain =
                FormulaireGboRepository.ObtenirMotifQualificationParCle(
                    parametresCreation.CleMotifQualification);

            // Initialisation de l'objet de paramètres de création côté Domaine.
            Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliationDomaine =
                new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(
                    parametresCreationFormulaireGBODomain,
                    informationsClientPourCreation,
                    parametresCreation.OffreClient,
                    motifQualificationDomain,
                    parametresCreation.Commentaire
                );

            // Sauvegarde de l'entité
            this.FormulaireGboRepository.CreerFormulaireRisqueResiliation(
                new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(
                    identite, parametresCreationFormulaireRisqueResiliationDomaine));

            return parametresCreationFormulaireRisqueResiliationDomaine.Cle;
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de risque de résiliation.</param>
        /// <returns></returns>
        public FormulaireRisqueResiliation ObtenirFormulaireRisqueResiliationParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation formulaire =
            FormulaireGboRepository.ObtenirFormulaireRisqueResiliationParCle(cle);

            //Retour.
            return FormulaireGBOMapper.Convertir(formulaire);
        }

        #endregion FormulaireRisqueResiliation

        #endregion Formulaires

        /// <summary>
        /// Obtient la clé d'un Formulaire GBO à partir de la Clé Dossier GBO associée.
        /// </summary>
        /// <param name="cle">Clé technique du Dossier GBO.</param>
        /// <returns></returns>
        public long ObtenirCleFormulaireGboDepuisCleDossier(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            long cleFormulaire =
            FormulaireGboRepository.ObtenirCleFormulaireGboDepuisCleDossier(cle);

            //Retour.
            return cleFormulaire;
        }

        /// <summary>
        /// Obtient le type d'un Formulaire GBO à partir de la Clé Formulaire
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO.</param>
        /// <returns></returns>
        public TypeFormulaireGBO ObtenirTypeFormulaireGboParCle(Identite identite, long cle)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();

            //Appel de la méthode.
            TypeFormulaireGBO typeFormulaireGBO =
                FormulaireGboRepository.ObtenirTypeFormulaireGboParCle(cle);

            //Retour.
            return typeFormulaireGBO;
        }

        #endregion IFormulaireGboService
    }
}