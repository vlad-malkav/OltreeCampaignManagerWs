﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    public class InfosAnnuaireService : IInfosAnnuaireService
    {
        #region Champs
        

        /// <summary>
        /// Interface regroupant les interfaces des repositories.
        /// </summary>
        private readonly IRepositories repositories;

        /// <summary>
        /// Interface regroupant les interfaces des briques externes.
        /// </summary>
        private readonly IBriquesServicesExternes briquesServicesExternes;

        /// <summary>
        /// Interface regroupant les interfaces des services externes.
        /// </summary>
        private readonly IServicesExternes servicesExternes;

        #endregion Champs

        #region Constructeur

        /// <summary>
        /// Constructeur avec groupements d'interfaces en paramètre.
        /// </summary>
        /// <param name="repositories">L'interface des repositories.</param>
        /// <param name="briquesServices">L'interface de la brique de service externes.</param>
        /// <param name="servicesExternes">L'interface du service externe.</param>
        public InfosAnnuaireService(IBriquesServicesExternes briquesServices, IServicesExternes servicesExternes, IRepositories repositories)
        {
            // Vérification des paramètres.
            briquesServices.Valider(nameof(briquesServices)).NonNul();
            servicesExternes.Valider(nameof(servicesExternes)).NonNul();
            repositories.Valider(nameof(repositories)).NonNul();

            // Assignation des valeurs.
            this.repositories = repositories;
            this.briquesServicesExternes = briquesServices;
            this.servicesExternes = servicesExternes;
        }

        #endregion Constructeur
        
        /// <summary>
        /// Obtient les informations relatives à la parution dans l’annuaire universel de la ligne.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la Ligne.</param>
        /// <returns>Informations relatives à la parution dans l’annuaire universel de la ligne.</returns>
        public InformationsParutionAnnuaireUniverselPourConsultation ObtenirParutionAnnuaireUniverselDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Appel à la méthode ObtenirDepuisCle du registre LigneRepository
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            //Appeler la méthode ObtenirOffreParCle de l’interface de service externe IReferentielServiceExterne, en lui passant ligne.CleOffre 
            //en paramètre, pour obtenir un objet de présentation de service externe de type OffrePourDetail, ‘offre’.
            OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Appeler la méthode ObtenirParCle de l’interface de service externe ITiersServiceExterne, en lui passant ligne.CleTiers en paramètre,
            //pour obtenir un objet de présentation de service externe de type TiersPourDetail, ‘tiers’
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            // Appeler la méthode ObtenirAnnuaireUniversel de l’interface de service externe IAnnuaireServiceExterne, en lui passant ligne.ReferenceExterne 
            // en paramètre, pour obtenir un objet de présentation de service externe de type InformationsAnnuaireUniversel, ‘annuaire’.
            InformationsAnnuaireUniversel annuaire = this.servicesExternes.AnnuaireServiceExterne.ObtenirAnnuaireUniversel(identite, ligne.ReferenceExterne);

            // Construire un objet de présentation de type InformationsParutionAnnuaireUniverselPourConsultation
            InformationsParutionAnnuaireUniverselPourConsultation annuairePourConsultation = new InformationsParutionAnnuaireUniverselPourConsultation()
            {
                CleTiers = ligne.CleTiers,
                ReferenceExterne = ligne.ReferenceExterne,
                NumeroLigne = ligne.Numero,
                DateActivation = ligne.ListeHistoriqueEtats.OrderByDescending(x => x.DateChangementEtat)
                                                            .First(x => x.NouvelEtat == EtatLigne.Activee)
                                                            .DateChangementEtat,
                DescriptionOffre = offre.Descriptif,
                Email = tiers.EmailContact,
                EstInscritAnnuaireUniversel = annuaire.DiffusionAnnuaireUniversel,
                ChoixParutionAnnuaire = ChoixParutionAnnuaireMapper.Convertir(annuaire)
            };

            // Retour de l'objet de présentation
            return annuairePourConsultation;
        }


        /// <summary>
        /// Définit la parution (ou le refus de parution) à l’annuaire universel.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="informationsParutionAnnuaire">Informations relatives à la parution dans l’annuaire universel.</param>
        /// <returns></returns>
        public void EnregistrerParutionAnnuaireUniversel(Identite identite, InformationsParutionAnnuaireUniverselPourEnregistrement informationsParutionAnnuaire)
        {
            // Vérification des entrées
            identite.Valider(nameof(identite)).NonNul();
            informationsParutionAnnuaire.Valider(nameof(informationsParutionAnnuaire)).NonNul();

            if(informationsParutionAnnuaire.EstInscritAnnuaireUniversel)
            {
                // Validation 
                informationsParutionAnnuaire.ChoixParutionAnnuaire.Valider(nameof(informationsParutionAnnuaire.ChoixParutionAnnuaire)).NonNul();

                // Convertir informationsParutionAnnuaire en objet de paramètre de service externe de type ParametresDefinirAnnuaire, ‘parametresAnnuaire’.
                ParametresDefinirAnnuaire parametresAnnuaire = ParametresDefinirAnnuaireMapper.Convertir(informationsParutionAnnuaire);

                // Appeler la méthode ModifierParutionAnnuaireUniverselParReferenceExterne de l’interface de service externe IAnnuaireServiceExterne (Souscription)
                this.servicesExternes.AnnuaireServiceExterne.ModifierParutionAnnuaireUniverselParReferenceExterne(identite,informationsParutionAnnuaire.ReferenceExterne, parametresAnnuaire);
            }
            else
            {
                // Appeler la méthode DefinirRefusAnnuaireUniverselParReferenceExterne de l’interface de service externe IAnnuaireServiceExterne
                this.servicesExternes.AnnuaireServiceExterne.DefinirRefusAnnuaireUniverselParReferenceExterne(identite, informationsParutionAnnuaire.ReferenceExterne);
            }
        }


        /// <summary>
        /// Liste les professions disponibles pour l’annuaire.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <returns>Liste des professions disponibles pour l’annuaire.</returns>
        public ProfessionPourLister[] ListerProfessionAnnuaire(Identite identite)
        {
            // Vérification des entrées
            identite.Valider(nameof(identite)).NonNul();

            // Appel de la méthode ListerProfessionAnnuaire de l’interface de service externe ISouscriptionServiceExterne
            List<ParamProfession> listeProfessions = this.servicesExternes.SouscriptionServiceExterne.ListerProfessionAnnuaire(identite);

            // Vérification du retour
            listeProfessions.Valider(nameof(listeProfessions)).NonNul();

            // Convertir chaque objet de la liste récupérée précédement en objet de présentation 
            ProfessionPourLister[] listeProfessionsPourLister = listeProfessions.Select(x=> ProfessionPourListerMapper.Convertir(x))
                                                                            .ToArray();

            return listeProfessionsPourLister;
        }
    }
}