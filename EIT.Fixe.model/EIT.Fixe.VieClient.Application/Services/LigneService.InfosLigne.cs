﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.Gbo;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Builders;
using EIT.Fixe.VieClient.Application.Constantes;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Application.Interface.Services;
using EIT.Fixe.VieClient.Application.Mappers;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Application.Services
{
    /// <summary>
    /// Service applicatif de gestion des lignes fixes.
    /// </summary>
    public sealed partial class LigneService : ILigneService
    {
        #region Méthodes

        /// <summary>
        /// Obtention de l’ensemble des informations nécessaires à l’affichage de la fiche de synthèse de la ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="numeroLigne">Numéro de ligne.</param>
        /// <returns>Ensemble des informations de la ligne nécessaires à la fiche de synthèse de la ligne fixe.</returns>
        public DetailLignePourFicheSynthese ObtenirInformationsLignePourFicheSyntheseParNumero(Identite identite, string numeroLigne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            numeroLigne.Valider(nameof(numeroLigne)).Obligatoire().Longueur(10);

            Ligne ligne = this.LigneRepository.ObtenirDepuisNumero(numeroLigne);
            return ObtenirInformationsLignePourFicheSyntheseParCle(identite, ligne.Cle);
        }

        /// <summary>
        /// Obtention de l’ensemble des informations nécessaires à l’affichage de la fiche de synthèse de la ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé technique de la ligne fixe.</param>
        /// <returns>Ensemble des informations de la ligne nécessaires à la fiche de synthèse de la ligne fixe.</returns>
        public DetailLignePourFicheSynthese ObtenirInformationsLignePourFicheSyntheseParCle(Identite identite, long cleLigne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            //Récupération de la Ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            //Récupération de la technologie.
            TechnologiePourDetail technologie = this.ReferentielServiceExterne.ObtenirTechnologieParCle(identite, ligne.CleTechnologie);
            technologie.Valider(nameof(technologie)).NonNul();

            //Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiersPourDetail = this.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiersPourDetail.Valider(nameof(tiersPourDetail)).NonNul();

            //Récupération location box.
            InformationsLocationBoxPourDetail locationBox = this.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(identite, ligne.CleGestionnaireOptions);

            // Recupération des historiques.
            int nombreResultatsHistoriques = this.serviceTechnique.Parametrage.NombreHistoriquesFicheSyntheseLigne;
            int indexListeHistoriques = 1;// On passe 1 et pas 0 au paramètre index de la recherche car il ne s'agit pas vraiment d'un index mais plutôt d'un numéro de pagination.
            HistoriquePourLister[] listeHistoriques = this.HistoriqueServiceExterne
                .RechercherHistoriquesParReferenceExterne(identite, ligne.ReferenceExterne, indexListeHistoriques, nombreResultatsHistoriques);

            //Récupération de la liste des clés des dossiers GBO (le nombre d'éléments à récupérer est paramétré)
            int nombreHistoriquesFicheSyntheseLigne = this.serviceTechnique.Parametrage.NombreHistoriquesFicheSyntheseLigne;
            List<int> listeCleDossierGbo = this.GboServiceExterne
                .ListerClesDossiersDepuisReferenceExterne(identite, ligne.ReferenceExterne, nombreHistoriquesFicheSyntheseLigne);

            //Récupération des dossiers GBO.
            Domain.CommonTypes.DTO.DossierGboPourLister[] listeDossierGBO = GboMapper.ConvertirPourDomaine(this.briquesServicesExternes.BriqueGboServiceExterne
                .RechercherDossiersParListeClesDossiers(identite, listeCleDossierGbo));

            //Appel la méthode AssociationsHistoriquesDossiersGboParListeClesDossiers
            AssociationHistoriqueDossierGboPourLister[] listeAssociationsHistoriquesDossierGbo =
                this.GboServiceExterne.ListerAssociationsHistoriquesDossiersGboParListeClesDossiersGbo(identite, listeCleDossierGbo?.ToArray());

            // Obtention du libellé de la marque.
            string libelleMarque = this.ReferentielServiceExterne.ObtenirLibelleMarqueParCle(identite, ligne.CleMarque);

            // Obtention des informations de l'offre.
            OffrePourDetail offre = this.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);


            // Obtention de l'adresse.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation = this.SouscriptionServiceExterne
                .ObtenirAdresseInstallationParCleEligibilite(identite, ligne.CleAdresseInstallation);


            // Appel à la méthode RechercherIcnParCle du service externe IIcnServiceExterne, en lui passant ligne.CleIcn, 
            // pour obtenir un objet de présentation de service externe de type Icn, ‘icn’
            Icn icn = null;
            if (ligne.CleIcn != null)
            {
                icn = this.briquesServicesExternes.IcnServiceExterne.RechercherIcnParCle(ligne.CleIcn.Value);
            }


            // Numéros de retours colis potentiellement associés à la ligne
            bool estGestionRetourColisAccessible = false;
            string numeroRetourColis = string.Empty;

            // Si la ligne est résiliée
            if (ligne.ValeurEtat == Fixe.Domain.CommonTypes.EtatLigne.Resiliee)
            {
                estGestionRetourColisAccessible = true;
                // Extraire le numéro de retour colis associé
                numeroRetourColis = ligne.ListeDemandeResiliation.OrderByDescending(x => x.SuiviDateCreation)
                                                                    .First()
                                                                    .NumeroRetourEquipement;
            }

            // Numéros de retours colis associés à des SAV Equipements
            List<long> listeClesSavEquipement = this.servicesExternes.SavServiceExterne.ListerClesSavEquipementParReferenceExterne(identite, ligne.ReferenceExterne);
            // Si il existe des SAV Equipement associés à la ligne
            if (listeClesSavEquipement.Any())
            {
                // Si on a déjà un numéro de retour colis provenant de la demande de résiliation
                if (estGestionRetourColisAccessible)
                {
                    // Supprimer la valeur de numeroRetourColis. (un seul numéro de retour colis ou rien)
                    numeroRetourColis = string.Empty;
                }
                else
                {
                    estGestionRetourColisAccessible = true;

                    // S'il n'existe qu'un seul SAV Equipement
                    if (listeClesSavEquipement.Count == 1)
                    {
                        // Appeler la méthode ObtenirSavEquipementPourConsultationDepuisCle pour récupérer le numéro retour colis du SAV Equipement
                        numeroRetourColis = this.servicesExternes.SavEquipementServiceExterne.ObtenirNumeroRetourColisDepuisCleSavEquipement(identite, listeClesSavEquipement.First());
                    }
                }
            }



            // Motifs de résiliation
            List<MotifResiliationLignePourLister> motifsResiliation = new List<MotifResiliationLignePourLister>();
            if (!string.IsNullOrEmpty(ligne.MotifResiliation))
            {
                motifsResiliation.Add(new MotifResiliationLignePourLister() { Libelle = ligne.MotifResiliation });
            }

            // Motifs de suspensions
            List<MotifSuspensionLignePourLister> motifsSuspension = ligne.ListeMotifsSuspension(identite)
                                                                        .Select(x => new MotifSuspensionLignePourLister() { Libelle = x }).ToList();

            List<PromotionOffrePourLister> promotionsOffreARetourner = new List<PromotionOffrePourLister>();

            IList<DemandeRemisePromotion> listePromotionsActives = ligne.GestionnaireDemandeRemises.ListerPromotionsActives();
            listePromotionsActives
                .Where(p => p.ClePromotionInterne.HasValue)
                .ToList()
                .ForEach(
                        p => promotionsOffreARetourner.Add(
                        PromotionOffrePourListerMapper.Convertir(
                        this.ReferentielServiceExterne.ObtenirPromotionParCle(identite, p.ClePromotionInterne.Value, ligne.CleOffre))));

            // Initialisation de l'objet de retour.
            DetailLignePourFicheSynthese detailLignePourFicheSynthese = new DetailLignePourFicheSynthese()
            {
                AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                CanalVente = identite.Canal.ToString(),
                Cle = ligne.Cle,
                DateActivation = ligne.SuiviDateCreation,
                DateFinEngagement = ligne.DateFinEngagement,
                EstLienListeCommandesAccessible = true,
                Etat = ligne.ValeurEtat,
                LibelleMarque = libelleMarque,
                LibelleOffre = offre.Nom,
                ListeDossiersBackOffice = null,// Alimenté plus bas si lieu d'être.
                ListeHistoriques = listeHistoriques != null ? listeHistoriques.Select(h => HistoriqueMapper.Convertir(h)).ToArray() : null,
                ListeMotifsResiliation = motifsResiliation.ToArray(),
                ListeMotifsSuspension = motifsSuspension.ToArray(),
                Numero = ligne.Numero,
                Offre = offre.Nom,
                PrixLocationBox = locationBox != null ? locationBox.MontantTtc : 0,
                PrixOffre = offre.PrixCommercialisationTtc,
                PrixRemise = offre.MontantRemiseAutoTtc,
                PromotionsOffre = promotionsOffreARetourner.ToArray(),
                ReferenceExterne = ligne.ReferenceExterne,
                Technologie = technologie.Libelle,
                Tiers = TiersMapper.Convertir(tiersPourDetail),
                LibelleEtat = EnumExtension.GetEnumDescription(ligne.ValeurEtat),
                IcnTiers = InformationsIcnMapper.Convertir(icn),
                EstGestionRetourColisAccessible = estGestionRetourColisAccessible,
                NumeroRetourColis = numeroRetourColis
            };

            // On initialise les valeurs Facturation. Fait dans un second temps car les données sont parfois incohérentes en
            // base de données, l'équipe Facturation cherche la source du problème.
            if (System.Enum.IsDefined(typeof(Fixe.Domain.CommonTypes.Enumerations.ProfilSurconsommation), ligne.StatutSurconsommation))
            {
                detailLignePourFicheSynthese.StatutSurconsommation = ligne.StatutSurconsommation;
            }
            else
            {
                detailLignePourFicheSynthese.StatutSurconsommation = Fixe.Domain.CommonTypes.Enumerations.ProfilSurconsommation.NA;
            }
            detailLignePourFicheSynthese.LibelleStatutSurconsommation = EnumExtension.GetEnumDescription(detailLignePourFicheSynthese.StatutSurconsommation);

            // Alimentation des dossiers GBO de l'objet de retour.
            if (listeDossierGBO != null && listeDossierGBO.Any())
            {
                IList<DossierBackOfficeLignePourLister> listeDossiersBackOffice = new List<DossierBackOfficeLignePourLister>();

                foreach (var dossierGbo in listeDossierGBO)
                {
                    HistoriquePourLister historique = null;

                    // Récupération de l'historique du dossier GBO.
                    if (listeAssociationsHistoriquesDossierGbo != null && listeAssociationsHistoriquesDossierGbo.Any())
                    {
                        AssociationHistoriqueDossierGboPourLister historiqueDossierGbo = listeAssociationsHistoriquesDossierGbo
                            .FirstOrDefault(x => x.HistoriqueDossierGbo.CleDossierGbo == dossierGbo.Cle);
                        historique = listeHistoriques.FirstOrDefault(x => x.Cle == historiqueDossierGbo?.CleHistorique);
                    }

                    // Ajout des informations GBO/Historique à l'objet de retour.
                    listeDossiersBackOffice.Add(GboMapper.Convertir(dossierGbo, historique));
                }

                detailLignePourFicheSynthese.ListeDossiersBackOffice = listeDossiersBackOffice.ToArray();
            }

            // Retour
            return detailLignePourFicheSynthese;
        }

        /// <summary>
        /// Obtention d'une ligne par sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Ligne correspondant à la clé.</returns>
        public LignePourDetail ObtenirLigneParCle(Identite identite, long cleLigne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            return ObtenirLigne(identite, ligne);
        }

        /// <summary>
        /// Permet de savoir si une ligne existe ou non en fonction de son numéro.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="numero">Numéro de la ligne.</param>
        /// <returns>Ligne existante ou non.</returns>
        public bool EstLigneExistanteParNumero(Identite identite, string numero)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            numero.Valider(nameof(numero)).Obligatoire();

            //Appel la méthode ObtenirLigneParNumero de ILigneRepository.
            Ligne ligne = LigneRepository.ObtenirDepuisNumero(numero);

            //Si l’objet métier de type Ligne est null, alors renvoyer false sinon renvoyer true.
            return ligne != null;
        }

        /// <summary>
        /// Permet de savoir si une ligne existe ou non en fonction de sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne.</param>
        /// <returns>Ligne existante ou non.</returns>
        public bool EstLigneExistanteParCle(Identite identite, long cleLigne)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            //Appel la méthode ObtenirParCle de ILigneRepository.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            //Si l’objet métier de type Ligne est null, alors renvoyer false sinon renvoyer true.
            return ligne != null;
        }

        /// <summary>
        /// Méthode qui permet d'obtenir le détail d'une ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Détail de la ligne avec l'historique des demandes de resiliation.</returns>
        public LigneAvecHistoriqueDemandeResiliationPourDetail ObtenirDetailLigneParCle(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Récupération de l'adresse d'installation.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation =
                this.servicesExternes.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(identite, ligne.CleAdresseInstallation);
            adresseInstallation.Valider(nameof(adresseInstallation)).NonNul();

            // Création d'une liste des demandes de résiliation.
            List<DemandeResiliationPourLister> listeDemandesResiliation = new List<DemandeResiliationPourLister>();
            if (ligne.ListeDemandeResiliation.Any())
            {
                foreach (var demande in ligne.ListeDemandeResiliation)
                {
                    MotifResiliation motifResiliation = this.repositories.MotifResiliationRepository.ObtenirDepuisCle(demande.CleMotifResiliation);

                    listeDemandesResiliation.Add(new DemandeResiliationPourLister()
                    {
                        CleDemandeResiliation = demande.Cle,
                        DateAnnulationDemandeResiliation = demande.DateAnnulation,
                        DateDemandeResiliation = demande.SuiviDateCreation,
                        DateResiliationProgrammee = demande.DateResiliationProgrammee.Value,
                        MotifResiliation = motifResiliation != null ? motifResiliation.Libelle : string.Empty,
                        OrigineDemandeResiliation = motifResiliation != null ? motifResiliation.OrigineResiliation : OrigineResiliation.NA,
                        TypeResiliation = motifResiliation != null ? motifResiliation.TypeResiliation : TypeResiliation.NA
                    });
                }
            }

            // Récupération de la technologie de la ligne.
            TechnologiePourDetail technologie = this.servicesExternes.ReferentielServiceExterne.ObtenirTechnologieParCle(identite, ligne.CleTechnologie);

            // Récupération de l'offre de la ligne.
            OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Récupération du tiers de la ligne.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Retourne un objet LigneAvecHistoriqueDemandeResiliationPourDetail.
            return new LigneAvecHistoriqueDemandeResiliationPourDetail()
            {
                // EstAffichable est à true si il y a au moins une demande de résiliation sur la ligne.
                EstAffichable = listeDemandesResiliation.Any(),
                EstResiliable = ligne.EstResiliable,
                HistoriqueDemandesResiliation = listeDemandesResiliation.ToArray(),
                InformationsLigne = new LignePourDetail()
                {
                    AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                    Cle = ligne.Cle,
                    CleMarque = ligne.CleMarque,
                    DateFinEngagement = ligne.DateFinEngagement,
                    Etat = ligne.Etat.Valeur,
                    Numero = ligne.Numero,
                    ReferenceExterne = ligne.ReferenceExterne,
                    Technologie = technologie != null ? technologie.Libelle : string.Empty,
                    Offre = offre != null ? offre.Nom : string.Empty,
                    Tiers = TiersMapper.Convertir(tiers)
                }
            };
        }

        /// <summary>
        /// Rechercher la clé de la ligne à partir d'une cle ICN.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'initative de l'action.</param>
        /// <param name="cleIcn">Clé de l'ICN lié à la ligne.</param>
        /// <returns>Clé de la ligne.</returns>
        public long? RechercherCleLigneParCleIcn(Identite identite, long cleIcn)
        {
            // Vérification des entrées.
            cleIcn.Valider(nameof(cleIcn)).StrictementPositif();
            identite.Valider(nameof(identite)).NonNul();

            // Recherche de la ligne.
            Ligne ligneTrouvee = this.LigneRepository.RechercherParCleIcn(cleIcn);
            if (ligneTrouvee != null)
            {
                return ligneTrouvee.Cle;
            }
            return null;
        }
        /// <summary>
        /// Obtention de l'ensemble des informations décrivant les équipements associés à la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe.</param>
        /// <returns>Ensemble des informations décrivant les équipements associés à la ligne.</returns>
        public InformationsEquipementsLigne ObtenirInformationsEquipementsLigneDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            List<EquipementLignePourLister> listeEquipements = new List<EquipementLignePourLister>();
            if (ligne.ListeEquipement != null)
            {
                EquipementLignePourLister equipementPourLister;
                foreach (var equipement in ligne.ListeEquipement)
                {
                    equipementPourLister = this.ObtenirEquipementLignePourLister(identite, equipement.CleEquipement, equipement.CodeRefCom);
                    listeEquipements.Add(equipementPourLister);
                }
            }

            RefComKitBox kitBox = new RefComKitBox();
            KitBox kitBoxCourant = ligne.ObtenirKitBoxCourant();
            if (kitBoxCourant != null)
            {
                kitBox = this.ReferentielServiceExterne.ObtenirRefComKitBox(identite, (int)kitBoxCourant.CleKitBox);
            }
            bool estCreationSavEquipementPossible = false;
            bool estCreationTechnicienPossible = false;

            if (ligne.Etat.Valeur == EtatLigne.Activee)
            {
                estCreationSavEquipementPossible = true;

                estCreationTechnicienPossible = !this.servicesExternes.SavServiceExterne
                    .VerifierSavTechnicienEnCoursParReferenceExterne(identite, ligne.ReferenceExterne);
            }

            InformationsEquipementsLigne equipementsARetourner = new InformationsEquipementsLigne()
            {
                DescriptionKitBox = kitBox.Description,
                MontantDepotGarantie = kitBox.MontantDepotGarantie,
                ReferenceExterne = ligne.ReferenceExterne,
                ReferenceKitBox = kitBox.Libelle,
                CleKitBox = kitBox.Cle,
                ListeEquipementLignePourLister = listeEquipements.ToArray(),
                EstCreationSavEquipementPossible = estCreationSavEquipementPossible,
                EstCreationSavTechnicienPossible = estCreationTechnicienPossible
            };

            return equipementsARetourner;
        }

        /// <summary>
        /// Obtention de la liste des équipements présents sur la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne fixe.</param>
        /// <returns>Liste des équipements présents sur la ligne fixe.</returns>
        public EquipementLignePourLister[] ListerEquipementsDepuisReferenceExterne(Identite identite, string referenceExterne)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();

            // Appeler la méthode ObtenirDepuisReferenceExterne du registre ILigneRepository
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(referenceExterne);

            // Construire un tableau de EquipementLignePourLister
            List<EquipementLignePourLister> listeEquipements = new List<EquipementLignePourLister>();

            if (ligne.ListeEquipement != null)
            {
                foreach (var equipement in ligne.ListeEquipement)
                {
                    // Appeler la méthode privée ObtenirEquipementLignePourLister
                    EquipementLignePourLister equipementLignePourLister = this.ObtenirEquipementLignePourLister(identite, equipement.CleEquipement, equipement.CodeRefCom);

                    // Ajouter l'objet dans listeEquipements
                    listeEquipements.Add(equipementLignePourLister);
                }
            }
            return listeEquipements.ToArray();
        }

        /// <summary>
        /// Retourne les informations d'un équipement associé à une ligne.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="cleEquipement">Identifiant unique de l'équipement.</param>
        /// <param name="codeRefCom">Code RefCom de l'équipement.</param>
        /// <returns></returns>
        private EquipementLignePourLister ObtenirEquipementLignePourLister(Identite identite, long cleEquipement, string codeRefCom)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            cleEquipement.Valider(nameof(cleEquipement)).StrictementPositif();
            codeRefCom.Valider(nameof(codeRefCom)).NonNul();

            // Appeler la méthode ObtenirRefComSerialiseeDepuisCodeRefCom du service externe IReferentielServiceExterne
            RefComSerialisee referenceCommerciale = this.servicesExternes.ReferentielServiceExterne.ObtenirRefComSerialiseeDepuisCodeRefCom(identite, codeRefCom);
            referenceCommerciale.Valider(nameof(referenceCommerciale)).NonNul();

            // Appeler la méthode ObtenirEquipementDepuisCle du service ILogistiqueServiceExterne
            Equipement equipement = this.servicesExternes.LogistiqueServiceExterne.ObtenirEquipementDepuisCle(identite, cleEquipement);
            equipement.Valider(nameof(equipement)).NonNul();

            // Construire un objet de présentation de type EquipementLignePourLister
            EquipementLignePourLister equipementPourLister = new EquipementLignePourLister()
            {
                Cle = cleEquipement,
                Type = referenceCommerciale.Type,
                Modele = referenceCommerciale.Libelle,
                AdresseMac = equipement.AdresseMac,
                NumeroCarteTv = equipement.NumeroCarteTv,
                NumeroSerie = equipement.NumeroSerie,
                Etat = equipement.Etat,
                CodeRefCom = codeRefCom
            };

            return equipementPourLister;
        }

        /// <summary>
        /// Mise à jour des équipements de la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="cleAncienEquipement">Cle technique de l'ancien équipement.</param>
        /// <param name="cleNouvelEquipement">Clé technique du nouvel équipement.</param>
        /// <param name="codeRefComNouvelEquipement">Code refcom du nouvel équipement.</param>
        public void DefinirEquipementLigne(Identite identite, string referenceExterne, long cleAncienEquipement, long cleNouvelEquipement, string codeRefComNouvelEquipement)
        {
            // Vérification des paramètres entrants.
            identite.Valider(nameof(identite)).NonNul();
            referenceExterne.Valider(nameof(referenceExterne)).NonNul();
            cleAncienEquipement.Valider(nameof(cleAncienEquipement)).StrictementPositif();
            cleNouvelEquipement.Valider(nameof(cleNouvelEquipement)).StrictementPositif();
            codeRefComNouvelEquipement.Valider(nameof(codeRefComNouvelEquipement)).NonNul();

            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(referenceExterne);
            long clePrimaireEquipement = this.GenerateurCles.ObtenirCleLongue<EquipementLigne>();
            EquipementLigne equipement = new EquipementLigne(identite, clePrimaireEquipement, ligne, cleNouvelEquipement, codeRefComNouvelEquipement);
            ligne.ListeEquipement.Add(equipement);
        }

        /// <summary>
        /// Retourne les informations de la ligne pour le SVI RIO à partir du numéro de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="numeroLigne">Numéro de la ligne fixe.</param>
        /// <returns>Informations de la ligne pour le SVI RIO.</returns>
        public InformationsLignePourSviRio ObtenirInformationsLignePourRioParNumeroLigne(Identite identite, string numeroLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            numeroLigne.Valider(nameof(numeroLigne)).Obligatoire();

            // Récupération de la clé ligne.
            long cleLigne = this.LigneRepository.ObtenirDepuisNumero(numeroLigne).Cle;

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);

            // Retour des informations de la ligne pour le SVI RIO.
            return new InformationsLignePourSviRio()
            {
                CleLigne = ligne.Cle,
                CleMarque = ligne.CleMarque,
                DateFinEngagement = ligne.DateFinEngagement,
                NumeroMobileContactTiers = tiers.NumeroMobileDeContact,
                Rio = ligne.Rio
            };
        }

        /// <summary>
        /// Permet de récupérer les informations des promotions actives de type Offre d'une ligne pour le Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Liste des promotions actives pour le Selfcare.</returns>
        public List<PromotionPourLister> ObtenirPromotionsOffreActivesDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNull();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            List<PromotionPourLister> listePromotionsOffreActives = null;

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCle(cleLigne);

            // Récupération des promotions "SurOffre" actives.
            List<DemandeRemisePromotion> listePromotionsActives = ligne.GestionnaireDemandeRemises.ListerPromotionsActives()
                .Where(p => p.TypeDemandeRemise == TypeDemandeRemise.RemisePromotionSurOffre).ToList();

            foreach (DemandeRemisePromotion promotionActive in listePromotionsActives)
            {
                PromotionPourDetail promotion = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionParCle(identite,
                                                                                                                       promotionActive.ClePromotionInterne.GetValueOrDefault(),
                                                                                                                       ligne.CleOffre);
                if (listePromotionsOffreActives == null)
                {
                    listePromotionsOffreActives = new List<PromotionPourLister>();
                }

                listePromotionsOffreActives.Add(new PromotionPourLister()
                {
                    Cle = promotion.Cle,
                    Descriptif = promotion.Descriptif,
                    DureeValiditeEnMois = promotion.Duree,
                    PrixTtc = promotion.MontantTtc
                });
            }

            // Retour de la liste des promotions actives de l'offre.
            return listePromotionsOffreActives;
        }

        /// <summary>
        /// Permet de récupérer les informations d'une ligne à partir d'une clé tiers pour le Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Informations de la ligne pour le Selfcare.</returns>
        public InformationsLignePourSelfcare ObtenirInformationsLignePourSelfcareDepuisCleTiers(Identite identite, long cleTiers)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTiers.Valider(nameof(cleTiers)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCleTiers(cleTiers);

            // Récupération de la date activation de la ligne.
            DateTime dateActivation = this.ObtenirDateActivationLigne(ligne);

            // Récupération de l'offre.
            OffrePourDetail offre = this.servicesExternes.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Récupération des promotions actives.
            IList<DemandeRemisePromotion> listePromotionsActives = ligne.GestionnaireDemandeRemises.ListerPromotionsActives();

            // Calcul du montant total des promotions de l'offre.
            decimal montantTotalPromotionOffre = 0;
            foreach (DemandeRemisePromotion promotionActive in listePromotionsActives)
            {
                PromotionPourDetail promotion = this.servicesExternes.ReferentielServiceExterne.ObtenirPromotionParCle(identite,
                                                                                                                       promotionActive.ClePromotionInterne.GetValueOrDefault(),
                                                                                                                       ligne.CleOffre);
                montantTotalPromotionOffre += promotion.MontantTtc;
            }

            // Calcul du prix remisé de l'offre.
            decimal prixRemiseOffre = offre.PrixCommercialisationTtc - montantTotalPromotionOffre;

            // Récupération de l'option de location de la box.
            InformationsLocationBoxPourDetail locationBox = this.briquesServicesExternes.OptionsServiceExterne.ObtenirLocationBoxParCleGestionnaire(identite, ligne.CleGestionnaireOptions);

            // Récupération de l'adresse d'installation.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation = this.servicesExternes.SouscriptionServiceExterne.ObtenirAdresseInstallationParCleEligibilite(
                                                                                                                                                                        identite,
                                                                                                                                                                        ligne.CleAdresseInstallation);

            // Retour des informations de la ligne pour le Selfcare.
            return new InformationsLignePourSelfcare()
            {
                AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                CleCompteFacturation = ligne.CleCompteFacturation,
                CleLigne = ligne.Cle,
                CleMarque = ligne.CleMarque,
                CleOffre = ligne.CleOffre,
                DateActivation = dateActivation,
                DateFinEngagement = ligne.DateFinEngagement,
                NumeroTelephone = ligne.Numero,
                PrixLocationBox = locationBox != null ? locationBox.MontantTtc : 0,
                PrixOffreRemise = prixRemiseOffre,
                ReferenceExterne = ligne.ReferenceExterne,
                Rio = ligne.Rio
            };
        }

        /// <summary>
        /// Méthode qui permet de récupérer les informations de contact pour une ligne fixe. 
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <returns>Informations de contact.</returns>
        public InformationsContactPourDetail ObtenirInformationsContactDepuisCleLigne(Identite identite, long cleLigne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleLigne.Valider(nameof(cleLigne)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne);
            ligne.Valider(nameof(ligne)).NonNul();

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiers.Valider(nameof(tiers)).NonNul();

            // Récupération de la marque.
            Marque marque = ReferentielServiceExterne.ObtenirMarqueParCle(identite, ligne.CleMarque);
            marque.Valider(nameof(marque)).NonNul();

            // Instanciation et retour de l'objet InformationsContactPourDetail.
            return new InformationsContactPourDetail()
            {
                CleTiers = ligne.CleTiers,
                Email = tiers.EmailContact,
                NumeroLigne = ligne.Numero,
                TelephoneMobileDeContact = tiers.NumeroMobileDeContact,
                UrlSelfCare = marque.SiteWeb
            };
        }

        /// <summary>
        /// Méthode qui permet de récupérer les informations de contact pour la recherche de documents.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Informations de la ligne pour la recherche de documents.</returns>
        public InformationsLignePourRechercherDocuments ObtenirInformationsLignePourRechercherDocuments(Identite identite, long? cleLigne, string referenceExterne)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // Instanciation de l'objet Ligne.
            Ligne ligne;

            // Si la clé ligne possède une valeur.
            if (cleLigne.HasValue)
            {
                ligne = this.repositories.LigneRepository.ObtenirDepuisCle(cleLigne.Value);
            }
            else if (!string.IsNullOrWhiteSpace(referenceExterne)) // Si la clé ligne ne possède pas de valeur et que la référence externe est renseignée.
            {
                ligne = this.repositories.LigneRepository.ObtenirDepuisReferenceExterne(referenceExterne);
            }
            else // La clé ligne et la référence externe sont non valides, on lève une exception.
            {
                throw new ArgumentNullException("Veuillez renseigner la clé ligne ou la référence externe.");
            }

            // On liste les documents de ligne.
            DocumentLigne[] listeDocumentLigne = this.repositories.DocumentLigneRepository.Lister();

            // Instanciation et retour de l'objet InformationsLignePourRechercherDocuments.
            return new InformationsLignePourRechercherDocuments()
            {
                DocumentsPourLister = listeDocumentLigne.Select(d => DocumentPourListerMapper.Convertir(d)).ToArray(),
                NumeroLigne = ligne.Numero,
                ReferenceExterne = ligne.ReferenceExterne
            };
        }

        /// <summary>
        /// Méthode qui permet de récupérer les informations nécessaires pour l'authentification sur le selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTitulaire">Clé du titulaire</param>
        /// <returns>Informations nécessaires pour l'authentification sur le selfcare</returns>
        public InformationsAuthentificationLigne ObtenirInformationsAuthentificationLigne(Identite identite, long cleTitulaire)
        {
            //Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cleTitulaire.Valider(nameof(cleTitulaire)).StrictementPositif();

            //Récupération de la commande de souscription.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCleTiers(cleTitulaire);

            //Récupération des informations du titulaire.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiers = this.briquesServicesExternes.TiersServiceExterne.ObtenirParCle(identite, cleTitulaire);
            tiers.Valider(nameof(tiers)).NonNul();

            return new InformationsAuthentificationLigne()
            {
                CiviliteTitulaire = tiers.CiviliteEnum,
                NomTitulaire = tiers.Nom,
                PrenomTitulaire = tiers.Prenom,
                CleMarque = ligne.CleMarque,
                FonctionsBad = new List<string> { "FCT1TEST" }.ToArray()
            };
        }

        #region Méthodes Vue360

        /// <summary>
        /// Obtention des informations d’un titulaire de ligne fixe en vue de fournir en données sa Vue 360.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé unique du titulaire de la ligne.</param>
        public DetailTitulairePourVue360 ObtenirVue360TitulaireParCle(Identite identite, long cle)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();
            cle.Valider(nameof(cle)).StrictementPositif();

            // Récupération de la ligne.
            Ligne ligne = this.LigneRepository.ObtenirDepuisCleTiers(cle);
            ligne.Valider(nameof(ligne)).NonNul();

            // Récupération du login SFC
            string loginSFC = TiersServiceExterne.ObtenirLoginSfcParCleTiers(identite, ligne.CleTiers);

            // Récupération du tiers.
            Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail tiersPourDetail = TiersServiceExterne.ObtenirParCle(identite, ligne.CleTiers);
            tiersPourDetail.Valider(nameof(tiersPourDetail)).NonNul();

            // Récupération de la clé Tiers Mobile, et du droit ou non de charger les informations Mobile.
            int cleTiers;
            if (!Int32.TryParse(ligne.CleTiers.ToString(), out cleTiers) || cleTiers <= 0)
            {
                throw new ArgumentOutOfRangeException("La clé de tiers fournie est invalide");
            }
            TiersAssociePourDetail tiersAssocie = TiersServiceExterne.ObtenirCleTiersMobileParCleTiersFixe(identite, cleTiers);

            // Récupération de la technologie.
            TechnologiePourDetail technologiePourDetail = this.ReferentielServiceExterne.ObtenirTechnologieParCle(identite, ligne.CleTechnologie);
            technologiePourDetail.Valider(nameof(technologiePourDetail)).NonNul();

            // Obtention de l'adresse d'installation.
            Domain.CommonTypes.DTO.AdresseInstallationPourDetail adresseInstallation = this.SouscriptionServiceExterne
                .ObtenirAdresseInstallationParCleEligibilite(identite, ligne.CleAdresseInstallation);

            // Obtention des informations de l'offre de la ligne fixe.
            OffrePourDetail detailOffre = this.ReferentielServiceExterne.ObtenirOffreParCle(identite, ligne.CleOffre);

            // Obtention, si possible, des informations Mobile.
            List<CompteClientMobilePourLister> listeCompteClientMobilePourLister = null;// Initialisation à null car on n'a pas forcement le droit de charger ces informations.
            if (tiersAssocie.EstAssocie)// Si et seulement si le tiers est associé, on récupère les informations mobiles
            {
                // Récupération de la liste des comptes clients associés au tiers.
                CompteClientPourLister[] listeCompteClientPourLister = this.ComptesClientServiceExterne.RechercherComptesClientParCleTiersTitulaireLight(identite, (int)cle);
                listeCompteClientPourLister.Valider(nameof(listeCompteClientPourLister)).NonNul();

                // Création de la liste des comptes client mobile.
                listeCompteClientMobilePourLister = this.InitialiserListeComptesClientMobilePourVue360(identite, listeCompteClientPourLister);
            }

            // Récupération des seuils de surconsommation de la ligne
            InformationsSeuilsSurconsommation informationsSeuils = this.servicesExternes.FacturationServiceExterne.ObtenirInformationsSeuilsSurconsommationParReferenceExterne(identite,
                                                                                                                                                                                ligne.ReferenceExterne);
            informationsSeuils.Valider(nameof(informationsSeuils)).NonNul();

            // Initialisation de l'objet de retour, et retour de ce dernier.
            return new DetailTitulairePourVue360()
            {
                Email = loginSFC,
                LigneFixe = new DetailLigneFixeTitulairePourVue360()
                {
                    AdresseInstallation = AdresseInstallationPourDetailMapper.Convertir(adresseInstallation),
                    CleLigne = ligne.Cle,
                    EstReinitialisationCodeConfidentielPossible = true,
                    Numero = ligne.Numero,
                    SeuilSurconsommationTelephonie = informationsSeuils.SeuilSurconsommationTelephonie,
                    SeuilSurconsommationVod = informationsSeuils.SeuilSurconsommationVod,
                    Etat = ligne.ValeurEtat,
                    Technologie = technologiePourDetail.Libelle,
                    DenominationTitulaire = $"{tiersPourDetail.Civilite} {tiersPourDetail.Prenom} {tiersPourDetail.Nom}",
                    NomOffre = detailOffre.Nom,
                    LibelleEtat = EnumExtension.GetEnumDescription(ligne.ValeurEtat)
                },
                ListeComptesClientMobile = listeCompteClientMobilePourLister != null ? listeCompteClientMobilePourLister.ToArray() : null
            };
        }

        /// <summary>
        /// Chargement des comptes client mobile.
        /// </summary>
        /// <param name="identite">Identité.</param>
        /// <param name="comptesClient">Liste des comptes clients pour lesquels charger les données Mobile.</param>
        /// <returns>Liste de comptes client Mobile.</returns>
        private List<CompteClientMobilePourLister> InitialiserListeComptesClientMobilePourVue360(Identite identite, CompteClientPourLister[] comptesClient)
        {
            // Instanciation de la variable de retour.
            List<CompteClientMobilePourLister> retour = new List<CompteClientMobilePourLister>();

            // Si pas de compte client, pas de traitement.
            if (comptesClient == null || !comptesClient.Any())
            {
                return retour;
            }

            // Sinon pour chaque compte client :
            foreach (var compteClient in comptesClient)
            {
                // Récupération du détail du compte client.
                CompteClientPourDetail detailCompteClient = this.ComptesClientServiceExterne.ObtenirCompteClientParCle(identite, compteClient.Cle);

                // Chargement des lignes mobiles du compte.
                List<LigneCompteClientMobilePourLister> listeLigneCompteClientMobilePourLister = this.InitialiserListeLignesPourCompteClientMobilePourVue360(identite, detailCompteClient);

                // Récupération des informations de connexions du compte client.
                InformationsLoginCompteClient informationsLoginCompteClient = this.LoginServiceExterne.ObtenirLoginCcParCleCompteClient(identite, compteClient.Cle);

                // Initialisation de l'objet compte client mobile.
                CompteClientMobilePourLister compteClientMobilePourLister = Vue360Builder.InitialiserCompteClientMobilePourLister(informationsLoginCompteClient,
                    compteClient, listeLigneCompteClientMobilePourLister, detailCompteClient.ListeLignes != null ? detailCompteClient.ListeLignes.Count : 0);

                // Ajout du compte client à la liste à retourner.
                retour.Add(compteClientMobilePourLister);
            }

            // On retourne la liste.
            return retour;
        }

        /// <summary>
        /// Chargement de la liste des lignes d'un compte client mobile.
        /// </summary>
        /// <param name="identite">Identité de l'appelant.</param>
        /// <param name="compteClient">Informations du compte client mobile.</param>
        /// <returns>Liste de lignes mobiles du compte client.</returns>
        /// <remarks>On ne charge les données que si le compte client a maximum 10 lignes, sinon on renvoie une liste vide.</remarks>
        private List<LigneCompteClientMobilePourLister> InitialiserListeLignesPourCompteClientMobilePourVue360(Identite identite, CompteClientPourDetail compteClient)
        {
            List<LigneCompteClientMobilePourLister> ret = new List<LigneCompteClientMobilePourLister>();

            int nombreLignes = compteClient.ListeLignes != null ? compteClient.ListeLignes.Count : 0;

            // Si le compte client contient plus de 10 lignes, on ne fait rien, elle seront chargées sur demande de l'utilisateur.
            if (nombreLignes > ConfigurationVue360.NOMBRE_LIGNES_MAXIMUM_COMPTE_CLIENT_MOBILE)
            {
                return ret;
            }

            // Pour chaque ligne récupérée dans ce compte client:
            foreach (var ligneMobilePourLister in compteClient.ListeLignes)
            {
                /*Appel à la méthode ObtenirSeuilParCleLigne du service externe IGestionSurconsommationAboServiceExterne en fournissant 
                    la clé de la ligne, afin de récupérer le seuil de surconsommation de cette ligne.*/
                decimal seuilSurconsommationLigneMobile = this.GestionSurconsommationAboServiceExterne.ObtenirSeuilParCleLigne(identite, ligneMobilePourLister.Cle);

                /*Appel à la méthode ObtenirLoginLigneParCleLigne du service externe 
                ILoginServiceExterne afin de récupérer le niveau d’accès à l’espace client. */
                string niveauAccesEspaceClientMobile = this.LoginServiceExterne.ObtenirLoginLigneParCleLigne(identite, ligneMobilePourLister.Cle);

                // Initialisation de l'objet ligne.
                LigneCompteClientMobilePourLister ligneCompteClientMobilePourLister = new LigneCompteClientMobilePourLister()
                {
                    Cle = ligneMobilePourLister.Cle,
                    EstReseauFull = ligneMobilePourLister.CodeOperateur == this.serviceTechnique.Parametrage.CodeOperateurReseauFull,
                    EstSyntheseCrmMobileAccessible = true,
                    NiveauAccessEspaceClientMobile = niveauAccesEspaceClientMobile,
                    Numero = ligneMobilePourLister.Numero,
                    Offre = ligneMobilePourLister.LibelleOffre,
                    ScoreChurn = ligneMobilePourLister.ScoreChurn,
                    SeuilSurconsommation = seuilSurconsommationLigneMobile,
                    Statut = ligneMobilePourLister.Statut,
                    Utilisateur = string.Format("{0} {1}", ligneMobilePourLister.Tiers.Nom, ligneMobilePourLister.Tiers.Prenom)
                };

                // On ajoute la ligne à la collection à retourner.
                ret.Add(ligneCompteClientMobilePourLister);
            }

            return ret;
        }

        #endregion Méthodes Vue360

        /// <summary>
        /// Méthode qui permet d'obtenir une liste de documents ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <returns>Liste de documents ligne.</returns>
        public DocumentPourLister[] ObtenirDocumentsLigne(Identite identite)
        {
            // Vérification des entrées.
            identite.Valider(nameof(identite)).NonNul();

            // On liste les documents de ligne.
            DocumentLigne[] listeDocumentLigne = this.repositories.DocumentLigneRepository.Lister();

            // Instanciation et retour de l'objet InformationsLignePourRechercherDocuments.
            return listeDocumentLigne.Select(d => DocumentPourListerMapper.Convertir(d)).ToArray();
        }

        #endregion Méthodes
    }
}