﻿using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Application.Builders
{
    /// <summary>
    /// Méthodes génériques de construction d'objets consommés par la Vue360.
    /// </summary>
    internal static class Vue360Builder
    {
        /// <summary>
        /// Initialisation d'un objet de type CompteClientMobilePourLister.
        /// </summary>
        /// <param name="infosLoginCompteClient">Login compte client.</param>
        /// <param name="compteClient">Compte client.</param>
        /// <param name="listeLignesCompteClientMobilePourLister">Liste des lignes des comptes client mobiles.</param>
        /// <param name="nombreLignes">Nombre de lignes.</param>
        /// <returns>Objet CompteClientMobilePourLister instancié et initialisé.</returns>
        public static CompteClientMobilePourLister InitialiserCompteClientMobilePourLister(InformationsLoginCompteClient infosLoginCompteClient, 
            CompteClientPourLister compteClient, List<LigneCompteClientMobilePourLister> listeLignesCompteClientMobilePourLister, int nombreLignes)
        {
            return new CompteClientMobilePourLister()
            {
                Cle = compteClient.Cle,
                AccesSpecifiqueEspaceClient = infosLoginCompteClient.AAccesSpecifiqueEspaceClientMobile,
                LoginGestionnaire = infosLoginCompteClient.LoginGestionnaire,
                Numero = compteClient.Numero,
                Titulaire = string.Format("{0} {1}", compteClient.Titulaire.Nom, compteClient.Titulaire.Prenom),
                ListeLignes = listeLignesCompteClientMobilePourLister,
                NombreLignes = nombreLignes
            };
        }
    }
}