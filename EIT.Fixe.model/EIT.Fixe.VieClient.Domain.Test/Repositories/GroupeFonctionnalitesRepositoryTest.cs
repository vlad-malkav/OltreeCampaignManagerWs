﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repository Profil.
    /// </summary>
    [TestFixture]
    public class GroupeFonctionnalitesRepositoryTest
    {
        #region Propriétés

        private Identite identite;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IRepositories> repositories;
        private Mock<IBriquesServicesExternes> briquesExternes;

        #endregion Propriétés

        #region Initialisateur

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialisterServicesExternes();
            this.InitialiserRepositories();
            this.InitialiserBriquesExternes();

        }


        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation des services externes.
        /// </summary>
        private void InitialisterServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialisation des repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
        }

        /// <summary>
        /// Initialisation des briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            ParametreGroupeFonctionnalitesPourCreation parametreGroupeFctPourCreation = new ParametreGroupeFonctionnalitesPourCreation()
            {
                Cle = 1,
                Code = "Code",
                Description = "Description",
                EstActif = true,
                Libelle = "Libelle",
                SuiviDateCreation = DateTime.Now
            };

            GroupeFonctionnalites groupeFonctionnalites = CreerGroupeFonctionnalites();

            sourceDonnees.Add(groupeFonctionnalites);

            return sourceDonnees;
        }

        /// <summary>
        /// Creer une ligne.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private GroupeFonctionnalites CreerGroupeFonctionnalites()
        {
            ParametreGroupeFonctionnalitesPourCreation parametreGroupeFctPourCreation = new ParametreGroupeFonctionnalitesPourCreation()
            {
                Cle = 1,
                Code = "Code",
                Description = "Description",
                EstActif = true,
                Libelle = "Libelle",
                SuiviDateCreation = DateTime.Now
            };

            GroupeFonctionnalites groupeFonctionnalites = new GroupeFonctionnalites(identite, parametreGroupeFctPourCreation, null);

            return groupeFonctionnalites;
        }

        #endregion Initialisateur

        #region Test de la méthode Ajouter

        /// <summary>
        /// Test de la méthode AJouter avec les paramètre OK.
        /// </summary>
        [Test]
        public void Ajouter_ParametreOK_OK()
        {
            //Arrange.
            GroupeFonctionnalites entite = this.CreerGroupeFonctionnalites();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            GroupeFonctionnalitesRepository repository = new GroupeFonctionnalitesRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(entite);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode Ajouter avec le profil null. Exception levée.
        /// </summary>
        [Test]
        public void Ajouter_ProfilNull_ExceptionLevee()
        {
            //Arrange.
            GroupeFonctionnalites entite = this.CreerGroupeFonctionnalites();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            GroupeFonctionnalitesRepository repository = new GroupeFonctionnalitesRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode Ajouter

        #region Test de la méthode SupprimerDepuisDate

        /// <summary>
        /// Test de la méthode SupprimerDepuisDate avec les parametres OK.
        /// </summary>
        [Test]
        public void SupprimerDepuisDate_ParametreOK_OK()
        {
            //Arrange.
            GroupeFonctionnalites entite = this.CreerGroupeFonctionnalites();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            GroupeFonctionnalitesRepository repository = new GroupeFonctionnalitesRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            TestDelegate action = () => repository.SupprimerDepuisDate(entite.SuiviDateCreation);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode SupprimerDepuisDate avec la date invalide. Exception levée.
        /// </summary>
        [Test]
        public void SupprimerDepuisDate_DateInvalide_ExceptionLevee()
        {
            //Arrange.
            GroupeFonctionnalites entite = this.CreerGroupeFonctionnalites();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            GroupeFonctionnalitesRepository repository = new GroupeFonctionnalitesRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            TestDelegate action = () => repository.SupprimerDepuisDate(new DateTime());
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode SupprimerDepuisDate

        #region Test de la méthode ListerGroupesFonctionnalitesActifs

        /// <summary>
        /// Test de la méthode ListerGroupesFonctionnalitesActifs parametre OK. OK.
        /// </summary>
        [Test]
        public void ListerGroupesFonctionnalitesActifs_ParametreOK_OK()
        {
            //Arrange.
            GroupeFonctionnalites entite = this.CreerGroupeFonctionnalites();
            entite.EstActif = true;
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            GroupeFonctionnalitesRepository repository = new GroupeFonctionnalitesRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            GroupeFonctionnalites[] listeGroupe = repository.ListerGroupesFonctionnalitesActifs();
            //Assert.
            Assert.AreEqual(listeGroupe[listeGroupe.Length-1], entite);
        }

        #endregion Test de la méthode ListerGroupesFonctionnalitesActifs
    }
}
