﻿using System;
using System.Collections.Generic;
using System.Linq;
using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using Moq;
using NUnit.Framework;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.Domain.Repositories;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Clase de test de DemandeRemiseRepository
    /// </summary>
    [TestFixture]
    public class DemandeRemiseRepositoryTest
    {
        private Identite identite;
        private DateTime dateFinEngagement;
        private DetailLignePourCreation parametre;
        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        private Mock<IRepositories> repositories;

        private Mock<IHistoriqueDossierGboLigneRepository> ligneHistoriqueDossierGboRepository;
        private Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository;

        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.dateFinEngagement = new DateTime(2020, 12, 1);
            this.parametre = new DetailLignePourCreation()
            {
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                DateFinEngagement = this.dateFinEngagement,
                Numero = "0102030405",
                NumeroContratOperateur = "NumeroContratOperateur",
                ReferenceExterne = "refext",
                IdentifiantTransactionOperateur = 1,
                Rio = "rio",
                CleCommandeExpedition = 1,
                ListeDemandeRemisePourCreation = new List<DemandeRemisePourCreation>()
                {
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemiseSurForfait,
                        DetailRemiseForfaitPourCreation = new DemandeRemiseForfaitPourCreation()
                        {
                            MontantHT = 1
                        },

                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Descriptif = "RemiseSurForfait"
                        }
                    },
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurOffre,
                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Cle = 1,
                            MontantHT = 1,
                            Duree = -1,
                            Descriptif = "RemisePromotionSurOffre"
                        }
                    },
                    new DemandeRemisePourCreation()
                    {
                        TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurFrais,
                        PromotionPourDetail = new PromotionPourDetail()
                        {
                            Cle = 1,
                            MontantHT = 1,
                            Duree = 1,
                            Descriptif = "RemisePromotionSurFrais"
                        }
                    }
                },
                CleKitBox = 1
            };

            this.InitialiserServiceTechnique();
            this.InitialiserBriqueServiceExterne();
            this.InitialiserRepositories();
            this.InitialiserServiceExterne();
        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation du Repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.ligneHistoriqueDossierGboRepository = new Mock<IHistoriqueDossierGboLigneRepository>();
            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);


            // Setup des méthodes des différents services externes.
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirOffreParCle(identite, It.IsAny<int>())).Returns(new OffrePourDetail()
            {
                Cle = 1,
                LibelleRemiseAuto = "Libelle de la remise associée à l'offre"                
            });
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            this.parametre.Cle = 1;
            Ligne ligne1 = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            
            this.parametre.Cle = 2;
            Ligne ligne2 = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            
            sourceDonnees.Add(ligne1);
            sourceDonnees.Add(ligne2);
            return sourceDonnees;
        }

        /// <summary>
        /// Creer un repository avec datasource null.
        /// </summary>
        [Test]
        public void CreerDemandeRemise_SourceDonneesNull_LeveException()
        {
            IDataSource dataSource = null;

            TestDelegate action = () => new DemandeRemiseRepository(dataSource);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Liste des promotions a expirer.
        /// </summary>
        [Test]
        public void ListerPromotionsAExpirer_ParametreValide_OK()
        {            
            IDataSource dataSource = this.CreerSourceDonnees();
            DemandeRemiseRepository repository = new DemandeRemiseRepository(dataSource);

            Dictionary<long, List<long>> resultat = repository.ListerPromotionsAExpirer();

            Assert.AreEqual(resultat.Count, 2);
            KeyValuePair<long, List<long>> cleValeur = resultat.First();
            Assert.AreEqual(cleValeur.Key, 1);
            Assert.IsTrue(cleValeur.Value.Contains(1));
            cleValeur = resultat.ElementAt(1);
            Assert.AreEqual(cleValeur.Key, 2);
            Assert.IsTrue(cleValeur.Value.Contains(1));
        }
    }
}
