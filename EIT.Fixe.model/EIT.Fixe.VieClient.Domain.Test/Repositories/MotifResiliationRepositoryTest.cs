﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repository MotifResiliation.
    /// </summary>
    [TestFixture]
    public class MotifResiliationRepositoryTest
    {
        #region Propriétés 

        /// <summary>
        /// Clé valide. Correspond à un motif de résiliation dans le dataSource.
        /// </summary>
        private long CleValide { get { return 123; } }

        /// <summary>
        /// Clé invalide. Correspond à aucun motif de résiliation dans le dataSource.
        /// </summary>
        private long CleInvalide { get { return 999; } }

        /// <summary>
        /// Libellé valide. Correspond à un motif de résiliation dans le dataSource.
        /// </summary>
        private string LibelleValide { get { return "Coucou, je suis valide."; } }

        /// <summary>
        /// Libellé invalide. Correspond à aucun motif de résiliation dans le dataSource.
        /// </summary>
        private string LibelleInvalide { get { return "Mouhahaha, je suis invalide."; } }

        /// <summary>
        /// Retourne un motif de résiliation valide, qui est inséré dans le dataSource.
        /// </summary>
        private MotifResiliation MotifResiliationValide
        {
            get
            {
                return new MotifResiliation()
                {
                    Cle = this.CleValide,
                    Libelle = this.LibelleValide,
                    
                };
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            sourceDonnees.Add(this.MotifResiliationValide);

            return sourceDonnees;
        }

        /// <summary>
        /// Vérifie l'égalité entre deux Motif de résiliation.
        /// </summary>
        /// <param name="motifResiliationExpecte">Le motif résiliation attendu.</param>
        /// <param name="motifResiliationActuel">Le motif de résiliation actuel.</param>
        public void VerifierEgaliteEntreDeuxMotifResiliation(MotifResiliation motifResiliationAttendu, MotifResiliation motifResiliationActuel)
        {
            Assert.AreEqual(motifResiliationAttendu.Cle, motifResiliationActuel.Cle);
            Assert.AreEqual(motifResiliationAttendu.DelaiResiliation, motifResiliationActuel.DelaiResiliation);
            Assert.AreEqual(motifResiliationAttendu.EstFraisResiliationAppliques, motifResiliationActuel.EstFraisResiliationAppliques);
            Assert.AreEqual(motifResiliationAttendu.EstOuvertureRetourColisNecessaire, motifResiliationActuel.EstOuvertureRetourColisNecessaire);
            Assert.AreEqual(motifResiliationAttendu.Libelle, motifResiliationActuel.Libelle);
            Assert.AreEqual(motifResiliationAttendu.ListeModeRetourEquipement, motifResiliationActuel.ListeModeRetourEquipement);
            Assert.AreEqual(motifResiliationAttendu.Ordre, motifResiliationActuel.Ordre);
            Assert.AreEqual(motifResiliationAttendu.OrigineResiliation, motifResiliationActuel.OrigineResiliation);
            Assert.AreEqual(motifResiliationAttendu.SuiviAgentCreation, motifResiliationActuel.SuiviAgentCreation);
            Assert.AreEqual(motifResiliationAttendu.SuiviAgentModification, motifResiliationActuel.SuiviAgentModification);
            Assert.AreEqual(motifResiliationAttendu.SuiviDateCreation, motifResiliationActuel.SuiviDateCreation);
            Assert.AreEqual(motifResiliationAttendu.SuiviDateModification, motifResiliationActuel.SuiviDateModification);
            Assert.AreEqual(motifResiliationAttendu.TypeResiliation, motifResiliationActuel.TypeResiliation);
        }

        #endregion Méthodes d'initialisation

        #region Test de la création du repository

        /// <summary>
        /// Test de la création du repository avec un dataSource null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesNull_LeveException()
        {
            // Arrange.
            IDataSource dataSource = null;

            // Act.
            TestDelegate action = () => new MotifResiliationRepository(dataSource);

            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la création du repository avec un dataSource correct. Pas d'exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesOK_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();

            // Act.
            TestDelegate action = () => new MotifResiliationRepository(dataSource);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test de la création du repository

        #region Test de la méthode ObtenirParCle

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé inexistante. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleInexistante_LeveException()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            MotifResiliationRepository motifResiliationRepository = new MotifResiliationRepository(dataSource);

            // Act.
            TestDelegate action = () => motifResiliationRepository.ObtenirDepuisCle(this.CleInvalide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé existante. Retourne un objet MotifResiliation.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleExistante_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            MotifResiliationRepository motifResiliationRepository = new MotifResiliationRepository(dataSource);

            // Act.
            MotifResiliation motifResiliation = motifResiliationRepository.ObtenirDepuisCle(this.CleValide);

            // Assert.
            this.VerifierEgaliteEntreDeuxMotifResiliation(this.MotifResiliationValide, motifResiliation);
        }

        #endregion Test de la méthode ObtenirParCle

        #region Test de la méthode ListerMotifsResiliation

        /// <summary>
        /// Test de la méthode ListerMotifsResiliation.
        /// </summary>
        [Test]
        public void ListerMotifResiliation_OK()
        {
            // Arrange.
            IDataSource sourceDonnees = new DataSource();

            MotifResiliation motifResiliation1 = this.MotifResiliationValide;
            motifResiliation1.Cle = this.CleValide;
            sourceDonnees.Add(motifResiliation1);

            MotifResiliation motifResiliation2 = this.MotifResiliationValide;
            motifResiliation2.Cle = this.CleValide + 1;
            sourceDonnees.Add(motifResiliation2);

            MotifResiliation motifResiliation3 = this.MotifResiliationValide;
            motifResiliation3.Cle = this.CleValide + 2;
            sourceDonnees.Add(motifResiliation3);

            MotifResiliationRepository motifResiliationRepository = new MotifResiliationRepository(sourceDonnees);

            // Act.
            List<MotifResiliation> motifsResiliation = motifResiliationRepository.ListerMotifsResiliation();

            // Assert.
            Assert.AreEqual(3, motifsResiliation.Count);
            this.VerifierEgaliteEntreDeuxMotifResiliation(motifResiliation1, motifsResiliation[0]);
            this.VerifierEgaliteEntreDeuxMotifResiliation(motifResiliation2, motifsResiliation[1]);
            this.VerifierEgaliteEntreDeuxMotifResiliation(motifResiliation3, motifsResiliation[2]);
        }

        #endregion Test de la méthode ListerMotifsResiliation

    }
}
