﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test pour le repository d'une panne collective.
    /// </summary>
    [TestFixture]
    public class PanneCollectiveRepositoryTest
    {
        private Identite identite;
        private Mock<IServicesTechniques> serviceTechnique;
        private long cleLigne;
        private int dureeValidite;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.cleLigne = 1;
            this.dureeValidite = 2;
        }

       
        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            PanneCollective entite1 = CreerPanneCollective(1, DateTime.Now);
            PanneCollective entite2 = CreerPanneCollective(2, DateTime.Now);
            PanneCollective entite3 = CreerPanneCollective(3, DateTime.Now);
            sourceDonnees.Add(entite1);
            sourceDonnees.Add(entite2);
            sourceDonnees.Add(entite3);
            return sourceDonnees;
        }

        /// <summary>
        /// Creation d'une datasource avec une panne collective en plus.
        /// </summary>
        /// <param name="panne">Panne collective a ajouter.</param>
        private IDataSource CreerSourceDonnees(PanneCollective panne)
        {
            IDataSource sourceDonnees = CreerSourceDonnees();
            sourceDonnees.Add(panne);
            return sourceDonnees;
        }

        /// <summary>
        /// Creer une panne collective.
        /// </summary>
        /// <param name="cle">Clé de la panne.</param>
        private PanneCollective CreerPanneCollective(long cle, DateTime dateDebut)
        {
            PanneCollective panne = new PanneCollective(this.identite, cle, dateDebut);
            return panne;
        }

        /// <summary>
        /// Initialisation d'un repository de lignes.
        /// </summary>
        /// <returns></returns>
        private ILigneRepository InitialiserLigneRepository()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            return new LigneRepository(sourceDonnees);
        }

        #region Test CreerPanneCollective

        /// <summary>
        /// Creer un repository avec datasource null.
        /// </summary>
        [Test]
        public void CreerPanneCollective_SourceDonneesNull_LeveException()
        {
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            TestDelegate action = () => new PanneCollectiveRepository(null, ligneRepository);
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creer PannesCollectives avec objet null.
        /// </summary>
        [Test]
        public void CreerPannesCollectives_PanneNull_LeveException()
        {
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.Creer(null);
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creer PannesCollectives avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerPannesCollectives_ParametresValide_OK()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.Creer(CreerPanneCollective(this.cleLigne, DateTime.Now));
            
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test CreerPanneCollective

        #region Test ListerPannesCollectivesParCleLigne

        /// <summary>
        ///ListerPannesCollectivesParCleLigne avec identite null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParCleLigne_IdentiteNull_LeveException()
        {
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.ListerPannesCollectivesParCleLigne(null, cleLigne, dureeValidite);
            Assert.Throws<ArgumentException>(action);         
        }

        /// <summary>
        ///ListerPannesCollectivesParCleLigne avec cle de la ligne null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParCleLigne_CleLigneNull_LeveException()
        {
            long cleLigne = 0;
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.ListerPannesCollectivesParCleLigne(this.identite, cleLigne, dureeValidite);
            
             Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        ///ListerPannesCollectivesParCleLigne avec cle de la ligne invalide.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParCleLigne_CleLigneInvalide_LeveException()
        {
            long cleLigneInvalide = -1;
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.ListerPannesCollectivesParCleLigne(this.identite, cleLigneInvalide, dureeValidite);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        ///ListerPannesCollectivesParCleLigne avec cle de la durée null.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParCleLigne_DureeNull_LeveException()
        {
            int dureeValidite = 0;
            ILigneRepository ligneRepository = this.InitialiserLigneRepository();
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository);
            TestDelegate action = () => repository.ListerPannesCollectivesParCleLigne(this.identite, this.cleLigne, dureeValidite);

            Assert.Throws<ArgumentException>(action);
        }


        /// <summary>
        ///ListerPannesCollectivesParCleLigne avec Paramètres OK.
        /// </summary>
        [Test]
        public void ListerPannesCollectivesParCleLigne_ParametresValide_OK()
        {
            List<PanneCollective> listePannes = new List<PanneCollective>() { new PanneCollective(this.identite, 1, DateTime.Now) };

            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(x => x.ListePannesCollectives).Returns(listePannes);

            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            ligneRepository.Setup(x => x.ObtenirDepuisCle(this.cleLigne)).Returns(ligne.Object);
            
            IPanneCollectiveRepository repository = new PanneCollectiveRepository(this.CreerSourceDonnees(), ligneRepository.Object);

            IEnumerable<PanneCollective> entiteRetournee = repository.ListerPannesCollectivesParCleLigne(this.identite, this.cleLigne, this.dureeValidite);

            Assert.AreEqual(entiteRetournee.First().Cle, entiteRetournee.First().Cle);
           
        }
        
        #endregion Test ListerPannesCollectivesParCleLigne

    }
}
