﻿using EIT.Fixe.Logistique.Domain.ExternalServices;
using EIT.Fixe.Logistique.Domain.Repositories;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using System;
using EIT.Fixe.Systeme.Tests;
using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Repositories;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test de FonctionnaliteRepository.
    /// </summary>
    public class FonctionnaliteRepositoryTest
    {
        #region Propriétés

        private Identite identite;
        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IRepositories> repositories;
        private Mock<IBriquesServicesExternes> briquesExternes;

        #endregion Propriétés

        #region Initialisateur

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialisterServicesExternes();
            this.InitialiserRepositories();
            this.InitialiserBriquesExternes();



        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation des services externes.
        /// </summary>
        private void InitialisterServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialisation des repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
        }

        /// <summary>
        /// Initialisation des briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            sourceDonnees.Add(this.CreerFonctionnalite());

            return sourceDonnees;
        }

        /// <summary>
        /// Creer une fonctionnalite.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Fonctionnalite CreerFonctionnalite()
        {
            ParametreFonctionnalitePourCreation parametreFonctionnalitePourCreation = new ParametreFonctionnalitePourCreation()
            {
                Cle = 1,
                Code = "code",
                Description = "description",
                EstActif = true,
                SuiviDateCreation = DateTime.Now
            };

            Fonctionnalite fonctionnalite = new Fonctionnalite(identite, parametreFonctionnalitePourCreation);

            return fonctionnalite;
        }

        #endregion Initialisateur

        #region Test de la méthode Ajouter.

        /// <summary>
        /// Test de la méthode Ajouter avec le paramètres OK. OK.
        /// </summary>
        [Test]
        public void Ajouter_ParametreOK_OK()
        {
            //Arrange.
            Fonctionnalite fct = this.CreerFonctionnalite();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            FonctionnaliteRepository repository = new FonctionnaliteRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(fct);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode Ajouter avec la fonctionnalite nulle. Exception levée.
        /// </summary>
        [Test]
        public void Ajouter_FonctionnliteNulle_ExceptionLevee()
        {
            //Arrange.
            Fonctionnalite fct = this.CreerFonctionnalite();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            FonctionnaliteRepository repository = new FonctionnaliteRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode Ajouter.

        #region Test de la méthode SupprimerDepuisDate

        /// <summary>
        /// Test de la méthode supprimer avec les paramètres OK. OK.
        /// </summary>
        [Test]
        public void SupprimerDepuisDate_ParametreOK_OK()
        {
            //Arrange.
            Fonctionnalite fct = this.CreerFonctionnalite();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            FonctionnaliteRepository repository = new FonctionnaliteRepository(sourceDonnees);
            repository.Ajouter(fct);
            //Act.
            TestDelegate action = () => repository.SupprimerDepuisDate(fct.SuiviDateCreation);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode supprimer avec la date nulle. ExceptionLevee.
        /// </summary>
        [Test]
        public void SupprimerDepuisDate_DateNulle_ExceptionLevee()
        {
            //Arrange.
            Fonctionnalite fct = this.CreerFonctionnalite();
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            FonctionnaliteRepository repository = new FonctionnaliteRepository(sourceDonnees);
            repository.Ajouter(fct);
            //Act.
            TestDelegate action = () => repository.SupprimerDepuisDate(new DateTime());
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode SupprimerDepuisDate

        #region Test de la méthode ListerFonctionnalitesActives

        /// <summary>
        /// Test de la méthode ListerFonctionnalitesActives.
        /// </summary>
        [Test]
        public void ListerFonctionnalitesACtives_ParametreOK_OK()
        {
            //Arrange.
            Fonctionnalite fct = this.CreerFonctionnalite();
            fct.EstActif = true;
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            FonctionnaliteRepository repository = new FonctionnaliteRepository(sourceDonnees);
            repository.Ajouter(fct);
            //Act.
            Fonctionnalite[] liste = repository.ListerFonctionnalitesActives();
            //Assert.
            Assert.AreEqual(liste[liste.Length - 1], fct);
        }

        #endregion Test de la méthode ListerFonctionnalitesActives
    }
}
