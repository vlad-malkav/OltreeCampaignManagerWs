﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIT.DataAccess;
using EIT.Fixe.Domain.Entities;
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using NUnit.Framework;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    [TestFixture]
    public class HistoriqueDossierGboLigneRepositoryTest
    {
        private Identite identite;
        private string referenceExterneLigne;
        private int cleDossierValide;
        private int cleDossierDoublon;
        private int cleDossierInexistant;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.referenceExterneLigne = "referenceExterne";
            this.cleDossierValide = 42;
            this.cleDossierDoublon = 666;
            this.cleDossierInexistant = -1;

            this.identite = new Identite()
            {
                Memoid = "MemoId",
                Canal = Canal.Technique
            };
        }


        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            sourceDonnees.Add(new HistoriqueDossierGboLigne(this.identite, 1L, this.referenceExterneLigne, this.cleDossierValide));
            sourceDonnees.Add(new HistoriqueDossierGboLigne(this.identite, 1L, this.referenceExterneLigne, this.cleDossierDoublon));
            sourceDonnees.Add(new HistoriqueDossierGboLigne(this.identite, 1L, this.referenceExterneLigne, this.cleDossierDoublon));

            return sourceDonnees;
        }


        #region Test ObtenirParCleDossier

        /// <summary>
        /// Test de ObtenirParCleDossier avec une clé de dossier valide
        /// </summary>
        [Test]
        public void ObtenirParCleDossier_ParametreValide_OK()
        {

            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());

            HistoriqueDossierGboLigne resultat = null;

            Assert.DoesNotThrow(() => resultat = repository.RechercherParCleDossier(this.cleDossierValide));
            Assert.IsNotNull(resultat);
        }
        /// <summary>
        /// Test de ObtenirParCleDossier avec une clé de dossier inexistante
        /// </summary>
        [Test]
        public void ObtenirParCleDossier_CleInexistante_KO()
        {
            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());

            HistoriqueDossierGboLigne resultat = null;

            Assert.DoesNotThrow(() => resultat = repository.RechercherParCleDossier(this.cleDossierInexistant));
            Assert.IsNull(resultat);
        }
        /// <summary>
        /// Test de ObtenirParCleDossier avec une clé de dossier en double
        /// </summary>
        [Test]
        public void ObtenirParCleDossier_CleEnDouble_KO()
        {
            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());

            HistoriqueDossierGboLigne resultat = null;

            Assert.Throws<InvalidOperationException>(() => resultat = repository.RechercherParCleDossier(this.cleDossierDoublon));
            Assert.IsNull(resultat);
        }

        #endregion

        #region Test RechercherParListeCleDossier

        /// <summary>
        /// Test de RechercherParListeCleDossier avec une clé de dossier valide et une autre absente
        /// </summary>
        [Test]
        public void RechercherParListeCleDossier_ParametreValide_OK()
        {

            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());
            var listeCleDossier = new List<int>
            {
                this.cleDossierValide,
                this.cleDossierInexistant
            };

            List<HistoriqueDossierGboLigne> resultat = null;

            Assert.DoesNotThrow(() => resultat = repository.RechercherParListeCleDossier(listeCleDossier));
            Assert.IsNotNull(resultat);
            Assert.IsTrue(resultat.Count == 1);
            Assert.AreEqual(this.cleDossierValide, resultat[0].CleDossierGbo);
        }

        /// <summary>
        /// Test de RechercherParListeCleDossier avec une clé de dossier inexistante
        /// </summary>
        [Test]
        public void RechercherParListeCleDossier_CleInexistante_OK()
        {

            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());
            var listeCleDossier = new List<int>
            {
                this.cleDossierInexistant
            };

            List<HistoriqueDossierGboLigne> resultat = null;

            Assert.DoesNotThrow(() => resultat = repository.RechercherParListeCleDossier(listeCleDossier));
            Assert.IsNotNull(resultat);
            Assert.IsTrue(resultat.Count == 0);
        }

        /// <summary>
        /// Test de RechercherParListeCleDossier avec une clé de dossier valide, inexistante, et doublon
        /// </summary>
        [Test]
        public void RechercherParListeCleDossier_CleDoublons_KO()
        {
            var repository = new HistoriqueDossierGboLigneRepository(this.CreerSourceDonnees());

            var listeCleDossier = new List<int>
            {
                this.cleDossierValide,
                this.cleDossierInexistant,
                this.cleDossierDoublon
            };

            List<HistoriqueDossierGboLigne> resultat = null;

            Assert.DoesNotThrow(() => resultat = repository.RechercherParListeCleDossier(listeCleDossier));
            Assert.IsNotNull(resultat);
            Assert.IsTrue(resultat.Count == 3);
        }

        #endregion
    }
}
