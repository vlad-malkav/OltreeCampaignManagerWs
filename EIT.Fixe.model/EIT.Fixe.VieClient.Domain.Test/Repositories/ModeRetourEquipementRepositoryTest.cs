﻿using System;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repository ModeRetourEquipement.
    /// </summary>
    [TestFixture]
    public class ModeRetourEquipementRepositoryTest
    {
        #region Propriétés 

        /// <summary>
        /// Clé valide. Correspond à un mode de retour équipement dans le dataSource.
        /// </summary>
        private long CleValide { get { return 123; } }

        /// <summary>
        /// Clé invalide. Correspond à aucun mode de retour équipement dans le dataSource.
        /// </summary>
        private long CleInvalide { get { return 999; } }

        /// <summary>
        /// Libellé valide. Correspond à un mode de retour équipement dans le dataSource.
        /// </summary>
        private string LibelleValide { get { return "Coucou, je suis valide."; } }

        /// <summary>
        /// Libellé invalide. Correspond à aucun mode de retour équipement dans le dataSource.
        /// </summary>
        private string LibelleInvalide { get { return "Mouhahaha, je suis invalide."; } }

        /// <summary>
        /// Retourne un mode de retour equipement valide, qui est inséré dans le dataSource.
        /// </summary>
        private ModeRetourEquipement ModeRetourEquipementValide
        {
            get
            {
                return new ModeRetourEquipement()
                {
                    Cle = this.CleValide,
                    Libelle = this.LibelleValide,
                    TypeEnvoi = CommonTypes.Enumerations.TypeEnvoi.DepotEnAgence
                };
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            sourceDonnees.Add(this.ModeRetourEquipementValide);

            return sourceDonnees;
        }

        /// <summary>
        /// Vérifie l'égalité entre deux ModeRetourEquipement.
        /// </summary>
        /// <param name="modeRetourEquipementAttendu">Le mode de retour équipement attendu.</param>
        /// <param name="modeRetourEquipementActuel">Le mode de retour équipement actuel.</param>
        public void VerifierEgaliteEntreDeuxModeRetourEquipement(ModeRetourEquipement modeRetourEquipementAttendu, ModeRetourEquipement modeRetourEquipementActuel)
        {
            Assert.AreEqual(modeRetourEquipementAttendu.Cle, modeRetourEquipementActuel.Cle);
            Assert.AreEqual(modeRetourEquipementAttendu.EstCocheParDefaut, modeRetourEquipementActuel.EstCocheParDefaut);
            Assert.AreEqual(modeRetourEquipementAttendu.EstEnvoiEtiquettePrepayee, modeRetourEquipementActuel.EstEnvoiEtiquettePrepayee);
            Assert.AreEqual(modeRetourEquipementAttendu.Libelle, modeRetourEquipementActuel.Libelle);
            Assert.AreEqual(modeRetourEquipementAttendu.SuiviAgentCreation, modeRetourEquipementActuel.SuiviAgentCreation);
            Assert.AreEqual(modeRetourEquipementAttendu.SuiviAgentModification, modeRetourEquipementActuel.SuiviAgentModification);
            Assert.AreEqual(modeRetourEquipementAttendu.SuiviDateCreation, modeRetourEquipementActuel.SuiviDateCreation);
            Assert.AreEqual(modeRetourEquipementAttendu.SuiviDateModification, modeRetourEquipementActuel.SuiviDateModification);
            Assert.AreEqual(modeRetourEquipementAttendu.TypePriseEnCharge, modeRetourEquipementActuel.TypePriseEnCharge);
        }

        #endregion Méthodes d'initialisation

        #region Test de la création du repository

        /// <summary>
        /// Test de la création du repository avec un dataSource null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesNull_LeveException()
        {
            // Arrange.
            IDataSource dataSource = null;

            // Act.
            TestDelegate action = () => new ModeRetourEquipementRepository(dataSource);

            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la création du repository avec un dataSource correct. Pas d'exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesOK_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();

            // Act.
            TestDelegate action = () => new ModeRetourEquipementRepository(dataSource);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test de la création du repository

        #region Test de la méthode ObtenirParCle

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé inexistante. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleInexistante_LeveException()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            ModeRetourEquipementRepository modeRetourEquipementRepository = new ModeRetourEquipementRepository(dataSource);

            // Act.
            TestDelegate action = () => modeRetourEquipementRepository.ObtenirDepuisCle(this.CleInvalide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé existante. Retourne un objet ModeRetourEquipement.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleExistante_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            ModeRetourEquipementRepository modeRetourEquipementRepository = new ModeRetourEquipementRepository(dataSource);

            // Act.
            ModeRetourEquipement modeRetourEquipement = modeRetourEquipementRepository.ObtenirDepuisCle(this.CleValide);

            // Assert.
            this.VerifierEgaliteEntreDeuxModeRetourEquipement(this.ModeRetourEquipementValide, modeRetourEquipement);
        }

        #endregion Test de la méthode ObtenirParCle

        #region Test de la méthode ObtenirParTypeEnvoi

        /// <summary>
        /// Test de la méthode ObtenirParTypeEnvoi avec une clé existante. Retourne un objet ModeRetourEquipement.
        /// </summary>
        [Test]
        public void OObtenirParTypeEnvoi_CleExistante_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            ModeRetourEquipementRepository modeRetourEquipementRepository = new ModeRetourEquipementRepository(dataSource);

            // Act.
            ModeRetourEquipement modeRetourEquipement = modeRetourEquipementRepository.ObtenirDepuisTypeEnvoi(CommonTypes.Enumerations.TypeEnvoi.DepotEnAgence);

            // Assert.
            this.VerifierEgaliteEntreDeuxModeRetourEquipement(this.ModeRetourEquipementValide, modeRetourEquipement);
        }

        #endregion Test de la méthode ObtenirParTypeEnvoi
    }
}
