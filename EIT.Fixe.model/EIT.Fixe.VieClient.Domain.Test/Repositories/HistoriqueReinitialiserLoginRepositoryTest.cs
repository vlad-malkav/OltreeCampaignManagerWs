﻿using EIT.DataAccess;
using EIT.Fixe.Logistique.Domain.ExternalServices;
using EIT.Fixe.Logistique.Domain.Repositories;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test de HistoriqueReinitialiserLoginRepository.
    /// </summary>
    public class HistoriqueReinitialiserLoginRepositoryTest
    {
        #region Propriétés

        private Identite identite;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IRepositories> repositories;
        private Mock<IBriquesServicesExternes> briquesExternes;

        #endregion Propriétés

        #region Initialisateur

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialisterServicesExternes();
            this.InitialiserRepositories();
            this.InitialiserBriquesExternes();
        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation des services externes.
        /// </summary>
        private void InitialisterServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialisation des repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
        }

        /// <summary>
        /// Initialisation des briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            return sourceDonnees;
        }

        /// <summary>
        /// Creer une fonctionnalite.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private HistoriqueReinitialiserLogin CreerHistorique()
        {
            ParametreHistoriqueReinitialiserLoginPourCreation param = new ParametreHistoriqueReinitialiserLoginPourCreation()
            {
                CanalDemande = "canalDemande",
                Cle = 1,
                CleLigne = 1,
                Destinataire = "destinataire",
                Identifiant = "identifiant",
                ModeEnvoi = CommonTypes.Enumerations.CanalCommunication.Sms
            };

            HistoriqueReinitialiserLogin histo = new HistoriqueReinitialiserLogin(this.identite, param);
            
            return histo;
        }

        #endregion Initialisateur

        #region Test de la méthode Ajouter

        /// <summary>
        /// Test de la méthode Ajouter avec les paramètres OK.
        /// </summary>
        [Test]
        public void Ajouter_ParametreOK_OK()
        {
            //Arrange.
            HistoriqueReinitialiserLogin histo = CreerHistorique();
            IDataSource data = CreerSourceDonnees();
            HistoriqueReinitialiserLoginRepository repository = new HistoriqueReinitialiserLoginRepository(data);
            //Act.
            TestDelegate action = () => repository.Ajouter(histo);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode Ajouter avec l'historique null.Exception levée.
        /// </summary>
        [Test]
        public void Ajouter_HistoriqueReinitialiserLoginNull_ExceptionLevee()
        {
            //Arrange.
            IDataSource data = CreerSourceDonnees();
            HistoriqueReinitialiserLoginRepository repository = new HistoriqueReinitialiserLoginRepository(data);
            //Act.
            TestDelegate action = () => repository.Ajouter(null);
            //Assert.
            Assert.Throws<ArgumentException>(action); 
        }

        #endregion Test de la méthode Ajouter

        #region Test de la méthode ListerDepuisCleLigne

        /// <summary>
        /// Test de la méthode ListerDepuisCleLigne.
        /// </summary>
        [Test]
        public void ListerDepuisCleLigne_OK()
        {
            //Arrange.
            HistoriqueReinitialiserLogin histo = CreerHistorique();
            IDataSource data = CreerSourceDonnees();
            data.Add(histo);
            HistoriqueReinitialiserLoginRepository repository = new HistoriqueReinitialiserLoginRepository(data);
            //Act.
            List<HistoriqueReinitialiserLogin> liste = repository.ListerDepuisCleLigne(1);
            //Assert.
            Assert.AreEqual(liste[0], histo);
        }

        #endregion Test de la méthode ListerDepuisCleLigne
    }
}
