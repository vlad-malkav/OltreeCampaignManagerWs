﻿using System;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repository DemandeResiliation.
    /// </summary>
    [TestFixture]
    public class DemandeResiliationRepositoryTest
    {
        #region Propriétés 

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite IdentiteValide
        {
            get
            {
                return new Identite() { Memoid = "MemoId" };
            }
        }

        /// <summary>
        /// Clé valide. Correspond à une demande de résiliation équipement dans le dataSource.
        /// </summary>
        private long CleValide { get { return 123; } }

        /// <summary>
        /// Clé invalide. Correspond à aucune demande de résiliation dans le dataSource.
        /// </summary>
        private long CleInvalide { get { return 999; } }

        /// <summary>
        /// Retourne objet DemandeResiliation valide, qui est inséré dans le dataSource.
        /// </summary>
        private DemandeResiliation DemandeResiliationValide
        {
            get
            {
                Mock<DemandeResiliation> demandeResiliation = new Mock<DemandeResiliation>();
                demandeResiliation.Setup(x => x.Cle).Returns(this.CleValide);

                return demandeResiliation.Object;
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();
            sourceDonnees.Add(this.DemandeResiliationValide);

            return sourceDonnees;
        }

        /// <summary>
        /// Vérifie l'égalité entre deux DemandeResiliation.
        /// </summary>
        /// <param name="demandeResiliationAttendue">La demande de résiliation attendue.</param>
        /// <param name="demandeResiliationActuelle">La demande de résiliation actuelle.</param>
        public void VerifierEgaliteEntreDeuxDemandeResiliation(DemandeResiliation demandeResiliationAttendue, DemandeResiliation demandeResiliationActuelle)
        {
            Assert.AreEqual(demandeResiliationAttendue.Cle, demandeResiliationActuelle.Cle);
        }

        #endregion Méthodes d'initialisation

        #region Test de la création du repository

        /// <summary>
        /// Test de la création du repository avec un dataSource null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesNull_LeveException()
        {
            // Arrange.
            IDataSource dataSource = null;

            // Act.
            TestDelegate action = () => new DemandeResiliationRepository(dataSource);

            // Assert.
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Test de la création du repository avec un dataSource correct. Pas d'exception.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesOK_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();

            // Act.
            TestDelegate action = () => new DemandeResiliationRepository(dataSource);

            // Assert.
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test de la création du repository

        #region Test de la méthode ObtenirParCle

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé inexistante. Lève une exception.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleInexistante_LeveException()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            DemandeResiliationRepository demandeResiliationRepository = new DemandeResiliationRepository(dataSource);

            // Act.
            TestDelegate action = () => demandeResiliationRepository.ObtenirDepuisCle(this.CleInvalide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode ObtenirParCle avec une clé existante. Retourne un objet DemandeResiliation.
        /// </summary>
        [Test]
        public void ObtenirParCle_CleExistante_OK()
        {
            // Arrange.
            IDataSource dataSource = this.CreerSourceDonnees();
            DemandeResiliationRepository demandeResiliationRepository = new DemandeResiliationRepository(dataSource);

            // Act.
            DemandeResiliation demandeResiliation = demandeResiliationRepository.ObtenirDepuisCle(this.CleValide);

            // Assert.
            this.VerifierEgaliteEntreDeuxDemandeResiliation(this.DemandeResiliationValide, demandeResiliation);
        }

        #endregion Test de la méthode ObtenirParCle
    }
}
