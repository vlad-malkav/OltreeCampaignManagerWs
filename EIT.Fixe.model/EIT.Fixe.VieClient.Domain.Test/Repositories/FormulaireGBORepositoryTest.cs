﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Castle.Components.DictionaryAdapter;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test pour le repository des Formulaires GBO.
    /// </summary>
    [TestFixture]
    public class FormulaireGboRepositoryTest
    {
        private Identite identite;

        private MotifDysfonctionnement MotifDysfonctionnement_1, MotifDysfonctionnement_2;
        private MotifQualification MotifQualification_1, MotifQualification_2;
        private NatureDemandeIntervention NatureDemandeIntervention_1, NatureDemandeIntervention_2;
        private OrigineDysfonctionnement OrigineDysfonctionnement_1, OrigineDysfonctionnement_2;
        private RegionCDC RegionCDC_1, RegionCDC_2;

        private FormulaireGBO FormulaireGBO;
        private FormulaireCN2DI FormulaireCN2DI;
        private FormulaireCN3EQ FormulaireCN3EQ;
        private FormulaireMPS FormulaireMPS;
        private FormulaireRisqueResiliation FormulaireRisqueResiliation;

        private List<PieceJointeFormulaireGbo> ListePieceJointeFormulaireGbo;
        private PieceJointeFormulaireGbo PieceJointeFormulaireGbo_1, PieceJointeFormulaireGbo_2;

        /// <summary>
        /// Retourne une clé de FormulaireGBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            sourceDonnees.Add(this.MotifDysfonctionnement_1 = GenererMotifDysfonctionnement(1));
            sourceDonnees.Add(this.MotifDysfonctionnement_2 = GenererMotifDysfonctionnement(2));
            sourceDonnees.Add(this.MotifQualification_1 = GenererMotifQualification(1));
            sourceDonnees.Add(this.MotifQualification_2 = GenererMotifQualification(2));
            sourceDonnees.Add(this.NatureDemandeIntervention_1 = GenererNatureDemandeIntervention(1));
            sourceDonnees.Add(this.NatureDemandeIntervention_2 = GenererNatureDemandeIntervention(2));
            sourceDonnees.Add(this.OrigineDysfonctionnement_1 = GenererOrigineDysfonctionnement(1));
            sourceDonnees.Add(this.OrigineDysfonctionnement_2 = GenererOrigineDysfonctionnement(2));
            sourceDonnees.Add(this.RegionCDC_1 = GenererRegionCDC(1));
            sourceDonnees.Add(this.RegionCDC_2 = GenererRegionCDC(2));

            sourceDonnees.Add(this.PieceJointeFormulaireGbo_1 = GeneratePieceJointeFormulaireGbo(1));
            sourceDonnees.Add(this.PieceJointeFormulaireGbo_2 = GeneratePieceJointeFormulaireGbo(2));

            this.ListePieceJointeFormulaireGbo = new List<PieceJointeFormulaireGbo>();
            this.ListePieceJointeFormulaireGbo.Add(this.PieceJointeFormulaireGbo_1);
            this.ListePieceJointeFormulaireGbo.Add(this.PieceJointeFormulaireGbo_2);

            int idGbo = 1;

            sourceDonnees.Add(this.FormulaireGBO = GenererFormulaireGBO(idGbo, idGbo++, this.RegionCDC_1));
            sourceDonnees.Add(this.FormulaireCN2DI = GenererFormulaireCN2DI(idGbo, idGbo++, this.RegionCDC_1, this.MotifDysfonctionnement_1, this.OrigineDysfonctionnement_1, this.ListePieceJointeFormulaireGbo));
            sourceDonnees.Add(this.FormulaireCN3EQ = GenererFormulaireCN3EQ(idGbo, idGbo++, this.RegionCDC_1, this.NatureDemandeIntervention_1, this.ListePieceJointeFormulaireGbo));
            sourceDonnees.Add(this.FormulaireMPS = GenererFormulaireMPS(idGbo, idGbo++, this.RegionCDC_1));
            sourceDonnees.Add(this.FormulaireRisqueResiliation = GenererFormulaireRisqueResiliation(idGbo, idGbo++, this.RegionCDC_1, this.MotifQualification_1));

            return sourceDonnees;
        }

        /// <summary>
        /// Creer un repository avec datasource null.
        /// </summary>
        [Test]
        public void CreerFormulaireGboRepository_SourceDonneesNull_LeveException()
        {
            IDataSource dataSource = null;

            TestDelegate action = () => new FormulaireGboRepository(dataSource);

            Assert.Throws<ArgumentNullException>(action);
        }

        #region Méthodes - IFormulaireGboRepository - Tables de Paramétrage

        #region Utiles

        /// <summary>
        /// Générer un MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private MotifDysfonctionnement GenererMotifDysfonctionnement(long cle)
        {
            return new MotifDysfonctionnement(this.identite, cle, "MotifDysfonctionnement-" + cle);
        }

        /// <summary>
        /// Générer un MotifQualification.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private MotifQualification GenererMotifQualification(long cle)
        {
            return new MotifQualification(this.identite, cle, "MotifQualification-" + cle);
        }

        /// <summary>
        /// Générer un NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private NatureDemandeIntervention GenererNatureDemandeIntervention(long cle)
        {
            return new NatureDemandeIntervention(this.identite, cle, "NatureDemandeIntervention-" + cle);
        }

        /// <summary>
        /// Générer un OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private OrigineDysfonctionnement GenererOrigineDysfonctionnement(long cle)
        {
            return new OrigineDysfonctionnement(this.identite, cle, "OrigineDysfonctionnement-" + cle);
        }

        /// <summary>
        /// Générer un RegionCDC.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private RegionCDC GenererRegionCDC(long cle)
        {
            return new RegionCDC(this.identite, cle, "RegionCDC-" + cle);
        }

        #endregion Utiles

        #region MotifDysfonctionnement

        #region Test ObtenirMotifDysfonctionnementParCle

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirMotifDysfonctionnementParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirMotifDysfonctionnementParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifDysfonctionnementParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            MotifDysfonctionnement motifDysfonctionnement = repository.ObtenirMotifDysfonctionnementParCle(this.MotifDysfonctionnement_1.Cle);

            // Assert
            Assert.AreEqual(motifDysfonctionnement.Cle, this.MotifDysfonctionnement_1.Cle, "Cle incorrecte");
            Assert.AreEqual(motifDysfonctionnement.Libelle, this.MotifDysfonctionnement_1.Libelle, "Libelle incorrect");
        }

        #endregion Test ObtenirMotifDysfonctionnementParCle

        #region Test ListerMotifDysfonctionnement

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifDysfonctionnement.</returns>
        [Test]
        public void ListerMotifDysfonctionnement_OK_ParametreValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            IEnumerable<MotifDysfonctionnement> resultat = repository.ListerMotifDysfonctionnement();
            MotifDysfonctionnement[] tableauMotifDysfonctionnement = resultat.ToArray();

            Assert.AreEqual(tableauMotifDysfonctionnement.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauMotifDysfonctionnement[0].Cle, this.MotifDysfonctionnement_1.Cle, "Cle résultat 1 incorrecte");
            Assert.AreEqual(tableauMotifDysfonctionnement[0].Libelle, this.MotifDysfonctionnement_1.Libelle, "Libelle résultat 1 incorrect");
            Assert.AreEqual(tableauMotifDysfonctionnement[1].Cle, this.MotifDysfonctionnement_2.Cle, "Cle résultat 2 incorrecte");
            Assert.AreEqual(tableauMotifDysfonctionnement[1].Libelle, this.MotifDysfonctionnement_2.Libelle, "Libelle résultat 2 incorrect");
        }

        #endregion Test ListerMotifDysfonctionnement

        #endregion MotifDysfonctionnement

        #region MotifQualification

        #region Test ObtenirMotifQualificationParCle

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifQualificationParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirMotifQualificationParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifQualificationParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirMotifQualificationParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec une clé inexistante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifQualificationParCle_CleInexistante_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirMotifQualificationParCle(99);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type MotifQualification avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirMotifQualificationParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            MotifQualification motifQualification = repository.ObtenirMotifQualificationParCle(this.MotifQualification_1.Cle);

            // Assert
            Assert.AreEqual(motifQualification.Cle, this.MotifQualification_1.Cle, "Cle incorrecte");
            Assert.AreEqual(motifQualification.Libelle, this.MotifQualification_1.Libelle, "Libelle incorrect");
        }

        #endregion Test ObtenirMotifQualificationParCle

        #region Test ListerMotifQualification

        /// <summary>
        /// Recherche tous les MotifQualification.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifQualification.</returns>
        [Test]
        public void ListerMotifQualification_OK_ParametreValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            IEnumerable<MotifQualification> resultat = repository.ListerMotifQualification();
            MotifQualification[] tableauMotifQualification = resultat.ToArray();

            Assert.AreEqual(tableauMotifQualification.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauMotifQualification[0].Cle, this.MotifQualification_1.Cle, "Cle résultat 1 incorrecte");
            Assert.AreEqual(tableauMotifQualification[0].Libelle, this.MotifQualification_1.Libelle, "Libelle résultat 1 incorrect");
            Assert.AreEqual(tableauMotifQualification[1].Cle, this.MotifQualification_2.Cle, "Cle résultat 2 incorrecte");
            Assert.AreEqual(tableauMotifQualification[1].Libelle, this.MotifQualification_2.Libelle, "Libelle résultat 2 incorrect");
        }

        #endregion Test ListerMotifQualification

        #endregion MotifQualification

        #region NatureDemandeIntervention

        #region Test ObtenirNatureDemandeInterventionParCle

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirNatureDemandeInterventionParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirNatureDemandeInterventionParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec une clé inexistante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_CleInexistante_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirNatureDemandeInterventionParCle(99);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirNatureDemandeInterventionParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            NatureDemandeIntervention natureDemandeIntervention = repository.ObtenirNatureDemandeInterventionParCle(this.NatureDemandeIntervention_1.Cle);

            // Assert
            Assert.AreEqual(natureDemandeIntervention.Cle, this.NatureDemandeIntervention_1.Cle, "Cle incorrecte");
            Assert.AreEqual(natureDemandeIntervention.Libelle, this.NatureDemandeIntervention_1.Libelle, "Libelle incorrect");
        }

        #endregion Test ObtenirNatureDemandeInterventionParCle

        #region Test ListerNatureDemandeIntervention

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention.
        /// </summary>
        /// <returns>Retourne la liste de tous les NatureDemandeIntervention.</returns>
        [Test]
        public void ListerNatureDemandeIntervention_OK_ParametreValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            IEnumerable<NatureDemandeIntervention> resultat = repository.ListerNatureDemandeIntervention();
            NatureDemandeIntervention[] tableauNatureDemandeIntervention = resultat.ToArray();

            Assert.AreEqual(tableauNatureDemandeIntervention.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauNatureDemandeIntervention[0].Cle, this.NatureDemandeIntervention_1.Cle, "Cle résultat 1 incorrecte");
            Assert.AreEqual(tableauNatureDemandeIntervention[0].Libelle, this.NatureDemandeIntervention_1.Libelle, "Libelle résultat 1 incorrect");
            Assert.AreEqual(tableauNatureDemandeIntervention[1].Cle, this.NatureDemandeIntervention_2.Cle, "Cle résultat 2 incorrecte");
            Assert.AreEqual(tableauNatureDemandeIntervention[1].Libelle, this.NatureDemandeIntervention_2.Libelle, "Libelle résultat 2 incorrect");
        }

        #endregion Test ListerNatureDemandeIntervention

        #endregion NatureDemandeIntervention

        #region OrigineDysfonctionnement

        #region Test ObtenirOrigineDysfonctionnementParCle

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirOrigineDysfonctionnementParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirOrigineDysfonctionnementParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec une clé inexistante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_CleInexistante_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirOrigineDysfonctionnementParCle(99);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirOrigineDysfonctionnementParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            OrigineDysfonctionnement origineDysfonctionnement = repository.ObtenirOrigineDysfonctionnementParCle(this.OrigineDysfonctionnement_1.Cle);

            // Assert
            Assert.AreEqual(origineDysfonctionnement.Cle, this.OrigineDysfonctionnement_1.Cle, "Cle incorrecte");
            Assert.AreEqual(origineDysfonctionnement.Libelle, this.OrigineDysfonctionnement_1.Libelle, "Libelle incorrect");
        }

        #endregion Test ObtenirOrigineDysfonctionnementParCle

        #region Test ListerOrigineDysfonctionnement

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les OrigineDysfonctionnement.</returns>
        [Test]
        public void ListerOrigineDysfonctionnement_OK_ParametreValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            IEnumerable<OrigineDysfonctionnement> resultat = repository.ListerOrigineDysfonctionnement();
            OrigineDysfonctionnement[] tableauOrigineDysfonctionnement = resultat.ToArray();

            Assert.AreEqual(tableauOrigineDysfonctionnement.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauOrigineDysfonctionnement[0].Cle, this.OrigineDysfonctionnement_1.Cle, "Cle résultat 1 incorrecte");
            Assert.AreEqual(tableauOrigineDysfonctionnement[0].Libelle, this.OrigineDysfonctionnement_1.Libelle, "Libelle résultat 1 incorrect");
            Assert.AreEqual(tableauOrigineDysfonctionnement[1].Cle, this.OrigineDysfonctionnement_2.Cle, "Cle résultat 2 incorrecte");
            Assert.AreEqual(tableauOrigineDysfonctionnement[1].Libelle, this.OrigineDysfonctionnement_2.Libelle, "Libelle résultat 2 incorrect");
        }

        #endregion Test ListerOrigineDysfonctionnement

        #endregion OrigineDysfonctionnement

        #region RegionCDC

        #region Test ObtenirRegionCdcParCle

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirRegionCdcParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirRegionCdcParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirRegionCdcParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirRegionCdcParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec une clé inexistante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirRegionCdcParCle_CleInexistante_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirRegionCdcParCle(99);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type RegionCDC avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirRegionCdcParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            RegionCDC regionCDC = repository.ObtenirRegionCdcParCle(this.RegionCDC_1.Cle);

            // Assert
            Assert.AreEqual(regionCDC.Cle, this.RegionCDC_1.Cle, "Cle incorrecte");
            Assert.AreEqual(regionCDC.Libelle, this.RegionCDC_1.Libelle, "Libelle incorrect");
        }

        #endregion Test ObtenirRegionCdcParCle

        #region Test ListerRegionCdc

        /// <summary>
        /// Recherche tous les RegionCDC.
        /// </summary>
        /// <returns>Retourne la liste de tous les RegionCDC.</returns>
        [Test]
        public void ListerRegionCdc_OK_ParametreValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            IEnumerable<RegionCDC> resultat = repository.ListerRegionCdc();
            RegionCDC[] tableauRegionCDC = resultat.ToArray();

            Assert.AreEqual(tableauRegionCDC.Length, 2, "Nombre de résultats incorrect");
            Assert.AreEqual(tableauRegionCDC[0].Cle, this.RegionCDC_1.Cle, "Cle résultat 1 incorrecte");
            Assert.AreEqual(tableauRegionCDC[0].Libelle, this.RegionCDC_1.Libelle, "Libelle résultat 1 incorrect");
            Assert.AreEqual(tableauRegionCDC[1].Cle, this.RegionCDC_2.Cle, "Cle résultat 2 incorrecte");
            Assert.AreEqual(tableauRegionCDC[1].Libelle, this.RegionCDC_2.Libelle, "Libelle résultat 2 incorrect");
        }

        #endregion Test ListerRegionCdc

        #endregion RegionCDC

        #endregion Méthodes - IFormulaireGboRepository - Tables de Paramétrage

        #region Méthodes - IFormulaireGboRepository - Formulaires

        #region Utiles

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        /// <summary>
        /// Creer un FormulaireGBO.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private FormulaireGBO GenererFormulaireGBO(long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc)
        {
            ParametresCreationFormulaireGbo parametresCreationFormulaireGBO =
                GenerateParametresCreationFormulaireGboOk(cleFormulaireGBO, cleDossierGBO, regionCdc);
            return new FormulaireGBO(this.identite, parametresCreationFormulaireGBO);
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk(long cleFormulaireGbo, long cleDossierGbo, RegionCDC regionCdc)
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                cleFormulaireGbo,
                cleDossierGbo,
                regionCdc,
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        /// <summary>
        /// Creer un FormulaireCN2DI.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private FormulaireCN2DI GenererFormulaireCN2DI(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            MotifDysfonctionnement motifDysfonctionnement, OrigineDysfonctionnement origineDysfonctionnement,
            List<PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI =
                GenerateParametresCreationFormulaireCN2DIOk(
                    cleFormulaireGBO, cleDossierGBO, regionCdc,
                    motifDysfonctionnement, origineDysfonctionnement);
            return new FormulaireCN2DI(this.identite, parametresCreationFormulaireCN2DI, listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN2DI GenerateParametresCreationFormulaireCN2DIOk(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            MotifDysfonctionnement motifDysfonctionnement, OrigineDysfonctionnement origineDysfonctionnement)
        {
            return new ParametresCreationFormulaireCN2DI(
                GenerateParametresCreationFormulaireGboOk(cleFormulaireGBO, cleDossierGBO, regionCdc),
                GenerateInformationsClientPourCreation(),
                GenerateInformationsSupplementairesCN2DiPourCreationOk(),
                MotifDysfonctionnement_1,
                OrigineDysfonctionnement_1);
        }

        public InformationsSupplementairesCN2DiPourCreation GenerateInformationsSupplementairesCN2DiPourCreationOk()
        {
            return new InformationsSupplementairesCN2DiPourCreation
            {
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions",
                DateApproxAppelServiceClient = DateTime.Now,
                RaisonsDysfonctionnement = "Raisons",
                NumeroCommandeClient = "123456"
            };
        }

        /// <summary>
        /// Creer un FormulaireCN3EQ.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private FormulaireCN3EQ GenererFormulaireCN3EQ(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            NatureDemandeIntervention natureDemandeIntervention,
            List<PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo)
        {
            ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ =
                GenerateParametresCreationFormulaireCN3EQOk(
                    cleFormulaireGBO, cleDossierGBO, regionCdc,
                    natureDemandeIntervention);
            return new FormulaireCN3EQ(this.identite, parametresCreationFormulaireCN3EQ, listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN3EQ GenerateParametresCreationFormulaireCN3EQOk(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            NatureDemandeIntervention natureDemandeIntervention)
        {
            return new ParametresCreationFormulaireCN3EQ(
                GenerateParametresCreationFormulaireGboOk(cleFormulaireGBO, cleDossierGBO, regionCdc),
                GenerateInformationsSupplementairesCN3EqPourCreationOk(),
                NatureDemandeIntervention_1);
        }

        public InformationsSupplementairesCN3EqPourCreation GenerateInformationsSupplementairesCN3EqPourCreationOk()
        {
            return new InformationsSupplementairesCN3EqPourCreation
            {
                NumeroSuiviDossier = "12345",
                DateReponseCelluleN2 = DateTime.Now,
                RaisonContestation = "Raison",
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions"
            };
        }

        /// <summary>
        /// Creer un FormulaireMPS.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private FormulaireMPS GenererFormulaireMPS(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc)
        {
            ParametresCreationFormulaireMPS parametresCreationFormulaireMPS =
                GenerateParametresCreationFormulaireMPSOk(
                    cleFormulaireGBO, cleDossierGBO, regionCdc);
            return new FormulaireMPS(this.identite, parametresCreationFormulaireMPS);
        }

        public ParametresCreationFormulaireMPS GenerateParametresCreationFormulaireMPSOk(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc)
        {
            return new ParametresCreationFormulaireMPS(
                GenerateParametresCreationFormulaireGboOk(cleFormulaireGBO, cleDossierGBO, regionCdc),
                GenerateInformationsClientPourCreation(),
                DateTime.Now,
                ProfilSurconsommation.ClientStandard, 
                "Commentaire");
        }

        /// <summary>
        /// Creer un FormulaireRisqueResiliation.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private FormulaireRisqueResiliation GenererFormulaireRisqueResiliation(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            MotifQualification motifQualification)
        {
            ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation =
                GenerateParametresCreationFormulaireRisqueResiliationOk(
                    cleFormulaireGBO, cleDossierGBO, regionCdc,
                    motifQualification);
            return new FormulaireRisqueResiliation(this.identite, parametresCreationFormulaireRisqueResiliation);
        }

        public ParametresCreationFormulaireRisqueResiliation GenerateParametresCreationFormulaireRisqueResiliationOk(
            long cleFormulaireGBO, long cleDossierGBO, RegionCDC regionCdc,
            MotifQualification motifQualification)
        {
            return new ParametresCreationFormulaireRisqueResiliation(
                GenerateParametresCreationFormulaireGboOk(cleFormulaireGBO, cleDossierGBO, regionCdc),
                GenerateInformationsClientPourCreation(),
                "Offre",
                motifQualification,
                "Commentaire");
        }

        public ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk(
            long clePieceJointeFormulaireGbo)
        {
            return new ParametresCreationPieceJointeFormulaireGbo(
                clePieceJointeFormulaireGbo,
                "GUDOCID_TEST_" + clePieceJointeFormulaireGbo,
                "NomFichierTest_" + clePieceJointeFormulaireGbo + ".xml");
        }

        public Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo GeneratePieceJointeFormulaireGbo(
            long clePieceJointeFormulaireGbo)
        {
            return new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                this.identite,
                GenerateParametresCreationPieceJointeFormulaireGboOk(clePieceJointeFormulaireGbo));
        }

        public List<PieceJointeFormulaireGbo> GenerateListePieceJointeFormulaireGboOk(int nbParametresACreer)
        {
            List<PieceJointeFormulaireGbo> result =
                new List<PieceJointeFormulaireGbo>();

            for (int i = 1; i <= nbParametresACreer; i++)
            {
                result.Add(GeneratePieceJointeFormulaireGbo(i));
            }

            return result;
        }

        #endregion Utiles

        #region FormulaireGBO

        #region ObtenirFormulaireGboParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireGboParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireGboParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireGboParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireGboParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireGboParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            FormulaireGBO formulaireGBO = repository.ObtenirFormulaireGboParCle(this.FormulaireGBO.Cle);

            // Assert
            Assert.AreEqual(formulaireGBO.Cle, this.FormulaireGBO.Cle, "Cle incorrecte");
            Assert.AreEqual(formulaireGBO.CleDossierGbo, this.FormulaireGBO.CleDossierGbo, "CleDossierGbo incorrecte");
            Assert.AreEqual(formulaireGBO.CdcAdresseMail, this.FormulaireGBO.CdcAdresseMail, "CdcAdresseMail incorrecte");
            Assert.AreEqual(formulaireGBO.CdcCodeBanque, this.FormulaireGBO.CdcCodeBanque, "CdcCodeBanque incorrect");
            Assert.AreEqual(formulaireGBO.CdcCodeBranche, this.FormulaireGBO.CdcCodeBranche, "CdcCodeBranche incorrect");
            Assert.AreEqual(formulaireGBO.CdcLigneDirecte, this.FormulaireGBO.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
            Assert.AreEqual(formulaireGBO.CdcNomPrenom, this.FormulaireGBO.CdcNomPrenom, "CdcNomPrenom incorrect");
            Assert.AreEqual(formulaireGBO.RegionCdc.Cle, this.FormulaireGBO.RegionCdc.Cle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireGBO.RegionCdc.Libelle, this.FormulaireGBO.RegionCdc.Libelle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireGBO.TypeFormulaireGbo, this.FormulaireGBO.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
        }

        #endregion ObtenirFormulaireGboParCle

        #endregion FormulaireGBO

        #region FormulaireCN2DI

        #region Test ObtenirFormulaireCN2DiParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireCN2DiParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireCN2DiParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN2DiParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            FormulaireCN2DI formulaireCN2DI = repository.ObtenirFormulaireCN2DiParCle(this.FormulaireCN2DI.Cle);

            // Assert
            Assert.AreEqual(formulaireCN2DI.Cle, this.FormulaireCN2DI.Cle, "Cle incorrecte");
            Assert.AreEqual(formulaireCN2DI.CleDossierGbo, this.FormulaireCN2DI.CleDossierGbo, "CleDossierGbo incorrecte");
            Assert.AreEqual(formulaireCN2DI.CdcAdresseMail, this.FormulaireCN2DI.CdcAdresseMail, "CdcAdresseMail incorrecte");
            Assert.AreEqual(formulaireCN2DI.CdcCodeBanque, this.FormulaireCN2DI.CdcCodeBanque, "CdcCodeBanque incorrect");
            Assert.AreEqual(formulaireCN2DI.CdcCodeBranche, this.FormulaireCN2DI.CdcCodeBranche, "CdcCodeBranche incorrect");
            Assert.AreEqual(formulaireCN2DI.CdcLigneDirecte, this.FormulaireCN2DI.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
            Assert.AreEqual(formulaireCN2DI.CdcNomPrenom, this.FormulaireCN2DI.CdcNomPrenom, "CdcNomPrenom incorrect");
            Assert.AreEqual(formulaireCN2DI.RegionCdc.Cle, this.FormulaireCN2DI.RegionCdc.Cle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireCN2DI.RegionCdc.Libelle, this.FormulaireCN2DI.RegionCdc.Libelle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireCN2DI.TypeFormulaireGbo, this.FormulaireCN2DI.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
            Assert.AreEqual(formulaireCN2DI.ReferenceExterne, this.FormulaireCN2DI.ReferenceExterne, "ReferenceExterne incorrect");
            Assert.AreEqual(formulaireCN2DI.NomClient, this.FormulaireCN2DI.NomClient, "NomClient incorrect");
            Assert.AreEqual(formulaireCN2DI.PrenomClient, this.FormulaireCN2DI.PrenomClient, "PrenomClient incorrect");
            Assert.AreEqual(formulaireCN2DI.NumeroCommandeClient, this.FormulaireCN2DI.NumeroCommandeClient, "NumeroCommandeClient incorrecte");
            Assert.AreEqual(formulaireCN2DI.MotifDysfonctionnement, this.FormulaireCN2DI.MotifDysfonctionnement, "MotifDysfonctionnement incorrect");
            Assert.AreEqual(formulaireCN2DI.OrigineDysfonctionnement, this.FormulaireCN2DI.OrigineDysfonctionnement, "OrigineDysfonctionnement incorrecte");
            Assert.AreEqual(formulaireCN2DI.DateApproxAppelServiceClient, this.FormulaireCN2DI.DateApproxAppelServiceClient, "DateApproxAppelServiceClient incorrecte");
            Assert.AreEqual(formulaireCN2DI.RaisonsDysfonctionnement, this.FormulaireCN2DI.RaisonsDysfonctionnement, "RaisonsDysfonctionnement incorrecte");
            Assert.AreEqual(formulaireCN2DI.DemandeClient, this.FormulaireCN2DI.DemandeClient, "DemandeClient incorrecte");
            Assert.AreEqual(formulaireCN2DI.SolutionsDejaApportees, this.FormulaireCN2DI.SolutionsDejaApportees, "SolutionsDejaApportees incorrecte");
        }

        #endregion Test ObtenirFormulaireCN2DiParCle

        #region Test CreerFormulaireCN2DI

        /// <summary>
        /// Creer FormulaireCN2DI avec objet null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_FormulaireCN2DINull_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireCN2DI(null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creer FormulaireCN2DI avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_ParametresValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireCN2DI(this.FormulaireCN2DI);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test CreerFormulaireCN2DI

        #endregion FormulaireCN2DI

        #region FormulaireCN3EQ

        #region Test ObtenirFormulaireCN3EqParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireCN3EqParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireCN3EqParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireCN3EqParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            FormulaireCN3EQ formulaireCN3EQ = repository.ObtenirFormulaireCN3EqParCle(this.FormulaireCN3EQ.Cle);

            // Assert
            Assert.AreEqual(formulaireCN3EQ.Cle, this.FormulaireCN3EQ.Cle, "Cle incorrecte");
            Assert.AreEqual(formulaireCN3EQ.CleDossierGbo, this.FormulaireCN3EQ.CleDossierGbo, "CleDossierGbo incorrecte");
            Assert.AreEqual(formulaireCN3EQ.CdcAdresseMail, this.FormulaireCN3EQ.CdcAdresseMail, "CdcAdresseMail incorrecte");
            Assert.AreEqual(formulaireCN3EQ.CdcCodeBanque, this.FormulaireCN3EQ.CdcCodeBanque, "CdcCodeBanque incorrect");
            Assert.AreEqual(formulaireCN3EQ.CdcCodeBranche, this.FormulaireCN3EQ.CdcCodeBranche, "CdcCodeBranche incorrect");
            Assert.AreEqual(formulaireCN3EQ.CdcLigneDirecte, this.FormulaireCN3EQ.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
            Assert.AreEqual(formulaireCN3EQ.CdcNomPrenom, this.FormulaireCN3EQ.CdcNomPrenom, "CdcNomPrenom incorrect");
            Assert.AreEqual(formulaireCN3EQ.RegionCdc.Cle, this.FormulaireCN3EQ.RegionCdc.Cle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireCN3EQ.RegionCdc.Libelle, this.FormulaireCN3EQ.RegionCdc.Libelle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireCN3EQ.TypeFormulaireGbo, this.FormulaireCN3EQ.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
            Assert.AreEqual(formulaireCN3EQ.NumeroSuiviDossier, this.FormulaireCN3EQ.NumeroSuiviDossier, "NumeroSuiviDossier incorrect");
            Assert.AreEqual(formulaireCN3EQ.DateReponseCelluleN2, this.FormulaireCN3EQ.DateReponseCelluleN2, "DateReponseCelluleN2 incorrect");
            Assert.AreEqual(formulaireCN3EQ.ReferenceExterne, this.FormulaireCN3EQ.ReferenceExterne, "ReferenceExterne incorrect");
            Assert.AreEqual(formulaireCN3EQ.NatureDemandeIntervention, this.FormulaireCN3EQ.NatureDemandeIntervention, "NatureDemandeIntervention incorrect");
            Assert.AreEqual(formulaireCN3EQ.RaisonContestation, this.FormulaireCN3EQ.RaisonContestation, "RaisonContestation incorrect");
            Assert.AreEqual(formulaireCN3EQ.DemandeClient, this.FormulaireCN3EQ.DemandeClient, "DemandeClient incorrect");
            Assert.AreEqual(formulaireCN3EQ.SolutionsDejaApportees, this.FormulaireCN3EQ.SolutionsDejaApportees, "SolutionsDejaApportees incorrect");
        }

        #endregion Test ObtenirFormulaireCN3EqParCle

        #region Test CreerFormulaireCN3EQ

        /// <summary>
        /// Creer FormulaireCN3EQ avec objet null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_FormulaireCN3EQNull_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireCN3EQ(null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creer FormulaireCN3EQ avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_ParametresValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireCN3EQ(this.FormulaireCN3EQ);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test CreerFormulaireCN3EQ

        #endregion FormulaireCN3EQ

        #region FormulaireMPS

        #region Test ObtenirFormulaireMpsParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireMpsParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireMpsParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireMpsParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireMpsParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireMpsParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            FormulaireMPS formulaireMPS = repository.ObtenirFormulaireMpsParCle(this.FormulaireMPS.Cle);

            // Assert
            Assert.AreEqual(formulaireMPS.Cle, this.FormulaireMPS.Cle, "Cle incorrecte");
            Assert.AreEqual(formulaireMPS.CleDossierGbo, this.FormulaireMPS.CleDossierGbo, "CleDossierGbo incorrecte");
            Assert.AreEqual(formulaireMPS.CdcAdresseMail, this.FormulaireMPS.CdcAdresseMail, "CdcAdresseMail incorrecte");
            Assert.AreEqual(formulaireMPS.CdcCodeBanque, this.FormulaireMPS.CdcCodeBanque, "CdcCodeBanque incorrect");
            Assert.AreEqual(formulaireMPS.CdcCodeBranche, this.FormulaireMPS.CdcCodeBranche, "CdcCodeBranche incorrect");
            Assert.AreEqual(formulaireMPS.CdcLigneDirecte, this.FormulaireMPS.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
            Assert.AreEqual(formulaireMPS.CdcNomPrenom, this.FormulaireMPS.CdcNomPrenom, "CdcNomPrenom incorrect");
            Assert.AreEqual(formulaireMPS.RegionCdc.Cle, this.FormulaireMPS.RegionCdc.Cle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireMPS.RegionCdc.Libelle, this.FormulaireMPS.RegionCdc.Libelle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireMPS.TypeFormulaireGbo, this.FormulaireMPS.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
            Assert.AreEqual(formulaireMPS.ReferenceExterne, this.FormulaireMPS.ReferenceExterne, "ReferenceExterne incorrect");
            Assert.AreEqual(formulaireMPS.NomClient, this.FormulaireMPS.NomClient, "NomClient incorrect");
            Assert.AreEqual(formulaireMPS.PrenomClient, this.FormulaireMPS.PrenomClient, "PrenomClient incorrect");
            Assert.AreEqual(formulaireMPS.DateEffetDemande, this.FormulaireMPS.DateEffetDemande, "DateEffetDemande incorrecte");
            Assert.AreEqual(formulaireMPS.ProfilSurconsoDemande, this.FormulaireMPS.ProfilSurconsoDemande, "ProfilSurconsoDemande incorrect");
            Assert.AreEqual(formulaireMPS.Commentaire, this.FormulaireMPS.Commentaire, "Commentaire incorrecte");
        }

        #endregion Test ObtenirFormulaireMpsParCle

        #region Test CreerFormulaireMps

        /// <summary>
        /// Creer FormulaireMPS avec objet null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_FormulaireMPSNull_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireMps(null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creer FormulaireMPS avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_ParametresValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireMps(this.FormulaireMPS);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test CreerFormulaireMps

        #endregion FormulaireMPS

        #region FormulaireRisqueResiliation

        #region Test ObtenirFormulaireRisqueResiliationParCle

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec une clé négative.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_CleNegative_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireRisqueResiliationParCle(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec une clé à zéro.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_CleZero_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirFormulaireRisqueResiliationParCle(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation avec une clé existante.
        /// </summary>
        /// <returns></returns>
        [Test]
        public void ObtenirFormulaireRisqueResiliationParCle_ParametresValides_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            FormulaireRisqueResiliation formulaireRisqueResiliation = repository.ObtenirFormulaireRisqueResiliationParCle(this.FormulaireRisqueResiliation.Cle);

            // Assert
            Assert.AreEqual(formulaireRisqueResiliation.Cle, this.FormulaireRisqueResiliation.Cle, "Cle incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.CleDossierGbo, this.FormulaireRisqueResiliation.CleDossierGbo, "CleDossierGbo incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.CdcAdresseMail, this.FormulaireRisqueResiliation.CdcAdresseMail, "CdcAdresseMail incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.CdcCodeBanque, this.FormulaireRisqueResiliation.CdcCodeBanque, "CdcCodeBanque incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.CdcCodeBranche, this.FormulaireRisqueResiliation.CdcCodeBranche, "CdcCodeBranche incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.CdcLigneDirecte, this.FormulaireRisqueResiliation.CdcLigneDirecte, "CdcLigneDirecte incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.CdcNomPrenom, this.FormulaireRisqueResiliation.CdcNomPrenom, "CdcNomPrenom incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.RegionCdc.Cle, this.FormulaireRisqueResiliation.RegionCdc.Cle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.RegionCdc.Libelle, this.FormulaireRisqueResiliation.RegionCdc.Libelle, "RegionCDC incorrecte");
            Assert.AreEqual(formulaireRisqueResiliation.TypeFormulaireGbo, this.FormulaireRisqueResiliation.TypeFormulaireGbo, "TypeFormulaireGbo incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.ReferenceExterne, this.FormulaireRisqueResiliation.ReferenceExterne, "ReferenceExterne incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.NomClient, this.FormulaireRisqueResiliation.NomClient, "NomClient incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.PrenomClient, this.FormulaireRisqueResiliation.PrenomClient, "PrenomClient incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.OffreClient, this.FormulaireRisqueResiliation.OffreClient, "OffreClient incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.MotifQualification, this.FormulaireRisqueResiliation.MotifQualification, "MotifQualification incorrect");
            Assert.AreEqual(formulaireRisqueResiliation.Commentaire, this.FormulaireRisqueResiliation.Commentaire, "Commentaire incorrect");
        }

        #endregion Test ObtenirFormulaireRisqueResiliationParCle

        #region Test CreerFormulaireRisqueResiliation

        /// <summary>
        /// Creer FormulaireRisqueResiliation avec objet null.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_FormulaireRisqueResiliationNull_LeveException()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireRisqueResiliation(null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creer FormulaireRisqueResiliation avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_ParametresValide_OK()
        {
            // Act
            IFormulaireGboRepository repository = new FormulaireGboRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.CreerFormulaireRisqueResiliation(this.FormulaireRisqueResiliation);

            // Assert
            Assert.That(action, Throws.Nothing);
        }

        #endregion Test CreerFormulaireRisqueResiliation

        #endregion FormulaireRisqueResiliation

        #endregion Méthodes - IFormulaireGboRepository - Formulaires
    }
}
