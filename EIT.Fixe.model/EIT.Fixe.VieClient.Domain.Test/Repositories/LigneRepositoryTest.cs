﻿using System;
using System.Collections.Generic;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.DataAccess;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repositorie ligne.
    /// </summary>
    [TestFixture]
    public class LigneRepositoryTest
    {
        private Identite identite;
        private DetailLignePourCreation parametre;
        private DateTime dateFinEngagement;

        private long cle;
        private string numero;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        private Mock<IRepositories> repositories;

        private Mock<IHistoriqueDossierGboLigneRepository> ligneHistoriqueDossierGboRepository;
        private Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository;

        private string numeroContratOperateurLigne3 = "012345";
        private string cleGestionnaireOptionsLigne3 = "e8017aea-9682-4817-b709-c5139a183e8f";


        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserBriqueServiceExterne();
            this.InitialiserRepositories();
            this.InitialiserServiceExterne();

            this.cle = 1;
            this.numero = "0123456789";

            this.dateFinEngagement = new DateTime(2020, 12, 1);
            this.parametre = new DetailLignePourCreation()
            {
                Cle = this.cle,
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                CleCommandeExpedition = 1,
                DateFinEngagement = this.dateFinEngagement,
                Numero = "0102030405",
                NumeroContratOperateur = "NumeroContratOperateur",
                ReferenceExterne = "refext",
                IdentifiantTransactionOperateur = 1,
                Rio = "rio",
                ListeDemandeRemisePourCreation = new List<DemandeRemisePourCreation>(),
                CleKitBox = 1
            };
        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<ServiceExterne.IParametrage> parametrage = new Mock<ServiceExterne.IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation du Repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.ligneHistoriqueDossierGboRepository = new Mock<IHistoriqueDossierGboLigneRepository>();
            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IBriqueGboServiceExterne> BriqueGboServiceExterne = new Mock<IBriqueGboServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.BriqueGboServiceExterne).Returns(BriqueGboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<ServiceExterne.IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<ServiceExterne.IHistoriqueServiceExterne>();
            Mock<ServiceExterne.IReferentielServiceExterne> referentielService = new Mock<ServiceExterne.IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            DetailLignePourCreation parametres1 = this.parametre;
            parametres1.Numero = "0102030405";
            Ligne entite1 = new Ligne(this.identite, parametres1, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            DetailLignePourCreation parametres2 = this.parametre;
            parametres2.Cle = 2;
            parametres2.CleIcn = 2;
            parametres2.Numero = "0203040506";
            parametres2.ReferenceExterne = "refext2";
            parametres2.CleGestionnaireOptions = "3248cf76-acb0-4d14-95a7-c752aa4e8e82";
            Ligne entite2 = new Ligne(this.identite, parametres2, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            DetailLignePourCreation parametres3 = this.parametre;
            parametres3.Cle = 3;
            parametres3.CleIcn = 3;
            parametres3.Numero = "0304050607";
            parametres3.ReferenceExterne = "refext3";
            parametres3.NumeroContratOperateur = this.numeroContratOperateurLigne3;
            parametres2.CleGestionnaireOptions = this.cleGestionnaireOptionsLigne3;
            Ligne entite3 = new Ligne(this.identite, parametres3, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            sourceDonnees.Add(entite1);
            sourceDonnees.Add(entite2);
            sourceDonnees.Add(entite3);
            return sourceDonnees;
        }


        /// <summary>
        /// Creation d'une datasource avec une ligne en plus.
        /// </summary>
        /// <param name="ligne">La ligne a ajouter.</param>
        private IDataSource CreerSourceDonnees(Ligne ligne)
        {
            IDataSource sourceDonnees = CreerSourceDonnees();
            sourceDonnees.Add(ligne);
            return sourceDonnees;
        }

        /// <summary>
        /// Creer une ligne.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private Ligne CreerLigne(long cle)
        {
            DetailLignePourCreation parametres = this.parametre;
            parametres.Cle = cle;
            parametres.Numero = "0405060708";
            Ligne ligne = new Ligne(this.identite, parametres, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            return ligne;
        }

        /// <summary>
        /// Creer un repository avec datasource null.
        /// </summary>
        [Test]
        public void CreerLigne_SourceDonneesNull_LeveException()
        {
            IDataSource dataSource = null;

            TestDelegate action = () => new LigneRepository(dataSource);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Ajouter une commande d'expedition avec la commande d'expedition null.
        /// </summary>
        [Test]
        public void Ajouter_CommandeExpeditionNull_OK()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            TestDelegate action = () => repository.AjouterLigne(null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Ajouter une commande d'expedition.
        /// </summary>
        [Test]
        public void Ajouter_ParametreValide_OK()
        {
            Ligne entite = this.CreerLigne(4);
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            repository.AjouterLigne(entite);

            Assert.That(sourceDonnees.Query<Ligne>(), Contains.Item(entite));
        }

        /// <summary>
        /// Obtient une ligne avec un numero null.
        /// </summary>
        [Test]
        public void ObtenirLigneParNumero_NumeroNull_LeveException()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirDepuisNumero(string.Empty);

            // Assert
            Assert.That(action, Throws.ArgumentException);
        }

        /// <summary>
        /// Obtient une ligne par numero.
        /// </summary>
        [Test]
        public void ObtenirLigneParNumero_ParametreValide_OK()
        {

            // Arrange
            long cle = 4;
            numero = "0102030405";

            //Act
            Ligne entite = this.CreerLigne(cle);
            IDataSource sourceDonnees = this.CreerSourceDonnees(entite);
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            Ligne entiteRetournee = repository.ObtenirDepuisNumero(numero);

            //Assert
            Assert.AreEqual(entiteRetournee.Numero, numero);
            Assert.AreEqual(entiteRetournee.Cle, cle);
            Assert.AreEqual(entiteRetournee.CleCompteFacturation, 1);
            Assert.AreEqual(entiteRetournee.CleAdresseInstallation, 1);
            Assert.AreEqual(entiteRetournee.CleGestionnaireOptions, "1");
            Assert.AreEqual(entiteRetournee.CleIcn, 1);
            Assert.AreEqual(entiteRetournee.CleMarque, 1);
            Assert.AreEqual(entiteRetournee.CleOffre, 1);
            Assert.AreEqual(entiteRetournee.CleTechnologie, 1);
            Assert.AreEqual(entiteRetournee.CleTiers, 1);
            Assert.AreEqual(entiteRetournee.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(entiteRetournee.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(entiteRetournee.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(entiteRetournee.ReferenceExterne, "refext");
            Assert.AreEqual(entiteRetournee.Rio, "rio");
            Assert.AreEqual(entiteRetournee.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(entiteRetournee.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Obtient une ligne avec une clé nulle.
        /// </summary>
        [Test]
        public void ObtenirLigneParCle_CleNulle_LeveException()
        {
            this.cle = 0;

            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirDepuisCle(this.cle);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Obtient une ligne avec une clé nulle.
        /// </summary>
        [Test]
        public void ObtenirLigneParCle_ParametresValides_OK()
        {

            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            Ligne ligne = repository.ObtenirDepuisCle(this.cle);

            // Assert
            Assert.AreEqual(ligne.Numero, "0102030405");
            Assert.AreEqual(ligne.Cle, this.cle);
            Assert.AreEqual(ligne.CleCompteFacturation, 1);
            Assert.AreEqual(ligne.CleAdresseInstallation, 1);
            Assert.AreEqual(ligne.CleGestionnaireOptions, "1");
            Assert.AreEqual(ligne.CleIcn, 1);
            Assert.AreEqual(ligne.CleMarque, 1);
            Assert.AreEqual(ligne.CleOffre, 1);
            Assert.AreEqual(ligne.CleTechnologie, 1);
            Assert.AreEqual(ligne.CleTiers, 1);
            Assert.AreEqual(ligne.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(ligne.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(ligne.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(ligne.ReferenceExterne, "refext");
            Assert.AreEqual(ligne.Rio, "rio");
            Assert.AreEqual(ligne.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(ligne.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Test de ObtenirReferenceExterneParCleLigne avec une clé nulle.
        /// </summary>
        [Test]
        public void ObtenirReferenceExterneParCleLigne_CleNulle_LeveException()
        {
            this.cle = 0;

            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.ObtenirReferenceExterneDepuisCle(this.cle);

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de ObtenirReferenceExterneParCleLigne avec des parametres valides.
        /// </summary>
        [Test]
        public void ObtenirReferenceExterneParCleLigne_ParametresValides_OK()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            string referenceExterne = repository.ObtenirReferenceExterneDepuisCle(this.cle);

            //Assert
            Assert.AreEqual(referenceExterne, "refext");
        }

        /// <summary>
        /// Obtient une ligne inexistant par numero.
        /// </summary>
        [Test]
        public void ObtenirLigneParNumero_ParametreValide_Inexistant()
        {
            //Act
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            TestDelegate action = () => repository.ObtenirDepuisNumero("0102030406");

            //Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Recherche une ligne avec le numero vide.
        /// </summary>
        [Test]
        public void RechercherDepuisNumero_NumeroVide_LeveException()
        {
            //Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            TestDelegate action = () => repository.RechercherParNumero(string.Empty);

            //Assert
            Assert.That(action, Throws.ArgumentException);
        }


        /// <summary>
        /// Recherche une ligne par numero.
        /// </summary>
        [Test]
        public void RechercherDepuisNumero_ParametreValide_OK()
        {
            // Arrange
            long cle = 1;

            //Act
            Ligne entite = this.CreerLigne(cle);
            IDataSource sourceDonnees = this.CreerSourceDonnees(entite);
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            Ligne entiteRetournee = repository.RechercherParNumero("0405060708");

            //Assert
            Assert.AreEqual(entiteRetournee.Numero, entite.Numero);
            Assert.AreEqual(entiteRetournee.Cle, this.cle);
            Assert.AreEqual(entiteRetournee.CleCompteFacturation, 1);
            Assert.AreEqual(entiteRetournee.CleAdresseInstallation, 1);
            Assert.AreEqual(entiteRetournee.CleGestionnaireOptions,"1");
            Assert.AreEqual(entiteRetournee.CleIcn, 1);
            Assert.AreEqual(entiteRetournee.CleMarque, 1);
            Assert.AreEqual(entiteRetournee.CleOffre, 1);
            Assert.AreEqual(entiteRetournee.CleTechnologie, 1);
            Assert.AreEqual(entiteRetournee.CleTiers, 1);
            Assert.AreEqual(entiteRetournee.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(entiteRetournee.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(entiteRetournee.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(entiteRetournee.ReferenceExterne, "refext");
            Assert.AreEqual(entiteRetournee.Rio, "rio");
            Assert.AreEqual(entiteRetournee.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(entiteRetournee.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Recherche une ligne inexistant par numero.
        /// </summary>
        [Test]
        public void RechercherDepuisNumero_ParametreValide_Inexistant()
        {
            //Act
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            Ligne entiteRetournee = repository.RechercherParNumero("0102030406");

            //Assert
            Assert.IsNull(entiteRetournee);
        }


        /// <summary>
        /// Obtient une ligne avec le numero contrat vide.
        /// </summary>
        [Test]
        public void RechercherDepuisNumeroContrat_NumeroVide_LeveException()
        {
            // Arrange.
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            // Act.
            TestDelegate action = () => repository.ObtenirDepuisNumeroContrat(string.Empty);

            // Assert.
            Assert.That(action, Throws.ArgumentException);
        }


        /// <summary>
        /// Obtient une ligne par numero contrat.
        /// </summary>
        [Test]
        public void RechercherDepuisNumeroContrat_ParametreValide_OK()
        {
            // Arrange.
            long cle = 1;

            // Act.
            Ligne entite = this.CreerLigne(cle);
            IDataSource sourceDonnees = this.CreerSourceDonnees(entite);
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            Ligne entiteRetournee = repository.ObtenirDepuisNumeroContrat(this.numeroContratOperateurLigne3);

            // Assert.
            Assert.AreEqual(entiteRetournee.CleCompteFacturation, 1);
            Assert.AreEqual(entiteRetournee.CleAdresseInstallation, 1);
            Assert.AreEqual(entiteRetournee.CleGestionnaireOptions, this.cleGestionnaireOptionsLigne3);
            Assert.AreEqual(entiteRetournee.CleIcn, 3);
            Assert.AreEqual(entiteRetournee.CleMarque, 1);
            Assert.AreEqual(entiteRetournee.CleOffre, 1);
            Assert.AreEqual(entiteRetournee.CleTechnologie, 1);
            Assert.AreEqual(entiteRetournee.CleTiers, 1);
            Assert.AreEqual(entiteRetournee.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(entiteRetournee.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(entiteRetournee.NumeroContratOperateur, this.numeroContratOperateurLigne3);
            Assert.AreEqual(entiteRetournee.ReferenceExterne, "refext3");
            Assert.AreEqual(entiteRetournee.Rio, "rio");
            Assert.AreEqual(entiteRetournee.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(entiteRetournee.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Obtient une ligne inexistant par numero contrat.
        /// </summary>
        [Test]
        public void RechercherDepuisNumeroContrat_ParametreValide_Inexistant()
        {
            // Arrange.
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ILigneRepository repository = new LigneRepository(sourceDonnees);

            // Act.
            TestDelegate action = () => repository.ObtenirDepuisNumeroContrat("0102030406");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Obtenir ligne par reference externe avec la reference externe vide.
        /// </summary>
        [Test]
        public void ObtenirLigneParRefernceExterne_ReferenceExterneVide_LeveException()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            TestDelegate action = () => repository.ObtenirDepuisReferenceExterne(string.Empty);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Obtenir ligne par reference externe.
        /// </summary>
        [Test]
        public void ObtenirLigneParRefernceExterne_ParametreValide_OK()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            Ligne ligne = repository.ObtenirDepuisReferenceExterne("refext");

            Assert.IsNotNull(ligne);
            Assert.AreEqual(ligne.Numero, "0102030405");
            Assert.AreEqual(ligne.Cle, this.cle);
            Assert.AreEqual(ligne.CleCompteFacturation, 1);
            Assert.AreEqual(ligne.CleAdresseInstallation, 1);
            Assert.AreEqual(ligne.CleGestionnaireOptions, "1");
            Assert.AreEqual(ligne.CleIcn, 1);
            Assert.AreEqual(ligne.CleMarque, 1);
            Assert.AreEqual(ligne.CleOffre, 1);
            Assert.AreEqual(ligne.CleTechnologie, 1);
            Assert.AreEqual(ligne.CleTiers, 1);
            Assert.AreEqual(ligne.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(ligne.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(ligne.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(ligne.ReferenceExterne, "refext");
            Assert.AreEqual(ligne.Rio, "rio");
            Assert.AreEqual(ligne.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(ligne.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Obtenir ligne par reference externe inexistant.
        /// </summary>
        [Test]
        public void ObtenirLigneParReferenceExterne_ParametreValide_Inexistant()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            TestDelegate action = () => repository.ObtenirDepuisReferenceExterne("0102030406");

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        ///  Obtenir Numero Par Cle.
        /// </summary>
        [Test]
        public void ObtenirNumeroParCle_ParametreValide_OK()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            string numero = repository.ObtenirNumeroDepuisCle(1);

            Assert.AreEqual(numero, "0102030405");
        }

        /// <summary>
        ///  Obtenir Numero Par Cle inexistant.
        /// </summary>
        [Test]
        public void ObtenirNumeroParCle_ParametreValide_Inexixtant()
        {
            IDataSource sourceDonnees = this.CreerSourceDonnees();

            ILigneRepository repository = new LigneRepository(sourceDonnees);

            string numero = repository.ObtenirNumeroDepuisCle(5);

            Assert.IsNull(numero);
        }

        /// <summary>
        /// RechercherLigneParCleIcn avec une clé ICN nulle.
        /// </summary>
        [Test]
        public void RechercherLigneParCleIcn_CleIcnNulle_LeveException()
        {
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());
            
            // Act
            TestDelegate action = () => repository.RechercherParCleIcn(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// RechercherLigneParCleIcn avec une clé ICN negatif.
        /// </summary>
        [Test]
        public void RechercherLigneParCleIcn_CleIcnNegatif_LeveException()
        {
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            // Act
            TestDelegate action = () => repository.RechercherParCleIcn(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ObtenirLigneParCleIcn.
        /// </summary>
        [Test]
        public void RechercherLigneParCleIcn_ParametreValide_Ok()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            Ligne ligne = repository.RechercherParCleIcn(1);

            // Assert
            Assert.AreEqual(ligne.Numero, "0102030405");
            Assert.AreEqual(ligne.Cle, this.cle);
            Assert.AreEqual(ligne.CleCompteFacturation, 1);
            Assert.AreEqual(ligne.CleAdresseInstallation, 1);
            Assert.AreEqual(ligne.CleGestionnaireOptions, "1");
            Assert.AreEqual(ligne.CleIcn, 1);
            Assert.AreEqual(ligne.CleMarque, 1);
            Assert.AreEqual(ligne.CleOffre, 1);
            Assert.AreEqual(ligne.CleTechnologie, 1);
            Assert.AreEqual(ligne.CleTiers, 1);
            Assert.AreEqual(ligne.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(ligne.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(ligne.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(ligne.ReferenceExterne, "refext");
            Assert.AreEqual(ligne.Rio, "rio");
            Assert.AreEqual(ligne.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(ligne.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// ObtenirLigneParCleIcn.
        /// </summary>
        [Test]
        public void RechercherLigneParCleIcn_Inexistant_Ok()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            Ligne ligne = repository.RechercherParCleIcn(5);

            // Assert
            Assert.IsNull(ligne);
        }

        /// <summary>
        /// RechercherLigneParCleTiers avec une clé ICN nulle.
        /// </summary>
        [Test]
        public void RechercherLigneParCleTiers_CleTiersNulle_LeveException()
        {
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            // Act
            TestDelegate action = () => repository.RechercherParCleTiers(0);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// RechercherLigneParCleIcn avec une clé tiers negatif.
        /// </summary>
        [Test]
        public void RechercherLigneParCleTiers_CleTiersNegatif_LeveException()
        {
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            // Act
            TestDelegate action = () => repository.RechercherParCleTiers(-1);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// RechercherLigneParCleTiers.
        /// </summary>
        [Test]
        public void RechercherLigneParCleTiers_ParametreValide_Ok()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            Ligne ligne = repository.RechercherParCleTiers(1);

            // Assert
            Assert.AreEqual(ligne.Numero, "0102030405");
            Assert.AreEqual(ligne.Cle, this.cle);
            Assert.AreEqual(ligne.CleCompteFacturation, 1);
            Assert.AreEqual(ligne.CleAdresseInstallation, 1);
            Assert.AreEqual(ligne.CleGestionnaireOptions, "1");
            Assert.AreEqual(ligne.CleIcn, 1);
            Assert.AreEqual(ligne.CleMarque, 1);
            Assert.AreEqual(ligne.CleOffre, 1);
            Assert.AreEqual(ligne.CleTechnologie, 1);
            Assert.AreEqual(ligne.CleTiers, 1);
            Assert.AreEqual(ligne.DateFinEngagement, this.dateFinEngagement);
            Assert.AreEqual(ligne.IdentifiantTransactionOperateur, 1);
            Assert.AreEqual(ligne.NumeroContratOperateur, "NumeroContratOperateur");
            Assert.AreEqual(ligne.ReferenceExterne, "refext");
            Assert.AreEqual(ligne.Rio, "rio");
            Assert.AreEqual(ligne.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
            Assert.AreEqual(ligne.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// RechercherLigneParCleTiers.
        /// </summary>
        [Test]
        public void RechercherLigneParCleTiers_Inexistant_Ok()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            Ligne ligne = repository.RechercherParCleTiers(5);

            // Assert
            Assert.IsNull(ligne);
        }

        /// <summary>
        /// Récupération de la ligne depuis une clé de gestionnaire d'options.
        /// </summary>
        [Test]
        public void ObtenirDepuisCleGestionnaireOptions_LigneExiste_Ok()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            var cleGestionnaireExistante = "e8017aea-9682-4817-b709-c5139a183e8f";
            Ligne ligne = null;

            // Assert
            Assert.DoesNotThrow(() => ligne = repository.ObtenirDepuisCleGestionnaireOptions(cleGestionnaireExistante));
            Assert.IsNotNull(ligne);
        }

        /// <summary>
        /// Récupération de la ligne depuis une clé de gestionnaire d'options.
        /// </summary>
        [Test]
        public void ObtenirDepuisCleGestionnaireOptions_LigneExiste_Ko()
        {
            // Act
            ILigneRepository repository = new LigneRepository(this.CreerSourceDonnees());

            var cleGestionnaireInexistante = "clé-Bidon";
            Ligne ligne = null;

            // Assert
            Assert.Throws<InvalidOperationException>(() => ligne = repository.ObtenirDepuisCleGestionnaireOptions(cleGestionnaireInexistante));
            Assert.IsNull(ligne);
        }
    }
}