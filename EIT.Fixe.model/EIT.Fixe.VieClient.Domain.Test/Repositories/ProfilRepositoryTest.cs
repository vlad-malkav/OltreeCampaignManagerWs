﻿using EIT.DataAccess;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Repositories;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Repositories
{
    /// <summary>
    /// Classe de test du repository Profil.
    /// </summary>
    [TestFixture]
    public class ProfilRepositoryTest
    {
        #region Propriétés

        private Identite identite;

        private long cle;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IRepositories> repositories;
        private Mock<IBriquesServicesExternes> briquesExternes;

        #endregion Propriétés

        #region Initialisateur

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            identite = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialisterServicesExternes();
            this.InitialiserRepositories();
            this.InitialiserBriquesExternes();

            this.cle = 50;

        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation des services externes.
        /// </summary>
        private void InitialisterServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialisation des repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
        }

        /// <summary>
        /// Initialisation des briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Creation d'une datasource.
        /// </summary>
        private IDataSource CreerSourceDonnees()
        {
            IDataSource sourceDonnees = new DataSource();

            ParametreProfilPtfPourCreation parametreProfilPtfPourCreation = new ParametreProfilPtfPourCreation()
            {
                Cle = 1,
                Code = "code",
                Description = "description",
                EstActif = false,
                Libelle = "libelle",
                RessourceSas = "ressourcesas",
                SuiviDateCreation = DateTime.Today
            };

            ProfilPtf profilPtf1 = new ProfilPtf(identite, parametreProfilPtfPourCreation, null);

            sourceDonnees.Add(profilPtf1);

            return sourceDonnees;
        }
        
        /// <summary>
        /// Creer une ligne.
        /// </summary>
        /// <param name="cle">La cle.</param>
        private ProfilPtf CreerProfilPtf(long cle, string ressourceSas = "ressourcesas")
        {
            ParametreProfilPtfPourCreation parametreProfilPtfPourCreation = new ParametreProfilPtfPourCreation()
            {
                Cle = cle,
                Code = "code",
                Description = "description",
                EstActif = true,
                Libelle = "libelle",
                RessourceSas = ressourceSas,
                SuiviDateCreation = DateTime.Today
            };

            ProfilPtf profilPtf = new ProfilPtf(identite, parametreProfilPtfPourCreation, null);

            return profilPtf;
        }

        #endregion Initialisateur

        #region Test de la méthode RechercherProfilActifDepuisRessourceSas

        /// <summary>
        /// Test de la méthode RechercherProfilActifDepuisRessourceSas avec une ressource sas vide. Lève une exception.
        /// </summary>
        [Test]
        public void RechercherProfilActifDepuisRessourceSas_RessourceSas_LeveException()
        {
            // Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            sourceDonnees.Add(entite);
            ProfilRepository repository = new ProfilRepository(sourceDonnees);

            // Act.
            TestDelegate action = () => repository.RechercherProfilActifDepuisRessourceSas("");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode RechercherProfilActifDepuisRessourceSas avec les paramètres valide.
        /// </summary>
        [Test]
        public void RechercherProfilActifDepuisRessourceSas_ParametreValide_OK()
        {
            // Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            sourceDonnees.Add(entite);
            ProfilRepository repository = new ProfilRepository(sourceDonnees);

            // Act.
            ProfilPtf entiteObtenue = repository.RechercherProfilActifDepuisRessourceSas(ressourceSas);

            // Assert.
            Assert.AreEqual(entite.Cle, entiteObtenue.Cle);
            Assert.AreEqual(entite.Code, entiteObtenue.Code);
            Assert.AreEqual(entite.Description, entiteObtenue.Description);
            Assert.AreEqual(entite.EstActif, entiteObtenue.EstActif);
            Assert.AreEqual(entite.Libelle, entiteObtenue.Libelle);
            Assert.AreEqual(entite.ListeGroupesFonctionnalites, entiteObtenue.ListeGroupesFonctionnalites);
            Assert.AreEqual(entite.RessourceSas, entiteObtenue.RessourceSas);
            Assert.AreEqual(entite.SuiviAgentCreation, entiteObtenue.SuiviAgentCreation);
            Assert.AreEqual(entite.SuiviAgentModification, entiteObtenue.SuiviAgentModification);
            Assert.AreEqual(entite.SuiviDateCreation, entiteObtenue.SuiviDateCreation);
            Assert.AreEqual(entite.SuiviDateModification, entiteObtenue.SuiviDateModification);
        }

        #endregion Test de la méthode RechercherProfilActifDepuisRessourceSas

        #region Test de la méthode Ajouter

        /// <summary>
        /// Test de la méthode AJouter avec les paramètre OK.
        /// </summary>
        [Test]
        public void Ajouter_ParametreOK_OK()
        {
            //Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ProfilRepository repository = new ProfilRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(entite);
            //Assert.
            Assert.That(action, Throws.Nothing);
        }

        /// <summary>
        /// Test de la méthode Ajouter avec le profil null. Exception levée.
        /// </summary>
        [Test]
        public void Ajouter_ProfilNull_ExceptionLevee()
        {
            //Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ProfilRepository repository = new ProfilRepository(sourceDonnees);
            //Act.
            TestDelegate action = () => repository.Ajouter(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode Ajouter

        #region Test de la méthode ListerProfilsActifs

        /// <summary>
        /// Test de la méthode ListerProfilsActifs OK.
        /// </summary>
        [Test]
        public void ListerProfilsActifs_ParametreOK_OK()
        {
            //Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            entite.EstActif = true;
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ProfilRepository repository = new ProfilRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            ProfilPtf[] profils = repository.ListerProfilsActifs();
            //Assert.
            Assert.AreEqual(profils[0], entite);
        }

        #endregion Test de la méthode ListerProfilsActifs

        #region Test de la méthode ListerDatesSuiviCreation

        /// <summary>
        /// Test de la méthode ListerDatesSuiviCreation OK.
        /// </summary>
        [Test]
        public void ListerDatesSuiviCreation_ParametreOK_OK()
        {
            //Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            entite.EstActif = true;
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ProfilRepository repository = new ProfilRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            DateTime[] dates = repository.ListerDatesSuiviCreation();
            //Assert.
            Assert.AreEqual(dates[0], entite.SuiviDateCreation);
        }

        #endregion Test de la méthode ListerDatesSuiviCreation

        #region Test de la méthode SupprimerDepuisDate

        public void SupprimerDepuisDate_ParametreOK_OK()
        {
            //Arrange.
            string ressourceSas = "ressourceSas";
            ProfilPtf entite = this.CreerProfilPtf(cle, ressourceSas);
            entite.EstActif = true;
            IDataSource sourceDonnees = this.CreerSourceDonnees();
            ProfilRepository repository = new ProfilRepository(sourceDonnees);
            repository.Ajouter(entite);
            //Act.
            repository.SupprimerDepuisDate(entite.SuiviDateCreation);
            DateTime[] dates = repository.ListerDatesSuiviCreation();
            //Assert.
            Assert.AreEqual(dates.Length, 0);
        }

        #endregion Test de la méthode SupprimerDepuisDate
    }
}
