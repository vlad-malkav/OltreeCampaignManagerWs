﻿using System;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Entities;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet métier EquipementLigne.
    /// </summary>
    [TestFixture]
    public class EquipementLigneTest
    {
        #region Propriétés 

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private Mock<IServicesTechniques> servicesTechniques { get; set; }

        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Retourne une clé d'équipement ligne valide.
        /// </summary>
        private long CleEquipementLigneValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de ligne valide.
        /// </summary>
        private long CleLigneValide
        {
            get
            {
                return 10;
            }
        }

        /// <summary>
        /// Retourne une clé d'équipement valide.
        /// </summary>
        private long CleEquipementValide
        {
            get
            {
                return 100;
            }
        }

        /// <summary>
        /// Retourne un code ref com valide.
        /// </summary>
        private string CodeRefComValide
        {
            get
            {
                return "CodeRefCom";
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identiteValide = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserRepositories();
        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();
        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.servicesTechniques = new Mock<IServicesTechniques>();
            this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
            this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        #endregion Méthodes d'initialisation et de vérification

        #region Tests de l'initialisation de l'objet

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où l'identité est null. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_IdentiteNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(null, this.CleEquipementLigneValide, new Mock<Ligne>().Object, this.CleEquipementValide, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où la clé équipement de ligne est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CleEquipementLigneAZero_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, 0, new Mock<Ligne>().Object, this.CleEquipementValide, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où la clé équipement de ligne est négative. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CleEquipementLigneNegative_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, -400, new Mock<Ligne>().Object, this.CleEquipementValide, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où la ligne est null. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CleLigneNegative_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, null, this.CleEquipementValide, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où la clé équipement est à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CleEquipementAZero_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, new Mock<Ligne>().Object, 0, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où la clé équipement est négative. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CleEquipementNegative_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, new Mock<Ligne>().Object, -400, this.CodeRefComValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où le code ref com est vide. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CodeRefComVide_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, new Mock<Ligne>().Object, this.CleEquipementValide, "");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où le code ref com est à null. Lève une exception.
        /// </summary>
        [Test]
        public void EquipementLigne_CodeRefComNull_LeveException()
        {
            // Act.
            TestDelegate action = () => new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, new Mock<Ligne>().Object, this.CleEquipementValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur de EquipementLigne dans le cas où les paramètres sont OK.
        /// </summary>
        [Test]
        public void EquipementLigne_ParametresOK_OK()
        {
            // Arrange & Act.
            EquipementLigne equipementLigne = new EquipementLigne(this.identiteValide, this.CleEquipementLigneValide, new Mock<Ligne>().Object, this.CleEquipementValide, this.CodeRefComValide);

            // Assert.
            Assert.AreEqual(this.CleEquipementLigneValide, equipementLigne.Cle);
            Assert.AreEqual(this.CleEquipementValide, equipementLigne.CleEquipement);
            //Assert.AreEqual(this.CleLigneValide, equipementLigne.Ligne);
            Assert.AreEqual(this.CodeRefComValide, equipementLigne.CodeRefCom);
            Assert.AreEqual(this.identiteValide.Memoid, equipementLigne.SuiviAgentCreation);
        }

        #endregion Tests de l'initialisation de l'objet
    }
}
