﻿using EIT.Fixe.Systeme.Identification;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test d'une demande de remise a l'état NA.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemiseForfaitTest
    {
        private DemandeRemiseForfait demande;

        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialisationEtatNA()
        {
            this.identite = new Identite() { Memoid = "test" };

            this.parametre = new DemandeRemiseForfaitPourCreation()
            {
                MontantHT = 1
            };

            this.InitialiserServiceTechnique();

            this.demande = new DemandeRemiseForfait(this.identite, 1, this.parametre, true, this.serviceTechnique.Object);
        }

        /// <summary>
        /// Expirer.
        /// </summary>
        [Test]
        public void NA_VersExpirer_LeveException()
        {
            this.InitialisationEtatNA();

            TestDelegate action = () => this.demande.Expirer(this.identite);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Résilier avec une demande non automatique.
        /// </summary>
        [Test]
        public void NA_VersResilier_LeveException()
        {
            this.InitialisationEtatNA();

            TestDelegate action = () => this.demande.Resilier(this.identite, this.cleOffre);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Est activé.
        /// </summary>
        [Test]
        public void NAEstActive_ParametreValide_OK()
        {
            this.InitialisationEtatNA();

            Assert.IsTrue(this.demande.EstActive());
        }
        
        /// <summary>
        /// Est obsolète.
        /// </summary>
        [Test]
        public void NAEstObsolete_ParametreValide_False()
        {
            this.InitialisationEtatNA();

            Assert.IsFalse(this.demande.EstObsolete());
        }
    }
}
