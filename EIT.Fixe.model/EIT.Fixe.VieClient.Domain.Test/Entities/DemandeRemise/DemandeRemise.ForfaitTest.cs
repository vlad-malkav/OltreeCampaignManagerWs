﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test des demande de remise par forfait.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemiseForfaitTest
    {
        private Identite identite;
        private Mock<IServicesTechniques> serviceTechnique;
        private DemandeRemiseForfaitPourCreation parametre;
        private int cleOffre;

        /// <summary>
        /// initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite(){ Memoid = "test" };

            this.parametre = new DemandeRemiseForfaitPourCreation()
            {
                MontantHT = 1
            };

            this.InitialiserServiceTechnique();

            this.cleOffre = 1234;
        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Créer une demande de remise forfait avec l'identité null.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemiseForfait(null, 1, this.parametre, true, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait avec la clé null.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_CleNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemiseForfait(this.identite, 0, this.parametre, true, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait avec la clé negatif.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_CleNegatif_LeveException()
        {
            TestDelegate action = () => new DemandeRemiseForfait(this.identite, -1, this.parametre, true, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait avec les paramètres null.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_ParametreNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemiseForfait(this.identite, 1, null, true, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait avec le service technique null.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemiseForfait(this.identite, 1, this.parametre, true, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait.
        /// </summary>
        [Test]
        public void CreerDemandeRemiseForfait_ParametresValides_OK()
        {
            DemandeRemiseForfait demande = new DemandeRemiseForfait(this.identite, 1, this.parametre, true, this.serviceTechnique.Object);

            Assert.AreEqual(demande.Cle, 1);
            Assert.AreEqual(demande.EstSurParc, true);
            Assert.AreEqual(demande.MontantHT, this.parametre.MontantHT);
            Assert.AreEqual(demande.TypeDemandeRemise, TypeDemandeRemise.RemiseSurForfait);
            Assert.IsNull(demande.DureeValidite);
            Assert.AreEqual(demande.SuiviAgentCreation, this.identite.Memoid);
            Assert.AreEqual(demande.SuiviAgentModification, this.identite.Memoid);
        }

        /// <summary>
        /// Est activé.
        /// </summary>
        [Test]
        public void EstActive_ParametreValide_OK()
        {
            DemandeRemiseForfait demande = new DemandeRemiseForfait(this.identite, 1, this.parametre, true, this.serviceTechnique.Object);

            Assert.IsTrue(demande.EstActive());
        }
    }
}
