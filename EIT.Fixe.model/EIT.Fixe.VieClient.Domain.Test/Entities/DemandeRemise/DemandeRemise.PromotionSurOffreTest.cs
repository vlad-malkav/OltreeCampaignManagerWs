﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test des demande de remise par promotion sur offre.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemisePromotionSurOffreTest
    {
        private Identite identite;
        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private PromotionPourDetail parametre;
        private int cleOffre;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite(){ Memoid = "test" };

            this.parametre = new PromotionPourDetail()
            {
                Cle = 1,
                MontantHT = 1,
                Duree = 5
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();

            this.cleOffre = 1234;
        }

        /// <summary>
        /// Initialisation du ServiceTechniques.
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec l'identité null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(null, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec la clé null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_CleNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(this.identite, 0, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec la clé negatif.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_CleNegatif_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(this.identite, -1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec les paramètres null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_ParametreNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(this.identite, 1, null, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec le service technique null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, null, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur offre avec le service technique null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_ServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait promotion sur offre.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurOffre_ParametresValides_OK()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.AreEqual(demande.Cle, 1);
            Assert.AreEqual(demande.ClePromotion(), this.parametre.Cle);
            Assert.AreEqual(demande.EstSurParc, true);
            Assert.AreEqual(demande.MontantHT, this.parametre.MontantHT);
            Assert.AreEqual(demande.TypeDemandeRemise, TypeDemandeRemise.RemisePromotionSurOffre);
            Assert.AreEqual(demande.DureeValidite, this.parametre.Duree);
            Assert.AreEqual(demande.SuiviAgentCreation, this.identite.Memoid);
            Assert.AreEqual(demande.SuiviAgentModification, this.identite.Memoid);
            Assert.AreEqual(demande.ValeurEtat, EtatDemandeRemise.Activee);
            Assert.AreEqual(demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Activee);
        }

        /// <summary>
        /// Expirer avec l'identité null.
        /// </summary>
        [Test]
        public void Expirer_IdentiteNull_LeveException()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            TestDelegate action = () => demande.Expirer(null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Est automatique.
        /// </summary>
        [Test]
        public void EstAutomatique_ParametreValide_OK()
        {
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                EstAutomatique = false
            });

            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.IsFalse(demande.EstAutomatique(this.identite, this.cleOffre));
        }

        /// <summary>
        /// Est automatique avec identité null, exception levée.
        /// </summary>
        [Test]
        public void EstAutomatique_IdentiteNull_LeveException()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            TestDelegate action = () => demande.EstAutomatique(null, this.cleOffre);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Est automatique avec la clé offre null, exception levée.
        /// </summary>
        [Test]
        public void EstAutomatique_CleOffreNull_LeveException()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            TestDelegate action = () => demande.EstAutomatique(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Est résiliable.
        /// </summary>
        [Test]
        public void EstResiliable_ParametreValide_OK()
        {
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                EstAutomatique = false
            });

            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.AreEqual(demande.EstResiliable(this.identite, this.cleOffre), !demande.EstAutomatique(this.identite, this.cleOffre));
        }

        /// <summary>
        /// Est résiliable avec identité null, exception levée.
        /// </summary>
        [Test]
        public void EstResiliable_IdentiteNull_LeveException()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            TestDelegate action = () => demande.EstResiliable(null, this.cleOffre);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Est résiliable avec la clé offre null, exception levée.
        /// </summary>
        [Test]
        public void EstResiliable_CleOffreNull_LeveException()
        {
            DemandeRemisePromotionSurOffre demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            TestDelegate action = () => demande.EstResiliable(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }
    }
}
