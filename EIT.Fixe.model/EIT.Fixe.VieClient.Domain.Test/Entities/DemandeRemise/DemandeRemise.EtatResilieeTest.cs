﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using Moq;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test d'une demande de remise a l'état resiliée.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemisePromotionSurOffreTest
    {
        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialisationEtatResiliee()
        {
            this.identite = new Identite() { Memoid = "test" };

            this.parametre = new PromotionPourDetail()
            {
                Cle = 1,
                MontantHT = 1,
                Duree = 5
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();

            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                EstAutomatique = false
            });

            this.demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);
            this.demande.Resilier(this.identite, this.cleOffre);
        }

        /// <summary>
        /// Expirer.
        /// </summary>
        [Test]
        public void Resilier_VersExpiree_LeveException()
        {
            this.InitialisationEtatResiliee();

            TestDelegate action = () => this.demande.Expirer(this.identite);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Resilier.
        /// </summary>
        [Test]
        public void Resilier_VersResiliee_LeveException()
        {
            this.InitialisationEtatResiliee();

            TestDelegate action = () => this.demande.Resilier(this.identite, this.cleOffre);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Est activé.
        /// </summary>
        [Test]
        public void ResilierEstActive_ParametreValide_OK()
        {
            this.InitialisationEtatResiliee();

            Assert.IsFalse(this.demande.EstActive());
        }

        /// <summary>
        /// Est obsolète.
        /// </summary>
        [Test]
        public void ResilierEstObsolete_ParametreValide_OK()
        {
            this.InitialisationEtatResiliee();

            Assert.IsTrue(this.demande.EstObsolete());
        }
    }
}
