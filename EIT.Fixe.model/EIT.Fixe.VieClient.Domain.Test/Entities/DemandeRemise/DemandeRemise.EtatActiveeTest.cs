﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using Moq;
using NUnit.Framework;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test d'une demande de remise a l'état activée.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemisePromotionSurOffreTest
    {
        private DemandeRemisePromotionSurOffre demande;

        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialisationEtatActivee()
        {
            this.identite = new Identite() { Memoid = "test" };

            this.parametre = new PromotionPourDetail()
            {
                Cle = 1,
                MontantHT = 1,
                Duree = 5
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();

            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                EstAutomatique = false
            });

            this.demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);
        }

        /// <summary>
        /// Expirer.
        /// </summary>
        [Test]
        public void Activee_VersExpirer_OK()
        {
            this.InitialisationEtatActivee();

            this.demande.Expirer(this.identite);

            Assert.AreEqual(this.demande.ValeurEtat, EtatDemandeRemise.Expiree);
            Assert.AreEqual(this.demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Expiree);
        }

        /// <summary>
        /// Résilier avec une demande non automatique.
        /// </summary>
        [Test]
        public void Activee_VersResilier_OK()
        {
            this.InitialisationEtatActivee();

            this.demande.Resilier(this.identite, this.cleOffre);

            Assert.AreEqual(this.demande.ValeurEtat, EtatDemandeRemise.Resiliee);
            Assert.AreEqual(this.demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Resiliee);
        }

        /// <summary>
        /// Résilier avec une demande automatique.
        /// </summary>
        [Test]
        public void Activee_VersResilier_LeveException()
        {
            this.InitialisationEtatActivee();
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                EstAutomatique = true
            });

            TestDelegate action = () => this.demande.Resilier(this.identite, this.cleOffre);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Résilier avec l'identité null, lève une exception.
        /// </summary>
        [Test]
        public void Activee_IdentiteNull_LeveException()
        {
            this.InitialisationEtatActivee();

            TestDelegate action = () => this.demande.Resilier(null, this.cleOffre);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Résilier avec la clé offre null, lève une exception.
        /// </summary>
        [Test]
        public void Activee_CleOffreNull_LeveException()
        {
            this.InitialisationEtatActivee();

            TestDelegate action = () => this.demande.Resilier(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Est activé.
        /// </summary>
        [Test]
        public void ActiveeEstActive_ParametreValide_OK()
        {
            this.InitialisationEtatActivee();

            Assert.IsTrue(this.demande.EstActive());
        }

        /// <summary>
        /// Est obsolète.
        /// </summary>
        [Test]
        public void ActiveeEstObsolete_ParametreValide_OK()
        {
            this.InitialisationEtatActivee();

            Assert.IsFalse(this.demande.EstObsolete());
        }
    }
}
