﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test des demande de remise par promotion sur frais.
    /// </summary>
    [TestFixture]
    public class DemandeRemisePromotionSurFraisTest
    {
        private Identite identite;
        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private PromotionPourDetail parametre;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite(){ Memoid = "test" };

            this.parametre = new PromotionPourDetail()
            {
                Cle = 1,
                MontantHT = 1,
                Duree = 5
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();
        }

        /// <summary>
        /// Initialisation du ServiceTechniques.
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec l'identité null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(null, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec la clé null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_CleNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(this.identite, 0, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec la clé negatif.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_CleNegatif_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(this.identite, -1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec les paramètres null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_ParametreNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(this.identite, 1, null, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec le service technique null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(this.identite, 1, this.parametre, true, null, this.servicesExternes.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise promotion sur frais avec le service technique null.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_ServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new DemandeRemisePromotionSurFrais(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Créer une demande de remise forfait promotion sur frais.
        /// </summary>
        [Test]
        public void CreerDemandeRemisePromotionSurFrais_ParametresValides_OK()
        {
            DemandeRemisePromotionSurFrais demande = new DemandeRemisePromotionSurFrais(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.AreEqual(demande.Cle, 1);
            Assert.AreEqual(demande.ClePromotion(), this.parametre.Cle);
            Assert.AreEqual(demande.EstSurParc, true);
            Assert.AreEqual(demande.MontantHT, this.parametre.MontantHT);
            Assert.AreEqual(demande.TypeDemandeRemise, TypeDemandeRemise.RemisePromotionSurFrais);
            Assert.AreEqual(demande.DureeValidite, this.parametre.Duree);
            Assert.AreEqual(demande.SuiviAgentCreation, this.identite.Memoid);
            Assert.AreEqual(demande.SuiviAgentModification, this.identite.Memoid);
            Assert.AreEqual(demande.ValeurEtat, EtatDemandeRemise.Expiree);
            Assert.AreEqual(demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Expiree);
        }

        /// <summary>
        /// Est résiliable.
        /// </summary>
        [Test]
        public void EstResiliable_ParametreValide_OK()
        {
            DemandeRemisePromotionSurFrais demande = new DemandeRemisePromotionSurFrais(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);

            Assert.IsFalse(demande.EstResiliable(this.identite, 0));
        }
    }
}
