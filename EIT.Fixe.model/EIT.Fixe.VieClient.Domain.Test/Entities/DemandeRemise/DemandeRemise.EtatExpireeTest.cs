﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.DemandeRemise
{
    /// <summary>
    /// Classe de test d'une demande de remise a l'état expirée.
    /// </summary>
    [TestFixture]
    public partial class DemandeRemisePromotionSurOffreTest
    {
        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialisationEtatExpirer()
        {
            this.identite = new Identite() { Memoid = "test" };

            this.parametre = new PromotionPourDetail()
            {
                Cle = 1,
                MontantHT = 1,
                Duree = 5
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServiceExterne();

            this.demande = new DemandeRemisePromotionSurOffre(this.identite, 1, this.parametre, true, this.serviceTechnique.Object, this.servicesExternes.Object);
            this.demande.Expirer(this.identite);
        }

        /// <summary>
        /// Expirer.
        /// </summary>
        [Test]
        public void Expirer_VersExpiree_LeveException()
        {
            this.InitialisationEtatExpirer();

            TestDelegate action = () => this.demande.Expirer(this.identite);

            Assert.Throws<InvalidOperationException>(action);
        }

        /// <summary>
        /// Est activé.
        /// </summary>
        [Test]
        public void ExpirerEstActive_ParametreValide_OK()
        {
            this.InitialisationEtatExpirer();

            Assert.IsFalse(this.demande.EstActive());
        }

        /// <summary>
        /// Est obsolete.
        /// </summary>
        [Test]
        public void ExpirerEstObsolete_ParametreValide_OK()
        {
            this.InitialisationEtatExpirer();

            Assert.IsTrue(this.demande.EstObsolete());
        }
    }
}
