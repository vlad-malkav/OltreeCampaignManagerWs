﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test des kitbox.
    /// </summary>
    [TestFixture]
    public class KitBoxTest
    {
        private Identite identite;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "Memoid" };
        }

        /// <summary>
        /// constructeur avec identite null.
        /// </summary>
        [Test]
        public void Constructeur_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new KitBox(null, 1, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// constructeur avec cle null.
        /// </summary>
        [Test]
        public void Constructeur_CleNull_LeveException()
        {
            TestDelegate action = () => new KitBox(this.identite, 0, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// constructeur avec cle negatif.
        /// </summary>
        [Test]
        public void Constructeur_CleNegatif_LeveException()
        {
            TestDelegate action = () => new KitBox(this.identite, -1, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// constructeur avec cle kitbox null.
        /// </summary>
        [Test]
        public void Constructeur_CleKitBoxNull_LeveException()
        {
            TestDelegate action = () => new KitBox(this.identite, 1, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// constructeur avec cle kitbox negatif.
        /// </summary>
        [Test]
        public void Constructeur_CleKitBoxNegatif_LeveException()
        {
            TestDelegate action = () => new KitBox(this.identite, 1, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// constructeur avec identite null.
        /// </summary>
        [Test]
        public void Constructeur_ParametreValide_OK()
        {
            KitBox kitBox = new KitBox(this.identite, 1, 1);

            Assert.AreEqual(kitBox.Cle, 1);
            Assert.AreEqual(kitBox.CleKitBox, 1);
            Assert.IsTrue(kitBox.EstActif);
            Assert.AreEqual(kitBox.SuiviAgentCreation, this.identite.Memoid);
            Assert.AreEqual(kitBox.SuiviAgentModification, this.identite.Memoid);

        }
    }
}
