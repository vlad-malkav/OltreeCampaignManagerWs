﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet Fonctionnalite.
    /// </summary>
    [TestFixture]
    public class FonctionnaliteTest
    {
        private Identite identite;
        private ParametreFonctionnalitePourCreation parametreFonctionnalite;
        private Fonctionnalite fonctionnalite;

        #region Initialisation

        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametreFonctionnalite = new ParametreFonctionnalitePourCreation()
            {
                Cle = 1,
                Code = "Code",
                Description = "Description",
                EstActif = true
            };

            this.fonctionnalite = new Fonctionnalite(this.identite, this.parametreFonctionnalite);
        }

        #endregion Initialisation

        #region Test Constructeur

        /// <summary>
        /// Test du constructeur avec les paramètre OK.
        /// </summary>
        [Test]
        public void CreerFonctionnalite_ParametreOK_OK()
        {
            //Arrange & Act.
            Fonctionnalite fct = new Fonctionnalite(this.identite, this.parametreFonctionnalite);

            //Assert.
            Assert.AreEqual(fct.Cle, this.fonctionnalite.Cle);
            Assert.AreEqual(fct.Code, this.fonctionnalite.Code);
            Assert.AreEqual(fct.Description, this.fonctionnalite.Description);
        }

        /// <summary>
        /// Test du constructeur avec l'identite nulle.
        /// </summary>
        [Test]
        public void CreerFonctionnalite_IdentiteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new Fonctionnalite(null, this.parametreFonctionnalite);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur avec l'identite nulle.
        /// </summary>
        [Test]
        public void CreerFonctionnalite_ParametreFonctionnaliteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new Fonctionnalite(this.identite, null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test Constructeur

        #region Test Desactiver

        /// <summary>
        /// Test de la méthode désactiver.
        /// </summary>
        [Test]
        public void Desactiver_OK()
        {
            //Arrange & Act
            this.fonctionnalite.Desactiver(identite);

            //Assert
            Assert.AreEqual(this.fonctionnalite.EstActif, false);
        }

        #endregion Test Desactiver
    }
}
