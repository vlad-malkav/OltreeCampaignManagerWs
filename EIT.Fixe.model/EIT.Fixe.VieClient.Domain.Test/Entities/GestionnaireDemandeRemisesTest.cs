﻿using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.DemandeRemise;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test du GestionnaireDemandeRemises.
    /// </summary>
    [TestFixture]
    public class GestionnaireDemandeRemisesTest
    {
        private Identite identite;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        private Mock<IRepositories> repositories;
        private List<DemandeRemisePourCreation> listeDemande;
        private GestionnaireDemandeRemises gestionnaire;
        private long cleDemandeRemise;
        private long cleLigne;
        private int cleOffre;

        private Mock<IHistoriqueDossierGboLigneRepository> ligneHistoriqueDossierGboRepository;
        private Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "test" };

            this.InitialiserServiceTechnique();
            this.InitialiserBriqueServiceExterne();
            this.InitialiserRepositories();
            this.InitialiserServiceExterne();
            this.cleDemandeRemise = 2;
            this.cleLigne = 1;
            this.listeDemande = new List<DemandeRemisePourCreation>()
            {
                new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemise.RemiseSurForfait,
                    DetailRemiseForfaitPourCreation = new DemandeRemiseForfaitPourCreation()
                    {
                        MontantHT = 1
                    },

                    PromotionPourDetail = new PromotionPourDetail()
                    {
                        Descriptif = "RemiseSurForfait"
                    }
                },
                new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurOffre,
                    PromotionPourDetail = new PromotionPourDetail()
                    {
                        Cle = 1,
                        MontantHT = 1,
                        Duree = 1,
                        Descriptif = "RemisePromotionSurOffre"
                    }
                },
                new DemandeRemisePourCreation()
                {
                    TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurFrais,
                    PromotionPourDetail = new PromotionPourDetail()
                    {
                        Cle = 1,
                        MontantHT = 1,
                        Duree = 1,
                        Descriptif = "RemisePromotionSurFrais"
                    }
                }
            };
            this.cleOffre = 1234;
            this.gestionnaire = new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);
        }

        /// <summary>
        /// Initialisation du ServiceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles GenerateurCles = new GenerateurCles();
            Mock<IParametrage> parametrage = new Mock<IParametrage>();

            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(GenerateurCles);
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
        }

        /// <summary>
        /// Initialisation du Repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            Mock<ILigneRepository> ligneRepository = new Mock<ILigneRepository>();
            this.ligneHistoriqueDossierGboRepository = new Mock<IHistoriqueDossierGboLigneRepository>();
            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();

            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(s => s.LigneRepository).Returns(ligneRepository.Object);

            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(s => s.CleOffre).Returns(1);
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>())).Returns(ligne.Object);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();
            Mock<IValorisationServiceExterne> valorisationServiceExterne = new Mock<IValorisationServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();

            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.ValorisationServiceExterne).Returns(valorisationServiceExterne.Object);

            this.briquesServicesExterne.Setup(x => x.ValorisationServiceExterne.ChangerRemise(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<List<RemisePourValorisation>>()));
        }

        /// <summary>
        /// Initialisation du serviceExternes.
        /// </summary>
        private void InitialiserServiceExterne()
        {
            Mock<IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<IHistoriqueServiceExterne>();
            Mock<IReferentielServiceExterne> referentielService = new Mock<IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();

            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);

            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new OffrePourDetail()
            {
                LibelleRemiseAuto = "LibelleRemiseAuto"
            });
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new PromotionPourDetail()
            {
                CodePromo = "CodePromo"
            });

        }

        #region Test Constructeur
        /// <summary>
        /// Creation avec l'identite null.
        /// </summary>
        [Test]
        public void Creer_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(null, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec la cle null.
        /// </summary>
        [Test]
        public void Creer_CleNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 0, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle negatif.
        /// </summary>
        [Test]
        public void Creer_CleNegatif_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, -1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la reference externe vide.
        /// </summary>
        [Test]
        public void Creer_ReferenceExterneVide_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, string.Empty, this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec la cle ligne null.
        /// </summary>
        [Test]
        public void Creer_CleLigneNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 0, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle ligne negatif.
        /// </summary>
        [Test]
        public void Creer_CleLigneNegatif_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, -1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la clé offre null.
        /// </summary>
        [Test]
        public void Creer_CleOffreNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, this.cleLigne, 0, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création avec la clé offre negative.
        /// </summary>
        [Test]
        public void Creer_CleOffreNegatif_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, this.cleLigne, -1, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec le service externe null.
        /// </summary>
        [Test]
        public void Creer_ServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, null, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec le repositorie null.
        /// </summary>
        [Test]
        public void Creer_RepositorieNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, null, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec la brique service externe null.
        /// </summary>
        [Test]
        public void Creer_BriqueServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, null, this.serviceTechnique.Object);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec le service technique null.
        /// </summary>
        [Test]
        public void Creer_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation.
        /// </summary>
        [Test]
        public void Creer_ParametreValides_OK()
        {
            GestionnaireDemandeRemises gestionnaire = new GestionnaireDemandeRemises(this.identite, 1, "test", this.listeDemande, 1, this.cleOffre, this.servicesExternes.Object, this.repositories.Object, this.briquesServicesExterne.Object, this.serviceTechnique.Object);

            Assert.AreEqual(gestionnaire.Cle, 1);
            Assert.AreEqual(gestionnaire.RefExterne, "test");
            Assert.AreEqual(gestionnaire.ListeDemandesRemises.Count, 3);
            DemandeRemiseForfait demandeForfait = (DemandeRemiseForfait)gestionnaire.ListeDemandesRemises.ElementAt(0);
            Assert.AreEqual(demandeForfait.MontantHT, 1);
            DemandeRemisePromotionSurOffre demandeSurOffre = (DemandeRemisePromotionSurOffre)gestionnaire.ListeDemandesRemises.ElementAt(1);
            Assert.AreEqual(demandeSurOffre.ClePromotion(), 1);
            Assert.AreEqual(demandeSurOffre.MontantHT, 1);
            Assert.AreEqual(demandeSurOffre.DureeValidite, 1);
            DemandeRemisePromotionSurFrais demandeSurFrais = (DemandeRemisePromotionSurFrais)gestionnaire.ListeDemandesRemises.ElementAt(2);
            Assert.AreEqual(demandeSurFrais.ClePromotion(), 1);
            Assert.AreEqual(demandeSurFrais.MontantHT, 1);
            Assert.AreEqual(demandeSurFrais.DureeValidite, 1);
        }
        #endregion Test Constructeur

        #region Test ResilierDemandeRemiseParCle
        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec identite null, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_IdentiteNull_LeveeException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(null,this.cleDemandeRemise, this.cleLigne, this.cleOffre);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle damande remise null, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleDemandeRemiseNull_LeveeException()
        {
            long cleDemandeRemise = 0;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, cleDemandeRemise, this.cleLigne, this.cleOffre);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle damande remise invalide, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleDemandeRemiseInvalide_LeveeException()
        {
            long cleDemandeRemiseInvalide = -1;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, cleDemandeRemiseInvalide, this.cleLigne, this.cleOffre);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle ligne null, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleLigneNull_LeveeException()
        {
            long cleLigne = 0;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, this.cleDemandeRemise, cleLigne, this.cleOffre);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle ligne invalide, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleLigneInvalide_LeveeException()
        {
            long cleLigneInvalide = -1;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, this.cleDemandeRemise, cleLigneInvalide, this.cleOffre);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle offre null, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleOffreNull_LeveeException()
        {
            int cleOffreInvalide = 0;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, this.cleDemandeRemise, this.cleLigne, cleOffreInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test ResilierDemandeRemiseParCle avec cle offre invalide, Levée une exception.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleOffreInvalide_LeveeException()
        {
            int cleOffreInvalide = -1;
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, this.cleDemandeRemise, this.cleLigne, cleOffreInvalide);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Test ResilierDemandeRemiseParCle

        #region Test AppliquerModificationEnValorisation
        /// <summary>
        /// Appliquer Modification En Valorisation avec Identite Null
        /// </summary>
        [Test]
        public void AppliquerModificationEnValorisation_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.AppliquerModificationsEnValorisation(null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Appliquer Modification En Valorisation avec Identite Null
        /// </summary>
        [Test]
        public void AppliquerModificationEnValorisation_ParametreValide_OK()
        {
            this.gestionnaire.AppliquerModificationsEnValorisation(this.identite);

            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisReferenceExterne(It.IsAny<string>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirOffreParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>()));

            this.briquesServicesExterne.Verify(x => x.ValorisationServiceExterne.ChangerRemise(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<List<RemisePourValorisation>>()));
        }
        #endregion Test AppliquerModificationEnValorisation

        #region Test CreerEtActiverDemandeRemisePromotion
        /// <summary>
        /// CreerEtActiverDemandeRemisePromotion.
        /// </summary>
        [Test]
        public void CreerEtActiver_ParametreValide_OK()
        {
            DemandeRemisePourCreation demande = new DemandeRemisePourCreation()
            {
                TypeDemandeRemise = TypeDemandeRemise.RemisePromotionSurFrais,
                PromotionPourDetail = new PromotionPourDetail()
                {
                    Cle = 1,
                    MontantHT = 1,
                    Duree = 1,
                    Descriptif = "RemisePromotionSurFrais"
                }
            };

            this.gestionnaire.CreerEtActiverDemandeRemisePromotion(this.identite, demande, this.cleLigne, this.cleOffre);

            Assert.AreEqual(this.gestionnaire.ListeDemandesRemises.Count, 4);
        }
        #endregion Test CreerEtActiverDemandeRemisePromotion

        #region Test ExpirerDemandeRemiseParCle
        /// <summary>
        /// ExpirerDemandeRemiseParCle avec identite null.
        /// </summary>
        [Test]
        public void ExpirerDemandeRemiseParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ExpirerDemandeRemiseParCle(null, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ExpirerDemandeRemiseParCle avec cle null.
        /// </summary>
        [Test]
        public void ExpirerDemandeRemiseParCle_CleNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ExpirerDemandeRemiseParCle(this.identite, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ExpirerDemandeRemiseParCle avec cle negatif.
        /// </summary>
        [Test]
        public void ExpirerDemandeRemiseParCle_CleNegatif_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ExpirerDemandeRemiseParCle(this.identite, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ExpirerDemandeRemiseParCle.
        /// </summary>
        [Test]
        public void ExpirerDemandeRemiseParCle_ParametreValide_OK()
        {
            this.gestionnaire.ExpirerDemandeRemiseParCle(this.identite, 2);

            AbstractDemandeRemise demande = this.gestionnaire.ListeDemandesRemises.First(x => x.Cle == 2);
            Assert.AreEqual(demande.ValeurEtat, EtatDemandeRemise.Expiree);
            Assert.AreEqual(demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Expiree);
        }

        #endregion Test ExpirerDemandeRemiseParCle

        #region Test ListerPromotionsActives
        /// <summary>
        /// ListerPromotionsActives.
        /// </summary>
        [Test]
        public void ListerPromotionsActives_ParametreValide_OK()
        {
            IList<DemandeRemisePromotion> liste = this.gestionnaire.ListerPromotionsActives();

            Assert.AreEqual(liste.Count,1);
        }
        #endregion Test ListerPromotionsActives

        #region Test ListerPromotionsObsoletes
        /// <summary>
        /// ListerPromotionsObsoletes.
        /// </summary>
        [Test]
        public void ListerPromotionsObsoletes_ParametreValide_OK()
        {
            IList<DemandeRemisePromotion> liste = this.gestionnaire.ListerPromotionsObsoletes();

            Assert.AreEqual(liste.Count, 1);
        }
        #endregion Test ListerPromotionsObsoletes

        #region Test ResilierDemandeRemiseParCle
        /// <summary>
        /// ResilierDemandeRemiseParCle avec identite null.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(null, 1, 1, 1);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec cle null.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 0, 1, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec cle negatif.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleNegatif_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, -1, 1, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec cle ligne null.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleLigneNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 1, 0, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec cle ligne negatif.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleLigneNegatif_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 1, -1, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec clé offre null.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleOffreNull_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 1, 1, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle avec clé offre négative.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_CleOffreNegatif_LeveException()
        {
            TestDelegate action = () => this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 1, 1, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// ResilierDemandeRemiseParCle.
        /// </summary>
        [Test]
        public void ResilierDemandeRemiseParCle_ParametreValide_OK()
        {
            this.gestionnaire.ResilierDemandeRemiseParCle(this.identite, 2, 1, 1);

            AbstractDemandeRemise demande = this.gestionnaire.ListeDemandesRemises.First(x => x.Cle == 2);
            Assert.AreEqual(demande.ValeurEtat, EtatDemandeRemise.Resiliee);
            Assert.AreEqual(demande.ListeHistoriquesEtats.Last().NouvelEtat, EtatDemandeRemise.Resiliee);
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirPromotionParCle(It.IsAny<Identite>(), It.IsAny<int>(), It.IsAny<int>()));
        }
        #endregion Test ResilierDemandeRemiseParCle
    }
}
