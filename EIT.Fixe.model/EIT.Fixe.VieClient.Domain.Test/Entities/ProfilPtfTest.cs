﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet ProfilPtf.
    /// </summary>
    [TestFixture]
    public class ProfilPtfTest
    {
        private Identite identite;
        private ProfilPtf profilPtf;
        private ParametreProfilPtfPourCreation parametreProfilPtfPourCreation;
        private List<ParametreGroupeFonctionnalitesPourCreation> listeGroupeFonctionnalite;
        private ParametreGroupeFonctionnalitesPourCreation parametreGroupeFonctionnalitesPourCreation;

        #region Initialisation

        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametreGroupeFonctionnalitesPourCreation = new ParametreGroupeFonctionnalitesPourCreation()
            {
                Cle = 1
            };

            this.listeGroupeFonctionnalite = new List<ParametreGroupeFonctionnalitesPourCreation>();
            this.listeGroupeFonctionnalite.Add(this.parametreGroupeFonctionnalitesPourCreation);

            this.parametreProfilPtfPourCreation = new ParametreProfilPtfPourCreation()
            {
                Cle = 1,
                Code = "code",
                Description = "desciprtion",
                EstActif = true,
                Libelle = "Libelle",
                RessourceSas = "RessourceSas",
                SuiviDateCreation = new DateTime(2018, 3, 13)
            };

            this.profilPtf = new ProfilPtf(this.identite, this.parametreProfilPtfPourCreation, null);
        }

        #endregion Initialisation

        #region Test Constructeur

        /// <summary>
        /// Test du constructeur avec les paramètres OK.
        /// </summary>
        [Test]
        public void CreerProfilTpf_ParametreOK_OK()
        {
            //Arrange & Act.
            ProfilPtf profilTest = new ProfilPtf(this.identite, this.parametreProfilPtfPourCreation, null);

            //Assert.
            Assert.AreEqual(profilTest.Cle, this.profilPtf.Cle);
            Assert.AreEqual(profilTest.Code, this.profilPtf.Code);
            Assert.AreEqual(profilTest.Description, this.profilPtf.Description);
            Assert.AreEqual(profilTest.Libelle, this.profilPtf.Libelle);
            Assert.AreEqual(profilTest.RessourceSas, this.profilPtf.RessourceSas);
        }

        /// <summary>
        /// Test du constructeur avec l'identite nulle.
        /// </summary>
        [Test]
        public void CreerProfilTpf_IdentiteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new ProfilPtf(null, this.parametreProfilPtfPourCreation, null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur avec le parametreProfilPtfPourCreation null.
        /// </summary>
        [Test]
        public void CreerProfilTpf_ParametreProfilNull_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new ProfilPtf(this.identite, null, null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test Constructeur

        #region Test AjouterGroupeFonctionnalites

        /// <summary>
        /// Test de la méthode AjouterGroupeFonctionnalite avec les paramètres OK.
        /// </summary>
        [Test]
        public void AjouterGroupeFonctionnalites_ParametreOK()
        {
            //Arrange & Act
            GroupeFonctionnalites groupeFct = new GroupeFonctionnalites(this.identite, this.parametreGroupeFonctionnalitesPourCreation, null);
            this.profilPtf.AjouterGroupeFonctionnalites(groupeFct);

            //Assert
            Assert.Contains(groupeFct, this.profilPtf.ListeGroupesFonctionnalites.ToList());
        }

        /// <summary>
        /// Test de la méthode AjouterGroupeFonctionnalite avec le GroupeFonctionnalites null.
        /// </summary>
        [Test]
        public void AjouterGroupeFonctionnalites_GroupeFonctionnalitesNull_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => this.profilPtf.AjouterGroupeFonctionnalites(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test AjouterGroupeFonctionnalites

        #region Test Desactiver

        /// <summary>
        /// Test de la méthode désactiver.
        /// </summary>
        [Test]
        public void Desactiver_OK()
        {
            //Arrange & Act
            this.profilPtf.Desactiver(identite);

            //Assert
            Assert.AreEqual(this.profilPtf.EstActif, false);
        }

        #endregion Test Desactiver
    }
}
