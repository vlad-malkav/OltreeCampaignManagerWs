﻿using System;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using NUnit.Framework;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test pour HistoriqueEtatLigne.
    /// </summary>
    [TestFixture]
    public class HistoriqueEtatLigneTest
    {
        private Identite identite;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "test", Canal = Canal.FaceAFace };
        }

        /// <summary>
        /// Creation avec l'identite null.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatLigne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatLigne(null, 1, EtatLigne.Activee, EtatLigne.Resiliee);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation avec la cle null.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatLigne_CleNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatLigne(this.identite, 0, EtatLigne.Activee, EtatLigne.Resiliee);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle negatif.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatLigne_CleNegatif_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatLigne(this.identite, -1, EtatLigne.Activee, EtatLigne.Resiliee);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec le nouvel etat = NA.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatLigne_NouvelEtatNA_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatLigne(this.identite, 1, EtatLigne.Activee, EtatLigne.NA);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatLigne_ParametreValide_OK()
        {
            HistoriqueEtatLigne historique = new HistoriqueEtatLigne(this.identite, 1, EtatLigne.Activee, EtatLigne.Resiliee);

            Assert.AreEqual(historique.Cle, 1);
            Assert.AreEqual(historique.Canal, this.identite.Canal);
            Assert.AreEqual(historique.AncienEtat, EtatLigne.Activee);
            Assert.AreEqual(historique.NouvelEtat, EtatLigne.Resiliee);
            Assert.AreEqual(historique.AgentModification, this.identite.Memoid);
        }
    }
}
