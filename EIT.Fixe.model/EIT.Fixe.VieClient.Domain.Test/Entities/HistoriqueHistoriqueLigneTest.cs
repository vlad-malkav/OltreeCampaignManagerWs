﻿using System;
using EIT.Fixe.Systeme.Identification;
using NUnit.Framework;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test pour HistoriqueHistoriqueLigne.
    /// </summary>
    [TestFixture]
    public class HistoriqueHistoriqueLigneTest
    {
        private Identite identite;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "test"};
        }

        /// <summary>
        /// Creation avec l'identite null.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueHistoriqueLigne(null, 1, 1);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation avec la cle null.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_CleNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueHistoriqueLigne(this.identite, 0, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle negatif.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_CleNegatif_LeveException()
        {
            TestDelegate action = () => new HistoriqueHistoriqueLigne(this.identite, -1, 1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle historique null.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_CleHistoriqueNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueHistoriqueLigne(this.identite, 1, 0);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation avec la cle historique negatif.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_CleHistoriqueNegatif_LeveException()
        {
            TestDelegate action = () => new HistoriqueHistoriqueLigne(this.identite, 1, -1);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation.
        /// </summary>
        [Test]
        public void CreerHistoriqueHistoriqueLigne_ParametreValide_OK()
        {
            HistoriqueHistoriqueLigne historique = new HistoriqueHistoriqueLigne(this.identite, 1, 1);

            Assert.AreEqual(historique.Cle, 1);
            Assert.AreEqual(historique.CleHistorique, 1);
            Assert.AreEqual(historique.SuiviAgentCreation, this.identite.Memoid);
        }
    }
}
