﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using NUnit.Framework;

namespace EIT.Fixe.VieClient.Domain.Test
{
    /// <summary>
    /// Classe de test pour l'etat Resiliee d'une ligne.
    /// </summary>
    [TestFixture]
    public partial class LigneTest
    {
        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialiserEtatResiliee()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.ligne = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            
        }
    }
}
