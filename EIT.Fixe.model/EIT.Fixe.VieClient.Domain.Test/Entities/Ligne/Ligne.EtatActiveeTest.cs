﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using Moq;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using NUnit.Framework;
using System;
using System.Linq;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.Domain.ExternalServices;

namespace EIT.Fixe.VieClient.Domain.Test
{
    /// <summary>
    /// Classe de test pour l'etat Activee d'une ligne.
    /// </summary>
    [TestFixture]
    public partial class LigneTest
    {
        #region Initialisateur

        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialiserEtatActivee()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.ligne = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
        }

        #endregion Initialisateur

        #region Tests de la méthode ModifierStatutSurconsommation dans l'état "Activee"

        /// <summary>
        /// Modification du statut de surconsommation.
        /// </summary>
        [Test]
        public void ModifierStatutSurconsommation_ParametreValide_OK()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            // Act.
            this.ligne.ModifierStatutSurconsommation(this.identite, ProfilSurconsommation.NouveauClient);

            // Assert.
            Assert.AreEqual(this.ligne.StatutSurconsommation, ProfilSurconsommation.NouveauClient);
        }

        #endregion Tests de la méthode ModifierStatutSurconsommation dans l'état "Activee"

        #region Tests de la méthode CreerDemandeResiliation dans l'état "Activee"

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans l'état "Activee" avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_IdentiteNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatActivee();
            CommonTypes.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new CommonTypes.DTO.DemandeResiliationPourCreation()
            {

            };

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeResiliation(null, demandeResiliationPourCreation);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans l'état "Activee" avec le paramètre DemandeResiliationPourCreation à null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_DemandeResiliationPourCreationNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeResiliation(this.identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans l'état "Activee" avec les paramètres OK.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_ParametreOK_OK()
        {
            // Arrange.
            this.InitialiserEtatActivee();
            CommonTypes.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                CleMotifResiliation = this.CleMotifResiliationValide,
                TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new CommonTypes.DTO.AdressePourSaisie()
                },
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                DateResiliationProgrammee = DateTime.Now.AddDays(1),
                DateReceptionCourrierAr = DateTime.Now.AddDays(1),
            };
            int nombreDemandeResiliation = ligne.ListeDemandeResiliation.Count;

            // Act.
            this.ligne.CreerDemandeResiliation(this.identite, demandeResiliationPourCreation);

            // Assert.
            this.serviceTechnique.Verify(x => x.GenerateurCles.ObtenirCleLongue<DemandeResiliation>());
            this.repositories.Verify(x => x.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliationValide));
            Assert.AreEqual(nombreDemandeResiliation + 1, ligne.ListeDemandeResiliation.Count);
            Assert.AreEqual(identite.Memoid, ligne.SuiviAgentModification);
        }

        #endregion  Tests de la méthode CreerDemandeResiliation dans l'état "Activee"

        #region Tests de la méthode Resilier dans l'état "Activee"

        /// <summary>
        /// Test de la méthode Resilier dans l'état "Activee" avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ResilierEtatActivee_IdentiteNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            // Act.
            TestDelegate action = () => this.ligne.Resilier(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Resilier dans l'état "Activee" les paramètres valide.
        /// </summary>
        [Test]
        public void ResilierEtatActivee_ParametresOK_OK()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            Mock<IGboServiceExterne> gboServiceExterne = new Mock<IGboServiceExterne>();
            this.servicesExternes.Setup(s => s.GboServiceExterne).Returns(gboServiceExterne.Object);
            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new Fixe.Domain.Gbo.ReponseCreationDossierGbo { CleDossierGbo = 1, CleHistoriqueAssociationDossierGboLigne = 1 });
            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCleLongue<Domain.Entities.HistoriqueEtatLigne>()).Returns(1);

            CommonTypes.DTO.DemandeResiliationPourCreation demandeResiliationPourCreation = new CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                CleMotifResiliation = this.CleMotifResiliationValide,
                TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new CommonTypes.DTO.AdressePourSaisie()
                },
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                DateResiliationProgrammee = DateTime.Now.AddDays(1),
                DateReceptionCourrierAr = DateTime.Now.AddDays(1),
            };

            this.ligne.CreerDemandeResiliation(this.identite, demandeResiliationPourCreation);

            // Act.
            this.ligne.Resilier(this.identite);

            // Assert.
            Assert.AreEqual(EtatLigne.Resiliee, ligne.ListeHistoriqueEtats.Last().NouvelEtat);
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(It.IsAny<Identite>(), this.CleLigneValide ,It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            //this.briquesServicesExterne.Verify(x => x.BriqueGboServiceExterne.CreerDossier(this.identite, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>()));
        }

        #endregion Tests de la méthode Resilier dans l'état "Activee"

        #region Test de la méthode Suspendre dans l'état "Activee"

        /// <summary>
        /// Test de la méthode Suspendre dans l'état activée avec les paramètres OK.
        /// </summary>
        [Test]
        public void Suspendre_EtatActivee_ParametreOK_OK()
        {
            // Arrange.
            this.InitialiserEtatActivee();
            // Act.
            this.ligne.Suspendre(this.identite);
            // Assert.
            Assert.AreEqual(this.ligne.ValeurEtat, EtatLigne.Suspendue);
        }

        /// <summary>
        /// Test de la méthode Suspendre dans l'état Activee avec l'identite nulle.
        /// </summary>
        [Test]
        public void Suspendre_EtatActivee_IdentiteNulle_ExceptionLevee()
        {
            // Arrange.
            this.InitialiserEtatActivee();
            // Act.
            TestDelegate action = () => this.ligne.Suspendre(null);
            // Assert.
            Assert.Throws<ArgumentException>(action);

        }

        #endregion Test de la méthode Suspendre dans l'état "Activee"
        
    }
}
