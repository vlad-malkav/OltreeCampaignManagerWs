﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Linq;
using Moq;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.Domain.ExternalServices;

namespace EIT.Fixe.VieClient.Domain.Test
{
    /// <summary>
    /// Classe de test pour l'etat Suspendue d'une ligne.
    /// </summary>
    [TestFixture]
    public partial class LigneTest
    {
        #region Initialisateur

        private DemandeResiliationPourCreation informationResiliation;
        /// <summary>
        /// Initialisation.
        /// </summary>
        public void InitialiserEtatSuspendue()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.ligne = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
            this.ligne.Suspendre(this.identite);
            TiersPourEnvoiBonRetour tiersPourEnvoiBonRetour = new TiersPourEnvoiBonRetour()
            {
                Nom = "nom",
                Prenom = "prenom",
                Adresse = new AdressePourSaisie(),
                Civilite = Fixe.Domain.CommonTypes.Civilite.M,
                EmailTiers = "Email",
                TelephoneMobileTiers = "0123456789"
            };
            this.informationResiliation = new DemandeResiliationPourCreation()
            {
                CleModeRetourEquipement = 1,
                CleMotifResiliation = this.CleMotifResiliationValide,
                DateReceptionCourrierAr = new DateTime(2025, 3, 19),
                Email = "Email",
                EstNouveauTiersEnvoiBonRetour = false,
                DateResiliationProgrammee = new DateTime(2025, 3, 20),
                TiersEnvoiBonRetour = tiersPourEnvoiBonRetour
            };
        }

        #endregion Initialisateur

        #region Test CreerDemandeResiliation

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation avec les paramètres OK.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_Suspendue_ParametreOK_OK()
        {
            //Arrange.
            this.InitialiserEtatSuspendue();
            int nombreDemandeResiliation = ligne.ListeDemandeResiliation.Count;
            // Act.
            this.ligne.CreerDemandeResiliation(this.identite, this.informationResiliation);

            // Assert.
            this.serviceTechnique.Verify(x => x.GenerateurCles.ObtenirCleLongue<DemandeResiliation>());
            this.repositories.Verify(x => x.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliationValide));
            Assert.AreEqual(nombreDemandeResiliation + 1, ligne.ListeDemandeResiliation.Count);
            Assert.AreEqual(identite.Memoid, ligne.SuiviAgentModification);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans l'état "Activee" avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_Suspendue_IdentiteNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeResiliation(null, this.informationResiliation);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode CreerDemandeResiliation dans l'état "Activee" avec le paramètre DemandeResiliationPourCreation à null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeResiliation_Suspendue_DemandeResiliationPourCreationNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatActivee();

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeResiliation(this.identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test CreerDemandeResiliation

        #region Test Resilier

        /// <summary>
        /// Test de la méthode Resilier dans l'état "Activee" avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void ResilierEtatSuspendue_IdentiteNull_LeveException()
        {
            // Arrange.
            this.InitialiserEtatSuspendue();

            // Act.
            TestDelegate action = () => this.ligne.Resilier(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Resilier dans l'état "Activee" les paramètres valide.
        /// </summary>
        [Test]
        public void ResilierEtatSuspendue_ParametresOK_OK()
        {
            // Arrange.
            this.InitialiserEtatSuspendue();


            Mock<IGboServiceExterne> gboServiceExterne = new Mock<IGboServiceExterne>();
            this.servicesExternes.Setup(s => s.GboServiceExterne).Returns(gboServiceExterne.Object);
            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);
            this.briquesServicesExterne.Setup(l => l.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(new Fixe.Domain.Gbo.ReponseCreationDossierGbo { CleDossierGbo = 1, CleHistoriqueAssociationDossierGboLigne = 1 });
            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCleLongue<Domain.Entities.HistoriqueEtatLigne>()).Returns(1);

            DemandeResiliationPourCreation demandeResiliationPourCreation = new DemandeResiliationPourCreation()
            {
                CleMotifResiliation = this.CleMotifResiliationValide,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourSaisie()
                },
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                DateResiliationProgrammee = DateTime.Now.AddDays(1),
                DateReceptionCourrierAr = DateTime.Now.AddDays(1),
            };

            this.ligne.CreerDemandeResiliation(this.identite, demandeResiliationPourCreation);

            // Act.
            this.ligne.Resilier(this.identite);

            // Assert.



            Assert.AreEqual(EtatLigne.Resiliee, ligne.ListeHistoriqueEtats.Last().NouvelEtat);
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(It.IsAny<Identite>(), this.CleLigneValide, It.IsAny<CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            //this.briquesServicesExterne.Verify(x => x.BriqueGboServiceExterne.CreerDossier(this.identite, It.IsAny<string>(), It.IsAny<string>(),  It.IsAny<int>(), It.IsAny<int>()));
        }

        #endregion Test Resilier
    }
}
