﻿using System;
using System.Linq;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Domain.ExternalServices;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Messaging;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.Domain.Repositories;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Systeme.Persistance;

namespace EIT.Fixe.VieClient.Domain.Test
{
    /// <summary>
    /// Classe de test de l'objet Ligne.
    /// </summary>
    [TestFixture]
    public partial class LigneTest
    {
        private long cle;
        private Identite identite;
        private DetailLignePourCreation parametre;
        private Ligne ligne;
        private DateTime dateFinEngagement;

        private Mock<IServicesTechniques> serviceTechnique;
        private Mock<IServicesExternes> servicesExternes;
        private Mock<IBriquesServicesExternes> briquesServicesExterne;
        private Mock<IRepositories> repositories;
        
        private Mock<IHistoriqueDossierGboLigneRepository> ligneHistoriqueDossierGboRepository;
        private Mock<IAssociationHistoriqueDossierGboRepository> ligneAssociationHistoriqueDossierGboRepository;

        /// <summary>
        /// Retourne une de ligne valide.
        /// </summary>
        private long CleLigneValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de motif de résiliation valide.
        /// </summary>
        private long CleMotifResiliationValide
        {
            get
            {
                return 10;
            }
        }

        /// <summary>
        /// Retourne une clé de mode de retour équipement valide.
        /// </summary>
        private long CleModeRetourEquipementValide
        {
            get
            {
                return 100;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "memoid" };
            this.dateFinEngagement = new DateTime(2020, 12, 1);
            this.cle = this.CleLigneValide;
            this.parametre = new DetailLignePourCreation()
            {
                Cle = this.cle,
                CleCompteFacturation = 1,
                CleAdresseInstallation = 1,
                CleGestionnaireOptions = "1",
                CleIcn = 1,
                CleMarque = 1,
                CleOffre = 1,
                CleTechnologie = 1,
                CleTiers = 1,
                CleCommandeExpedition = 1,
                DateFinEngagement = this.dateFinEngagement,
                Numero = "0102030405",
                NumeroContratOperateur = "NumeroContratOperateur",
                ReferenceExterne = "refext",
                IdentifiantTransactionOperateur = 1,
                Rio = "rio",
                CleKitBox = 1
            };

            this.InitialiserServiceTechnique();
            this.InitialiserServicesExternes();
            this.InitialiserBriqueServiceExterne();
            this.InitialiserRepositories();
            this.ligne = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);
        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(x => x.MotifResiliationRepository).Returns(new Mock<IMotifResiliationRepository>().Object);
            MotifResiliation motifResiliation = new MotifResiliation()
            {
                Cle = 1,
                DelaiResiliation = 10,
                ListeModeRetourEquipement = new List<ModeRetourEquipement>()
                {
                    new ModeRetourEquipement()
                    {
                        EstCocheParDefaut = true,
                        Cle = 1
                    }
                }
            };
            this.repositories.Setup(x => x.MotifResiliationRepository.ObtenirDepuisCle(this.CleMotifResiliationValide)).Returns(motifResiliation);

            this.repositories.Setup(x => x.LigneRepository).Returns(new Mock<ILigneRepository>().Object);
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide)).Returns(new Mock<Ligne>().Object);

            this.ligneHistoriqueDossierGboRepository = new Mock<IHistoriqueDossierGboLigneRepository>();
            this.ligneAssociationHistoriqueDossierGboRepository = new Mock<IAssociationHistoriqueDossierGboRepository>();

            //this.ligneHistoriqueDossierGboRepository.Setup(s => s.ListerClesDossiersDepuisReferenceExterneLigne(It.IsAny<Identite>(), this.ref)).Returns(new List<int>() { 1, 2, 3 });
            //this.ligneAssociationHistoriqueDossierGboRepository.Setup(s => s.LigneAssociationHistoriqueDossierGboRepository).Returns(ligneAssociationHistoriqueDossierGboRepository.Object);
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {

            this.servicesExternes = new Mock<IServicesExternes>();
            Mock<ServiceExterne.IHistoriqueServiceExterne> historiqueServiceExterne = new Mock<ServiceExterne.IHistoriqueServiceExterne>();
            Mock<ServiceExterne.IReferentielServiceExterne> referentielService = new Mock<ServiceExterne.IReferentielServiceExterne>();
            Mock<ISouscriptionServiceExterne> souscriptionService = new Mock<ISouscriptionServiceExterne>();
            Mock<IGboServiceExterne> gboServiceExterne = new Mock<IGboServiceExterne>();

            this.servicesExternes.Setup(x => x.LogistiqueServiceExterne).Returns(new Mock<ILogistiqueServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.LogistiqueServiceExterne.CreerDemandeRetourEquipement(It.IsAny<Identite>(), It.IsAny<string>())).Returns(new DemandeRetourEquipement() { Cle = 1, Numero = "0606060606" });
            this.servicesExternes.Setup(s => s.HistoriqueServiceExterne).Returns(historiqueServiceExterne.Object);
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne).Returns(referentielService.Object);
            this.servicesExternes.Setup(s => s.GboServiceExterne).Returns(gboServiceExterne.Object);
            Marque marque = new Marque()
            {
                TelephoneFixeSc = "TelephoneFixeSc",
                TelephoneMobileSc = "TelephoneMobileSc",
                HeureFermetureSc = "HeureFermetureSc",
                HeureOuvertureSc = "HeureOuvertureSc",
                Libelle = "Libelle",
                UrlAssistance = "UrlAssistance"
            };
            this.servicesExternes.Setup(s => s.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(marque);
            this.servicesExternes.Setup(s => s.SouscriptionServiceExterne).Returns(souscriptionService.Object);
            this.servicesExternes.Setup(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(It.IsAny<Identite>(), this.CleLigneValide, It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>())).Returns(1);
            this.servicesExternes.Setup(x => x.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<long>()));


            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>())).Returns(new Marque()
            {
                SiteWeb = "SiteWeb",
                Libelle = "Libelle"
            });

            this.servicesExternes.Setup(x => x.GboServiceExterne.CreerAssociationHistoriqueDossierGbo(It.IsAny<Identite>(), It.IsAny<long>(), It.IsAny<long>()));

            this.servicesExternes.Setup(x => x.GboServiceExterne.CreerHistoriqueDossierGboLigne(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>())).Returns(1);

        }

        /// <summary>
        /// Initialisation du serviceTechniques
        /// </summary>
        private void InitialiserServiceTechnique()
        {
            GenerateurCles generateurCles = new GenerateurCles();
            Mock<ServiceExterne.IParametrage> parametrage = new Mock<ServiceExterne.IParametrage>();

            Mock<IGenerateurSequences> generateurSequence = new Mock<IGenerateurSequences>();
            this.serviceTechnique = new Mock<IServicesTechniques>();
            this.serviceTechnique.Setup(s => s.GenerateurCles).Returns(generateurCles); 
            this.serviceTechnique.Setup(s => s.Parametrage).Returns(parametrage.Object);
            this.serviceTechnique.Setup(s => s.Parametrage.CleMotifResiliationRetractation).Returns(this.CleMotifResiliationValide);

            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCleLongue<DemandeResiliation>()).Returns(111);
            generateurSequence.Setup(x => x.ObtenirEntier(It.IsAny<string>())).Returns(1);
            this.serviceTechnique.Setup(s => s.GenerateurSequences).Returns(generateurSequence.Object);
            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCle<HistoriqueEtatLigne>()).Returns(555);
            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCleLongue<GestionnaireDemandeRemises>()).Returns(666);
            this.serviceTechnique.Setup(x => x.GenerateurCles.ObtenirCleLongue<KitBox>()).Returns(1);

            this.serviceTechnique.Setup(x => x.MessagingSystem).Returns(new Mock<IMessagingSystem>().Object);
        }

        /// <summary>
        /// Initialisation du BriqueserviceExternes.
        /// </summary>
        private void InitialiserBriqueServiceExterne()
        {
            Mock<IComptesClientServiceExterne> comptesClientServiceExterne = new Mock<IComptesClientServiceExterne>();
            Mock<IGboServiceExterne> gboServiceExterne = new Mock<IGboServiceExterne>();
            Mock<IBriqueGboServiceExterne> briqueGboServiceExterne = new Mock<IBriqueGboServiceExterne>();
            Mock<IGestionSurconsommationAboServiceExterne> gestionSurconsommationAboServiceExterne = new Mock<IGestionSurconsommationAboServiceExterne>();
            Mock<IAuthentificationServiceExterne> loginServiceExterne = new Mock<IAuthentificationServiceExterne>();
            Mock<ITiersServiceExterne> tiersServiceExterne = new Mock<ITiersServiceExterne>();
            Mock<EIT.Fixe.VieClient.Domain.ServiceExterne.ICommunicationClientServiceExterne> communicationClientServiceExterne = new Mock<EIT.Fixe.VieClient.Domain.ServiceExterne.ICommunicationClientServiceExterne>();

            this.briquesServicesExterne = new Mock<IBriquesServicesExternes>();
            this.briquesServicesExterne.Setup(s => s.ComptesClientServiceExterne).Returns(comptesClientServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.BriqueGboServiceExterne).Returns(briqueGboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.GestionSurconsommationAboServiceExterne).Returns(gestionSurconsommationAboServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.AuthentificationServiceExterne).Returns(loginServiceExterne.Object);
            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne).Returns(tiersServiceExterne.Object);
            this.briquesServicesExterne.Setup(x => x.ValorisationServiceExterne).Returns(new Mock<IValorisationServiceExterne>().Object);
            this.briquesServicesExterne.Setup(x => x.InterfaceOperateurServiceExterne).Returns(new Mock<IInterfaceOperateurServiceExterne>().Object);
            this.briquesServicesExterne.Setup(x => x.OptionsServiceExterne).Returns(new Mock<IOptionsServiceExterne>().Object);
            this.briquesServicesExterne.Setup(x => x.IcnServiceExterne).Returns(new Mock<IBriqueIcnServiceExterne>().Object);
            this.briquesServicesExterne.Setup(x => x.BriqueGboServiceExterne.CreerDossier(It.IsAny<Identite>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(1);

            this.briquesServicesExterne.Setup(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>())).Returns(new Domain.CommonTypes.DTO.TiersServiceExterne.TiersPourDetail()
            {
                Cle = 1,
                CiviliteEnum = Fixe.Domain.CommonTypes.Civilite.M,
                Nom = "Nom",
                Prenom = "Prenom",
                NumeroDepartementNaissance = "50",
                DateNaissance = new DateTime(2010, 11, 12),
                NumeroMobileDeContact = "0123456789",
                NumeroFixeDeContact = "0123456789",
                EmailContact = "test@test.fr",
                ListeAdresses = new List<AdresseTiers>()
                {
                    new AdresseTiers()
                    {
                        CodePostal = "CodePostal",
                        ComplementIdentification = "ComplementIdentification",
                        Ville = "Ville",
                        Voie = "Voie",
                        EstPrincipale = true
                    }
                }
            });

            this.briquesServicesExterne.Setup(s => s.CommunicationClientServiceExterne.EnvoyerSmsRemiseEnService(It.IsAny<Identite>(), It.IsAny<ParametreSmsRemiseEnService>()));
        }

        #region Test Constructeur


        /// <summary>
        /// Création d'une ligne avec la clé null.
        /// </summary>
        [Test]
        public void CreerLigne_CleNull_LeveException()
        {
            this.parametre.Cle = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé negative.
        /// </summary>
        [Test]
        public void CreerLigne_CleNegatif_LeveException()
        {
            this.parametre.Cle = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec l'identité null.
        /// </summary>
        [Test]
        public void CreerLigne_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new Ligne(null, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec les informations null.
        /// </summary>
        [Test]
        public void CreerLigne_InformationLigneNull_LeveException()
        {
            TestDelegate action = () => new Ligne(this.identite, null, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé de facturation null.
        /// </summary>
        [Test]
        public void CreerLigne_CleCompteFacturationNull_LeveException()
        {
            this.parametre.CleCompteFacturation = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé de facturation négatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleCompteFacturationNegatif_LeveException()
        {
            this.parametre.CleCompteFacturation = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé du KitBox null.
        /// </summary>
        [Test]
        public void CreerLigne_CleKitBoxNull_LeveException()
        {
            this.parametre.CleKitBox = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé du kitbox négatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleKitBoxNegatif_LeveException()
        {
            this.parametre.CleKitBox = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé d'éligibilité null.
        /// </summary>
        [Test]
        public void CreerLigne_CleAdresseInstallationNull_LeveException()
        {
            this.parametre.CleAdresseInstallation = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé d'eligibilite negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleAdresseInstallationNegatif_LeveException()
        {
            this.parametre.CleAdresseInstallation = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé gestionnaire d'option null.
        /// </summary>
        [Test]
        public void CreerLigne_CleGestionnaireOptionsNull_LeveException()
        {
            this.parametre.CleGestionnaireOptions = null;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé gestionnaire d'option negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleGestionnaireOptionsVide_LeveException()
        {
            this.parametre.CleGestionnaireOptions = string.Empty;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé marque null.
        /// </summary>
        [Test]
        public void CreerLigne_CleMarqueNull_LeveException()
        {
            this.parametre.CleMarque = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé marque negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleMarqueNegatif_LeveException()
        {
            this.parametre.CleMarque = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé marque null.
        /// </summary>
        [Test]
        public void CreerLigne_CleOffreNull_LeveException()
        {
            this.parametre.CleOffre = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé marque negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleOffreNegatif_LeveException()
        {
            this.parametre.CleOffre = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé technologique null.
        /// </summary>
        [Test]
        public void CreerLigne_CleTechnologieNull_LeveException()
        {
            this.parametre.CleTechnologie = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé technologique negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleTechnologieNegatif_LeveException()
        {
            this.parametre.CleTechnologie = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé tiers null.
        /// </summary>
        [Test]
        public void CreerLigne_CleTiersNull_LeveException()
        {
            this.parametre.CleTiers = 0;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la clé tiers negatif.
        /// </summary>
        [Test]
        public void CreerLigne_CleTiersNegatif_LeveException()
        {
            this.parametre.CleTiers = -1;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la date fin d'engagement null.
        /// </summary>
        [Test]
        public void CreerLigne_DateFinEngagementNull_LeveException()
        {
            this.parametre.DateFinEngagement = DateTime.MinValue;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le numero null.
        /// </summary>
        [Test]
        public void CreerLigne_NumeroNull_LeveException()
        {
            this.parametre.Numero = string.Empty;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le numero trop long.
        /// </summary>
        [Test]
        public void CreerLigne_NumeroTropLong_LeveException()
        {
            this.parametre.Numero = "numero trop long";

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le numero contrat operateur null.
        /// </summary>
        [Test]
        public void CreerLigne_NumeroContratOperateurNull_LeveException()
        {
            this.parametre.NumeroContratOperateur = string.Empty;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le numéro contrat opérateur trop long.
        /// </summary>
        [Test]
        public void CreerLigne_NumeroContratOperateurTropLong_LeveException()
        {
            this.parametre.NumeroContratOperateur = "le numero contrat operateur est beaucoup trop long";

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la référence externe null.
        /// </summary>
        [Test]
        public void CreerLigne_ReferenceExterneNull_LeveException()
        {
            this.parametre.ReferenceExterne = string.Empty;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la référence externe null.
        /// </summary>
        [Test]
        public void CreerLigne_RIONull_LeveException()
        {
            this.parametre.Rio = string.Empty;

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la référence externe trop long.
        /// </summary>
        [Test]
        public void CreerLigne_ReferenceExterneTropLong_LeveException()
        {
            this.parametre.ReferenceExterne = "la reference externe est beaucoup trop long";

            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le service technique null.
        /// </summary>
        [Test]
        public void CreerLigne_ServiceTechniqueNull_LeveException()
        {
            TestDelegate action = () => new Ligne(this.identite, this.parametre, null, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le service externe null.
        /// </summary>
        [Test]
        public void CreerLigne_ServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, null, this.briquesServicesExterne.Object, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec la brique service externe null.
        /// </summary>
        [Test]
        public void CreerLigne_BriqueServiceExterneNull_LeveException()
        {
            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, null, this.repositories.Object);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne avec le repositorie null.
        /// </summary>
        [Test]
        public void CreerLigne_RepositorieNull_LeveException()
        {
            TestDelegate action = () => new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, null);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création d'une ligne.
        /// </summary>
        [Test]
        public void CreerLigne_ParametresValide_OK()
        {
            this.ligne = new Ligne(this.identite, this.parametre, this.serviceTechnique.Object, this.servicesExternes.Object, this.briquesServicesExterne.Object, this.repositories.Object);

            Assert.AreEqual(this.ligne.Cle, this.cle, "erreur Cle");
            Assert.AreEqual(this.ligne.ReferenceExterne, this.parametre.ReferenceExterne, "erreur ReferenceExterne");
            Assert.AreEqual(this.ligne.Numero, this.parametre.Numero, "erreur Numero");
            Assert.AreEqual(this.ligne.CleCompteFacturation, this.parametre.CleCompteFacturation, "erreur CleCompteFacturation");
            Assert.AreEqual(this.ligne.CleGestionnaireOptions, this.parametre.CleGestionnaireOptions, "erreur CleGestionnaireOptions");
            Assert.AreEqual(this.ligne.NumeroContratOperateur, this.parametre.NumeroContratOperateur, "erreur NumeroContratOperateur");
            Assert.AreEqual(this.ligne.CleMarque, this.parametre.CleMarque, "erreur CleMarque");
            Assert.AreEqual(this.ligne.CleAdresseInstallation, this.parametre.CleAdresseInstallation, "erreur CleAdresseInstallation");
            Assert.AreEqual(this.ligne.DateFinEngagement, this.dateFinEngagement, "erreur DateFinEngagement");
            Assert.AreEqual(this.ligne.CleTechnologie, this.parametre.CleTechnologie, "erreur CleTechnologie");
            Assert.AreEqual(this.ligne.CleOffre, this.parametre.CleOffre, "erreur CleOffre");
            Assert.AreEqual(this.ligne.CleTiers, this.parametre.CleTiers, "erreur CleTiers");
            Assert.AreEqual(this.ligne.CleIcn, this.parametre.CleIcn, "erreur CleIcn");
            Assert.AreEqual(this.ligne.SuiviAgentCreation, this.identite.Memoid, "erreur SuiviAgentCreation");
            Assert.AreEqual(this.ligne.ValeurEtat, EtatLigne.Activee, "erreur Etat");
            Assert.AreEqual(this.ligne.ListeKitBox.Count, 1);

            HistoriqueEtatLigne dernierHistorique = this.ligne.ListeHistoriqueEtats.Last();
            Assert.AreEqual(dernierHistorique.NouvelEtat, EtatLigne.Activee, "erreur NouvelEtat");
            Assert.AreEqual(dernierHistorique.AncienEtat, EtatLigne.NA, "erreur AncienEtat");
        }
        #endregion Test Construcetur

        #region Test ModifierStatutSurconsommation
        ///<summary>
        ///Modifier statut surconsommation avec l'identité null
        ///</summary>
        [Test]
        public void ModifierStatutSurconsommation_IdentiteNull_LeveException()
        {
            TestDelegate action = () => this.ligne.ModifierStatutSurconsommation(null, ProfilSurconsommation.NouveauClient);

            Assert.Throws<ArgumentException>(action);
        }
        #endregion Test ModifierStatutSurconsommation

        #region Test RemettreEnService

        /// <summary>
        /// Test de la méthode RemettreEnService avec les paramètres OK.
        /// </summary>
        [Test]
        public void RemettreEnService_ParametreOK_OK()
        {
            //Arrange
            this.ligne.Suspendre(this.identite);
            //Act.
            this.ligne.RemettreEnService(this.identite);

            this.briquesServicesExterne.Verify(s => s.TiersServiceExterne.ObtenirParCle(It.IsAny<Identite>(), It.IsAny<long>()));
            this.servicesExternes.Verify(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(It.IsAny<Identite>(), It.IsAny<int>()));
            this.briquesServicesExterne.Verify(s => s.CommunicationClientServiceExterne.EnvoyerSmsRemiseEnService(It.IsAny<Identite>(), It.IsAny<ParametreSmsRemiseEnService>()));
            //Assert.
            Assert.AreEqual(this.ligne.ValeurEtat, EtatLigne.Activee);
        }

        /// <summary>
        /// Test de la méthode RemettreEnService avec l'identite nulle.
        /// </summary>
        [Test]
        public void RemettreEnService_IdentiteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => this.ligne.RemettreEnService(null);
            //Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test RemettreEnService

        #region Test Suspendre

        /// <summary>
        /// Test de la méthode Suspendre avec les paramètres OK.
        /// </summary>
        [Test]
        public void Suspendre_ParametreOK_OK()
        {
            //Arrange & Act.
            this.ligne.Suspendre(this.identite);
            //Assert.
            Assert.AreEqual(this.ligne.ValeurEtat, EtatLigne.Suspendue);
        }

        /// <summary>
        /// Test de la méthode Suspendre avec l'identite nulle.
        /// </summary>
        [Test]
        public void Suspendre_IdentiteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => this.ligne.Suspendre(null);
            //Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test Suspendre

        #region Test de la méthode CreerDemandeRetractation


        /// <summary>
        /// Verify CreerDemandeRetractation.
        /// </summary>
        [Test]
        public void Verify_CreerDemandeRetractation_ParametreOK_OK()
        {

            Domain.CommonTypes.DTO.DemandeRetractationPourCreation informationsRetractation = new Domain.CommonTypes.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = true,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    EmailTiers = "email",
                    TelephoneMobileTiers = "telephonemobile",
                    Civilite = Fixe.Domain.CommonTypes.Civilite.M,
                    Nom = "nom",
                    Prenom = "prenom",
                    Adresse = new AdressePourSaisie()
                    {
                        CodePostal = "59000",
                        Complement = "APT 59",
                        Ville = "LILLE",
                        Voie = "RUE DE LILLE"
                    }
                }
            };
            int nombreDemandeResiliation = ligne.ListeDemandeResiliation.Count;

            // Act.
            this.ligne.CreerDemandeRetractation(this.identite, informationsRetractation);

            // Assert.
            this.serviceTechnique.Verify(x => x.Parametrage.CleMotifResiliationRetractation);
            this.repositories.Verify(x => x.MotifResiliationRepository.ObtenirDepuisCle(It.IsAny<long>()));
        }

        /// <summary>
        /// Test de la méthode de creation de demande de retractation.
        /// Parametre OK.
        /// Retour OK.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_ParametreOK_OK()
        {

            Domain.CommonTypes.DTO.DemandeRetractationPourCreation informationsRetractation = new Domain.CommonTypes.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = true,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    EmailTiers = "email",
                    TelephoneMobileTiers = "telephonemobile",
                    Civilite = Fixe.Domain.CommonTypes.Civilite.M,
                    Nom = "nom",
                    Prenom = "prenom",
                    Adresse = new AdressePourSaisie()
                    {
                        CodePostal = "59000",
                        Complement = "APT 59",
                        Ville = "LILLE",
                        Voie = "RUE DE LILLE"
                    }
                }
            };
            int nombreDemandeResiliation = ligne.ListeDemandeResiliation.Count;

            // Act.
            this.ligne.CreerDemandeRetractation(this.identite, informationsRetractation);

            // Assert.
            Assert.AreEqual(nombreDemandeResiliation + 1, ligne.ListeDemandeResiliation.Count);
            Assert.AreEqual(identite.Memoid, ligne.SuiviAgentModification);
        }

        /// <summary>
        /// Test de la méthode Retractation avec l'identité null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_IdentiteNull_LeveException()
        {
            //Arrange.
            Domain.CommonTypes.DTO.DemandeRetractationPourCreation informationsRetractation = new Domain.CommonTypes.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = null
            };

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeRetractation(null, informationsRetractation);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Retractation avec les informations null. Lève une exception.
        /// </summary>
        [Test]
        public void CreerDemandeRetractation_DemandeRetractationPourCreationNull_LeveException()
        {
            //Arrange.
            Domain.CommonTypes.DTO.DemandeRetractationPourCreation informationsRetractation = new Domain.CommonTypes.DTO.DemandeRetractationPourCreation()
            {
                DateReceptionCourierAr = DateTime.Now.AddDays(1),
                Email = "email",
                EstNouveauTiersEnvoiBonRetour = false,
                TiersEnvoiBonRetour = null
            };

            // Act.
            TestDelegate action = () => this.ligne.CreerDemandeRetractation(this.identite, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test de la méthode CreerDemandeRetractation

        #region Test KitBoxCourant
        /// <summary>
        /// KitBoxCourant.
        /// </summary>
        [Test]
        public void KitBoxCourant_TouveActif_OK()
        {
            KitBox kitBox = this.ligne.ObtenirKitBoxCourant();

            Assert.IsNotNull(kitBox);
            Assert.IsTrue(kitBox.EstActif);
        }

        /// <summary>
        /// KitBoxCourant avec liste kitbox null.
        /// </summary>
        [Test]
        public void KitBoxCourant_ListeKitBoxNull_LeveException()
        {
            this.ligne.ListeKitBox = null;
            
            Assert.That(() => this.ligne.ObtenirKitBoxCourant(), Throws.ArgumentNullException);
        }

        /// <summary>
        /// KitBoxCourant avec liste kitbox vide.
        /// </summary>
        [Test]
        public void KitBoxCourant_ListeKitBoxVide_LeveException()
        {
            this.ligne.ListeKitBox = new List<KitBox>();

            Assert.That(() => this.ligne.ObtenirKitBoxCourant(), Throws.Exception);
        }

        /// <summary>
        /// KitBoxCourant avec liste kitbox contenant plusieur actif.
        /// </summary>
        [Test]
        public void KitBoxCourant_ListeKitBoxPlusieurActif_LeveException()
        {
            this.ligne.ListeKitBox.Add(new KitBox(this.identite,2,2));

            Assert.That(() => this.ligne.ObtenirKitBoxCourant(), Throws.Exception);
        }
        #endregion Test KitBoxCourant
    }
}
