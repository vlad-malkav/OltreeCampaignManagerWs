﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using Moq;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet métier DemandeResilisation.
    /// </summary>
    [TestFixture]
    public partial class DemandeResiliationTest
    {
        #region Initialisateur

        /// <summary>
        /// Initialise un objet DemandeResiliation dans l'état "EnCours". 
        /// </summary>
        /// <returns>L'objet DemandeResiliation.</returns>
        public DemandeResiliation InitialiserEtatEnCours()
        {
            DemandeResiliationPourCreation informationsDemandeResiliation = new DemandeResiliationPourCreation()
            {
                DateResiliationProgrammee = DateTime.Now.AddDays(-1),
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourSaisie()
                }
            };

            DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

            return demandeResiliation;
        }

        #endregion Initialisateur

        #region Tests de la méthode Annuler dans l'état "EnCours"

        /// <summary>
        /// Test de la méthode Annuler dans l'état "EnCours" avec une identité null. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursAnnuler_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.Annuler(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Annuler dans l'état "EnCours" avec les paramètres OK.
        /// </summary>
        [Test]
        public void EtatEnCoursAnnuler_ParametreOk_Ok()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            demandeResiliation.Annuler(this.identiteValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.servicesExternes.Verify(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identiteValide, It.IsAny<long>(), It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
            this.briquesExternes.Verify(x => x.CommunicationClientServiceExterne.EnvoyerMailAnnulerResiliation(this.identiteValide, It.IsAny<ParametresEmailAnnulerResiliation>()));
            Assert.AreEqual(this.identiteValide.Memoid, demandeResiliation.SuiviAgentModification);
        }

        #endregion Tests de la méthode Annuler dans l'état "EnCours"

        #region Tests de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours"

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec une identité null. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.DefinirNumeroRetourEquipement(null, this.CleDemandeRetourEquipementValide, this.NumeroRetourEquipementValide);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec une cle de demande de retour équipement à zéro. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_CleDemandeRetourEquipementAZero_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, 0, this.NumeroRetourEquipementValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec une clé de demande de retour équipement négative. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_CleDemandeRetourEquipementNegative_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, -400, this.NumeroRetourEquipementValide);

            // Assert.
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec une un numéro de retour équipement vide. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_NumeroRetourEquipementValideVide_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, "");

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec un numéro de retour équipement null. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_NumeroRetourEquipementValideNull_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours" avec les paramètres OK.
        /// </summary>
        [Test]
        public void EtatEnCoursDefinirNumeroRetourEquipement_ParametresOK_OK()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, this.NumeroRetourEquipementValide);

            // Assert.
            Assert.AreEqual(this.CleDemandeRetourEquipementValide, demandeResiliation.CleDemandeRetourEquipement);
            Assert.AreEqual(this.NumeroRetourEquipementValide, demandeResiliation.NumeroRetourEquipement);
            Assert.AreEqual(identiteValide.Memoid, demandeResiliation.SuiviAgentModification);
        }

        #endregion Tests de la méthode DefinirNumeroRetourEquipement dans l'état "EnCours"

        #region Tests de la méthode Traiter dans l'état "EnCours"

        /// <summary>
        /// Test de la méthode Traiter dans l'état "EnCours" avec une identité null. Lève une exception.
        /// </summary>
        [Test]
        public void EtatEnCoursTraiter_IdentiteNull_LeveException()
        {
            // Arrange.
            DemandeResiliation demandeResiliation = this.InitialiserEtatEnCours();

            // Act.
            TestDelegate action = () => demandeResiliation.Traiter(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode Traiter dans l'état "EnCours" les paramètres Ok. Dans le cas où la date de résiliation programmée est future.
        /// </summary>
        [Test]
        public void EtatEnCoursTraiter_SiDateResiliationProgrammeeFuture_Ok()
        {
            // Arrange.
            long CleLigneValide2 = 111;
            DemandeResiliationPourCreation informationsDemandeResiliation = new DemandeResiliationPourCreation()
            {
                DateResiliationProgrammee = DateTime.Now.AddDays(1),
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourSaisie()
                }
            };

            Mock<Ligne> ligne = new Mock<Ligne>();
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(CleLigneValide2)).Returns(ligne.Object);

            DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, CleLigneValide2, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

            // Act.
            demandeResiliation.Traiter(this.identiteValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(CleLigneValide2));
            ligne.Verify(x => x.Resilier(this.identiteValide), Times.Never);
        }

        /// <summary>
        /// Test de la méthode Traiter dans l'état "EnCours" les paramètres Ok. Dans le cas ou la date de résiliation programée est passée.
        /// </summary>
        [Test]
        public void EtatEnCoursTraiter_SiDateResiliationProgrammeePassee_Ok()
        {
            // Arrange.
            long CleLigneValide2 = 111;
            DemandeResiliationPourCreation informationsDemandeResiliation = new DemandeResiliationPourCreation()
            {
                DateResiliationProgrammee = DateTime.Now.AddDays(-1),
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                TiersEnvoiBonRetour = new TiersPourEnvoiBonRetour()
                {
                    Adresse = new AdressePourSaisie()
                }
            };

            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(x => x.CleTiers).Returns(this.CleTiersValide);
            ligne.Setup(x => x.CleMarque).Returns(this.CleMarqueValide);
            ligne.Setup(x => x.CleOffre).Returns(this.CleOffreValide);
            ligne.Setup(x => x.ReferenceExterne).Returns(this.ReferenceExterneValide);
            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(CleLigneValide2)).Returns(ligne.Object);
            this.repositories.Setup(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide)).Returns(new ModeRetourEquipement());

            DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, CleLigneValide2, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);
            demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, this.NumeroRetourEquipementValide);

            // Act.
            demandeResiliation.Traiter(this.identiteValide);

            // Assert.
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(CleLigneValide2));
            ligne.Verify(x => x.Resilier(this.identiteValide));
        }

        #endregion Tests de la méthode Traiter dans l'état "EnCours"
    }
}
