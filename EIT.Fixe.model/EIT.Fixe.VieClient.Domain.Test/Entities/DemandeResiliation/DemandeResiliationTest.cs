﻿using System;
using EIT.Fixe.Systeme.Identification;
using Moq;
using NUnit.Framework;
using EIT.Fixe.Systeme.Tests;
using EIT.Fixe.VieClient.Domain.ServiceExterne;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.ServiceExterne.InterfacesDeParametres;
using EIT.Fixe.VieClient.Domain.Repositories.Interfaces;
using EIT.Fixe.VieClient.Domain.Entities.Ligne;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Systeme.Persistance;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet métier DemandeResilisation.
    /// </summary>
    [TestFixture]
    public partial class DemandeResiliationTest
    {
        #region Propriétés 

        /// <summary>
        /// Interface des services techniques.
        /// </summary>
        private Mock<IServicesTechniques> servicesTechniques { get; set; }

        /// <summary>
        /// Interface des services externes
        /// </summary>
        private Mock<IServicesExternes> servicesExternes { get; set; }

        /// <summary>
        /// Interface des repositories.
        /// </summary>
        private Mock<IRepositories> repositories { get; set; }

        /// <summary>
        /// Interface des briques externes.
        /// </summary>
        private Mock<IBriquesServicesExternes> briquesExternes { get; set; }

        /// <summary>
        /// Retourne une identité valide.
        /// </summary>
        private Identite identiteValide { get; set; }

        /// <summary>
        /// Retourne une clé d'équipement ligne valide.
        /// </summary>
        private long CleEquipementLigneValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de ligne valide.
        /// </summary>
        private long CleLigneValide
        {
            get
            {
                return 10;
            }
        }

        /// <summary>
        /// Retourne une clé de demande de résiliation valide.
        /// </summary>
        private long CleDemandeResiliationValide
        {
            get
            {
                return 100;
            }
        }

        /// <summary>
        /// Retourne une clé d'équipement valide.
        /// </summary>
        private long CleEquipementValide
        {
            get
            {
                return 1000;
            }
        }

        /// <summary>
        /// Retourne une clé valide d'un mode retour équipement.
        /// </summary>
        private long CleModeRetourEquipementValide
        {
            get
            {
                return 10000;
            }
        }

        /// <summary>
        /// Retourne une clé valide d'une demande de retour équipement.
        /// </summary>
        private long CleDemandeRetourEquipementValide
        {
            get
            {
                return 100000;
            }
        }

        /// <summary>
        /// Retourne une clé valide d'une marque.
        /// </summary>
        private int CleMarqueValide
        {
            get
            {
                return 1000000;
            }
        }

        /// <summary>
        /// Retourne une clé valide d'un tiers.
        /// </summary>
        private long CleTiersValide
        {
            get
            {
                return 10000000;
            }
        }

        /// <summary>
        /// Retourne une clé valide d'une offre.
        /// </summary>
        private int CleOffreValide
        {
            get
            {
                return 100000000;
            }
        }

        /// <summary>
        /// Retourne une référence externe valide.
        /// </summary>
        private string ReferenceExterneValide
        {
            get
            {
                return "ReferenceExterne";
            }
        }

        /// <summary>
        /// Retourne un numéro de retour équipement valide.
        /// </summary>
        private string NumeroRetourEquipementValide
        {
            get
            {
                return "0606060606";
            }
        }

        /// <summary>
        /// Retourne un code ref com valide.
        /// </summary>
        private string CodeRefComValide
        {
            get
            {
                return "CodeRefCom";
            }
        }

        #endregion Propriétés

        #region Méthodes d'initialisation et de vérification

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identiteValide = new Identite() { Memoid = "MemoId" };
            this.InitialiserServiceTechnique();
            this.InitialiserBriquesExternes();
            this.InitialiserServicesExternes();
            this.InitialiserRepositories();
        }

        /// <summary>
        /// Initalise les repositories.
        /// </summary>
        private void InitialiserRepositories()
        {
            this.repositories = new Mock<IRepositories>();
            this.repositories.Setup(x => x.ModeRetourEquipementRepository).Returns(new Mock<IModeRetourEquipementRepository>().Object);

            Mock<Ligne> ligne = new Mock<Ligne>();
            ligne.Setup(x => x.CleTiers).Returns(this.CleTiersValide);
            ligne.Setup(x => x.CleMarque).Returns(this.CleMarqueValide);
            ligne.Setup(x => x.CleOffre).Returns(this.CleOffreValide);
            ligne.Setup(x => x.ReferenceExterne).Returns(this.ReferenceExterneValide);
            ligne.Setup(x => x.ListeHistoriqueEtats).Returns(new List<HistoriqueEtatLigne>()
            {
                new HistoriqueEtatLigne(this.identiteValide, 2687498, EtatLigne.Activee, EtatLigne.Resiliee)
            });

            this.repositories.Setup(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide)).Returns(ligne.Object);


            this.repositories.Setup(x => x.MotifResiliationRepository.ObtenirDepuisCle(It.IsAny<long>())).Returns(new MotifResiliation() { CodeArticle = "1234" });
        }

        /// <summary>
        /// Initialise les services externes.
        /// </summary>
        private void InitialiserServicesExternes()
        {
            this.servicesExternes = new Mock<IServicesExternes>();
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne).Returns(new Mock<IReferentielServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirMarqueParCle(this.identiteValide, this.CleMarqueValide)).Returns(new Mock<CommonTypes.DTO.Marque>().Object);
            this.servicesExternes.Setup(x => x.ReferentielServiceExterne.ObtenirOffreParCle(this.identiteValide, this.CleOffreValide)).Returns(new Mock<OffrePourDetail>().Object);

            this.servicesExternes.Setup(x => x.LogistiqueServiceExterne).Returns(new Mock<ILogistiqueServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.LogistiqueServiceExterne.GererCommandeRetourEquipement(this.identiteValide, this.ReferenceExterneValide, It.IsAny<CommonTypes.DTO.CommandeRetourEquipementPourCreation>()));

            this.servicesExternes.Setup(x => x.HistoriqueServiceExterne).Returns(new Mock<IHistoriqueServiceExterne>().Object);
            this.servicesExternes.Setup(x => x.HistoriqueServiceExterne.CreerHistoriqueFonctionnelPourLigne(this.identiteValide, this.CleLigneValide ,It.IsAny<Domain.CommonTypes.DTO.HistoriquesServiceExterne.HistoriquePourCreation>()));
        }

        /// <summary>
        /// Initialise les briques externes.
        /// </summary>
        private void InitialiserBriquesExternes()
        {
            this.briquesExternes = new Mock<IBriquesServicesExternes>();

            this.briquesExternes.Setup(x => x.CommunicationClientServiceExterne).Returns(new Mock<ICommunicationClientServiceExterne>().Object);
            this.briquesExternes.Setup(x => x.CommunicationClientServiceExterne.EnvoyerMailConfirmerResiliationSansEtiquette(this.identiteValide, It.IsAny<ParametresEmailConfirmerResiliationSansEtiquette>()));
            this.briquesExternes.Setup(x => x.CommunicationClientServiceExterne.EnvoyerMailAnnulerResiliation(this.identiteValide, It.IsAny<ParametresEmailAnnulerResiliation>()));


            TiersPourDetail tiers = new TiersPourDetail()
            {
                ListeAdresses = new List<AdresseTiers>()
                {
                    new AdresseTiers()
                    {
                        EstPrincipale = true
                    }
                }
            };
            
            this.briquesExternes.Setup(x => x.TiersServiceExterne).Returns(new Mock<ITiersServiceExterne>().Object);
            this.briquesExternes.Setup(x => x.TiersServiceExterne.ObtenirParCle(this.identiteValide, this.CleTiersValide)).Returns(tiers);
        }

    /// <summary>
    /// Initialisation du serviceTechniques
    /// </summary>
    private void InitialiserServiceTechnique()
    {
        GenerateurCles generateurCles = new GenerateurCles();
        Mock<IParametrage> parametrage = new Mock<IParametrage>();
        Mock<IGenerateurSequences> generateurSequence = new Mock<IGenerateurSequences>();

        this.servicesTechniques = new Mock<IServicesTechniques>();
        generateurSequence.Setup(x => x.ObtenirEntier(It.IsAny<string>())).Returns(1);
        this.servicesTechniques.Setup(s => s.GenerateurSequences).Returns(generateurSequence.Object);
        this.servicesTechniques.Setup(s => s.GenerateurCles).Returns(generateurCles);
        this.servicesTechniques.Setup(s => s.Parametrage).Returns(parametrage.Object);
    }

    #endregion Méthodes d'initialisation et de vérification

    #region Tests de l'initialisation de l'objet

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où l'identité est null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_IdentiteNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(null, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où la clé équipement de ligne est à zéro. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_CleEquipementLigneAZero_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, 0, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentOutOfRangeException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où la clé équipement de ligne est négative. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_CleEquipementLigneNegative_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, -400, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentOutOfRangeException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où la clé de ligne est à zéro. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_CleLigneAZero_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, 0, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentOutOfRangeException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où la clé de ligne est négative. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_CleLigneNegative_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, -400, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentOutOfRangeException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où la DemandeResiliationPourCreation est à null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_DemandeResiliationPourCreationNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = null;

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où IRepositoriers est à null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_RepositoriesNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, null, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où IServicesExternes est à null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_ServicesExternesNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, null, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où IServicesTechniques est à null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_ServicesTechniquesNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, null, this.briquesExternes.Object);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où IBriquesExternes est à null. Lève une exception.
    /// </summary>
    [Test]
    public void DemandeResiliation_BriquesExternesNull_LeveException()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        TestDelegate action = () => new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, null);

        // Assert.
        Assert.Throws<ArgumentException>(action);
    }

    /// <summary>
    /// Test du constructeur de DemandeResiliation dans le cas où les paramètres sont ok.
    /// </summary>
    [Test]
    public void TiersService_ParametresOK_OK()
    {
        // Arrange.
        CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
        {
            TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
            {
                Adresse = new CommonTypes.DTO.AdressePourSaisie()
            }
        };

        // Act.
        DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

        // Assert.
        Assert.AreEqual(this.CleDemandeResiliationValide, demandeResiliation.Cle);
        //Assert.AreEqual(this.CleLigneValide, demandeResiliation.Ligne);
        Assert.AreEqual(this.identiteValide.Memoid, demandeResiliation.SuiviAgentCreation);
        Assert.AreEqual(this.identiteValide.Memoid, demandeResiliation.SuiviAgentCreation);
    }

    #endregion Tests de l'initialisation de l'objet
}
}
