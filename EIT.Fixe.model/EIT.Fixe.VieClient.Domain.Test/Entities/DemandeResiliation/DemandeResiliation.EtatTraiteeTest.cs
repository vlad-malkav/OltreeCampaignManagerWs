﻿using System;
using Moq;
using NUnit.Framework;
using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using EIT.Fixe.VieClient.Domain.Entities;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet métier DemandeResilisation.
    /// </summary>
    [TestFixture]
    public partial class DemandeResiliationTest
    {
        #region Initialisateur

        /// <summary>
        /// Initialise un objet DemandeResiliation dans l'état "Traitee". 
        /// </summary>
        /// <returns>L'objet DemandeResiliation.</returns>
        public DemandeResiliation InitialiserEtatTraitee()
        {
            CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                DateResiliationProgrammee = DateTime.Now.AddDays(-1),
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new CommonTypes.DTO.AdressePourSaisie()
                },
                CleMotifResiliation = 1
            };

            DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

            // Passage de l'état "Encours" à l'état "Traitee"
            demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, this.NumeroRetourEquipementValide);
            demandeResiliation.Traiter(this.identiteValide);

            return demandeResiliation;
        }

        #endregion Initialisateur

        #region Tests de la méthode GererRetourEquipement dans l'état "Traitee"

        /// <summary>
        /// Test de la méthode GererRetourEquipement dans l'état "Traitee" avec une identité null. Lève une exception.
        /// </summary>
        [Test]
        public void EtatTraiteeGererRetourEquipement_IdentiteNull_LeveException()
        {
            // Arrange.
            this.repositories.Setup(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide)).Returns(new ModeRetourEquipement());
            DemandeResiliation demandeResiliation = this.InitialiserEtatTraitee();

            // Act.
            TestDelegate action = () => demandeResiliation.GererRetourEquipement(null);

            // Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test de la méthode GererRetourEquipement dans l'état "Traitee" avec les paramètres OK et un mode retour avec EstEnvoiEtiquettePrepayee à true.
        /// </summary>
        [Test]
        public void EtatTraiteeGererRetourEquipement_ParametresOKEstEnvoiEtiquettePrepayeeTrue_OK()
        {
            // Arrange.
            this.repositories.Setup(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide)).Returns(new ModeRetourEquipement()
            {
                EstEnvoiEtiquettePrepayee = true,
            });
            DemandeResiliation demandeResiliation = this.InitialiserEtatTraitee();

            // Act.
            demandeResiliation.GererRetourEquipement(this.identiteValide);

            // Assert.
            this.repositories.Verify(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide));
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesExternes.Verify(x => x.CommunicationClientServiceExterne.EnvoyerMailConfirmerResiliationAvecEtiquette(this.identiteValide, It.IsAny<ParametresEmailConfirmerResiliationAvecEtiquette>()));
        }

        /// <summary>
        /// Test de la méthode GererRetourEquipement dans l'état "Traitee" avec les paramètres OK et un mode retour avec EstEnvoiEtiquettePrepayee à false.
        /// </summary>
        [Test]
        public void EtatTraiteeGererRetourEquipement_ParametresOKEstEnvoiEtiquettePrepayeeFalse_OK()
        {
            // Arrange.
            this.repositories.Setup(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide)).Returns(new ModeRetourEquipement()
            {
                EstEnvoiEtiquettePrepayee = false,
            });
            DemandeResiliation demandeResiliation = this.InitialiserEtatTraitee();

            // Act.
            demandeResiliation.GererRetourEquipement(this.identiteValide);

            // Assert.
            this.repositories.Verify(x => x.ModeRetourEquipementRepository.ObtenirDepuisCle(this.CleModeRetourEquipementValide));
            this.repositories.Verify(x => x.LigneRepository.ObtenirDepuisCle(this.CleLigneValide));
            this.briquesExternes.Verify(x => x.CommunicationClientServiceExterne.EnvoyerMailConfirmerResiliationSansEtiquette(this.identiteValide, It.IsAny<ParametresEmailConfirmerResiliationSansEtiquette>()));
            this.briquesExternes.Verify(x => x.CommunicationClientServiceExterne.EnvoyerCourrierConfirmerResiliationSansEtiquette(this.identiteValide, It.IsAny<ParametresCourrierConfirmerResiliationSansEtiquette>()));
            Assert.AreEqual(this.identiteValide.Memoid, demandeResiliation.SuiviAgentModification);
        }

        #endregion Tests de la méthode GererRetourEquipement dans l'état "Traitee"
    }
}
