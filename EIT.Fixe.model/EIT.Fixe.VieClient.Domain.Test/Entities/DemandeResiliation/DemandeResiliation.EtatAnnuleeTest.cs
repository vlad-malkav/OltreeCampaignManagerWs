﻿using EIT.Fixe.VieClient.Domain.Entities.DemandeResiliation;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet métier DemandeResilisation.
    /// </summary>
    [TestFixture]
    public partial class DemandeResiliationTest
    {
        #region Initialisateur

        /// <summary>
        /// Initialise un objet DemandeResiliation dans l'état "Annulee". 
        /// </summary>
        /// <returns>L'objet DemandeResiliation.</returns>
        public DemandeResiliation InitialiserEtatAnnulee()
        {
            CommonTypes.DTO.DemandeResiliationPourCreation informationsDemandeResiliation = new CommonTypes.DTO.DemandeResiliationPourCreation()
            {
                DateResiliationProgrammee = DateTime.Now.AddDays(-1),
                CleModeRetourEquipement = this.CleModeRetourEquipementValide,
                TiersEnvoiBonRetour = new CommonTypes.DTO.TiersPourEnvoiBonRetour()
                {
                    Adresse = new CommonTypes.DTO.AdressePourSaisie()
                }
            };

            DemandeResiliation demandeResiliation = new DemandeResiliation(this.identiteValide, this.CleDemandeResiliationValide, this.CleLigneValide, informationsDemandeResiliation, this.repositories.Object, this.servicesExternes.Object, this.servicesTechniques.Object, this.briquesExternes.Object);

            // Passage de l'état "Encours" à l'état "Annulee"
            demandeResiliation.DefinirNumeroRetourEquipement(this.identiteValide, this.CleDemandeRetourEquipementValide, this.NumeroRetourEquipementValide);
            demandeResiliation.Annuler(this.identiteValide);

            return demandeResiliation;
        }

        #endregion Initialisateur
    }
}
