﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using System.Linq;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet GroupeFonctionnalites.
    /// </summary>
    [TestFixture]
    public class GroupeFonctionnalitesTest
    {
        private Identite identite;
        private GroupeFonctionnalites groupeFonctionnalite;
        private ParametreGroupeFonctionnalitesPourCreation parametreGroupeFonctionnalites;
        private ParametreFonctionnalitePourCreation parametreFonctionnalite;

        #region Initialisation

        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametreGroupeFonctionnalites = new ParametreGroupeFonctionnalitesPourCreation()
            {
                Cle = 1,
                Code = "Code",
                Description = "Desciption",
                Libelle = "Libelle"
            };

            this.parametreFonctionnalite = new ParametreFonctionnalitePourCreation()
            {
                Cle = 1,
                Code = "Code",
                Description = "Description",
                EstActif = true                
            };

            this.groupeFonctionnalite = new GroupeFonctionnalites(this.identite, this.parametreGroupeFonctionnalites, null);
        }

        #endregion Initialisation

        #region Test Constructeur

        /// <summary>
        /// Test du constructeur avec les paramètres OK.
        /// </summary>
        [Test]
        public void CreerGroupeFonctionnalites_ParametreOK_OK()
        {
            //Arrange & Act.
            GroupeFonctionnalites groupeFct = new GroupeFonctionnalites(this.identite, this.parametreGroupeFonctionnalites, null);

            //Assert.
            Assert.AreEqual(groupeFct.Cle, this.groupeFonctionnalite.Cle);
            Assert.AreEqual(groupeFct.Code, this.groupeFonctionnalite.Code);
            Assert.AreEqual(groupeFct.Description, this.groupeFonctionnalite.Description);
            Assert.AreEqual(groupeFct.Libelle, this.groupeFonctionnalite.Libelle);
        }

        /// <summary>
        /// Test du constructeur avec l'identite nulle.
        /// </summary>
        [Test]
        public void CreerGroupeFonctionnalites_IdentiteNulle_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new GroupeFonctionnalites(null, this.parametreGroupeFonctionnalites, null);

            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Test du constructeur avec le parametre groupe null.
        /// </summary>
        [Test]
        public void CreerGroupeFonctionnalites_ParametreGroupeFonctionnaliteNull_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => new GroupeFonctionnalites(this.identite, null, null);

            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test Constructeur

        #region Test AjouterFonctionnalite

        /// <summary>
        /// Test de la méthode AjouterFonctionnalite avec les parametres OK.
        /// </summary>
        [Test]
        public void AjouterFonctionnalite_ParametreOK_OK()
        {
            //Arrange.
            Fonctionnalite fct = new Fonctionnalite(this.identite, this.parametreFonctionnalite);
            //Act.
            this.groupeFonctionnalite.AjouterFonctionnalite(fct);
            //Assert.
            Assert.Contains(fct, this.groupeFonctionnalite.ListeFonctionnalites.ToList());
        }

        /// <summary>
        /// Test de la méthode AjouterFonctionnalite avec le pamarètre null.
        /// </summary>
        [Test]
        public void AjouterFonctionnalite_ParametreNull_ExceptionLevee()
        {
            //Arrange & Act.
            TestDelegate action = () => this.groupeFonctionnalite.AjouterFonctionnalite(null);
            //Assert.
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Test AjouterFonctionnalite

        #region Test Desactiver

        /// <summary>
        /// Test de la méthode désactiver.
        /// </summary>
        [Test]
        public void Desactiver_OK()
        {
            //Arrange & Act
            this.groupeFonctionnalite.Desactiver(identite);

            //Assert
            Assert.AreEqual(this.groupeFonctionnalite.EstActif, false);
        }

        #endregion Test Desactiver

    }
}
