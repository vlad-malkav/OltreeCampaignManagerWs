﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet PanneCollective.
    /// </summary>
    [TestFixture]
    public class PanneCollectiveTest
    {
        private Identite identite;
        private PanneCollective panne;
        private long cle;
        private DateTime dateDebut;
       

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };
            this.cle = 1;
            this.dateDebut = DateTime.Now;
          

            this.panne = new PanneCollective(this.identite, this.cle, this.dateDebut);
        }

        #region Test Constructeur
        /// <summary>
        /// Creation d'une panne collective avec la identite null.
        /// </summary>
        [Test]
        public void CreerPanneCollective_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new PanneCollective(null, cle, this.dateDebut);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'une panne collective avec la clé null.
        /// </summary>
        [Test]
        public void CreerPanneCollective_CleNull_LeveException()
        {
            long cle = 0;
            TestDelegate action = () => new PanneCollective(this.identite, cle, this.dateDebut);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'une panne collective avec la clé invalide.
        /// </summary>
        [Test]
        public void CreerPanneCollective_CleInvalide_LeveException()
        {
            long cleInvalide = -1;
            TestDelegate action = () => new PanneCollective(this.identite, cleInvalide, this.dateDebut);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'une panne collective avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerPanneCollective_ParametresValide_OK()
        {
          
            this.panne =  new PanneCollective(this.identite, this.cle, this.dateDebut);

            Assert.AreEqual(this.panne.Cle, this.cle, "erreur Cle");
            
        }
        #endregion Test Constructeur
    }
}
