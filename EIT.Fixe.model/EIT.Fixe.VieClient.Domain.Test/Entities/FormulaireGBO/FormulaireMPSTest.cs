﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet FormulaireMPS.
    /// </summary>
    [TestFixture]
    class FormulaireMPSTest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.FormulaireMPS formulaireMPS;
        private ParametresCreationFormulaireMPS parametresCreationFormulaireMPS;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };

            this.parametresCreationFormulaireMPS = GenerateParametresCreationFormulaireMPSOk();

            this.formulaireMPS = new Domain.Entities.FormulaireGBO.FormulaireMPS(
                this.identite, this.parametresCreationFormulaireMPS);
        }

        public ParametresCreationFormulaireMPS GenerateParametresCreationFormulaireMPSOk()
        {
            return new ParametresCreationFormulaireMPS(
                GenerateParametresCreationFormulaireGboOk(),
                GenerateInformationsClientPourCreation(),
                DateTime.Now,
                ProfilSurconsommation.ClientStandard,
                "Commentaire");
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk()
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire de niveau 1 de demande de modification du profil de surconsommation avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_ParametresValide_Ok()
        {
            this.formulaireMPS = new Domain.Entities.FormulaireGBO.FormulaireMPS(this.identite, this.parametresCreationFormulaireMPS);

            Assert.AreEqual(this.formulaireMPS.ReferenceExterne,
                this.formulaireMPS.ReferenceExterne, "erreur ReferenceExterne");
            Assert.AreEqual(this.formulaireMPS.NomClient,
                this.formulaireMPS.NomClient, "erreur NomClient");
            Assert.AreEqual(this.formulaireMPS.PrenomClient,
                this.formulaireMPS.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.formulaireMPS.DateEffetDemande,
                this.formulaireMPS.DateEffetDemande, "erreur DateEffetDemande");
            Assert.AreEqual(this.formulaireMPS.ProfilSurconsoDemande,
                this.formulaireMPS.ProfilSurconsoDemande, "erreur ProfilSurconsoDemande");
            Assert.AreEqual(this.formulaireMPS.Commentaire,
                this.formulaireMPS.Commentaire, "erreur Commentaire");
        }

        #endregion

        #region Tests Spécifiques

        #region Paramètre - InformationsClientPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 1 de demande de modification du profil de surconsommation avec ParametresCreationFormulaireInformationsClientPourCreation.InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_InformationsClientPourCreationNull_LeveException()
        {
            parametresCreationFormulaireMPS.InformationsClientPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireMPS(this.identite, this.parametresCreationFormulaireMPS);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Paramètre - InformationsClientPourCreation

        #region Attribut - ParametresCreation.DateEffetDemande

        /// <summary>
        /// Creation d'un Formulaire de niveau 1 de demande de modification du profil de surconsommation avec ParametresCreationFormulaireMPS.DateEffetDemande Null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_DateEffetDemandeNull_LeveException()
        {
            parametresCreationFormulaireMPS.DateEffetDemande = default(DateTime);
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireMPS(this.identite, this.parametresCreationFormulaireMPS);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.Commentaire

        /// <summary>
        /// Creation d'un Formulaire de niveau 1 de demande de modification du profil de surconsommation avec ParametresCreationFormulaireMPS.InformationsClientPourCreation.Commentaire Null.
        /// </summary>
        [Test]
        public void CreerFormulaireMps_CommentaireNull_LeveException()
        {
            parametresCreationFormulaireMPS.Commentaire = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireMPS(this.identite, this.parametresCreationFormulaireMPS);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #endregion

        #endregion
    }
}
