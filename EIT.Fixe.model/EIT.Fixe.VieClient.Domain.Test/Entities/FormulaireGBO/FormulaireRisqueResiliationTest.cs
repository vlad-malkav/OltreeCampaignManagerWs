﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet FormulaireRisqueResiliation.
    /// </summary>
    [TestFixture]
    public class FormulaireRisqueResiliationTest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation formulaireRisqueResiliation;
        private ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }


        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametresCreationFormulaireRisqueResiliation = GenerateParametresCreationFormulaireRisqueResiliationOk();

            this.formulaireRisqueResiliation = new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(
                this.identite, parametresCreationFormulaireRisqueResiliation);
        }

        public ParametresCreationFormulaireRisqueResiliation GenerateParametresCreationFormulaireRisqueResiliationOk()
        {
            return new ParametresCreationFormulaireRisqueResiliation(
                GenerateParametresCreationFormulaireGboOk(),
                GenerateInformationsClientPourCreation(),
                "Offre",
                new MotifQualification(this.identite, 1, "MotifQualification-1"),
                "Commentaire");
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk()
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire de niveau 4 de risque de résiliation avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_ParametresValide_OK()
        {
            this.formulaireRisqueResiliation = new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(this.identite, this.parametresCreationFormulaireRisqueResiliation);
            
            Assert.AreEqual(this.formulaireRisqueResiliation.NomClient,
                this.parametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation.NomClient, "erreur NomClient");
            Assert.AreEqual(this.formulaireRisqueResiliation.PrenomClient,
                this.parametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.formulaireRisqueResiliation.OffreClient,
                this.parametresCreationFormulaireRisqueResiliation.OffreClient, "erreur OffreClient");
            Assert.AreEqual(this.formulaireRisqueResiliation.MotifQualification,
                this.parametresCreationFormulaireRisqueResiliation.MotifQualification, "erreur MotifQualification");
            Assert.AreEqual(this.formulaireRisqueResiliation.Commentaire,
                this.parametresCreationFormulaireRisqueResiliation.Commentaire, "erreur Commentaire");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Paramètre - InformationsClientPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 4 de risque de résiliation avec ParametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_InformationsClientPourCreationNull_LeveException()
        {
            parametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(this.identite, this.parametresCreationFormulaireRisqueResiliation);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Paramètre - InformationsClientPourCreation

        #region Attribut - ParametresCreation.MotifMotifQualification

        /// <summary>
        /// Creation d'un Formulaire de niveau 4 de risque de résiliation avec ParametresCreation.MotifQualification Null.
        /// </summary>
        [Test]
        public void CreerFormulaireRisqueResiliation_MotifQualificationNull_LeveException()
        {
            parametresCreationFormulaireRisqueResiliation.MotifQualification = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireRisqueResiliation(this.identite, this.parametresCreationFormulaireRisqueResiliation);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Attribut - ParametresCreation.MotifDysfonctionnement

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
