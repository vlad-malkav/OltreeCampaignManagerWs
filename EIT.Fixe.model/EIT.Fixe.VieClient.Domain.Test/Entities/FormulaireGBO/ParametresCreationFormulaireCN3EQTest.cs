﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    [TestFixture]
    class ParametresCreationFormulaireCN3EQTest
    {
        private Identite identite;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;
        private ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ;
        private InformationsCdcPourCreation informationsCDCPourCreation;
        private InformationsSupplementairesCN3EqPourCreation informationsSupplementairesCN3EqPourCreation;
        private NatureDemandeIntervention natureDemandeIntervention;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };

            this.informationsCDCPourCreation = GenerateInformationsCdcPourCreation();

            this.parametresCreationFormulaireGBO = new ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                this.informationsCDCPourCreation,
                "THD0123456789");

            this.informationsSupplementairesCN3EqPourCreation = GenerateInformationsSupplementairesCN3EqPourCreation();

            this.natureDemandeIntervention = new NatureDemandeIntervention(this.identite, 1, "NatureDemandeIntervention-1");

            this.parametresCreationFormulaireCN3EQ = new ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);
        }

        public InformationsCdcPourCreation GenerateInformationsCdcPourCreation()
        {
            return new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };
        }

        public InformationsSupplementairesCN3EqPourCreation GenerateInformationsSupplementairesCN3EqPourCreation()
        {
            return new InformationsSupplementairesCN3EqPourCreation
            {
                NumeroSuiviDossier = "12345",
                DateReponseCelluleN2 = DateTime.Now,
                RaisonContestation = "Raison",
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ de base avec ParametresCreationFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_ParametresCreationFormulaireGboNull_LeveException()
        {
            this.parametresCreationFormulaireGBO = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            Assert.Throws<NullReferenceException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ de base avec InformationsSupplementairesCN3EqPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_InformationsSupplementairesCN3EqPourCreationNull_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ de base avec NatureDemandeIntervention Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_NatureDemandeInterventionNull_LeveException()
        {
            this.natureDemandeIntervention = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_ParametresValide_OK()
        {
            this.parametresCreationFormulaireCN3EQ = new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.Cle,
                this.parametresCreationFormulaireGBO.Cle, "erreur Cle");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.CleDossierGbo,
                this.parametresCreationFormulaireGBO.CleDossierGbo, "erreur CleDossierGbo");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsCdcPourCreation.CdcAdresseMail,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsCdcPourCreation.CdcCodeBanque,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsCdcPourCreation.CdcCodeBranche,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsCdcPourCreation.CdcLigneDirecte,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsCdcPourCreation.CdcNomPrenom,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2,
                this.informationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2, "erreur DateReponseCelluleN2");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient,
                this.informationsSupplementairesCN3EqPourCreation.DemandeClient, "erreur DemandeClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier,
                this.informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier, "erreur NumeroSuiviDossier");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation,
                this.informationsSupplementairesCN3EqPourCreation.RaisonContestation, "erreur RaisonContestation");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees,
                this.informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees, "erreur SolutionsDejaApportees");
            Assert.AreEqual(this.parametresCreationFormulaireCN3EQ.NatureDemandeIntervention,
                this.natureDemandeIntervention, "erreur NatureDemandeIntervention");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_NumeroSuiviDossierNull_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_NumeroSuiviDossierVide_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2 Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_DateReponseCelluleN2Null_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2 = default(DateTime);

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - InformationsSupplementairesCN3EqPourCreation.RaisonContestation

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.RaisonContestation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_RaisonContestationNull_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.RaisonContestation = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.RaisonContestation vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_RaisonContestationVide_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.RaisonContestation = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - InformationsSupplementairesCN3EqPourCreation.DemandeClient

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.DemandeClient Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_DemandeClientNull_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.DemandeClient = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_DemandeClientVide_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.DemandeClient = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_SolutionsDejaApporteesNull_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN3EQ avec InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN3EQ_SolutionsDejaApporteesVide_LeveException()
        {
            this.informationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN3EQ(this.parametresCreationFormulaireGBO,
                this.informationsSupplementairesCN3EqPourCreation,
                this.natureDemandeIntervention);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
