﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet ParametresCreationFormulaireCN2DI.
    /// </summary>
    [TestFixture]
    class ParametresCreationFormulaireCN2DITest
    {
        private Identite identite;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;
        private ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI;
        private InformationsCdcPourCreation informationsCDCPourCreation;
        private InformationsClientPourCreation informationsClientPourCreation;
        private InformationsSupplementairesCN2DiPourCreation informationsSupplementairesCN2DiPourCreation;
        private MotifDysfonctionnement motifDysfonctionnement;
        private OrigineDysfonctionnement origineDysfonctionnement;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.informationsCDCPourCreation = GenerateInformationsCdcPourCreation();

            this.informationsClientPourCreation = GenerateInformationsClientPourCreation();

            this.informationsSupplementairesCN2DiPourCreation = GenerateInformationsSupplementairesCN2DiPourCreation();

            this.parametresCreationFormulaireGBO = new ParametresCreationFormulaireGbo(this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                this.informationsCDCPourCreation,
                "THD0123456789");

            this.motifDysfonctionnement = new MotifDysfonctionnement(this.identite, 1, "MotifDysfonctionnement-1");

            this.origineDysfonctionnement = new OrigineDysfonctionnement(this.identite, 1, "OrigineDysfonctionnement-1");

            this.parametresCreationFormulaireCN2DI = new ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);
        }

        public InformationsCdcPourCreation GenerateInformationsCdcPourCreation()
        {
            return new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        public InformationsSupplementairesCN2DiPourCreation GenerateInformationsSupplementairesCN2DiPourCreation()
        {
            return new InformationsSupplementairesCN2DiPourCreation
            {
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions",
                DateApproxAppelServiceClient = DateTime.Now,
                RaisonsDysfonctionnement = "Raisons",
                NumeroCommandeClient = "123456"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI de base avec ParametresCreationFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_ParametresCreationFormulaireGboNull_LeveException()
        {
            this.parametresCreationFormulaireGBO = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            Assert.Throws<NullReferenceException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI de base avec InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_InformationsClientPourCreationNull_LeveException()
        {
            this.informationsClientPourCreation = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI de base avec InformationsSupplementairesCN2DiPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_InformationsSupplementairesCN2DiPourCreationNull_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI de base avec MotifDysfonctionnement Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_MotifDysfonctionnementNull_LeveException()
        {
            this.motifDysfonctionnement = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_ParametresValide_OK()
        {
            this.parametresCreationFormulaireCN2DI = new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.Cle,
                this.parametresCreationFormulaireGBO.Cle, "erreur Cle");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.CleDossierGbo,
                this.parametresCreationFormulaireGBO.CleDossierGbo, "erreur CleDossierGbo");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsCdcPourCreation.CdcAdresseMail,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsCdcPourCreation.CdcCodeBanque,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsCdcPourCreation.CdcCodeBranche,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsCdcPourCreation.CdcLigneDirecte,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsCdcPourCreation.CdcNomPrenom,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.ReferenceExterne,
                this.parametresCreationFormulaireGBO.ReferenceExterne, "erreur ReferenceExterne");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsClientPourCreation.NomClient,
                this.informationsClientPourCreation.NomClient, "erreur NomClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsClientPourCreation.PrenomClient,
                this.informationsClientPourCreation.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient,
                this.informationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient, "erreur DateApproxAppelServiceClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DemandeClient,
                this.informationsSupplementairesCN2DiPourCreation.DemandeClient, "erreur DemandeClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.NumeroCommandeClient,
                this.informationsSupplementairesCN2DiPourCreation.NumeroCommandeClient, "erreur NumeroCommandeClient");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement,
                this.informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement, "erreur RaisonsDysfonctionnement");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees,
                this.informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees, "erreur SolutionsDejaApportees");
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.MotifDysfonctionnement,
                this.motifDysfonctionnement);
            Assert.AreEqual(this.parametresCreationFormulaireCN2DI.OrigineDysfonctionnement,
                this.origineDysfonctionnement);
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - InformationsSupplementaires.RaisonsDysfonctionnement

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsClientPourCreation.ReferenceExterne Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_RaisonsDysfonctionnementNull_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsClientPourCreation.ReferenceExterne vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_RaisonsDysfonctionnementVide_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - InformationsSupplementaires.DemandeClient

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsSupplementairesPourCreation.DemandeClient Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_DemandeClientNull_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.DemandeClient = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsSupplementairesPourCreation.DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_DemandeClientVide_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.DemandeClient = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - InformationsSupplementaires.DemandeClient

        #region Attribut - InformationsSupplementaires.SolutionsDejaApportees

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsSupplementairesPourCreation.SolutionsDejaApportees Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_SolutionsDejaApporteesNull_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireCN2DI avec InformationsSupplementairesPourCreation.SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireCN2DI_SolutionsDejaApporteesVide_LeveException()
        {
            this.informationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees = "";

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireCN2DI(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.informationsSupplementairesCN2DiPourCreation,
                this.motifDysfonctionnement,
                this.origineDysfonctionnement);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
