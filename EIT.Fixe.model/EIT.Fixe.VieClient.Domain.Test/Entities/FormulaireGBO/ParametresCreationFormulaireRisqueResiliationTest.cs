﻿using System;
using EIT.Fixe.Systeme.Identification;
using NUnit.Framework;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    [TestFixture]
    class ParametresCreationFormulaireRisqueResiliationTest
    {
        private Identite identite;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;
        private ParametresCreationFormulaireRisqueResiliation parametresCreationFormulaireRisqueResiliation;
        private InformationsCdcPourCreation informationsCDCPourCreation;
        private InformationsClientPourCreation informationsClientPourCreation;
        private string offreClient;
        private MotifQualification motifQualification;
        private string commentaire;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };

            this.informationsCDCPourCreation = GenerateInformationsCdcPourCreation();

            this.parametresCreationFormulaireGBO = new ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                this.informationsCDCPourCreation,
                "THD0123456789");

            this.informationsClientPourCreation = GenerateInformationsClientPourCreation();

            this.offreClient = "Offre";

            this.motifQualification = new MotifQualification(this.identite, 1, "MotifQualification-1");

            this.commentaire = "Commentaire";

            this.parametresCreationFormulaireRisqueResiliation = new ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.offreClient,
                this.motifQualification,
                this.commentaire);
        }

        public InformationsCdcPourCreation GenerateInformationsCdcPourCreation()
        {
            return new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireRisqueResiliation de base avec ParametresCreationFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireRisqueResiliation_ParametresCreationFormulaireGboNull_Ok()
        {
            this.parametresCreationFormulaireGBO = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.offreClient,
                this.motifQualification,
                this.commentaire);

            Assert.Throws<NullReferenceException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireRisqueResiliation de base avec InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireRisqueResiliation_InformationsClientPourCreationNull_LeveException()
        {
            this.informationsClientPourCreation = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.offreClient,
                this.motifQualification,
                this.commentaire);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireRisqueResiliation de base avec MotifQualification Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireRisqueResiliation_MotifQualificationNull_LeveException()
        {
            this.motifQualification = null;

            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.offreClient,
                this.motifQualification,
                this.commentaire);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireRisqueResiliation de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireRisqueResiliation_ParametresValide_OK()
        {
            this.parametresCreationFormulaireRisqueResiliation = new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                this.offreClient,
                this.motifQualification,
                this.commentaire);

            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.Cle,
                this.parametresCreationFormulaireGBO.Cle, "erreur Cle");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.CleDossierGbo,
                this.parametresCreationFormulaireGBO.CleDossierGbo, "erreur CleDossierGbo");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsCdcPourCreation.CdcAdresseMail,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsCdcPourCreation.CdcCodeBanque,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsCdcPourCreation.CdcCodeBranche,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsCdcPourCreation.CdcLigneDirecte,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsCdcPourCreation.CdcNomPrenom,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation.NomClient,
                this.informationsClientPourCreation.NomClient, "erreur NomClient");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.InformationsClientPourCreation.PrenomClient,
                this.informationsClientPourCreation.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.OffreClient,
                this.offreClient, "erreur OffreClient");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.MotifQualification,
                this.motifQualification, "erreur MotifQualification");
            Assert.AreEqual(this.parametresCreationFormulaireRisqueResiliation.Commentaire,
                this.commentaire, "erreur Commentaire");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                    this.informationsClientPourCreation,
                    this.offreClient,
                    this.motifQualification,
                    null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientVide_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireRisqueResiliation(this.parametresCreationFormulaireGBO,
                    this.informationsClientPourCreation,
                    this.offreClient,
                    this.motifQualification,
                    "");

            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
