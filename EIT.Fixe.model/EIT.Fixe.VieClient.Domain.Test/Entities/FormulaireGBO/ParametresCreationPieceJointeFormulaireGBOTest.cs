﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet ParametresCreationPieceJointeFormulaireGbo.
    /// </summary>
    [TestFixture]
    public class ParametresCreationPieceJointeFormulaireGboTest
    {
        private Identite identite;
        private ParametresCreationPieceJointeFormulaireGbo ParametresCreationPieceJointeFormulaireGbo;

        /// <summary>
        /// Retourne une clé de Pièce Jointe de Formulaire GBO valide.
        /// </summary>
        private long ClePieceJointeFormulaireGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne un GUDOCID valide.
        /// </summary>
        private string GuDocIdValide
        {
            get
            {
                return "RjA1MDU2OTEtNTU3ZS1lZTAwLWIzNTQtMDI2YTNjNTliMTEzfEVJVFB8MA==";
            }
        }

        /// <summary>
        /// Retourne un Nom de Fichier valide.
        /// </summary>
        private string NomFichierValide
        {
            get
            {
                return "FichierTest.xml";
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite {Memoid = "Memoid"};

            this.ParametresCreationPieceJointeFormulaireGbo = new ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                this.GuDocIdValide,
                this.NomFichierValide);
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationPieceJointeFormulaireGbo_ParametresValide_OK()
        {
            this.ParametresCreationPieceJointeFormulaireGbo = new ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                this.GuDocIdValide,
                this.NomFichierValide);

            Assert.AreEqual(this.ParametresCreationPieceJointeFormulaireGbo.Cle, this.ClePieceJointeFormulaireGboValide, "erreur Cle");
            Assert.AreEqual(this.ParametresCreationPieceJointeFormulaireGbo.GuDocId, this.GuDocIdValide, "erreur GuDocId");
            Assert.AreEqual(this.ParametresCreationPieceJointeFormulaireGbo.NomFichier, this.NomFichierValide, "erreur NomFichier");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - Cle

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec Cle négative.
        /// </summary>
        [Test]
        public void CreerParametresCreationPieceJointeFormulaireGbo_CleNegative_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                -1,
                this.GuDocIdValide,
                this.NomFichierValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec Cle à 0.
        /// </summary>
        [Test]
        public void CreerParametresCreationPieceJointeFormulaireGbo_CleZero_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                0,
                this.GuDocIdValide,
                this.NomFichierValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - Cle

        #region Attribut - GuDocId

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec GuDocId Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_GuDocIdNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                null,
                this.NomFichierValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec GuDocId vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_GuDocIdVide_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                "",
                this.NomFichierValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - GuDocId

        #region Attribut - NomFichier

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec NomFichier Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_NomFichierNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                this.GuDocIdValide,
                null);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationPieceJointeFormulaireGbo de base avec NomFichier vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_NomFichierVide_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationPieceJointeFormulaireGbo(
                this.ClePieceJointeFormulaireGboValide,
                this.GuDocIdValide,
                "");

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - NomFichier

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
