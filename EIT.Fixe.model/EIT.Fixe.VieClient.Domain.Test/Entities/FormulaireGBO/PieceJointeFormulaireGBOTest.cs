﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.PieceJointeFormulaireGbo
{
    /// <summary>
    /// Classe de test de l'objet PieceJointeFormulaireGbo.
    /// </summary>
    [TestFixture]
    public class PieceJointeFormulaireGboTest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo PieceJointeFormulaireGbo;
        private ParametresCreationPieceJointeFormulaireGbo parametresCreationPieceJointeFormulaireGbo;

        /// <summary>
        /// Retourne une clé de Pièce Jointe de Formulaire GBO valide.
        /// </summary>
        private long ClePieceJointeFormulaireGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGboValide
        {
            get
            {
                return 1;
            }
        }


        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametresCreationPieceJointeFormulaireGbo = GenerateParametresCreationPieceJointeFormulaireGboOk();

            this.PieceJointeFormulaireGbo = new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                this.identite, parametresCreationPieceJointeFormulaireGbo);
        }

        public ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk()
        {
            return new ParametresCreationPieceJointeFormulaireGbo(
                    ClePieceJointeFormulaireGboValide,
                    "RjA1MDU2OTEtNTU3ZS1lZTAwLWIzNTQtMDI2YTNjNTliMTEzfEVJVFB8MA==",
                    "FichierTest.xml");
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec Identite nNull.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_IdentiteNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(null, parametresCreationPieceJointeFormulaireGbo);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_ParametresCreationPieceJointeFormulaireGboNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_ParametresValide_OK()
        {
            this.PieceJointeFormulaireGbo = new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            Assert.AreEqual(this.PieceJointeFormulaireGbo.Cle, this.parametresCreationPieceJointeFormulaireGbo.Cle, "erreur Cle");
            Assert.AreEqual(this.PieceJointeFormulaireGbo.GuDocId, this.parametresCreationPieceJointeFormulaireGbo.GuDocId, "erreur GuDocId");
            Assert.AreEqual(this.PieceJointeFormulaireGbo.NomFichier, this.parametresCreationPieceJointeFormulaireGbo.NomFichier, "erreur NomFichier");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - ParametresCreationPieceJointeFormulaireGbo.Cle

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.Cle négative.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_CleNegative_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.Cle = -1;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.Cle à 0.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_CleZero_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.Cle = 0;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - ParametresCreationPieceJointeFormulaireGbo.Cle

        #region Attribut - ParametresCreationPieceJointeFormulaireGbo.InformationsCdcPourCreation.GuDocId

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.GuDocId Null.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_GuDocIdNull_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.GuDocId = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.GuDocId vide.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_GuDocIdVide_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.GuDocId = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationPieceJointeFormulaireGbo.InformationsCdcPourCreation.GuDocId

        #region Attribut - ParametresCreationPieceJointeFormulaireGbo.NomFichier

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.NomFichier Null.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_CdcAdresseMailNull_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.NomFichier = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'une Pièce Jointe de Formulaire GBO avec ParametresCreationPieceJointeFormulaireGbo.NomFichier vide.
        /// </summary>
        [Test]
        public void CreerPieceJointeFormulaireGbo_CdcAdresseMailVide_LeveException()
        {
            this.parametresCreationPieceJointeFormulaireGbo.NomFichier = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(this.identite, this.parametresCreationPieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationPieceJointeFormulaireGbo.NomFichier

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
