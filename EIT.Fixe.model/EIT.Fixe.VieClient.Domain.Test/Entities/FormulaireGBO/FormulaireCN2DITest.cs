﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet FormulaireCN2DI.
    /// </summary>
    [TestFixture]
    public class FormulaireCN2DITest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.FormulaireCN2DI formulaireCN2DI;
        private ParametresCreationFormulaireCN2DI parametresCreationFormulaireCN2DI;
        private List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }


        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametresCreationFormulaireCN2DI = GenerateParametresCreationFormulaireCN2DIOk();

            this.listePieceJointeFormulaireGbo =
                GenerateListePieceJointeFormulaireGboOk(2);

            this.formulaireCN2DI = new Domain.Entities.FormulaireGBO.FormulaireCN2DI(
                this.identite, parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN2DI GenerateParametresCreationFormulaireCN2DIOk()
        {
            return new ParametresCreationFormulaireCN2DI(
                GenerateParametresCreationFormulaireGboOk(),
                GenerateInformationsClientPourCreation(),
                GenerateInformationsSupplementairesCN2DiPourCreationOk(),
                new MotifDysfonctionnement(this.identite, 1, "MotifDysfonctionnement-1"),
                new OrigineDysfonctionnement(this.identite, 1, "OrigineDysfonctionnement-1"));
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk()
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        public InformationsSupplementairesCN2DiPourCreation GenerateInformationsSupplementairesCN2DiPourCreationOk()
        {
            return new InformationsSupplementairesCN2DiPourCreation
            {
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions",
                DateApproxAppelServiceClient = DateTime.Now,
                RaisonsDysfonctionnement = "Raisons",
                NumeroCommandeClient = "123456"
            };
        }

        public ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk(
            long clePieceJointeFormulaireGbo)
        {
            return new ParametresCreationPieceJointeFormulaireGbo(
                clePieceJointeFormulaireGbo,
                "GUDOCID_TEST_" + clePieceJointeFormulaireGbo,
                "NomFichierTest_" + clePieceJointeFormulaireGbo + ".xml");
        }

        public Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo GeneratePieceJointeFormulaireGboOk(
            long clePieceJointeFormulaireGbo)
        {
            return new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                this.identite,
                GenerateParametresCreationPieceJointeFormulaireGboOk(clePieceJointeFormulaireGbo));
        }

        public List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> GenerateListePieceJointeFormulaireGboOk(int nbParametresACreer)
        {
            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> result =
                new List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();

            for (int i = 1; i <= nbParametresACreer; i++)
            {
                result.Add(GeneratePieceJointeFormulaireGboOk(i));
            }

            return result;
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_ParametresValide_OK()
        {
            this.formulaireCN2DI = new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            Assert.AreEqual(this.formulaireCN2DI.NomClient,
                this.parametresCreationFormulaireCN2DI.InformationsClientPourCreation.NomClient, "erreur NomClient");
            Assert.AreEqual(this.formulaireCN2DI.PrenomClient,
                this.parametresCreationFormulaireCN2DI.InformationsClientPourCreation.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.formulaireCN2DI.NumeroCommandeClient,
                this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.NumeroCommandeClient, "erreur NumeroCommandeClient");
            Assert.AreEqual(this.formulaireCN2DI.MotifDysfonctionnement,
                this.parametresCreationFormulaireCN2DI.MotifDysfonctionnement, "erreur MotifDysfonctionnement");
            Assert.AreEqual(this.formulaireCN2DI.OrigineDysfonctionnement,
                this.parametresCreationFormulaireCN2DI.OrigineDysfonctionnement, "erreur OrigineDysfonctionnement");
            Assert.AreEqual(this.formulaireCN2DI.DateApproxAppelServiceClient,
                this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient, "erreur DateApproxAppelServiceClient");
            Assert.AreEqual(this.formulaireCN2DI.RaisonsDysfonctionnement,
                this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement, "erreur RaisonsDysfonctionnement");
            Assert.AreEqual(this.formulaireCN2DI.DemandeClient,
                this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DemandeClient, "erreur DemandeClient");
            Assert.AreEqual(this.formulaireCN2DI.SolutionsDejaApportees,
                this.parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees, "erreur SolutionsDejaApportees");
            Assert.AreEqual(this.formulaireCN2DI.ListePiecesJointes.Count,
                this.listePieceJointeFormulaireGbo.Count, "erreur ListePiecesJointes");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Paramètre - InformationsClientPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreationFormulaireCN2DI.InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_InformationsClientPourCreationNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsClientPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Paramètre - InformationsClientPourCreation

        #region Paramètre - InformationsSupplementairesCN2DiPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_InformationsSupplementairesCN2DiPourCreationNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Paramètre - InformationsSupplementairesCN2DiPourCreation

        #region Attribut - ParametresCreation.MotifDysfonctionnement

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.MotifDysfonctionnement Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_MotifDysfonctionnementNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.MotifDysfonctionnement = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Attribut - ParametresCreation.MotifDysfonctionnement

        #region Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2 Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DateReponseCelluleN2Null_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DateApproxAppelServiceClient = default(DateTime);
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_RaisonsDysfonctionnementNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_RaisonsDysfonctionnementVide_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.RaisonsDysfonctionnement

        #region Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DemandeClient = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_DemandeClientVide_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.DemandeClient = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.DemandeClient

        #region Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_SolutionsDejaApporteesNull_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN2DI_SolutionsDejaApporteesVide_LeveException()
        {
            parametresCreationFormulaireCN2DI.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN2DI(this.identite, this.parametresCreationFormulaireCN2DI, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreation.InformationsSupplementairesCN2DiPourCreation.SolutionsDejaApportees

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
