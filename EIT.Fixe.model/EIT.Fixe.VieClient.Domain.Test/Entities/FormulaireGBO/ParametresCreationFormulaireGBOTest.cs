﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet ParametresCreationFormulaireGbo.
    /// </summary>
    [TestFixture]
    public class ParametresCreationFormulaireGboTest
    {
        private Identite identite;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;
        private InformationsCdcPourCreation informationsCDCPourCreation;
        private RegionCDC regionCdc;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une Référence Externe valide.
        /// </summary>
        private string ReferenceExterneValide
        {
            get
            {
                return "THD0123456789";
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };
            this.regionCdc = new RegionCDC(this.identite, 1, "RegionCDC-1");

            this.informationsCDCPourCreation =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            this.parametresCreationFormulaireGBO = new ParametresCreationFormulaireGbo(this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_InformationsCdcPourCreationNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                    CleFormulaireGBOValide,
                    CleDossierGboValide,
                    this.regionCdc,
                    null,
                    this.ReferenceExterneValide);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_ParametresValide_OK()
        {
            this.parametresCreationFormulaireGBO = new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            Assert.AreEqual(this.parametresCreationFormulaireGBO.Cle, CleFormulaireGBOValide, "erreur Cle");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.CleDossierGbo, CleDossierGboValide, "erreur CleDossierGbo");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, this.informationsCDCPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, this.informationsCDCPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, this.informationsCDCPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, this.informationsCDCPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, this.informationsCDCPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.RegionCdc, this.regionCdc, "erreur CdcCleRegion");
            Assert.AreEqual(this.parametresCreationFormulaireGBO.ReferenceExterne, this.ReferenceExterneValide, "erreur ReferenceExterne");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - Cle

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec Cle négative.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CleNegative_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                -1, 
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec Cle à 0.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CleZero_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                0,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - Cle

        #region Attribut - CleDossierGbo

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec CleDossierGbo négative.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CleDossierGboNegative_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                -1,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec CleDossierGbo à 0.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CleDossierGboZero_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                0,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.CleDossierGbo

        #region Attribut - InformationsCdcPourCreation.CdcAdresseMail

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcAdresseMail Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcAdresseMailNull_LeveException()
        {
            this.informationsCDCPourCreation.CdcAdresseMail = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcAdresseMail vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcAdresseMailVide_LeveException()
        {
            this.informationsCDCPourCreation.CdcAdresseMail = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcAdresseMail

        #region Attribut - InformationsCdcPourCreation.CdcCodeBanque

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBanque Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBanqueNull_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBanque = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBanque vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBanqueVide_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBanque = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBanque de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBanqueTailleIncorrecte_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBanque = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - InformationsCdcPourCreation.CdcCodeBanque

        #region Attribut - InformationsCdcPourCreation.CdcCodeBranche

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBranche Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBrancheNull_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBranche = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBranche vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBrancheVide_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBranche = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcCodeBranche de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcCodeBrancheTailleIncorrecte_LeveException()
        {
            this.informationsCDCPourCreation.CdcCodeBranche = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - InformationsCdcPourCreation.CdcCodeBranche

        #region Attribut - InformationsCdcPourCreation.CdcLigneDirecte

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcLigneDirecte Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcLigneDirecteNull_LeveException()
        {
            this.informationsCDCPourCreation.CdcLigneDirecte = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcLigneDirecte vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcLigneDirecteVide_LeveException()
        {
            this.informationsCDCPourCreation.CdcLigneDirecte = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcLigneDirecte de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcLigneDirecteTailleIncorrecte_LeveException()
        {
            this.informationsCDCPourCreation.CdcLigneDirecte = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - InformationsCdcPourCreation.CdcLigneDirecte

        #region Attribut - InformationsCdcPourCreation.CdcNomPrenom

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcNomPrenom Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcNomPrenomNull_LeveException()
        {
            this.informationsCDCPourCreation.CdcNomPrenom = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec InformationsCdcPourCreation.CdcNomPrenom vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_CdcNomPrenomVide_LeveException()
        {
            this.informationsCDCPourCreation.CdcNomPrenom = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleFormulaireGBOValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - InformationsCdcPourCreation.CdcNomPrenom

        #region Attribut - RegionCDC

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec RegionCDC Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_RegionCDCNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                null,
                this.informationsCDCPourCreation,
                this.ReferenceExterneValide);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Attribut - InformationsCdcPourCreation.CdcCleRegion

        #region Attribut - ReferenceExterne

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec ReferenceExterne Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_ReferenceExterneNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                null);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireGbo de base avec ReferenceExterne vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireGbo_ReferenceExterneVide_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireGbo(
                this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                this.regionCdc,
                this.informationsCDCPourCreation,
                "");

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.CleDossierGbo

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
