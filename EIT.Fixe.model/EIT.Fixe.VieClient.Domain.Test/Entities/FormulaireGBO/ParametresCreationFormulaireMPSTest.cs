﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet ParametresCreationFormulaireMPS.
    /// </summary>
    [TestFixture]
    public class ParametresCreationFormulaireMPSTest
    {
        private Identite identite;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;
        private ParametresCreationFormulaireMPS parametresCreationFormulaireMPS;
        private InformationsCdcPourCreation informationsCDCPourCreation;
        private InformationsClientPourCreation informationsClientPourCreation;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };

            this.informationsCDCPourCreation = GenerateInformationsCdcPourCreation();

            this.informationsClientPourCreation = GenerateInformationsClientPourCreation();

            this.parametresCreationFormulaireGBO = new ParametresCreationFormulaireGbo(this.CleFormulaireGBOValide,
                this.CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                this.informationsCDCPourCreation,
                "THD0123456789");
            this.parametresCreationFormulaireMPS = new ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation,
                DateTime.Now,
                ProfilSurconsommation.ClientStandard,
                "Commentaire");
        }

        public InformationsCdcPourCreation GenerateInformationsCdcPourCreation()
        {
            return new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };
        }

        public InformationsClientPourCreation GenerateInformationsClientPourCreation()
        {
            return new InformationsClientPourCreation
            {
                PrenomClient = "PrenomClient",
                NomClient = "NomClient"
            };
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireMPS de base avec ParametresCreationFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_ParametresCreationFormulaireGboNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(null,
                this.informationsClientPourCreation, DateTime.Now, ProfilSurconsommation.ClientStandard, "Commentaire");

            Assert.Throws<NullReferenceException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireMPS de base avec InformationsClientPourCreation Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_InformationsClientPourCreationNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO,
                null, DateTime.Now, ProfilSurconsommation.ClientStandard, "Commentaire");

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire MPS de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_ParametresValide_OK()
        {
            DateTime dateEffetDemande = DateTime.Now;
            ProfilSurconsommation profilSurconsoDemande = ProfilSurconsommation.ClientStandard;
            string commentaire = "Commentaire";

            this.parametresCreationFormulaireMPS = new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO, this.informationsClientPourCreation, dateEffetDemande, profilSurconsoDemande, commentaire);

            Assert.AreEqual(this.parametresCreationFormulaireMPS.Cle,
                this.parametresCreationFormulaireGBO.Cle, "erreur Cle");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.CleDossierGbo,
                this.parametresCreationFormulaireGBO.CleDossierGbo, "erreur CleDossierGbo");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsCdcPourCreation.CdcAdresseMail,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsCdcPourCreation.CdcCodeBanque,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsCdcPourCreation.CdcCodeBranche,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsCdcPourCreation.CdcLigneDirecte,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsCdcPourCreation.CdcNomPrenom,
                this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsClientPourCreation.NomClient,
                this.informationsClientPourCreation.NomClient, "erreur NomClient");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.InformationsClientPourCreation.PrenomClient,
                this.informationsClientPourCreation.PrenomClient, "erreur PrenomClient");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.DateEffetDemande,
                dateEffetDemande, "erreur DateEffetDemande");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.ProfilSurconsoDemande,
                profilSurconsoDemande, "erreur profilSurconsoDemande");
            Assert.AreEqual(this.parametresCreationFormulaireMPS.Commentaire,
                commentaire, "erreur Commentaire");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Attribut - ParametresCreation.DateEffetDemande

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireMPS de base avec DateEffetDemande Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_DateEffetDemandeNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation, default(DateTime), ProfilSurconsommation.ClientStandard, "Commentaire");

            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.Commentaire

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireMPS de base avec Commentaire Null.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_CommentaireNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation, DateTime.Now, ProfilSurconsommation.ClientStandard, null);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un ParametresCreationFormulaireMPS de base avec Commentaire Vide.
        /// </summary>
        [Test]
        public void CreerParametresCreationFormulaireMPS_CommentaireVide_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.ParametresCreationFormulaireMPS(this.parametresCreationFormulaireGBO,
                this.informationsClientPourCreation, DateTime.Now, ProfilSurconsommation.ClientStandard, "");

            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
