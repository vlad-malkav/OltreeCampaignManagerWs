﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet FormulaireGBO.
    /// </summary>
    [TestFixture]
    public class FormulaireGBOTest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.FormulaireGBO formulaireGBO;
        private ParametresCreationFormulaireGbo parametresCreationFormulaireGBO;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }


        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametresCreationFormulaireGBO = GenerateParametresCreationFormulaireGboOk();

            this.formulaireGBO = new Domain.Entities.FormulaireGBO.FormulaireGBO(
                this.identite, parametresCreationFormulaireGBO);
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk()
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec Identite nNull.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_IdentiteNull_LeveException()
        {
            TestDelegate action =
                () => new Domain.Entities.FormulaireGBO.FormulaireGBO(null, parametresCreationFormulaireGBO);

            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_ParametresCreationFormulaireGboNull_LeveException()
        {
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, null);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_ParametresValide_OK()
        {
            this.formulaireGBO = new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            Assert.AreEqual(this.formulaireGBO.Cle, this.parametresCreationFormulaireGBO.Cle, "erreur Cle");
            Assert.AreEqual(this.formulaireGBO.CleDossierGbo, this.parametresCreationFormulaireGBO.CleDossierGbo, "erreur CleDossierGbo");
            Assert.AreEqual(this.formulaireGBO.CdcAdresseMail, this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail, "erreur CdcAdresseMail");
            Assert.AreEqual(this.formulaireGBO.CdcCodeBanque, this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque, "erreur CdcCodeBanque");
            Assert.AreEqual(this.formulaireGBO.CdcCodeBranche, this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche, "erreur CdcCodeBranche");
            Assert.AreEqual(this.formulaireGBO.CdcLigneDirecte, this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte, "erreur CdcLigneDirecte");
            Assert.AreEqual(this.formulaireGBO.CdcNomPrenom, this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom, "erreur CdcNomPrenom");
            Assert.AreEqual(this.formulaireGBO.RegionCdc.Cle, this.parametresCreationFormulaireGBO.RegionCdc.Cle, "erreur CdcCleRegion");
            Assert.AreEqual(this.formulaireGBO.RegionCdc.Libelle, this.parametresCreationFormulaireGBO.RegionCdc.Libelle, "erreur CdcCleRegion");
            Assert.AreEqual(this.formulaireGBO.ReferenceExterne, this.parametresCreationFormulaireGBO.ReferenceExterne, "erreur ReferenceExterne");
            Assert.AreEqual(this.formulaireGBO.TypeFormulaireGbo, TypeFormulaireGBO.NonDefini, "erreur TypeFormulaireGbo");
        }

        #endregion Tests de base

        #region Tests Spécifiques

        #region Paramètre - ParametresCreationFormulaireGbo.InformationsClientPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 2 de demande d'intervention avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_InformationsClientPourCreationNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Paramètre - ParametresCreationFormulaireGbo.InformationsClientPourCreation

        #region Attribut - ParametresCreationFormulaireGbo.Cle

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.Cle négative.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CleNegative_LeveException()
        {
            this.parametresCreationFormulaireGBO.Cle = -1;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.Cle à 0.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CleZero_LeveException()
        {
            this.parametresCreationFormulaireGBO.Cle = 0;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.Cle

        #region Attribut - ParametresCreationFormulaireGbo.CleDossierGbo

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.CleDossierGbo négative.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CleDossierGboNegative_LeveException()
        {
            parametresCreationFormulaireGBO.CleDossierGbo = -1;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.CleDossierGbo à 0.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CleDossierGboZero_LeveException()
        {
            parametresCreationFormulaireGBO.CleDossierGbo = 0;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.CleDossierGbo

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcAdresseMail

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcAdresseMail Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcAdresseMailNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcAdresseMail vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcAdresseMailVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcAdresseMail = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcAdresseMail

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBanque

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBanque Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBanqueNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBanque vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBanqueVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBanque de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBanqueTailleIncorrecte_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBanque = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBanque

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBranche

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBranche Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBrancheNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBranche vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBrancheVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBranche de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcCodeBrancheTailleIncorrecte_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcCodeBranche = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCodeBranche

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcLigneDirecte

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcLigneDirecte Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcLigneDirecteNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcLigneDirecte vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcLigneDirecteVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcLigneDirecte de taille incorrecte.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcLigneDirecteTailleIncorrecte_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcLigneDirecte = "1";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcLigneDirecte

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcNomPrenomNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_CdcNomPrenomVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.InformationsCdcPourCreation.CdcNomPrenom = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom

        #region Attribut - ParametresCreationFormulaireGbo.RegionCDC

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.RegionCDC Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_RegionNegative_LeveException()
        {
            this.parametresCreationFormulaireGBO.RegionCdc = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcCleRegion

        #region Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.ReferenceExterne Null.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_ReferenceExterneNull_LeveException()
        {
            this.parametresCreationFormulaireGBO.ReferenceExterne = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire GBO de base avec ParametresCreationFormulaireGbo.ReferenceExterne vide.
        /// </summary>
        [Test]
        public void CreerFormulaireGBO_ReferenceExterneVide_LeveException()
        {
            this.parametresCreationFormulaireGBO.ReferenceExterne = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireGBO(this.identite, this.parametresCreationFormulaireGBO);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion Attribut - ParametresCreationFormulaireGbo.InformationsCdcPourCreation.CdcNomPrenom

        #endregion Tests Spécifiques

        #endregion Test Constructeur
    }
}
