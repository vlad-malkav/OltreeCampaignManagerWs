﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using EIT.Fixe.VieClient.Domain.Entities.FormulaireGBO;
using EIT.Fixe.VieClient.Domain.Entities.TableParametrageGBO;

namespace EIT.Fixe.VieClient.Domain.Test.Entities.FormulaireGBO
{
    /// <summary>
    /// Classe de test de l'objet FormulaireCN3EQ.
    /// </summary>
    [TestFixture]
    class FormulaireCN3EQTest
    {
        private Identite identite;
        private Domain.Entities.FormulaireGBO.FormulaireCN3EQ formulaireCN3EQ;
        private ParametresCreationFormulaireCN3EQ parametresCreationFormulaireCN3EQ;
        private List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> listePieceJointeFormulaireGbo;

        /// <summary>
        /// Retourne une clé de Formulaire GBO valide.
        /// </summary>
        private long CleFormulaireGBOValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Retourne une clé de Dossier GBO valide.
        /// </summary>
        private long CleDossierGboValide
        {
            get
            {
                return 1;
            }
        }

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite { Memoid = "Memoid" };

            this.parametresCreationFormulaireCN3EQ = GenerateParametresCreationFormulaireCN3EQOk();

            this.listePieceJointeFormulaireGbo =
                GenerateListePieceJointeFormulaireGboOk(2);

            this.formulaireCN3EQ = new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(
                this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);
        }

        public ParametresCreationFormulaireCN3EQ GenerateParametresCreationFormulaireCN3EQOk()
        {
            return new ParametresCreationFormulaireCN3EQ(
                GenerateParametresCreationFormulaireGboOk(),
                GenerateInformationsSupplementairesCN3EqPourCreationOk(),
                new NatureDemandeIntervention(this.identite, 1, "NatureDemandeIntervention-1"));
        }

        public ParametresCreationFormulaireGbo GenerateParametresCreationFormulaireGboOk()
        {
            InformationsCdcPourCreation informationsCDCPourCreationOk =
            new InformationsCdcPourCreation
            {
                CdcAdresseMail = "Test",
                CdcCodeBanque = "12345",
                CdcCodeBranche = "12345",
                CdcLigneDirecte = "0666666666",
                CdcNomPrenom = "Test"
            };

            return new ParametresCreationFormulaireGbo(
                CleFormulaireGBOValide,
                CleDossierGboValide,
                new RegionCDC(this.identite, 1, "RegionCDC-1"),
                informationsCDCPourCreationOk,
                "THD0123456789");
        }

        public InformationsSupplementairesCN3EqPourCreation GenerateInformationsSupplementairesCN3EqPourCreationOk()
        {
            return new InformationsSupplementairesCN3EqPourCreation
            {
                NumeroSuiviDossier = "12345",
                DateReponseCelluleN2 = DateTime.Now,
                RaisonContestation = "Raison",
                DemandeClient = "Demande",
                SolutionsDejaApportees = "Solutions"
            };
        }

        public ParametresCreationPieceJointeFormulaireGbo GenerateParametresCreationPieceJointeFormulaireGboOk(
            long clePieceJointeFormulaireGbo)
        {
            return new ParametresCreationPieceJointeFormulaireGbo(
                clePieceJointeFormulaireGbo,
                "GUDOCID_TEST_" + clePieceJointeFormulaireGbo,
                "NomFichierTest_" + clePieceJointeFormulaireGbo + ".xml");
        }

        public Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo GeneratePieceJointeFormulaireGboOk(
            long clePieceJointeFormulaireGbo)
        {
            return new Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo(
                this.identite,
                GenerateParametresCreationPieceJointeFormulaireGboOk(clePieceJointeFormulaireGbo));
        }

        public List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> GenerateListePieceJointeFormulaireGboOk(int nbParametresACreer)
        {
            List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo> result =
                new List<Domain.Entities.FormulaireGBO.PieceJointeFormulaireGbo>();

            for (int i = 1; i <= nbParametresACreer; i++)
            {
                result.Add(GeneratePieceJointeFormulaireGboOk(i));
            }

            return result;
        }

        #region Test Constructeur

        #region Tests de base

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec paramètres OK.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_ParametresValide_Ok()
        {
            this.formulaireCN3EQ = new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            Assert.AreEqual(this.formulaireCN3EQ.NumeroSuiviDossier,
                this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier, "erreur NumeroSuiviDossier");
            Assert.AreEqual(this.formulaireCN3EQ.DateReponseCelluleN2,
                this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2, "erreur DateReponseCelluleN2");
            Assert.AreEqual(this.formulaireCN3EQ.RaisonContestation,
                this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation, "erreur RaisonContestation");
            Assert.AreEqual(this.formulaireCN3EQ.DemandeClient,
                this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient, "erreur DemandeClient");
            Assert.AreEqual(this.formulaireCN3EQ.SolutionsDejaApportees,
                this.parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees, "erreur SolutionsDejaApportees");
            Assert.AreEqual(this.formulaireCN3EQ.NatureDemandeIntervention,
                this.parametresCreationFormulaireCN3EQ.NatureDemandeIntervention, "erreur NatureDemandeIntervention");
        }

        #endregion

        #region Tests Spécifiques

        #region Paramètre - InformationsSupplementairesCN3EqPourCreation

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_InformationsSupplementairesCN3EqPourCreationNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion

        #region Paramètre - NatureDemandeIntervention

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.NatureDemandeIntervention Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_NatureDemandeInterventionNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.NatureDemandeIntervention = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentNullException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_NumeroSuiviDossierNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_NumeroSuiviDossierVide_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.NumeroSuiviDossier = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2 Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DateReponseCelluleN2Null_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DateReponseCelluleN2 = default(DateTime);
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN3EqPourCreation.RaisonContestation

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_RaisonContestationNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_RaisonContestationVide_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.RaisonContestation = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN3EqPourCreation.DemandeClient

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DemandeClientNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_DemandeClientVide_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.DemandeClient = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #region Attribut - ParametresCreation.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees Null.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_SolutionsDejaApporteesNull_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees = null;
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Creation d'un Formulaire de niveau 3 d'engagement qualité avec ParametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees vide.
        /// </summary>
        [Test]
        public void CreerFormulaireCN3EQ_SolutionsDejaApporteesVide_LeveException()
        {
            parametresCreationFormulaireCN3EQ.InformationsSupplementairesCN3EqPourCreation.SolutionsDejaApportees = "";
            TestDelegate action = () => new Domain.Entities.FormulaireGBO.FormulaireCN3EQ(this.identite, this.parametresCreationFormulaireCN3EQ, this.listePieceJointeFormulaireGbo);

            // Assert
            Assert.Throws<ArgumentException>(action);
        }

        #endregion

        #endregion

        #endregion
    }
}
