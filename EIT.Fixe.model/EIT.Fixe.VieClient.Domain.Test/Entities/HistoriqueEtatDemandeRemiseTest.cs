﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;
using System;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test pour HistoriqueEtatDemandeRemise.
    /// </summary>
    [TestFixture]
    public class HistoriqueEtatDemandeRemiseTest
    {
        private Identite identite;

        /// <summary>
        /// Initialisation.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "test", Canal = Canal.FaceAFace };
        }

        /// <summary>
        /// Création avec l'identite null.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatDemandeRemise_IdentiteNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatDemandeRemise(null, 1, EtatDemandeRemise.Activee);

            Assert.Throws<ArgumentException>(action);
        }

        /// <summary>
        /// Création avec la clé null.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatDemandeRemise_CleNull_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatDemandeRemise(this.identite, 0, EtatDemandeRemise.Activee);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création avec la clé négative.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatDemandeRemise_CleNegatif_LeveException()
        {
            TestDelegate action = () => new HistoriqueEtatDemandeRemise(this.identite, -1, EtatDemandeRemise.Activee);

            Assert.Throws<ArgumentOutOfRangeException>(action);
        }

        /// <summary>
        /// Création.
        /// </summary>
        [Test]
        public void CreerHistoriqueEtatDemandeRemise_ParametreValide_OK()
        {
            HistoriqueEtatDemandeRemise historique = new HistoriqueEtatDemandeRemise(this.identite, 1, EtatDemandeRemise.Activee);

            Assert.AreEqual(historique.Cle, 1);
            Assert.AreEqual(historique.Canal, this.identite.Canal);
            Assert.AreEqual(historique.NouvelEtat, EtatDemandeRemise.Activee);
            Assert.AreEqual(historique.AgentModification, this.identite.Memoid);
        }
    }
}
