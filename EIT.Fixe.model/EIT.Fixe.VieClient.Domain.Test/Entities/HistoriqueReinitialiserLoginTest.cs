﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO;
using EIT.Fixe.VieClient.Domain.Entities;
using NUnit.Framework;

namespace EIT.Fixe.VieClient.Domain.Test.Entities
{
    /// <summary>
    /// Classe de test de l'objet HistoriqueReinitialiserLogin;
    /// </summary>
    [TestFixture]
    public class HistoriqueReinitialiserLoginTest
    {
        private Identite identite;
        private HistoriqueReinitialiserLogin historique;
        private ParametreHistoriqueReinitialiserLoginPourCreation parametreCreation;

        #region Initialisation

        [SetUp]
        public void SetUp()
        {
            this.identite = new Identite() { Memoid = "MemoId" };

            this.parametreCreation = new ParametreHistoriqueReinitialiserLoginPourCreation()
            {
                Cle = 1,
                CleLigne = 1,
                Destinataire = "Destinataire",
                Identifiant = "Identifiant",
                ModeEnvoi = CommonTypes.Enumerations.CanalCommunication.Email
            };

            this.historique = new HistoriqueReinitialiserLogin(this.identite, this.parametreCreation);
        }

        #endregion Initialisation

        #region Test Constructeur

        /// <summary>
        /// Test du constructeur avec les parametres OK.
        /// </summary>
        [Test]
        public void CreerHistoriqueReinitialiserLogin_ParametreOK_OK()
        {
            //Arrange & Act.
            HistoriqueReinitialiserLogin historique = new HistoriqueReinitialiserLogin(this.identite, this.parametreCreation);

            //Assert.
            Assert.AreEqual(historique.Canal, this.historique.Canal);
            Assert.AreEqual(historique.Cle, this.historique.Cle);
            Assert.AreEqual(historique.CleLigne, this.historique.CleLigne);
            Assert.AreEqual(historique.Destinataire, this.historique.Destinataire);
            Assert.AreEqual(historique.Identifiant, this.historique.Identifiant);
        }

        #endregion Test Constructeur
    }
}
