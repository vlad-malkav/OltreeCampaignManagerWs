﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’un motif de résiliation d’une ligne fixe pour afficher dans une liste.
    /// </summary>
    [DataContract]
    public class MotifResiliationLignePourLister
    {
        /// <summary>
        /// Libellé du motif.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}
