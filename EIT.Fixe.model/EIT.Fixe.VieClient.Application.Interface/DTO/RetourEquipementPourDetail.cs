﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail du retour équipement.
    /// </summary>
    [DataContract]
    public class RetourEquipementPourDetail
    {
        /// <summary>
        /// Motif du retour.
        /// </summary>
        [DataMember]
        public string LibelleMotif { get; set; }

        /// <summary>
        /// Mode de retour des équipements.
        /// </summary>
        [DataMember]
        public string LibelleModeRetour { get; set; }

        /// <summary>
        /// Type de prise en charge. Enumération.
        /// </summary>
        [DataMember]
        public TypePriseEnCharge TypePriseEnCharge { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [DataMember]
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Date d'expiration.
        /// </summary>
        [DataMember]
        public DateTime DateExpiration { get; set; }

        /// <summary>
        /// Liste des articles attendus.
        /// </summary>
        [DataMember]
        public ArticlePourLister[] ListeArticles { get; set; }
    }
}
