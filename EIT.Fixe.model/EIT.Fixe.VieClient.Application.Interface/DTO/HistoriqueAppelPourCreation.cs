﻿using EIT.Fixe.Domain.Historique;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Historique appel pour création.
    /// </summary>
    [DataContract]
    public class HistoriqueAppelPourCreation
    {
        /// <summary>
        /// Référence externe de la ligne fixe pour laquelle créer l'historique.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }
        /// <summary>
        /// Durée de l'appel, en seconde.
        /// </summary>
        [DataMember]
        public int DureeAppel { get; set; }
        /// <summary>
        /// Date de l'appel.
        /// </summary>
        [DataMember]
        public DateTime DateAppel { get; set; }
        /// <summary>
        /// Prénom de l'applant.
        /// </summary>
        [DataMember]
        public string PrenomTiers { get; set; }
        /// <summary>
        /// Nom de l'applant.
        /// </summary>
        [DataMember]
        public string NomTiers { get; set; }
        /// <summary>
        /// Numéro de téléphone de l'appelant.
        /// </summary>
        [DataMember]
        public string NumeroAppelant { get; set; }
        /// <summary>
        /// Numéro de téléphone de l'appelé.
        /// </summary>
        [DataMember]
        public string NumeroAppele { get; set; }
        /// <summary>
        /// Libellé du point de vente CMI.
        /// </summary>
        [DataMember]
        public string PointDeVenteCmi { get; set; }
        /// <summary>
        /// Clé du média.
        /// </summary>
        [DataMember]
        public int CleMedia { get; set; }
        /// <summary>
        /// Clé de la qualification de premier niveau de l'appel.
        /// </summary>
        [DataMember]
        public int CleQualificationAppelNiveau1 { get; set; }
        /// <summary>
        /// Clé de la qualification de second niveau de l'appel.
        /// </summary>
        [DataMember]
        public int CleQualificationAppelNiveau2 { get; set; }
        /// <summary>
        /// Clé origine.
        /// </summary>
        [DataMember]
        public Nullable<int> CleOrigine { get; set; }
        /// <summary>
        /// Commentaire.
        /// </summary>
        [DataMember]
        public string Commentaire { get; set; }
        /// <summary>
        /// Type métier niveau 1.
        /// </summary>
        [DataMember]
        public TypeHistoriqueMetierNiveau1 TypeMetierNiveau1 { get; set; }
        /// <summary>
        /// Type métier niveau 2.
        /// </summary>
        [DataMember]
        public TypeHistoriqueMetierNiveau2 TypeMerierNiveau2 { get; set; }

    }
}
