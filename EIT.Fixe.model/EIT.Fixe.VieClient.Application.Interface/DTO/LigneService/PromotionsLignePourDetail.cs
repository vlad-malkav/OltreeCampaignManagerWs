﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du détail des promotions en place sur une ligne + informations minimales de la ligne. 
    /// </summary>
    [DataContract]
    public class PromotionsLignePourDetail
    {
        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Référence externe de la ligne.
        /// </summary>
        [DataMember]
        public string RefExterne { get; set; }

        /// <summary>
        /// Liste des promotions à l'état {Active}.
        /// </summary>
        [DataMember]
        public PromotionLignePourLister[] ListePromotionsActives { get; set; }

        /// <summary>
        /// Liste des promotions à l'état {Expirée ou Résiliée}.
        /// </summary>
        [DataMember]
        public PromotionLignePourLister[] ListePromotionsObsoletes { get; set; }
        
    }
}