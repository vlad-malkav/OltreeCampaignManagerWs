﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations minimales d’une promotion nécessaires à l’affichage dans une liste déroulante. 
    /// </summary>
    [DataContract]
    public class PromotionPourLister 
    {
        /// <summary>
        /// Clé unique de la promotion.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Descriptif de la promotion.
        /// </summary>
        [DataMember]
        public string Descriptif { get; set; }

        /// <summary>
        /// Prix TTC de la promotion, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal PrixTtc { get; set; }

        /// <summary>
        /// Durée de validité (en mois) de la promotion. 
        /// Null si la promotion est illimitée.        
        /// </summary>
        [DataMember]
        public int? DureeValiditeEnMois { get; set; }
    }
}