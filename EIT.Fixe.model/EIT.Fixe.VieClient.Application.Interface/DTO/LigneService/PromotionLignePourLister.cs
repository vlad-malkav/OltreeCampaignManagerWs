﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary> 
    /// Classe de présentation du détail des informations 
    /// relatives à une promotion en place sur une ligne. 
    /// </summary> 
    [DataContract]
    public class PromotionLignePourLister
    {
        /// <summary> 
        /// Clé unique de la (demande de remise de type) promotion. 
        /// </summary> 
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de la promotion.
        /// </summary>
        [DataMember]
        public string Descriptif { get; set; }

        /// <summary>
        /// Code de la promotion.
        /// </summary>
        [DataMember]
        public string CodePromo { get; set; }

        /// <summary>
        /// Enum définit sur quoi appliquée la promotion.
        /// </summary>
        [DataMember]
        public TypeApplicationPromotion TypeApplication { get; set; }
        
        /// <summary>
        /// Date d'application.
        /// </summary>
        [DataMember]
        public DateTime DateApplication { get; set; }

        /// <summary>
        /// Durée de validité de la promotion en mois. Null si la promotion est illimitée.
        /// </summary>
        [DataMember]
        public int? DureeValiditeEnMois { get; set; }

        /// <summary>
        /// Le montant TTC de la promotion liée à l'offre.
        /// </summary>
        [DataMember]
        public decimal? MontantPromotionSurOffre { get; set; }

        /// <summary>
        /// Le montant TTC de la promotion liée à la commande de souscription de la ligne.
        /// </summary>
        [DataMember]
        public decimal? MontantPromotionSurCommande { get; set; }

        /// <summary>
        /// MemoID du conseiller qui a mis en place la promotion ou au login de l’espace 
        /// client du client (ID du client) ou BCH pour le canal technique.
        /// </summary>
        [DataMember]
        public string MemoID { get; set; }

        /// <summary>
        /// Etat de la demande de remise.
        /// </summary>
        [DataMember]
        public EtatDemandeRemise Etat { get; set; }

        /// <summary>
        /// Date de fin de la promotion. 
        /// ie : date de l’état actuel de la promotion si et seulement si Etat = { Expiree ou Résiliee }
        /// Corolaire : DateFin = null si Etat = { Activee }.
        /// </summary>
        [DataMember]
        public DateTime? DateFin { get; set; }

        /// <summary>
        /// Indique si la demande de remise est supprimable ou non.
        /// </summary>
        [DataMember]
        public bool EstSuppressionPossible { get; set; }
    }
}