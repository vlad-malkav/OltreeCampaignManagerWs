﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Liste de clés des demandes de remise en place sur une ligne et éligibles à expiration + clé de la ligne associée.
    /// </summary>
    [DataContract]
    public class DemandesRemisesLignePourExpiration
    {
        /// <summary>
        /// Clé unique de la ligne qui contient des demandes de remise éligibles à expiration.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }
       
        /// <summary>
        /// Liste des clés des demandes de remise éligibles à expiration sur la ligne.
        /// </summary>
        [DataMember]
        public List<long> ListeClesDemandeRemise { get; set; }
    }
}