﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations décrivant les équipements associés à la ligne.
    /// </summary>
    [DataContract]
    public sealed class InformationsEquipementsLigne
    {
        /// <summary>
        /// Référence externe de la ligne.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Référence du kit de la box.
        /// </summary>
        [DataMember]
        public string ReferenceKitBox { get; set; }

        /// <summary>
        /// Clé du kit de la box.
        /// </summary>
        [DataMember]
        public long CleKitBox { get; set; }

        /// <summary>
        /// Montant du dépôt de garantie.
        /// </summary>
        [DataMember]
        public decimal MontantDepotGarantie { get; set; }

        /// <summary>
        /// Descriptif du kit.
        /// </summary>
        [DataMember]
        public string DescriptionKitBox { get; set; }

        /// <summary>
        /// Liste des équipements de la ligne.
        /// </summary>
        [DataMember]
        public EquipementLignePourLister[] ListeEquipementLignePourLister { get; set; }
        
        /// <summary>
        /// Indique si le lien "Créer SAV équipement" est affiché.
        /// </summary>
        [DataMember]
        public bool EstCreationSavEquipementPossible { get; set; }
        
        /// <summary>
        /// Indique si le lien "Créer SAV technicien" est affiché.
        /// </summary>
        [DataMember]
        public bool EstCreationSavTechnicienPossible { get; set; }
    }
}