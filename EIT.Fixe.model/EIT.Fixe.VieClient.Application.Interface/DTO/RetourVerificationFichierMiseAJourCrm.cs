﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations retournées après la vérification du fichier pour la mise à jour CRM.
    /// </summary>
    [DataContract]
    public class RetourVerificationFichierMiseAJourCrm
    {
        /// <summary>
        /// Indique si le fichier est valide pour la mise à jour.
        /// </summary>
        [DataMember]
        public bool EstFichierValide { get; set; }

        /// <summary>
        /// Nombre de lignes traitées.
        /// </summary>
        [DataMember]
        public int NombreLignesTraitees { get; set; }

        /// <summary>
        /// Lignes en erreur dans le fichier.
        /// </summary>
        [DataMember]
        public ErreurFichierMiseAJourCrmPourLister[] Erreurs { get; set; }

    }
}
