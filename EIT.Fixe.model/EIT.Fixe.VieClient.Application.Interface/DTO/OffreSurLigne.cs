﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations de l'offre sur la ligne.
    /// </summary>
    [DataContract]
    public class OffreSurLigne
    {
        /// <summary>
        /// Clé de l'offre.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Nom de l'offre.
        /// </summary>
        [DataMember]
        public string Nom { get; set; }

        /// <summary>
        /// Texte informatif.
        /// </summary>
        [DataMember]
        public string Descriptif { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        [DataMember]
        public string LibelleMarque { get; set; }

        /// <summary>
        /// Date d'activation de la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateActivation { get; set; }
    }
}
