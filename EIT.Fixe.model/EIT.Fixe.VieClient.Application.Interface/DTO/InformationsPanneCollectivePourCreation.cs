﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’une panne collective pour sa création.
    /// </summary>
    [DataContract]
    public class InformationsPanneCollectivePourCreation
    {
        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }
        
        /// <summary>
        /// Date de début de la panne.
        /// </summary>
        [DataMember]
        public DateTime DateDebut { get; set; }
    }
}