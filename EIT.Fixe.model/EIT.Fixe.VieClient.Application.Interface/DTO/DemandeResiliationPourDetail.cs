﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail d'une demande de résiliation.
    /// </summary>
    [DataContract]
    public class DemandeResiliationPourDetail
    {
        /// <summary>
        /// Informations sur la ligne.
        /// </summary>
        [DataMember]
        public LignePourDetail InformationsLigne { get; set; }

        /// <summary>
        /// Date de la demande de résiliation.
        /// </summary>
        [DataMember]
        public DateTime DateDemandeResiliation { get; set; }

        /// <summary>
        /// Origine de la demande de résiliation.
        /// </summary>
        [DataMember]
        public OrigineResiliation OrigineDemandeResiliation { get; set; }

        /// <summary>
        /// Libellé du motif de résiliation.
        /// </summary>
        [DataMember]
        public string LibelleMotifResiliation { get; set; }

        /// <summary>
        /// Libellé du mode de retour équipement.
        /// </summary>
        [DataMember]
        public string LibelleModeRetourEquipement { get; set; }

        /// <summary>
        /// Type de prise en charge.
        /// </summary>
        [DataMember]
        public TypePriseEnCharge TypePriseEnCharge { get; set; }

        /// <summary>
        /// Type de résiliation de la demande.
        /// </summary>
        [DataMember]
        public TypeResiliation TypeResiliation { get; set; }

        /// <summary>
        /// Indique si des frais de résiliation sont appliqués.
        /// </summary>
        [DataMember]
        public bool EstFraisResiliationAppliques { get; set; }

        /// <summary>
        /// Date de résiliation programmée pour la demande.
        /// </summary>
        [DataMember]
        public DateTime DateResiliationProgrammee { get; set; }

        /// <summary>
        /// Date d'annulation de la demande de résiliation.
        /// </summary>
        [DataMember]
        public DateTime? DateAnnulationDemandeResiliation { get; set; }

        /// <summary>
        /// Date de fin engagement.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Date de réception du courrier avec accusé reception.
        /// </summary>
        [DataMember]
        public DateTime DateReceptionCourrierAr { get; set; }

        /// <summary>
        /// Email du titulaire pour le bon de retour.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Adresse pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public TiersPourEnvoiBonRetour AdresseBonRetour { get; set; }

        /// <summary>
        /// Clé de la demande de retour équipement.
        /// </summary>
        [DataMember]
        public long CleDemandeRetourEquipement { get; set; }

        /// <summary>
        /// Numéro du retour équipement.
        /// </summary>
        [DataMember]
        public string NumeroRetourEquipement { get; set; }

        /// <summary>
        /// Indique si la demande de résiliation peut être annulée.
        /// </summary>
        [DataMember]
        public bool EstAnnulable { get; set; }
    }
}
