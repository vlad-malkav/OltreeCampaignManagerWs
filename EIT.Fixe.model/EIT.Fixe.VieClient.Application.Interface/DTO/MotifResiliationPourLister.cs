﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’un motif de résiliation d’une ligne fixe pour afficher dans une liste.
    /// </summary>
    [DataContract]
    public class MotifResiliationPourLister
    {
        /// <summary>
        /// Clé du motif de résiliation.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé du motif de résiliation.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Ordre d'affichage des motifs de résiliation.
        /// </summary>
        [DataMember]
        public int Ordre { get; set; }

        /// <summary>
        /// Origine de la résiliation.
        /// </summary>
        [DataMember]
        public OrigineResiliation OrigineResiliation { get; set; }

        /// <summary>
        /// Type de la résiliation.
        /// </summary>
        [DataMember]
        public TypeResiliation TypeResiliation { get; set; }

        /// <summary>
        /// Liste des modes de retour équipement.
        /// </summary>
        [DataMember]
        public ModeRetourEquipementPourLister[] ListeModeRetourEquipement { get; set; }

        /// <summary>
        /// Délai de résiliation.
        /// </summary>
        [DataMember]
        public int DelaiResiliation { get; set; }

        /// <summary>
        /// Indique si des frais de résiliation son appliqués.
        /// </summary>
        [DataMember]
        public bool EstFraisResiliationAppliques { get; set; }
    }
}