﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Equipement de la ligne pour lister.
    /// </summary>
    [DataContract]
    public sealed class EquipementLignePourLister
    {
        /// <summary>
        /// Clé unique de l'équipement.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Clé unique de l'équipement.
        /// </summary>
        [DataMember]
        public TypeRefCom Type { get; set; }

        /// <summary>
        /// Modèle de l'équipement.
        /// </summary>
        [DataMember]
        public string Modele { get; set; }

        /// <summary>
        /// Adresse MAC.
        /// </summary>
        [DataMember]
        public string AdresseMac { get; set; }

        /// <summary>
        /// Numéro de carte TV.
        /// </summary>
        [DataMember]
        public string NumeroCarteTv { get; set; }

        /// <summary>
        /// Numéro de série.
        /// </summary>
        [DataMember]
        public string NumeroSerie { get; set; }

        /// <summary>
        /// Etat de l'équipement.
        /// </summary>
        [DataMember]
        public EtatEquipement Etat { get; set; }

        /// <summary>
        /// Code article.
        /// </summary>
        [DataMember]
        public string CodeArticle { get; set; }

        /// <summary>
        /// Code de la référence commerciale de l'équipement.
        /// </summary>
        [DataMember]
        public string CodeRefCom { get; set; }
    }
}