﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d’une panne collective, en vue de les lister.
    /// </summary>
    [DataContract]
    public class PanneCollectivePourLister
    {
        /// <summary>
        /// Clé technique de la panne.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Date de début de la panne.
        /// </summary>
        [DataMember]
        public DateTime DateDebut { get; set; }
    }
}