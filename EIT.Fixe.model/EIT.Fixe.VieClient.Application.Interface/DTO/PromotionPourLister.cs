﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Promotion active de type Offre d'une ligne pour le selfcare
    /// </summary>
    public class PromotionPourLister
    {

    }
}
