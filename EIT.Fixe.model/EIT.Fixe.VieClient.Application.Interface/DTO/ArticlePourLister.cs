﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Article pour lister.
    /// </summary>
    [DataContract]
    public class ArticlePourLister
    {
        /// <summary>
        /// Type d'article.
        /// </summary>
        [DataMember]
        public string Type { get; set; }

        /// <summary>
        /// Modèle de l'article.
        /// </summary>
        [DataMember]
        public string Modele { get; set; }

        /// <summary>
        /// Numéro de série de l'article.
        /// </summary>
        [DataMember]
        public string NumeroSerie { get; set; }

        /// <summary>
        /// Indique si l'article est obligatoire.
        /// </summary>
        [DataMember]
        public bool EstObligatoire { get; set; }
    }
}
