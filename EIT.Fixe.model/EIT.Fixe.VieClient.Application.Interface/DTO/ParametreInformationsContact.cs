﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Paramètres d'informations de contact.
    /// </summary>
    [DataContract]
    public class ParametreInformationsContact
    {
        /// <summary>
        /// Clé du tiers.
        /// </summary>
        [DataMember]
        public long CleTiers { get; set; }

        /// <summary>
        /// Choix du client pour le contact par mailing.
        /// </summary>
        [DataMember]
        public bool ContactCourrier { get; set; }

        /// <summary>
        /// Choix du client pour le contact par télévente.
        /// </summary>
        [DataMember]
        public bool ContactTelevente { get; set; }

        /// <summary>
        /// Choix du client pour le contact par emailing.
        /// </summary>
        [DataMember]
        public bool ContactMail { get; set; }

        /// <summary>
        /// Choix du client pour le contact par sms.
        /// </summary>
        [DataMember]
        public bool ContactSms { get; set; }

        /// <summary>
        /// Choix du client pour le contact par message vocal.
        /// </summary>
        [DataMember]
        public bool ContactMessageVocal { get; set; }
    }
}
