﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d'une ligne pour sa création.
    /// </summary>
    [DataContract]
    public class InformationsLignePourCreationEtActivation
    {
        /// <summary>
        /// Clé marque.
        /// </summary>
        [DataMember]
        public int CleMarque { get; set; }

        /// <summary>
        /// Clé de l’offre souscrite.
        /// </summary>
        [DataMember]
        public int CleOffre { get; set; }
        
        /// <summary>
        /// Clé du tiers ayant souscrit l’offre.
        /// </summary>
        [DataMember]
        public long CleTiers { get; set; }

        /// <summary>
        /// Clé de la technologie de la ligne.
        /// </summary>
        [DataMember]
        public int CleTechnologie { get; set; }

        /// <summary>
        /// Clé de la commande d'expédition.
        /// </summary>
        [DataMember]
        public long CleCommandeExpedition { get; set; }

        /// <summary>
        /// Référence externe (identifiant THD).
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }
        
        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }
        
        /// <summary>
        /// Clé du compte de facturation de la ligne.
        /// </summary>
        [DataMember]
        public long CleCompteFacturation { get; set; }
        
        /// <summary>
        /// Clé du gestionnaire des options.
        /// </summary>
        [DataMember]
        public string CleGestionnaireOptions { get; set; }
        
        /// <summary>
        /// Numéro de contrat fourni par l’opérateur.
        /// </summary>
        [DataMember]
        public string NumeroContratOperateur { get; set; }
        
        /// <summary>
        /// Clé adresse d'installation.
        /// </summary>
        [DataMember]
        public long CleAdresseInstallation { get; set; }
        
        /// <summary>
        /// Clé ICN.
        /// </summary>
        [DataMember]
        public int? CleIcn { get; set; }

        /// <summary>
        /// Date de fin d’engagement.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Liste des clés des promotions appliquées sur la ligne.
        /// </summary>
        [DataMember]
        public List<long> ListeClesPromotions { get; set; }
        
        /// <summary>
        /// Numéro RIO sortant de la ligne.
        /// </summary>
        [DataMember]
        public string Rio { get; set; }
        
        /// <summary>
        /// Identifiant de transaction chez l'opérateur.
        /// </summary>
        [DataMember]
        public int IdentifiantTransactionOperateur { get; set; }

        /// <summary>
        /// Cle du KitBox.
        /// </summary>
        [DataMember]
        public long CleKitBox { get; set; }
    }
}