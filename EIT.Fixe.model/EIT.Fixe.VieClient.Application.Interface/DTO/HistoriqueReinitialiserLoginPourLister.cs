﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de l'historique de réinitialisation de login pour lister.
    /// </summary>
    [DataContract]
    public class HistoriqueReinitialiserLoginPourLister
    {
        /// <summary>
        /// Typde de demande.
        /// </summary>
        [DataMember]
        public string Type { get; set; }

        /// <summary>
        /// Date de la demande.
        /// </summary>
        [DataMember]
        public DateTime DateDemande { get; set; }

        /// <summary>
        /// Identifiant du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string Identifiant { get; set; }

        /// <summary>
        /// Mode d'envoi de la réinitialisation.
        /// </summary>
        [DataMember]
        public CanalCommunication ModeEnvoi { get; set; }

        /// <summary>
        /// Destinataire de la réinitialisation.
        /// </summary>
        [DataMember]
        public string Destinataire { get; set; }

        /// <summary>
        /// MemoId à l'initiative de la demande.
        /// </summary>
        [DataMember]
        public string MemoId { get; set; }

        /// <summary>
        /// Canal de la demande.
        /// </summary>
        [DataMember]
        public string Canal { get; set; }
    }
}
