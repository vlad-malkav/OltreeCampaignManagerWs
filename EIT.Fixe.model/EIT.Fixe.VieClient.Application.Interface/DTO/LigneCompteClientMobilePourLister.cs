﻿using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d'un compte client mobile, en vue de les lister.
    /// </summary>
    [DataContract]
    public class LigneCompteClientMobilePourLister
    {
        /// <summary>
        /// Numéro de la ligne mobile (MSISDN).
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// L’accès à la synthèse CRM mobile est-elle accessible pour cette ligne ou non.
        /// </summary>
        [DataMember]
        public bool EstSyntheseCrmMobileAccessible { get; set; }

        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Nom et prénom de l'utilisateur, si celui-ci est différent du titulaire de la ligne mobile.  
        /// Si non, c'est le nom/prénom du titulaire qui s'affiche.
        /// </summary>
        [DataMember]
        public string Utilisateur { get; set; }

        /// <summary>
        /// Libellé de l’offre commercialisée.
        /// </summary>
        [DataMember]
        public string Offre { get; set; }

        /// <summary>
        /// Réseau full ou light.
        /// </summary>
        [DataMember]
        public bool EstReseauFull { get; set; }

        /// <summary>
        /// Seuil de surconsommation, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal SeuilSurconsommation { get; set; }

        /// <summary>
        /// Score de churn.
        /// </summary>
        [DataMember]
        public int ScoreChurn { get; set; }


        /// <summary>
        /// Valeur du Statut de la ligne.
        /// </summary>
        [DataMember]
        public EtatLigneMobile Statut { get; set; }


        /// <summary>
        /// Libellé du Statut de la ligne.
        /// </summary>
        [DataMember]
        public string LibelleStatut
        {
            get
            {
                return EnumExtension.GetEnumDescription(this.Statut);
            }
        }

        /// <summary>
        /// Détail du niveau d’accès au SFC mobile.
        /// </summary>
        [DataMember]
        public string NiveauAccessEspaceClientMobile { get; set; }
    }
}