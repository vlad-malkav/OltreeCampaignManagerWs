﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’un historique de ligne pour alimenter une liste.
    /// Remarque : L’ensemble des informations portées par cet objet proviennent du service externe Historique.
    /// </summary>
    [DataContract]
    public class HistoriqueLignePourLister
    {
        /// <summary>
        /// Clé unique de l’historique.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Date et heure de l’historique.
        /// </summary>
        [DataMember]
        public DateTime Date { get; set; }

        /// <summary>
        /// Libellé du métier historique niveau 1.
        /// </summary>
        [DataMember]
        public string Type { get; set; }

        /// <summary>
        /// Libellé du métier historique niveau 2.
        /// </summary>
        [DataMember]
        public string Historique { get; set; }

        /// <summary>
        /// Canal à l’origine de l’historique.
        /// </summary>
        [DataMember]
        public string Canal { get; set; }

        /// <summary>
        /// Agent étant à l’origine de l’historique.
        /// </summary>
        [DataMember]
        public string Agent { get; set; }

        /// <summary>
        /// Le détail de cet historique est-il accessible ?
        /// </summary>
        [DataMember]
        public bool EstDetailAccessible { get; set; }
    }
}