﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de la ligne pour le SVI RIO.
    /// </summary>
    [DataContract]
    public class InformationsLignePourSviRio
    {
        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }

        /// <summary>
        /// Rio de la ligne.
        /// </summary>
        [DataMember]
        public string Rio { get; set; }

        /// <summary>
        /// Clé de la marque de la ligne.
        /// </summary>
        [DataMember]
        public int CleMarque { get; set; }

        /// <summary>
        /// Date de fin d’engagement de l’offre associée à la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Numéro mobile de contact du tiers de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroMobileContactTiers { get; set; }
    }
}
