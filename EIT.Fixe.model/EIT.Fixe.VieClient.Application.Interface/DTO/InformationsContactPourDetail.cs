﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de contact pour détail.
    /// </summary>
    [DataContract]
    public class InformationsContactPourDetail
    {
        /// <summary>
        /// Clé du tiers.
        /// </summary>
        [DataMember]
        public long CleTiers { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile de contact.
        /// </summary>
        [DataMember]
        public string TelephoneMobileDeContact { get; set; }

        /// <summary>
        /// Email de contact.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// URL du SelfCare.
        /// </summary>
        [DataMember]
        public string UrlSelfCare { get; set; }
    }
}
