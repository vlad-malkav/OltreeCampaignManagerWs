﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail des options de la ligne.
    /// </summary>
    [DataContract]
    public class OptionsLignePourDetail
    {
        /// <summary>
        /// Informations sur la ligne.
        /// </summary>
        [DataMember]
        public LignePourDetail InformationsLigne { get; set; }

        /// <summary>
        /// Liste des options de la ligne regroupée par catégorie et regroupement.
        /// </summary>
        [DataMember]
        public CategorieOptionsPourLister[] ListeCategorieOptions { get; set; }

        /// <summary>
        /// Montant total des options valorisées récurrentes.
        /// </summary>
        [DataMember]
        public decimal MontantTotalOptionsValoriseesRecurrentes { get; set; }
    }
}
