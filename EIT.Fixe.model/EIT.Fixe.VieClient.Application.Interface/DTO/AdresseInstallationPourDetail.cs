﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations composant une adresse d'installation.
    /// </summary>
    [DataContract]
    public class AdresseInstallationPourDetail
    {
        /// <summary>
        /// Clé unique de l'adresse.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de l'habitation.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }
        
        /// <summary>
        /// Nom de la rue.
        /// </summary>
        [DataMember]
        public string Rue { get; set; }

        /// <summary>
        /// Code postal.
        /// </summary>
        [DataMember]
        public string CodePostal { get; set; }

        /// <summary>
        /// Ville.
        /// </summary>
        [DataMember]
        public string Ville { get; set; }

        /// <summary>
        /// Complément.
        /// </summary>
        [DataMember]
        public string Complement { get; set; }
        
        /// <summary>
        /// Batiment.
        /// </summary>
        [DataMember]
        public string Batiment { get; set; }

        /// <summary>
        /// Etage.
        /// </summary>
        [DataMember]
        public string Etage { get; set; }

        /// <summary>
        /// Appartement.
        /// </summary>
        [DataMember]
        public string Appartement { get; set; }

        /// <summary>
        /// Escalier.
        /// </summary>
        [DataMember]
        public string Escalier { get; set; }
    }
}