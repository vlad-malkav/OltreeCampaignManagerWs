﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Objet de présentation ProfessionPourLister. 
    /// </summary>
    [DataContract]
    public class ProfessionPourLister
    {
        /// <summary>
        /// Clé de la profession.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libelle de la profession.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

    }
}
