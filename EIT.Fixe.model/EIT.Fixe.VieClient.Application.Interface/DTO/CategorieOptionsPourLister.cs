﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Catégorie des options.
    /// </summary>
    [DataContract]
    public class CategorieOptionsPourLister
    {
        /// <summary>
        /// Clé de la catégorie.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Libellé de la catégorie.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Ordre pour l'affichage de la catégorie.
        /// </summary>
        [DataMember]
        public int Ordre { get; set; }

        /// <summary>
        /// Liste des regroupements appartenant à la catégorie.
        /// </summary>
        [DataMember]
        public RegroupementOptionsPourLister[] ListeRegroupementOptions { get; set; }
    }
}
