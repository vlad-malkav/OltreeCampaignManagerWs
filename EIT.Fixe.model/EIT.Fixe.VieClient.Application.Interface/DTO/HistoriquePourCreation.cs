﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations concernant l'historique, pour sa création.
    /// </summary>
    /// <remarks>Il s'agit ici d'un historique de type Appel.</remarks>
    [DataContract]
    public class HistoriquePourCreation
    {
        /// <summary>
        /// Clé du métier de niveau 1.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Fonctionnel.</remarks>
        [DataMember]
        public int CleMetier1 { get; set; }

        /// <summary>
        /// Clé du métier de niveau 2.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Fonctionnel.</remarks>
        [DataMember]
        public int CleMetier2 { get; set; }

        /// <summary>
        /// Commentaire de l'historique.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Fonctionnel.</remarks>
        [DataMember]
        public string Commentaire { get; set; }

        /// <summary>
        /// Clé origine de l'historique.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Fonctionnel.</remarks>
        [DataMember]
        public int? CleOrigine { get; set; }

        /// <summary>
        /// Nom du tiers.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public string NomTiers { get; set; }

        /// <summary>
        /// Prénom du tiers.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public string PrenomTiers { get; set; }

        /// <summary>
        /// Numéro de téléphone de l'appelant.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public string NumeroTelephoneAppelant { get; set; }

        /// <summary>
        /// Numéro de téléphone de l'appelé.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public string NumeroTelephoneAppele { get; set; }

        /// <summary>
        /// Date de l'appel.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public DateTime DateAppel { get; set; }

        /// <summary>
        /// Durée de l'appel.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public int DureeAppel { get; set; }

        /// <summary>
        /// Clé du canal média.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public int CleCanalMedia { get; set; }

        /// <summary>
        /// Clé de qualification d'appel de niveau 1.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public int CleQualificationAppelNiveau1 { get; set; }

        /// <summary>
        /// Clé de qualification d'appel de niveau 2.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public int CleQualificationAppelNiveau2 { get; set; }

        /// <summary>
        /// Point de vente CMI.
        /// </summary>
        /// <remarks>Utilisé par l'historique de type Appel.</remarks>
        [DataMember]
        public string PointDeVenteCmi { get; set; }
    }
}