﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation des informations d'une demande de retractation à créer.
    /// </summary>
    [DataContract]
    public class DemandeRetractationPourCreation
    {
        /// <summary>
        /// Date de reception du courrier avec accusé de réception.
        /// </summary>
        [DataMember]
        public DateTime DateReceptionCourierAr { get; set; }

        /// <summary>
        /// Adresse email du titulaire.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// True si une nouvelle adresse a été saisie. False sinon.
        /// </summary>
        [DataMember]
        public bool EstNouveauTiersEnvoiBonRetour { get; set; }

        /// <summary>
        /// Tiers pour l'envoi du bon de retour. Renseigné si EstNouveauTiersEnvoiBonRetour est à True.
        /// </summary>
        [DataMember]
        public TiersPourEnvoiBonRetour TiersEnvoiBonRetour { get; set; }
    }
}
