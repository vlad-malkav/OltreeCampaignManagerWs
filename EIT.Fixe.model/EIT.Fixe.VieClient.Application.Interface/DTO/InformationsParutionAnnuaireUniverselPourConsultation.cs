﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations nécessaires à la consultation du détail de la parution à l’annuaire universel. 
    /// </summary>
    [DataContract]
    public class InformationsParutionAnnuaireUniverselPourConsultation
    {
        /// <summary>
        /// Clé technique du tiers.
        /// </summary>
        [DataMember]
        public long CleTiers { get; set; }

        /// <summary>
        /// Référence externe de la ligne.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de la ligne fixe.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Date d’activation de la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateActivation { get; set; }

        /// <summary>
        /// Description de l'offre.
        /// </summary>
        [DataMember]
        public string DescriptionOffre { get; set; }

        /// <summary>
        /// Inscrit dans l’annuaire universel.
        /// </summary>
        [DataMember]
        public bool EstInscritAnnuaireUniversel { get; set; }

        /// <summary>
        /// Email.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Choix de parution renseignées si inscrit à l’annuaire universel.
        /// </summary>
        [DataMember]
        public ChoixParutionAnnuaire ChoixParutionAnnuaire { get; set; }
    }
}
