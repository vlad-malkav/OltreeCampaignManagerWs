﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations composant une adresse postale.
    /// </summary>
    [DataContract]
    public class AdressePourDetail
    {
        /// <summary>
        /// Voie.
        /// </summary>
        [DataMember]
        public string Voie { get; set; }

        /// <summary>
        /// Complement de l'adresse.
        /// </summary>
        [DataMember]
        public string Complement { get; set; }

        /// <summary>
        /// Code postal.
        /// </summary>
        [DataMember]
        public string CodePostal { get; set; }

        /// <summary>
        /// Ville.
        /// </summary>
        [DataMember]
        public string Ville { get; set; }
    }
}
