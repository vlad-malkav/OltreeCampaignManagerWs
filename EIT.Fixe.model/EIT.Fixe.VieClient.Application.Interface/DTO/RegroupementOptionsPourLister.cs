﻿using EIT.Fixe.Domain.CommonTypes;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Regroupements des options.
    /// </summary>
    [DataContract]
    public class RegroupementOptionsPourLister
    {
        /// <summary>
        /// Clé du regroupement.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du regroupement.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Type d'exclusion pour le regroupement.
        /// </summary>
        [DataMember]
        public TypeExclusion TypeExclusion { get; set; }

        /// <summary>
        /// Ordre pour l'affichage du regroupement.
        /// </summary>
        [DataMember]
        public int Ordre { get; set; }

        /// <summary>
        /// Indique si le regroupement est modifiable.
        /// </summary>
        [DataMember]
        public bool EstModifiable { get; set; }

        /// <summary>
        /// Indique si aucune option du regroupement est modifiable.
        /// </summary>
        [DataMember]
        public bool EstAcuneOptionActive { get; set; }

        /// <summary>
        /// Liste des options appartenant au regroupement.
        /// </summary>
        [DataMember]
        public OptionPourLister[] Options { get; set; }
    }
}
