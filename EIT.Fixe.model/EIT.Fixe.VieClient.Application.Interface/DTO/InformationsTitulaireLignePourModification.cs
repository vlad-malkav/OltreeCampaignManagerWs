﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations du titulaire à modifier.
    /// </summary>
    [DataContract]
    public class InformationsTitulaireLignePourModification
    {
        /// <summary>
        /// Numéro de téléphone fixe du contact du tiers.
        /// </summary>
        [DataMember]
        public string TelephoneFixe { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du contact du tiers.
        /// </summary>
        [DataMember]
        public string TelephoneMobile { get; set; }

        /// <summary>
        /// Adresse email du tiers.
        /// </summary>
        [DataMember]
        public string Email { get; set; }
    }
}
