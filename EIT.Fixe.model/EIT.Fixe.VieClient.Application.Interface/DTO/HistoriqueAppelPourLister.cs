﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d'un historique d'appel.
    /// </summary>
    [DataContract]
    public class HistoriqueAppelPourLister
    {
        /// <summary>
        /// Clé du type métier de niveau 1.
        /// </summary>
        [DataMember]
        public long CleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Libellé du type métier de niveau 1.
        /// </summary>
        [DataMember]
        public string LibelleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Clé du type métier de niveau 2.
        /// </summary>
        [DataMember]
        public int CleTypeMetierNiveau2 { get; set; }

        /// <summary>
        /// Libellé du type métier de niveau 2.
        /// </summary>
        [DataMember]
        public string LibelleTypeMetierNiveau2 { get; set; }

        /// <summary>
        /// Clé de la qualification d'appel de niveau 1.
        /// </summary>
        [DataMember]
        public int CleQualificationAppelNiveau1 { get; set; }

        /// <summary>
        /// Libellé de la qualification d'appel de niveau 1.
        /// </summary>
        [DataMember]
        public string LibelleQualificationAppelNiveau1 { get; set; }

        /// <summary>
        /// Clé de la qualification d'appel de niveau 2.
        /// </summary>
        [DataMember]
        public int CleQualificationAppelNiveau2 { get; set; }

        /// <summary>
        /// Libellé de la qualification d'appel de niveau 2.
        /// </summary>
        [DataMember]
        public string LibelleQualificationAppelNiveau2 { get; set; }
    }
}