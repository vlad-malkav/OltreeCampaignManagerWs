﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    public class InformationLigne
    {
        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Valeur de l'état de la ligne fixe.
        /// </summary>
        public EtatLigne Etat { get; set; }

        /// <summary>
        /// Clé unique de la technologie de la ligne.
        /// </summary>
        public int CleTechnologie { get; set; }

        /// <summary>
        /// Référence externe, commune avec la commande de souscription, la commande d’activation ainsi que la commande d’expédition. 
        /// Remarque : a été mis en place afin de faciliter les interactions entre ces entités appartenant à des domaines distincts.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Clé de l’adresse d’installation.
        /// </summary>
        /// <remarks>
        /// La clé d'adresse d'installation et la clé d'éligibilité sont une seule et même donnée. On parle
        /// d'adresse d'éligiblité en Souscription et d'adresse d'installation en post-Souscription.
        /// </remarks>
        public long CleAdresseInstallation { get; set; }

        /// <summary>
        /// Clé du compte de facturation de la ligne.
        /// </summary>
        public long CleCompteFacturation { get; set; }
        
        /// <summary>
        /// Clé du gestionnaire des options.
        /// </summary>
        public string CleGestionnaireOptions { get; set; }

        /// <summary>
        /// Numéro de contrat fourni par l’opérateur.
        /// </summary>
        public string NumeroContratOperateur { get; set; }

        /// <summary>
        /// Identifiant de transaction avec l’opérateur.
        /// </summary>
        public int IdentifiantTransactionOperateur { get; set; }

        /// <summary>
        /// Clé marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Statut de surconsommation de la ligne.
        /// </summary>
        public ProfilSurconsommation StatutSurconsommation { get; set; }

        /// <summary>
        /// Date de fin d’engagement.
        /// </summary>
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Clé de l’offre souscrite.
        /// </summary>
        public int CleOffre { get; set; }

        /// <summary>
        /// Clé du tiers ayant souscrit l’offre.
        /// </summary>
        public long CleTiers { get; set; }

        /// <summary>
        /// Clé ICN.
        /// </summary>
        public int? CleIcn { get; set; }

        /// <summary>
        /// Numéro RIO sartant de la ligne.
        /// </summary>
        public string Rio { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        public DateTime SuiviDateCreation { get; set; }

        /// <summary>
        /// Agent de création.
        /// </summary>
        public string SuiviAgentCreation { get; set; }

        /// <summary>
        /// Date de dernière modification.
        /// </summary>
        public DateTime? SuiviDateModification { get; set; }

        /// <summary>
        /// Agent ayant effectué la dernière modification.
        /// </summary>
        public string SuiviAgentModification { get; set; }
    }
}
