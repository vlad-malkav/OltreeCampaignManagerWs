﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de la ligne pour le Selfcare.
    /// </summary>
    [DataContract]
    public class InformationsLignePourSelfcare
    {
        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }

        /// <summary>
        ///  Clé du compte de facturation.
        /// </summary>
        [DataMember]
        public long CleCompteFacturation { get; set; }

        /// <summary>
        /// Numéro de téléphone de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroTelephone { get; set; }

        /// <summary>
        /// Référence externe.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Rio de la ligne.
        /// </summary>
        [DataMember]
        public string Rio { get; set; }

        /// <summary>
        /// Date de fin d’engagement de l’offre associée à la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Date d’activation de la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateActivation { get; set; }

        /// <summary>
        /// Prix remisé de l’offre.
        /// </summary>
        [DataMember]
        public decimal PrixOffreRemise { get; set; }

        /// <summary>
        /// Prix de l’option de location de la box.
        /// </summary>
        [DataMember]
        public decimal PrixLocationBox { get; set; }

        /// <summary>
        /// Adresse d’installation de la ligne.
        /// </summary>
        [DataMember]
        public AdresseInstallationPourDetail AdresseInstallation { get; set; }

        /// <summary>
        /// Clé de l’offre de la ligne.
        /// </summary>
        [DataMember]
        public int CleOffre { get; set; }

        /// <summary>
        /// Clé de la marque de la ligne.
        /// </summary>
        [DataMember]
        public int CleMarque { get; set; }
    }
}
