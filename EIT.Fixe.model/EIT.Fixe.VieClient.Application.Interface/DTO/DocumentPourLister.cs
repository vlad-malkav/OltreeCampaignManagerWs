﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations des documents pour lister.
    /// </summary>
    [DataContract]
    public class DocumentPourLister
    {
        /// <summary>
        /// RefDoc du document.
        /// </summary>
        [DataMember]
        public string RefDoc { get; set; }

        /// <summary>
        /// Libellé du document.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}
