﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations des erreurs du fichier de mise à jour CRM.
    /// </summary>
    [DataContract]
    public class ErreurFichierMiseAJourCrmPourLister
    {
        /// <summary>
        /// Numéro de la ligne en erreur.
        /// </summary>
        [DataMember]
        public int NumeroLigne { get; set; }

        /// <summary>
        /// Numéro de la colonne en erreur.
        /// </summary>
        [DataMember]
        public int NumeroColonne { get; set; }

        /// <summary>
        /// Erreur rencontrée.
        /// </summary>
        [DataMember]
        public string Erreur { get; set; }
    }
}
