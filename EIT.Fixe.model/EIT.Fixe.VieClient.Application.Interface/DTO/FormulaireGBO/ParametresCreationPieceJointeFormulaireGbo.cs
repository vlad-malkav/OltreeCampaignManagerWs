﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Paramètres de création d'une Pièce Jointe de Formulaire GBO.
    /// </summary>
    [DataContract]
    public class ParametresCreationPieceJointeFormulaireGbo
    {
        /// <summary>
        /// GUDOCID.
        /// </summary>
        [DataMember]
        public virtual string GuDocId { get; set; }

        /// <summary>
        /// Nom du fichier.
        /// </summary>
        [DataMember]
        public virtual string NomFichier { get; set; }
    }
}