﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire de niveau 2 de demande d'intervention.
    /// </summary>
    [DataContract]
    public class ParametresCreationFormulaireCN2DI : ParametresCreationFormulaireGbo
    {
        /// <summary>
        /// Nom client.
        /// </summary>
        [DataMember]
        public string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [DataMember]
        public string PrenomClient { get; set; }

        /// <summary>
        /// Numéro commande client.
        /// </summary>
        [DataMember]
        public string NumeroCommandeClient { get; set; }

        /// <summary>
        /// CléMotif du dysfonctionnement.
        /// </summary>
        [DataMember]
        public long CleMotifDysfonctionnement { get; set; }

        /// <summary>
        /// Clé Origine du dysfonctionnement.
        /// </summary>
        [DataMember]
        public long? CleOrigineDysfonctionnement { get; set; }

        /// <summary>
        /// Date approximative d'appel du service client.
        /// </summary>
        [DataMember]
        public DateTime DateApproxAppelServiceClient { get; set; }

        /// <summary>
        /// Raisons du dysfonctionnement.
        /// </summary>
        [DataMember]
        public string RaisonsDysfonctionnement  { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        [DataMember]
        public string DemandeClient  { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        [DataMember]
        public string SolutionsDejaApportees  { get; set; }

    }
}