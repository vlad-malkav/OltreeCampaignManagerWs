﻿using System;
using System.Runtime.Serialization;
using EIT.Fixe.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire de modification de profil surconsommation.
    /// </summary>
    [DataContract]
    public class ParametresCreationFormulaireMPS : ParametresCreationFormulaireGbo
    {
        /// <summary>
        /// Nom client.
        /// </summary>
        [DataMember]
        public string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [DataMember]
        public string PrenomClient  { get; set; }

        /// <summary>
        /// Date d'effet de la demande.
        /// </summary>
        [DataMember]
        public DateTime DateEffetDemande  { get; set; }

        /// <summary>
        /// Profil de surconsommation demandé.
        /// </summary>
        [DataMember]
        public ProfilSurconsommation ProfilSurconsoDemande  { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        [DataMember]
        public string Commentaire  { get; set; }

    }
}