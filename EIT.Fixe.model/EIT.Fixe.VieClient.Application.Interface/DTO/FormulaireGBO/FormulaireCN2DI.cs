﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire de niveau 2 de demande d'intervention.
    /// </summary>
    [DataContract]
    public class FormulaireCN2DI : FormulaireGBO
    {
        /// <summary>
        /// Nom client.
        /// </summary>
        [DataMember]
        public string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [DataMember]
        public string PrenomClient { get; set; }

        /// <summary>
        /// Numéro commande client.
        /// </summary>
        [DataMember]
        public string NumeroCommandeClient { get; set; }

        /// <summary>
        /// Motif du dysfonctionnement.
        /// </summary>
        [DataMember]
        public MotifDysfonctionnement MotifDysfonctionnement { get; set; }

        /// <summary>
        /// Origine du dysfonctionnement.
        /// </summary>
        [DataMember]
        public OrigineDysfonctionnement OrigineDysfonctionnement { get; set; }

        /// <summary>
        /// Date approximative d'appel du service client.
        /// </summary>
        [DataMember]
        public DateTime DateApproxAppelServiceClient { get; set; }

        /// <summary>
        /// Raisons du dysfonctionnement.
        /// </summary>
        [DataMember]
        public string RaisonsDysfonctionnement  { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        [DataMember]
        public string DemandeClient  { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        [DataMember]
        public string SolutionsDejaApportees  { get; set; }

    }
}