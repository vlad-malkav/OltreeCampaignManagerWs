﻿using System.Runtime.Serialization;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire GBO de base.
    /// </summary>
    [KnownType(typeof(FormulaireCN2DI))]
    [KnownType(typeof(FormulaireCN3EQ))]
    [KnownType(typeof(FormulaireMPS))]
    [KnownType(typeof(FormulaireRisqueResiliation))]
    [DataContract]
    public class FormulaireGBO
    {
        /// <summary>
        /// Clé technique du Formulaire GBO de base.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Clé du Dossier GBO.
        /// </summary>
        [DataMember]
        public long CleDossierGbo { get; set; }

        /// <summary>
        /// Adresse mail du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcAdresseMail { get; set; }

        /// <summary>
        /// Code banque du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcCodeBanque { get; set; }

        /// <summary>
        /// Code branche du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcCodeBranche { get; set; }

        /// <summary>
        /// Ligne directe du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcLigneDirecte { get; set; }

        /// <summary>
        /// Nom et prenom concaténés du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcNomPrenom { get; set; }

        /// <summary>
        /// Région du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public RegionCDC RegionCdc { get; set; }

        /// <summary>
        /// Référence Externe client.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Type technique du Formulaire GBO, servant de discriminant notamment dans les canaux
        /// N'est pas exposé
        /// </summary>
        [DataMember]
        public TypeFormulaireGBO TypeFormulaireGbo { get; set; }

        /// <summary>
        /// Pièces jointes associées à ce Formulaire GBO.
        /// </summary>
        [DataMember]
        public virtual PieceJointeFormulaireGbo[] ListePiecesJointes { get; set; }
    }
}