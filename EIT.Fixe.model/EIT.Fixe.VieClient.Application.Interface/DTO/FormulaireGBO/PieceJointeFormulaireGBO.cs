﻿using System.Runtime.Serialization;
using EIT.Domain;
using EIT.Fixe.Infrastructure;
using EIT.Fixe.Systeme.Identification;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation d'une Pièce Jointe de Formulaire GBO.
    /// </summary>
    [DataContract]
    public class PieceJointeFormulaireGbo
    {
        /// <summary>
        /// Clé technique d'une Pièce Jointe de Formulaire GBO de base.
        /// </summary>
        [DataMember]
        public virtual long Cle { get; set; }

        /// <summary>
        /// GUDOCID.
        /// </summary>
        [DataMember]
        public virtual string GuDocId { get; set; }

        /// <summary>
        /// Nom du fichier.
        /// </summary>
        [DataMember]
        public virtual string NomFichier { get; set; }
    }
}