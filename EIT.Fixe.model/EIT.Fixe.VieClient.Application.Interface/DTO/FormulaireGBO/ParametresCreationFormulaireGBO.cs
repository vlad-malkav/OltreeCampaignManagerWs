﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Paramètres de création du Formulaire GBO.
    /// </summary>
    [DataContract]
    public class ParametresCreationFormulaireGbo
    {

        /// <summary>
        /// Adresse mail du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcAdresseMail { get; set; }

        /// <summary>
        /// Code banque du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcCodeBanque { get; set; }

        /// <summary>
        /// Code branche du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcCodeBranche { get; set; }

        /// <summary>
        /// Ligne directe du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcLigneDirecte { get; set; }

        /// <summary>
        /// Nom et prenom concaténés du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public string CdcNomPrenom { get; set; }

        /// <summary>
        /// Région du Chargé de Clientèle.
        /// </summary>
        [DataMember]
        public long CdcCleRegion { get; set; }

        /// <summary>
        /// Référence Externe client.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }
    }
}