﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire de niveau 3 d'engagement qualité.
    /// </summary>
    [DataContract]
    public class FormulaireCN3EQ : FormulaireGBO
    {
        /// <summary>
        /// Numero de suivi du dossier concerné.
        /// </summary>
        [DataMember]
        public string NumeroSuiviDossier  { get; set; }

        /// <summary>
        /// Date de réponse cellule N2.
        /// </summary>
        [DataMember]
        public DateTime DateReponseCelluleN2 { get; set; }

        /// <summary>
        /// nature de la demande d'intervention.
        /// </summary>
        [DataMember]
        public NatureDemandeIntervention NatureDemandeIntervention { get; set; }

        /// <summary>
        /// Raison de la contestation.
        /// </summary>
        [DataMember]
        public string RaisonContestation { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        [DataMember]
        public string DemandeClient { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        [DataMember]
        public string SolutionsDejaApportees { get; set; }

    }
}