﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Formulaire de risque de résiliation.
    /// </summary>
    [DataContract]
    public class ParametresCreationFormulaireRisqueResiliation : ParametresCreationFormulaireGbo
    {
        /// <summary>
        /// Nom client.
        /// </summary>
        [DataMember]
        public string NomClient  { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        [DataMember]
        public string PrenomClient { get; set; }

        /// <summary>
        /// Offre client.
        /// </summary>
        [DataMember]
        public string OffreClient { get; set; }

        /// <summary>
        /// Clé Motif de risque de résiliation.
        /// </summary>
        [DataMember]
        public long CleMotifQualification { get; set; }

        /// <summary>
        /// Commentaire.
        /// </summary>
        [DataMember]
        public string Commentaire  { get; set; }

    }
}