﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure.Extensions;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d'un dossier GBO d'une ligne fixe, en vue de les lister.
    /// </summary>
    [DataContract]
    public class DossierBackOfficeLignePourLister
    {
        /// <summary>
        /// Clé unique du dossier Back Office.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Date d’échéance du dossier.
        /// </summary>
        [DataMember]
        public DateTime DateEcheance { get; set; }

        /// <summary>
        /// Etat du dossier GBO.
        /// </summary>
        [DataMember]
        public EtatDossierGbo Etat { get; set; }

        /// <summary>
        /// Type du dossier.
        /// </summary>
        [DataMember]
        public string Type { get; set; }

        /// <summary>
        /// Historique.
        /// </summary>
        [DataMember]
        public string Historique { get; set; }

        /// <summary>
        /// Activité.
        /// </summary>
        [DataMember]
        public string Activite { get; set; }

        /// <summary>
        /// Dénomination du propriétaire.
        /// </summary>
        [DataMember]
        public string Proprietaire { get; set; }

        /// <summary>
        /// Le détail de ce dossier GBO est-il accessible ?
        /// </summary>
        [DataMember]
        public bool EstDetailAccessible { get; set; }

        /// <summary>
        /// Commentaire enregistré lors de l'ouverture.
        /// </summary>
        [DataMember]
        public string CommentaireOuverture { get; set; }
    }
}