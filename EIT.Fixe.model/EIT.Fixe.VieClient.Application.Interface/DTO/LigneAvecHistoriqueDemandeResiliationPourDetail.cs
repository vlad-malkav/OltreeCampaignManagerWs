﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail de la ligne avec l'historique des demandes de résiliation.
    /// </summary>
    [DataContract]
    public class LigneAvecHistoriqueDemandeResiliationPourDetail
    {
        /// <summary>
        /// Informations sur la ligne.
        /// </summary>
        [DataMember]
        public LignePourDetail InformationsLigne { get; set; }

        /// <summary>
        /// Historique des demandes de résiliation associées à la ligne.
        /// </summary>
        [DataMember]
        public DemandeResiliationPourLister[] HistoriqueDemandesResiliation { get; set; }

        /// <summary>
        /// Indique si l'historique des demandes de résiliation peut être affiché.
        /// </summary>
        [DataMember]
        public bool EstAffichable { get; set; }

        /// <summary>
        /// Indique si la ligne peut être résiliée.
        /// </summary>
        [DataMember]
        public bool EstResiliable { get; set; }
    }
}
