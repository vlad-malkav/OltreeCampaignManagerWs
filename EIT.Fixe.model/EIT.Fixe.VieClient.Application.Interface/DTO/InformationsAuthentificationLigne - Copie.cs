﻿using System.Runtime.Serialization;
using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation des informations nécessaire pour l'authentification d'une ligne.
    /// </summary>
    [DataContract]
    public class InformationsAuthentificationLigne
    {
        /// <summary>
        /// Liste des fonctions BAD
        /// </summary>
        [DataMember]
        public string[] FonctionsBad { get; set; }

        /// <summary>
        /// Civilité du titulaire associé à la ligne.
        /// </summary>
        [DataMember]
        public Civilite CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire associé à la ligne.
        /// </summary>
        [DataMember]
        public string NomTitulaire { get; set; }

        /// <summary>
        /// Prénom du titulaire associé à la ligne.
        /// </summary>
        [DataMember]
        public string PrenomTitulaire { get; set; }

        /// <summary>
        /// Clé de la marque de l'offre associée à la ligne.
        /// </summary>
        [DataMember]
        public int CleMarque { get; set; }

    }
}
