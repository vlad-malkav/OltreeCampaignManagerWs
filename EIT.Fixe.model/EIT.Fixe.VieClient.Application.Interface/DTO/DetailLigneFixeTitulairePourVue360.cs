﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure.Extensions;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail d'une ligne fixe en vue de fournir en données la Vue 360.
    /// </summary>
    [DataContract]
    public class DetailLigneFixeTitulairePourVue360
    {
        /// <summary>
        /// Numéro de la ligne fixe.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// Adresse d’installation.
        /// </summary>
        [DataMember]
        public AdresseInstallationPourDetail AdresseInstallation { get; set; }

        /// <summary>
        /// Seuil de surconsommation téléphonie en Euro (€).
        /// </summary>
        [DataMember]
        public decimal SeuilSurconsommationTelephonie { get; set; }

        /// <summary>
        /// Seuil de surconsommation VOD en Euro (€).
        /// </summary>
        [DataMember]
        public decimal SeuilSurconsommationVod { get; set; }

        /// <summary>
        /// Technologie de la ligne.
        /// </summary>
        [DataMember]
        public string Technologie { get; set; }

        /// <summary>
        /// Etat de la ligne à date de consultation.
        /// </summary>
        [DataMember]
        public EtatLigne Etat { get; set; }

        /// <summary>
        /// Libellé de l'état de la ligne.
        /// </summary>
        [DataMember]
        public string LibelleEtat { get; set; }

        /// <summary>
        /// La réinitialisation du code confidentiel Selfcare est est-elle possible ou non pour cette ligne.
        /// </summary>
        [DataMember]
        public bool EstReinitialisationCodeConfidentielPossible { get; set; }

        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }

        /// <summary>
        /// Dénomination du titulaire de la ligne fixe.
        /// </summary>
        /// <remarks>Se compose de la civilité, du prénom et du nom du titulaire.</remarks>
        [DataMember]
        public string DenominationTitulaire { get; set; }

        /// <summary>
        /// Libellé de l'offre de la ligne.
        /// </summary>
        [DataMember]
        public string NomOffre { get; set; }
    }
}