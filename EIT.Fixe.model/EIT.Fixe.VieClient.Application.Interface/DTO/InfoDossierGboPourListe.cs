﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Objet de présentation permettant de remonter les informations du dossier GBO pour lister
    /// </summary>
    [DataContract]
    public class InfoDossierGboPourListe
    {
        /// <summary>
        /// La clé du dossier GBO
        /// </summary>
        [DataMember]
        public  int CleDossier { get; set; }

        /// <summary>
        /// Correspond à l'identifiant THD (ref externe)
        /// </summary>
        [DataMember]
        public string LibellePorteur { get; set; }

        /// <summary>
        /// Correspond à l'identifiant THD (ref externe)
        /// </summary>
        [DataMember]
        public string ReferencePorteur { get; set; }

        /// <summary>
        /// Concaténation des champs nom + prénom du titulaire
        /// </summary>
        [DataMember]
        public string LibelleTitulaire { get; set; }
    }
}
