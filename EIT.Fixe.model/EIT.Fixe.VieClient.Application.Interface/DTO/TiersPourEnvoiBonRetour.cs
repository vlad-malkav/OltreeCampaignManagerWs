﻿using EIT.Fixe.Domain.CommonTypes;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du tiers pour envoi du bon de retour.
    /// </summary>
    [DataContract]
    public class TiersPourEnvoiBonRetour
    {
        /// <summary>
        /// Civilité du tiers pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public Civilite Civilite { get; set; }

        /// <summary>
        /// Prénom du tiers pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public string Prenom { get; set; }

        /// <summary>
        /// Nom du tiers pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public string Nom { get; set; }

        /// <summary>
        /// Adresse du tiers pour l'envoi du retour.
        /// </summary>
        [DataMember]
        public AdressePourDetail Adresse { get; set; }
    }
}
