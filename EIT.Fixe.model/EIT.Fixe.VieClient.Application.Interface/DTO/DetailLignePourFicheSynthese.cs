﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’une ligne fixe afin d’alimenter en donnée la fiche de synthèse de la ligne.
    /// </summary>
    [DataContract]
    public class DetailLignePourFicheSynthese
    {
        /// <summary>
        /// Informations du tiers physique de la ligne.
        /// </summary>
        [DataMember]
        public TiersPourDetail Tiers { get; set; }

        /// <summary>
        /// Liste des trois derniers historiques de la ligne.
        /// </summary>
        [DataMember]
        public HistoriqueLignePourLister[] ListeHistoriques { get; set; }

        /// <summary>
        /// Liste des dossiers Back Office de la ligne.
        /// </summary>
        [DataMember]
        public DossierBackOfficeLignePourLister[] ListeDossiersBackOffice { get; set; }

        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de ligne fixe.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// Libellé de l’offre souscrite par le client.
        /// </summary>
        [DataMember]
        public string Offre { get; set; }

        /// <summary>
        /// Nom de l’offre souscrite.
        /// </summary>
        [DataMember]
        public string LibelleOffre { get; set; }

        /// <summary>
        /// Prix de commercialisation TTC de l’offre, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal PrixOffre { get; set; }

        /// <summary>
        /// Prix remisé, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal? PrixRemise { get; set; }

        /// <summary>
        /// Prix TTC de location mensuelle de la box, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal PrixLocationBox { get; set; }

        /// <summary>
        /// Liste des promotions appliquées à l’offre.
        /// </summary>
        [DataMember]
        public PromotionOffrePourLister[] PromotionsOffre { get; set; }

        /// <summary>
        /// Date d’activation de la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateActivation { get; set; }

        /// <summary>
        /// Référence externe de la ligne (= identifiant THD).
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Technologie de la ligne.
        /// </summary>
        [DataMember]
        public string Technologie { get; set; }

        /// <summary>
        /// Date de fin d’engagement.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Adresse d’installation de la ligne (champs de l’adresse concaténés). Ex : ‘14 rue de babylone 75001 Paris’.
        /// </summary>
        [DataMember]
        public AdresseInstallationPourDetail AdresseInstallation { get; set; }

        /// <summary>
        /// Libellé du canal de vente.
        /// </summary>
        [DataMember]
        public string CanalVente { get; set; }

        /// <summary>
        /// Etat de la ligne.
        /// </summary>
        [DataMember]
        public EtatLigne Etat { get; set; }

        /// <summary>
        /// Libellé de l'état de la ligne.
        /// </summary>
        [DataMember]
        public string LibelleEtat { get; set; }

        /// <summary>
        /// Le lien ‘Liste des commandes’ est-il accessible ou non ?
        /// </summary>
        [DataMember]
        public bool EstLienListeCommandesAccessible { get; set; }

        /// <summary>
        /// Liste des motifs de suspension (uniquement possible dans le cas d’une ligne suspendue)
        /// </summary>
        [DataMember]
        public MotifSuspensionLignePourLister[] ListeMotifsSuspension { get; set; }

        /// <summary>
        /// Liste des motifs de résiliation (uniquement possible dans le cas d’une ligne à l’état résiliée).
        /// </summary>
        [DataMember]
        public MotifResiliationLignePourLister[] ListeMotifsResiliation { get; set; }

        /// <summary>
        /// Statut de surconsommation de la ligne.
        /// </summary>
        [DataMember]
        public ProfilSurconsommation StatutSurconsommation { get; set; }

        /// <summary>
        /// Libellé du statut de surconsommation de la ligne.
        /// </summary>
        [DataMember]
        public string LibelleStatutSurconsommation { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        [DataMember]
        public string LibelleMarque { get; set; }


        /// <summary>
        /// Informations bancaires du tiers.
        /// </summary>
        [DataMember]
        public InformationsIcn IcnTiers { get; set; }

        /// <summary>
        /// Le lien ‘Retour colis’ est-il accessible ou non ?
        /// </summary>
        [DataMember]
        public bool EstGestionRetourColisAccessible { get; set; }

        /// <summary>
        /// Numéro du retour colis vers lequel pointer via le lien 'Retour Colis'.
        /// </summary>
        [DataMember]
        public string NumeroRetourColis { get; set; }
    }
}