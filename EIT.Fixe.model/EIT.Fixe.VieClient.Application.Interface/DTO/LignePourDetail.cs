﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations d’une ligne fixe.
    /// </summary>
    [DataContract]
    public class LignePourDetail
    {
        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Numéro du compte client.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// Information du tiers titulaire de la ligne.
        /// </summary>
        [DataMember]
        public TiersPourDetail Tiers { get; set; }

        /// <summary>
        /// Adresse d’installation du titulaire de la ligne. 
        /// Champ composé afin d’afficher le numéro, la rue le code postal et la ville.
        /// </summary>
        [DataMember]
        public AdresseInstallationPourDetail AdresseInstallation { get; set; }

        /// <summary>
        /// Libellé de l’offre associée à la ligne.
        /// </summary>
        [DataMember]
        public string Offre { get; set; }

        /// <summary>
        /// Technologie exploitée par la ligne. 
        /// </summary>
        [DataMember]
        public string Technologie { get; set; }

        /// <summary>
        /// Identifiant THD du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Etat de la ligne à date de consultation.
        /// </summary>
        [DataMember]
        public EtatLigne Etat { get; set; }

        /// <summary>
        /// Date de fin d’engagement.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        /// <remarks>Propriété non utilisée dans Vie Client mais consommée, entre autres, par SVI et SFC.</remarks>
        [DataMember]
        public int CleMarque { get; set; }

        /// <summary>
        /// Date d'activation de la ligne.
        /// </summary>
        [DataMember]
        public DateTime DateActivation { get; set; }

        /// <summary>
        /// Numero de contrat fourni par l'operateur.
        /// </summary>
        [DataMember]
        public string NumeroContrat { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        [DataMember]
        public string LibelleMarque { get; set; }
    }
}