﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d’une promotion d’une offre afin de les lister.
    /// </summary>
    [DataContract]
    public class PromotionOffrePourLister
    {
        /// <summary>
        ///Libellé de la promotion.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Montant TTC de la promotion, en Euro (€).
        /// </summary>
        [DataMember]
        public decimal Montant { get; set; }
        
        /// <summary>
        /// Durée de la promotion, en mois.
        /// </summary>
        [DataMember]
        public int? Duree { get; set; }

        /// <summary>
        /// Promotion à caractère automatique ou non.
        /// </summary>
        [DataMember]
        public bool EstAutomatique { get; set; }

    }
}