﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Détail d'un titulaire de ligne en vue de fournir en données la Vue 360.
    /// </summary>
    [DataContract]
    public class DetailTitulairePourVue360
    {
        /// <summary>
        /// Email du titulaire qui lui sert également de login sur son espace client.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Informations de la ligne fixe du titulaire.
        /// </summary>
        [DataMember]
        public DetailLigneFixeTitulairePourVue360 LigneFixe { get; set; }

        /// <summary>
        /// Liste des comptes client mobile du client.
        /// </summary>
        [DataMember]
        public CompteClientMobilePourLister[] ListeComptesClientMobile { get; set; }
    }
}