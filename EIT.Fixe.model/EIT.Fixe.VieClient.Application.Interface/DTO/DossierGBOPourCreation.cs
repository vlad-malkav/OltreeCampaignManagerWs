﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Ensemble des informations concernant le dossier GBO pour sa création.
    /// </summary>
    [DataContract]
    public class DossierGBOPourCreation
    {
        /// <summary>
        /// Commentaire à associer au dossier.
        /// </summary>
        [DataMember]
        public string Commentaire { get; set; }

        /// <summary>
        /// Identifiant unique de l'agent qui doit traiter le dossier.
        /// </summary>
        [DataMember]
        public string AgentProprietaire{ get; set; }

        /// <summary>
        /// Clé de l'activité à laquelle est associé le dossier.
        /// </summary>
        [DataMember]
        public int CleActivite { get; set; }

        /// <summary>
        /// Délai d'échéance du dossier (en jours).
        /// </summary>
        [DataMember]
        public int Delai { get; set; }

        /// <summary>
        /// Indique si le dossier est confidentiel ou non.
        /// </summary>
        [DataMember]
        public bool EstConfidentiel { get; set; }
    }
}