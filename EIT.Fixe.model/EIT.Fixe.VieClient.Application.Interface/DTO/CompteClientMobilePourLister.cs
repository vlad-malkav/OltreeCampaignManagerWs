﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d'un compte client mobile, en vue de les lister.
    /// </summary>
    [DataContract]
    public class CompteClientMobilePourLister
    {
        /// <summary>
        /// Clé du compte client.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Numéro du compte client.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// Titulaire du compte client.
        /// </summary>
        [DataMember]
        public string Titulaire { get; set; }

        /// <summary>
        /// Login du gestionnaire, dans le cas où le client a déclaré le gestionnaire.
        /// </summary>
        [DataMember]
        public string LoginGestionnaire { get; set; }

        /// <summary>
        /// Le client a-t-il choisit de déclarer un gestionnaire.
        /// </summary>
        [DataMember]
        public bool AccesSpecifiqueEspaceClient { get; set; }

        /// <summary>
        /// Liste des lignes de ce compte client mobile. Attention, peut être vide même si le compte client est associé à des lignes mobiles, 
        /// se référer à la propriété NombreLignes pour savoir si ce compte client a des lignes ou non, et si oui combien.
        /// </summary>
        [DataMember]
        public List<LigneCompteClientMobilePourLister> ListeLignes { get; set; }

        /// <summary>
        /// Nombre de lignes mobiles associées à ce compte. Cette propriété existe est n’est pas un count de la propriété.
        /// </summary>
        [DataMember]
        public int NombreLignes { get; set; }
    }
}