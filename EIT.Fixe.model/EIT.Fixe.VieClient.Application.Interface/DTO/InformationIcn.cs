﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de paiement ICN.
    /// </summary>
    [DataContract]
    public class InformationsIcn
    {
        /// <summary>
        /// Code banque.
        /// </summary>
        [DataMember]
        public string CodeBanque { get; set; }

        /// <summary>
        /// Code guichet (ie : code caisse).
        /// </summary>
        [DataMember]
        public string CodeGuichet { get; set; }

        /// <summary>
        /// Code bureau.
        /// </summary>
        [DataMember]
        public string CodeBureau { get; set; }
    }
}