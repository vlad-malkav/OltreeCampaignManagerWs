﻿using EIT.Fixe.Domain.CommonTypes;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations de détail d'un tiers.
    /// </summary>
    [DataContract]
    public class TiersPourDetail
    {
        /// <summary>
        /// Clé unique du tiers.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Civilité.
        /// </summary>
        [DataMember]
        public Civilite Civilite { get; set; }

        /// <summary>
        /// Nom de famille.
        /// </summary>
        [DataMember]
        public string Nom { get; set; }

        /// <summary>
        /// Prénom.
        /// </summary>
        [DataMember]
        public string Prenom { get; set; }

        /// <summary>
        /// Adresse email du tiers.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Date de naissance du tiers.
        /// </summary>
        [DataMember]
        public DateTime DateNaissance { get; set; }

        /// <summary>
        /// Numéro de départment de naissance. Deux caractères maximum.
        /// </summary>
        [DataMember]
        public string DepartementNaissance { get; set; }

        /// <summary>
        /// Numéro de contact fixe du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroTelephoneFixeContact { get; set; }

        /// <summary>
        /// Numéro de contact mobile du titulaire.
        /// </summary>
        [DataMember]
        public string NumeroTelephoneContact { get; set; }

        /// <summary>
        /// Age du tiers.
        /// </summary>
        /// <remarks>Donnée calculée depuis la date de naissance.</remarks>
        [DataMember]
        public int AgeCalcule { get; set; }

        /// <summary>
        /// Adresse principale du tiers.
        /// </summary>
        [DataMember]
        public AdressePourDetail AdressePrincipale { get; set; }

        /// <summary>
        /// Indique si le tiers souhaite être contacté par courrier.
        /// </summary>
        [DataMember]
        public bool EstContactCourrierPossible { get; set; }

        /// <summary>
        /// Indique si le tiers souhaite être contacté par télévente.
        /// </summary>
        [DataMember]
        public bool EstContactTeleventePossible { get; set; }

        /// <summary>
        /// Indique si le tiers souhaite être contacté par email.
        /// </summary>
        [DataMember]
        public bool EstContactEmailPossible { get; set; }

        /// <summary>
        /// Indique si le tiers souhaite être contacté par SMS.
        /// </summary>
        [DataMember]
        public bool EstContactSmsPossible { get; set; }

        /// <summary>
        /// Indique si le tiers souhaite être contacté par un message vocal.
        /// </summary>
        [DataMember]
        public bool EstContactMessageVocalPossible { get; set; }
    }
}