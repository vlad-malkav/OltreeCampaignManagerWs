﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations du RIO de la ligne.
    /// </summary>
    [DataContract]
    public class InformationsRioPourDetail
    {
        /// <summary>
        /// Numéro de téléphone de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Indique si la ligne est résiliée depuis plus de 40 jours.
        /// </summary>
        [DataMember]
        public bool EstRioDisponible { get; set; }

        /// <summary>
        /// RIO de la ligne.
        /// </summary>
        [DataMember]
        public string Rio { get; set; }
    }
}
