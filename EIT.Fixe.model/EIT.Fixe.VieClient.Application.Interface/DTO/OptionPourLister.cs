﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Options pour affichage dans une liste.
    /// </summary>
    [DataContract]
    public class OptionPourLister
    {
        /// <summary>
        /// Clé de l'option.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Libellé de l'option.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Texte descriptif au format HTML.
        /// </summary>
        [DataMember]
        public string Descriptif { get; set; }

        /// <summary>
        /// Ordre d'affichage de l'option.
        /// </summary>
        [DataMember]
        public int Ordre { get; set; }

        /// <summary>
        /// Etat de l'option. 
        /// </summary>
        [DataMember]
        public EtatOption Etat { get; set; }

        /// <summary>
        /// Date de la demande de souscription de l'option.
        /// </summary>
        [DataMember]
        public DateTime? DateSouscription { get; set; }

        /// <summary>
        /// MemoId de l'utilisateur à l'origine de la demande de souscription de l'option.
        /// </summary>
        [DataMember]
        public string MemoIdSouscription { get; set; }

        /// <summary>
        /// Canal par lequel la demande de souscription de l'option a été faite.
        /// </summary>
        [DataMember]
        public string CanalSouscription { get; set; }

        /// <summary>
        /// Date d'activation de l'option.
        /// </summary>
        [DataMember]
        public DateTime? DateActivation { get; set; }

        /// <summary>
        /// Date de la demande de résiliation de l'option.
        /// </summary>
        [DataMember]
        public DateTime? DateResiliation { get; set; }

        /// <summary>
        /// MemoId de l'utilisateur à l'origine de la demande de résiliation de l'option.
        /// </summary>
        [DataMember]
        public string MemoIdResiliation { get; set; }

        /// <summary>
        /// Canal par lequel la demande de résiliation de l'option a été faite.
        /// </summary>
        [DataMember]
        public string CanalResiliation { get; set; }

        /// <summary>
        /// Date de désactivation de l'option.
        /// </summary>
        [DataMember]
        public DateTime? DateDesactivation { get; set; }

        /// <summary>
        /// Prix TTC de l'option.
        /// </summary>
        [DataMember]
        public decimal? PrixTtc { get; set; }

        /// <summary>
        /// Prix HT de l'option.
        /// </summary>
        [DataMember]
        public decimal? PrixHt { get; set; }

        /// <summary>
        /// Mode de facturation de l'option. 
        /// </summary>
        [DataMember]
        public ModeFacturation ModeFacturation { get; set; }

        /// <summary>
        /// Indique si l'option est modifiable.
        /// </summary>
        [DataMember]
        public bool EstModifiable { get; set; }

        /// <summary>
        /// Indique si l'otpion est souscrite ou en cours de souscription.
        /// </summary>
        [DataMember]
        public bool EstSouscrite { get; set; }

        /// <summary>
        /// Indique si l'option est facturée pour compte de tiers (non valorisée)
        /// </summary>
        public bool EstFct { get; set; }
    }
}
