﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’un motif de suspension d’une ligne fixe pour afficher dans une liste.
    /// </summary>
    [DataContract]
    public class MotifSuspensionLignePourLister
    {
        /// <summary>
        /// Libellé du motif.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}
