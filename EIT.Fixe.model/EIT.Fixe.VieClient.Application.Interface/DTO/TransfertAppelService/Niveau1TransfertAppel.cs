﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation pour Niveau 1 de transfert appel.
    /// </summary>
    [DataContract]
    public class Niveau1TransfertAppel
    {
        /// <summary>
        /// Clé du "Niveau 1".
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du "Niveau 1".
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}