﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation pour les paramètres de transfert d'appel.
    /// </summary>
    [DataContract]
    public class ParametresTransfertAppelVersLeSupportTechnique
    {
        /// <summary>
        /// Clé de la ligne fixe.
        /// </summary>
        [DataMember]
        public long CleLigne { get; set; }

        /// <summary>
        /// Clé du thème.
        /// </summary>
        [DataMember]
        public int CleTheme { get; set; }

        /// <summary>
        /// Clé du "Niveau 1".
        /// </summary>
        [DataMember]
        public int CleNiveau1 { get; set; }

        /// <summary>
        /// Clé du "Niveau2".
        /// </summary>
        [DataMember]
        public int CleNiveau2 { get; set; }

        /// <summary>
        /// Commentaire saisi par l'utilisateur.
        /// </summary>
        [DataMember]
        public string Commentaire { get; set; }

        /// <summary>
        /// Référence externe.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }
    }
}