﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation pour les informations nécessaires a l'initialisation de l'écran de transferts d'appels.
    /// </summary>
    [DataContract]
    public class InformationsInitialisationEcranTransfertAppel
    {
        /// <summary>
        /// Numéro de la ligne fixe.
        /// </summary>
        [DataMember]
        public string NumeroLigneFixe { get; set; }

        /// <summary>
        /// Délai en heures.
        /// </summary>
        [DataMember]
        public int Delai { get; set; }

        /// <summary>
        /// Libellé de la cellule qui gère l'activité.
        /// </summary>
        [DataMember]
        public string LibelleActivite { get; set; }

        /// <summary>
        /// Tableau de thèmes de transfert d'appel.
        /// </summary>
        [DataMember]
        public ThemeTransfertAppel[] ListeThemeTransfertAppel { get; set; }
    }
}