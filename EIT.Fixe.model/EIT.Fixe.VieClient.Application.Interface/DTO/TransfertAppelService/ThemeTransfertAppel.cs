﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du thème de transfert appel.
    /// </summary>
    [DataContract]
    public class ThemeTransfertAppel
    {
        /// <summary>
        /// Clé du thème.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du thème.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}