﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation de l'Origine du dysfonctionnement.
    /// </summary>
    [DataContract]
    public class OrigineDysfonctionnement
    {
        /// <summary>
        /// Clé de l'Origine du dysfonctionnement.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de l'Origine du dysfonctionnement.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}