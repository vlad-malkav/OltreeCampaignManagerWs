﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Motif de Qualification.
    /// </summary>
    [DataContract]
    public class MotifQualification
    {
        /// <summary>
        /// Clé du Motif de Qualification.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé du Motif de Qualification.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}