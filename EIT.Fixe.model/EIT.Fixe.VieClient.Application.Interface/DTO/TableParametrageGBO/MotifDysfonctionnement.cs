﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation du Motif du dysfonctionnement.
    /// </summary>
    [DataContract]
    public class MotifDysfonctionnement
    {
        /// <summary>
        /// Clé du Motif du dysfonctionnement.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé du Motif du dysfonctionnement.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}