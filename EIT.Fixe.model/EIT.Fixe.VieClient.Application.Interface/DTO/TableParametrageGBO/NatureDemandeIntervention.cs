﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation de la Nature de la demande d'intervention.
    /// </summary>
    [DataContract]
    public class NatureDemandeIntervention
    {
        /// <summary>
        /// Clé de la Nature de la demande d'intervention.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de la Nature de la demande d'intervention.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}