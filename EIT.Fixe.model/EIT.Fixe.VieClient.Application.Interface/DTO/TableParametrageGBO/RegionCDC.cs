﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation de la Région chargé de clientèle.
    /// </summary>
    [DataContract]
    public class RegionCDC
    {
        /// <summary>
        /// Clé de la Région chargé de clientèle.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de la Région chargé de clientèle.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }
    }
}