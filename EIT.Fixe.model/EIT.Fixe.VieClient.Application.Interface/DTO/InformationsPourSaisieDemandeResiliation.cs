﻿using EIT.Fixe.Domain.CommonTypes;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations pour la saisie d'une demande de résiliation.
    /// </summary>
    [DataContract]
    public class InformationsPourSaisieDemandeResiliation
    {
        /// <summary>
        /// Référence externe.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Date de la dernière facture.
        /// </summary>
        /// <remarks>Si pas de date de dernière facture, alors la valeur '01/01/0001 00:00:00' est envoyée.</remarks>
        [DataMember]
        public DateTime DateDerniereFacture { get; set; }

        /// <summary>
        /// Date de fin d'engagement.
        /// </summary>
        [DataMember]
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Liste des motifs de résiliation.
        /// </summary>
        [DataMember]
        public MotifResiliationPourLister[] ListeMotifResiliation { get; set; }

        /// <summary>
        /// Civilité du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public Civilite Civilite { get; set; }

        /// <summary>
        /// Prénom du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string Prenom { get; set; }

        /// <summary>
        /// Nom du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string Nom { get; set; }

        /// <summary>
        /// Email du titulaire de la ligne.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Adresse du titulaire pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public AdressePourDetail Adresse { get; set; }

        /// <summary>
        /// Indique si le client possède un ICN actif.
        /// </summary>
        [DataMember]
        public bool EstIcnActif { get; set; }
    }
}
