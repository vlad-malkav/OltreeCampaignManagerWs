﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Classe de présentation des informations d'une demande de résiliation à créer.
    /// </summary>
    [DataContract]
    public class DemandeResiliationPourCreation
    {
        /// <summary>
        /// Clé du motif de résiliation.
        /// </summary>
        [DataMember]
        public long CleMotifResiliation { get; set; }

        /// <summary>
        /// Clé du mode de retour équipement.
        /// </summary>
        [DataMember]
        public long CleModeRetourEquipement { get; set; }

        /// <summary>
        /// Date de réception du courrier avec accsué de reception.
        /// </summary>
        [DataMember]
        public DateTime DateReceptionCourrierAr { get; set; }

        /// <summary>
        /// Date de résiliation programmée.
        /// </summary>
        [DataMember]
        public DateTime? DateResiliationProgrammee { get; set; }

        /// <summary>
        /// Adresse email du titulaire.
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// Vérifie si une nouvelle adresse a été saisie.
        /// </summary>
        [DataMember]
        public bool EstNouveauTiersEnvoiBonRetour { get; set; }

        /// <summary>
        /// Tiers pour l'envoi du bon de retour.
        /// </summary>
        [DataMember]
        public TiersPourEnvoiBonRetour TiersEnvoiBonRetour { get; set; }
    }
}
