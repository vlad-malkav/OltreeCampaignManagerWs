﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Mode de retour équipement pour afficher dans une liste.
    /// </summary>
    [DataContract]
    public class ModeRetourEquipementPourLister
    {
        /// <summary>
        /// Clé du mode de retour équipement.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Libellé du mode de retour équipement.
        /// </summary>
        [DataMember]
        public string Libelle { get; set; }

        /// <summary>
        /// Type de prise en charge. 
        /// </summary>
        [DataMember]
        public TypePriseEnCharge TypePriseEnCharge { get; set; }

        /// <summary>
        /// Type d'envoi.
        /// </summary>
        [DataMember]
        public TypeEnvoi TypeEnvoi { get; set; }

        /// <summary>
        /// Indique si le mode de retour équipement est coché par défaut.
        /// </summary>
        [DataMember]
        public bool EstCocheParDefaut { get; set; }

        /// <summary>
        /// Indique si une étiquette est prépayée.
        /// </summary>
        [DataMember]
        public bool EstEnvoiEtiquettePrepayee { get; set; }

    }
}
