﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    ///  Ensemble des choix composant le détail de la parution à l’annuaire universel. 
    /// </summary>
    [DataContract]
    public class ChoixParutionAnnuaire
    {
        /// <summary>
        /// Diffusion du prénom.
        /// </summary>
        [DataMember]
        public bool EstPrenomDiffuse { get; set; }

        /// <summary>
        /// Diffusion de la profession.
        /// </summary>
        [DataMember]
        public bool EstProfessionDiffusee { get; set; }

        /// <summary>
        /// Profession du tiers. Renseignée uniquement si la profession est diffusée.
        /// </summary>
        [DataMember]
        public ProfessionPourLister Profession { get; set; }

        /// <summary>
        /// Diffusion de l'email.
        /// </summary>
        [DataMember]
        public bool EstEmailDiffuse { get; set; }

        /// <summary>
        /// Inscription dans l’annuaire inversé.
        /// </summary>
        [DataMember]
        public bool EstInscritAnnuaireInverse { get; set; }

        /// <summary>
        /// Limitation de l’adresse à la ville.
        /// </summary>
        [DataMember]
        public bool EstAdresseLimiteeAVille { get; set; }

        /// <summary>
        /// Utilisation des coordonnées à des fins de marketing.
        /// </summary>
        [DataMember]
        public bool EstUtilisationCoordoneesAutoriseePourMarketing { get; set; }


    }
}
