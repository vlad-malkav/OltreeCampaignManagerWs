﻿using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations principales d'un dossier GBO.
    /// </summary>
    [DataContract]
    public class DossierGboPourLister
    {
        /// <summary>
        /// Clé du dossier GBO.
        /// </summary>
        [DataMember]
        public int Cle { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        [DataMember]
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Date d'écheance du dossier.
        /// </summary>
        [DataMember]
        public DateTime DateEcheance { get; set; }

        /// <summary>
        /// Libellé de l'état du dossier GBO.
        /// </summary>
        [DataMember]
        public string Etat { get; set; }

        /// <summary>
        /// commentaire.
        /// </summary>
        [DataMember]
        public string Commentaire { get; set; }

        /// <summary>
        /// Clé d'activité.
        /// </summary>
        [DataMember]
        public int CleActivite { get; set; }

        /// <summary>
        /// Nom de l'activité.
        /// </summary>
        [DataMember]
        public string NomActivite { get; set; }

        /// <summary>
        /// Informations de l'historique associé au dossier GBO.
        /// </summary>
        /// <remarks>Uniquement si un historique a été associé au dossier, ce qui n'est pas systématique.</remarks>
        [DataMember]
        public HistoriqueAppelPourLister Historique { get; set; }

        /// <summary>
        /// Prénom du propriétaire.
        /// </summary>
        [DataMember]
        public string PrenomAgentProprietaire { get; set; }

        /// <summary>
        /// Nom du propriétaire.
        /// </summary>
        [DataMember]
        public string NomAgentProprietaire { get; set; }

        /// <summary>
        /// Clé de l'agent propriétaire.
        /// </summary>
        [DataMember]
        public int CleAgentProprietaire { get; set; }

        /// <summary>
        /// MémoId de l'agent propriétaire.
        /// </summary>
        [DataMember]
        public string MemoIdAgentProprietaire { get; set; }

        /// <summary>
        /// Clé du type métier niveau 1.
        /// </summary>
        [DataMember]
        public int CleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Libellé du type métier niveau 1.
        /// </summary>
        [DataMember]
        public string LibelleTypeMetierNiveau1 { get; set; }
    }
}