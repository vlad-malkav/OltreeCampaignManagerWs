﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Objet de retour lors de la création d'une qualificatoin d'appel.
    /// </summary>
    [DataContract]
    public class ReponseCreationQualificationAppel
    {
        /// <summary>
        /// Clé du dossier GBO créé.
        /// </summary>
        [DataMember]
        public int? CleDossierGbo { get; set; }

        /// <summary>
        /// Clé de l'historique créé.
        /// </summary>
        [DataMember]
        public long CleHistorique { get; set; }
    }
}