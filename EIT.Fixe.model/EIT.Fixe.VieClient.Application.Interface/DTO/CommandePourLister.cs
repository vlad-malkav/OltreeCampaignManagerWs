﻿using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.Souscription.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d’une commande afin de fournir en données une liste.
    /// </summary>
    [DataContract]
    public class CommandePourLister
    {
        /// <summary>
        /// Clé unique de la commande.
        /// </summary>
        [DataMember]
        public long Cle { get; set; }

        /// <summary>
        /// Numero  string Numéro de la commande.
        /// </summary>
        [DataMember]
        public string Numero { get; set; }

        /// <summary>
        /// Le type de la commande.
        /// </summary>
        [DataMember]
        public TypeCommande TypeCommande { get; set; }

        /// <summary>
        /// Date de la commande.
        /// </summary>
        [DataMember]
        public DateTime Date { get; set; }

        /// <summary>
        /// Le lien vers la synthèse de commande OSAF est-il accessible dans le cadre de cette commande ?
        /// </summary>
        [DataMember]
        public bool EstSyntheseOsafAccessible { get; set; }

        /// <summary>
        /// Etat de la commande.
        /// </summary>
        [DataMember]
        public EtatCommande Etat { get; set; }

    }
}