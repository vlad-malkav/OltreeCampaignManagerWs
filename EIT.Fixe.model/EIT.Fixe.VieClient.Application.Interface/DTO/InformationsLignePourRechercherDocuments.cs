﻿using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Informations d'une ligne pour rechercher des documents.
    /// </summary>
    [DataContract]
    public class InformationsLignePourRechercherDocuments
    {
        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        [DataMember]
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Référence externe.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Liste des documents à lister.
        /// </summary>
        [DataMember]
        public DocumentPourLister[] DocumentsPourLister { get; set; }
    }
}
