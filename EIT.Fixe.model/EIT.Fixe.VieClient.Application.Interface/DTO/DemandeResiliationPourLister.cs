﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Application.Interface.DTO
{
    /// <summary>
    /// Demandes de résiliation pour lister.
    /// </summary>
    [DataContract]
    public class DemandeResiliationPourLister
    {
        /// <summary>
        /// Clé de la demande de résiliation.
        /// </summary>
        [DataMember]
        public long CleDemandeResiliation { get; set; }

        /// <summary>
        /// Date de la demande de résiliation.
        /// </summary>
        [DataMember]
        public DateTime DateDemandeResiliation { get; set; }

        /// <summary>
        /// Origine de la demande de résiliation.
        /// </summary>
        [DataMember]
        public OrigineResiliation OrigineDemandeResiliation { get; set; }

        /// <summary>
        /// Motif de la résiliation pour la demande.
        /// </summary>
        [DataMember]
        public string MotifResiliation { get; set; }

        /// <summary>
        /// Type de résiliation pour la demande.
        /// </summary>
        [DataMember]
        public TypeResiliation TypeResiliation { get; set; }

        /// <summary>
        /// Date de la résiliation programmée.
        /// </summary>
        [DataMember]
        public DateTime DateResiliationProgrammee { get; set; }

        /// <summary>
        /// Date de l'annulation de la demande de résiliation.
        /// </summary>
        [DataMember]
        public DateTime? DateAnnulationDemandeResiliation { get; set; }
    }
}
