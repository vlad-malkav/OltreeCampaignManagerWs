﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using System.ServiceModel;
using TiersPourDetail = EIT.Fixe.VieClient.Application.Interface.DTO.TiersPourDetail;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Interface du service Tiers.
    /// </summary>
    [ServiceContract]
    public interface ITiersService
    {
        /// <summary>
        /// Méthode qui permet d'enregistrer les modifications apportées sur l'email et/ou numéros de téléphone du titulaire de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers de la ligne.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="informationsTitulaireLigne">Informations du titulaire à modifier.</param>
        [OperationContract]
        void EnregistrerInformationsTitulaireLigne(Identite identite, long cleTiers, long cleLigne, InformationsTitulaireLignePourModification informationsTitulaireLigne);

        /// <summary>
        /// Méthode qui permet d'obtenir le détail du titulaire de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Détail du titulaire de la ligne.</returns>
        [OperationContract]
        TiersPourDetail ObtenirDetailTitulaireLigneParCleTiers(Identite identite, long cleTiers);

        /// <summary>
        /// Méthode qui permet de vérifier si le tiers est associé à un tiers Mobile.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Booléen indiquant si le tiers est associé à un tiers mobile</returns>
        [OperationContract]
        TiersAssociePourDetail VerifierAssociationTiers(Identite identite, long cleTiers);
    }
}