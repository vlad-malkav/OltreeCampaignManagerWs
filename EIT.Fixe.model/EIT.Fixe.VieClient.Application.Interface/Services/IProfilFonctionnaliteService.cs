﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Contrat d'interface du service des fonctionnalités des profils.
    /// </summary>
    [ServiceContract]
    public interface IProfilFonctionnaliteService
    {
        /// <summary>
        /// Méthode qui permet de vérifier la composition du fichier de mise à jour CRM.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="lignesFichier">Lignes du fichier CSV uploadé.</param>
        /// <returns>Retour de la vérification concernant le fichier de mise à jour CRM.</returns>
        [OperationContract]
        RetourVerificationFichierMiseAJourCrm VerifierFichierMiseAJourCrm(Identite identite, string[] lignesFichier);

        /// <summary>
        /// Méthode qui permet de modifier les fonctionnalités de droits CRM.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="lignesFichier">Lignes du fichier CSV uploadé.</param>
        [OperationContract]
        void ModifierDroitsCrm(Identite identite, string[] lignesFichier);

        /// <summary>
        /// Méthode qui permet de lister les fonctionnalités autorisées à partir de ressources SAS.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="ressourcesSas">Liste des ressources SAS.</param>
        /// <returns>Fonctionnalités autorisées.</returns>
        [OperationContract]
        string[] ObtenirFonctionnalitesDepuisListeProfils(Identite identite, string[] ressourcesSas);

        /// <summary>
        /// Méthode qui permet de lister les ressources SAS actives des profils existants.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <returns>Ressources SAS actives.</returns>
        [OperationContract]
        string[] ListerProfilsExistants(Identite identite);
    }
}