﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    ///  Définit le service applicatif de ITransfertAppel.
    /// </summary>
    [ServiceContract]
    public interface ITransfertAppelService
    {
        /// <summary>
        /// Retourne les informations nécessaires à l’initialisation de l’écran de transfert des appels.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé unique de la ligne.</param>
        /// <returns>Informations nécessaires à l’initialisation de l’écran de transfert des appels.</returns>
        [OperationContract]
        InformationsInitialisationEcranTransfertAppel ObtenirInformationsInitialisationEcranTransfertAppel(Identite identite, long cleLigne);

        /// <summary>
        /// Retourne la liste des types de « Niveau 1 » associés à un « Thème » passé en paramètre.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleTheme">Clé du thème.</param>
        /// <returns>Tableau de "Niveau 1".</returns>
        [OperationContract]
        Niveau1TransfertAppel[] ListerNiveau1TransfertDesAppelsParCleTheme(Identite identite, int cleTheme);

        /// <summary>
        /// Retourne la liste des types de « Niveau 2 » associées à un type de « Niveau 1 » passé en paramètre.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleNiveau1">Clé du « niveau 1 ».</param>
        /// <returns>Tableau de "Niveau 2".</returns>
        [OperationContract]
        Niveau2TransfertAppel[] ListerNiveau2TransfertDesAppelsParCleNiveau1(Identite identite, int cleNiveau1);

        /// <summary>
        /// Transfère l'appel du service technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="parametresTransfertAppel">Ensemble d'informations saisies par l'utilisateur.</param>
        [OperationContract]
        void TransfererAppelServiceTechnique(Identite identite, ParametresTransfertAppelVersLeSupportTechnique parametresTransfertAppel);
    }
}