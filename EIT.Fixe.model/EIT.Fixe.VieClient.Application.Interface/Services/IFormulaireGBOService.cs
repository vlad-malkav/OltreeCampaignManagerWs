﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System.Collections.Generic;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Contrat d'interface du service de gestion des Formulaires GBO.
    /// </summary>
    [ServiceContract]
    public interface IFormulaireGboService
    {
        #region Tables de Paramétrage

        /// <summary>
        /// Obtient un objet métier de type MotifDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique du MotifDysfonctionnement.</param>
        /// <returns></returns>
        [OperationContract]
        MotifDysfonctionnement ObtenirMotifDysfonctionnementParCle(Identite identite, long cle);

        /// <summary>
        /// Recherche tous les MotifDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifDysfonctionnement.</returns>
        [OperationContract]
        MotifDysfonctionnement[] ListerMotifDysfonctionnement(Identite identite);

        /// <summary>
        /// Obtient un objet métier de type MotifQualification.
        /// </summary>
        /// <param name="cle">Clé technique du MotifQualification.</param>
        /// <returns></returns>
        [OperationContract]
        MotifQualification ObtenirMotifQualificationParCle(Identite identite, long cle);

        /// <summary>
        /// Recherche tous les MotifQualification.
        /// </summary>
        /// <returns>Retourne la liste de tous les MotifQualification.</returns>
        [OperationContract]
        MotifQualification[] ListerMotifQualification(Identite identite);

        /// <summary>
        /// Obtient un objet métier de type NatureDemandeIntervention.
        /// </summary>
        /// <param name="cle">Clé technique de la NatureDemandeIntervention.</param>
        /// <returns></returns>
        [OperationContract]
        NatureDemandeIntervention ObtenirNatureDemandeInterventionParCle(Identite identite, long cle);

        /// <summary>
        /// Recherche tous les NatureDemandeIntervention.
        /// </summary>
        /// <returns>Retourne la liste de tous les NatureDemandeIntervention.</returns>
        [OperationContract]
        NatureDemandeIntervention[] ListerNatureDemandeIntervention(Identite identite);

        /// <summary>
        /// Obtient un objet métier de type OrigineDysfonctionnement.
        /// </summary>
        /// <param name="cle">Clé technique de l'OrigineDysfonctionnement.</param>
        /// <returns></returns>
        [OperationContract]
        OrigineDysfonctionnement ObtenirOrigineDysfonctionnementParCle(Identite identite, long cle);

        /// <summary>
        /// Recherche tous les OrigineDysfonctionnement.
        /// </summary>
        /// <returns>Retourne la liste de tous les OrigineDysfonctionnement.</returns>
        [OperationContract]
        OrigineDysfonctionnement[] ListerOrigineDysfonctionnement(Identite identite);

        /// <summary>
        /// Obtient un objet métier de type RegionCDC.
        /// </summary>
        /// <param name="cle">Clé technique de la RegionCDC.</param>
        /// <returns></returns>
        [OperationContract]
        RegionCDC ObtenirRegionCdcParCle(Identite identite, long cle);

        /// <summary>
        /// Recherche tous les RegionCDC.
        /// </summary>
        /// <returns>Retourne la liste de tous les RegionCDC.</returns>
        [OperationContract]
        RegionCDC[] ListerRegionCdc(Identite identite);

        #endregion Tables de Paramétrage

        #region Formulaires

        /// <summary>
        /// Obtient un objet métier de type FormulaireGBO.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO de base.</param>
        /// <returns></returns>
        [OperationContract]
        FormulaireGBO ObtenirFormulaireGboParCle(Identite identite, long cle);

        /// <summary>
        /// Création d'un Formulaire de niveau 2 de demande d'intervention.
        /// </summary>
        /// <param name="parametresCreation">.</param>
        [OperationContract]
        long CreerFormulaireCN2DI(
            Identite identite,
            ParametresCreationFormulaireCN2DI parametresCreation,
            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo);

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN2DI.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 2 de demande d'intervention.</param>
        /// <returns></returns>
        [OperationContract]
        FormulaireCN2DI ObtenirFormulaireCN2DiParCle(Identite identite, long cle);

        /// <summary>
        /// Création d'un Formulaire de niveau 3 d'engagement qualité.
        /// </summary>
        /// <param name="parametresCreation">.</param>
        [OperationContract]
        long CreerFormulaireCN3EQ(
            Identite identite,
            ParametresCreationFormulaireCN3EQ parametresCreation,
            List<ParametresCreationPieceJointeFormulaireGbo> listeParametresCreationPieceJointeFormulaireGbo);

        /// <summary>
        /// Obtient un objet métier de type FormulaireCN3EQ.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de niveau 3 d'engagement qualité.</param>
        /// <returns></returns>
        [OperationContract]
        FormulaireCN3EQ ObtenirFormulaireCN3EqParCle(Identite identite, long cle);

        /// <summary>
        /// Création d'un Formulaire de modification de profil surconsommation.
        /// </summary>
        /// <param name="parametresCreation">.</param>
        [OperationContract]
        long CreerFormulaireMps(Identite identite, ParametresCreationFormulaireMPS parametresCreation);

        /// <summary>
        /// Obtient un objet métier de type FormulaireMPS.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de modification de profil surconsommation.</param>
        /// <returns></returns>
        [OperationContract]
        FormulaireMPS ObtenirFormulaireMpsParCle(Identite identite, long cle);

        /// <summary>
        /// Création d'un Formulaire de risque de résiliation.
        /// </summary>
        /// <param name="parametresCreation">.</param>
        [OperationContract]
        long CreerFormulaireRisqueResiliation(Identite identite, ParametresCreationFormulaireRisqueResiliation parametresCreation);

        /// <summary>
        /// Obtient un objet métier de type FormulaireRisqueResiliation.
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire de risque de résiliation.</param>
        /// <returns></returns>
        [OperationContract]
        FormulaireRisqueResiliation ObtenirFormulaireRisqueResiliationParCle(Identite identite, long cle);

        #endregion Formulaires

        /// <summary>
        /// Obtient la clé d'un Formulaire GBO à partir de la Clé Dossier GBO associée.
        /// </summary>
        /// <param name="cle">Clé technique du Dossier GBO.</param>
        /// <returns></returns>
        [OperationContract]
        long ObtenirCleFormulaireGboDepuisCleDossier(Identite identite, long cle);

        /// <summary>
        /// Obtient le type d'un Formulaire GBO à partir de la Clé Formulaire
        /// </summary>
        /// <param name="cle">Clé technique du Formulaire GBO.</param>
        /// <returns></returns>
        [OperationContract]
        TypeFormulaireGBO ObtenirTypeFormulaireGboParCle(Identite identite, long cle);
    }
}