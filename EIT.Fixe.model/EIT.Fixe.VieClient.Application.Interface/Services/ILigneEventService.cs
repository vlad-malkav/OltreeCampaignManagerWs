﻿using EIT.Fixe.Facturation.Domain.CommonTypes.Event;
using NrjMobile.InterfaceOperateur.Evenements.Fixe;
using NrjMobile.PiecesJustificatives.Evenements.GBO.Evenements;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Contrat d'interface du service de gestion des events des lignes fixes.
    /// </summary>
    [ServiceContract]
    public interface ILigneEventService
    {
        /// <summary>
        /// Méthode qui permet d'effectuer une résiliation automatique suite à la notification de portabilité sortant envoyée par la brique Interface Opérateur.
        /// </summary>
        /// <param name="eventPortabiliteSortante">Evénement envoyé par la brique IO.</param>
        [OperationContract]
        void SurPortabiliteSortante(PortabiliteSortante eventPortabiliteSortante);
        
        /// <summary>
        /// Méthode qui permet d'effectuer une résiliation automatique suite à la notification d'impayés envoyée par le domaine Facturation.
        /// </summary>
        /// <param name="eventImpayes">Evénement envoyé par le domaine Facturation.</param>
        [OperationContract]
        void ResilierLigneSurImpayes(ResilierLigneEvent eventImpayes);
        
        /// <summary>
        /// Evenement levé par la brique PJ lors de l'ouverture d'un dossier GBO par un dossier PJ
        /// </summary>
        /// <param name="eventDossierGboCreeParDossierPj">Evenement levé par la brique PJ</param>
        [OperationContract]
        void SurDossierGboCreeParDossierPj(DossierGBOCreeParDPJ eventDossierGboCreeParDossierPj);

        /// <summary>
        /// Evenement levé par la brique PJ lors de la numérisation d'un PJ non attendue
        /// </summary>
        /// <param name="eventDossierGboCreeParNumerisation">Evenement levé par la brique PJ</param>
        [OperationContract]
        void SurDossierGboCreeParNumerisation(DossierGBOCreeParNumerisation eventDossierGboCreeParNumerisation);
    }
}