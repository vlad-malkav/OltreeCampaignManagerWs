﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Interface du service DemandeResiliation.
    /// </summary>
    [ServiceContract]
    public interface IDemandeResiliationService
    {
        /// <summary>
        /// Méthode qui permet d'annuler une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation à annuler.</param>
        [OperationContract]
        void AnnulerDemandeResiliation(Identite identite, long cleDemandeResiliation);

        /// <summary>
        /// Méthode qui permet de lister les demandes de résiliation différées.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <returns>Liste des clés des demandes de résiliation à traiter.</returns>
        [OperationContract]
        long[] ListerDemandesResiliationATraiter(Identite identite);

        /// <summary>
        /// Méthode qui permet d'obtenir le détail d'une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation.</param>
        /// <returns>Détail de la demande de résiliation.</returns>
        [OperationContract]
        DemandeResiliationPourDetail ObtenirDetailDemandeResiliationParCle(Identite identite, long cleDemandeResiliation);

        /// <summary>
        /// Méthode qui permet de traiter une demande de résiliation différée.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDemandeResiliation">Clé de la demande de résiliation.</param>
        [OperationContract]
        void TraiterDemandeResiliationDifferee(Identite identite, long cleDemandeResiliation);
    }
}