﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    ///  Contrat d'interface du service de gestion des pannes collectives.
    /// </summary>
    [ServiceContract]
    public interface IPanneCollectiveService
    {
        /// <summary>
        /// Création d'une panne collective.
        /// </summary>
        /// <param name="identite">Informations d'identification de l'appelant.</param>
        /// <param name="informationsPanneCollective">Informations de la panne collective à créer.</param>
        /// <returns>Clé de la panne collective créée.</returns>
        [OperationContract]
        bool CreerPanneCollective(Identite identite, InformationsPanneCollectivePourCreation informationsPanneCollective);

        /// <summary>
        /// Indique si la ligne est oui ou non, impactée par une panne locale.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé unique de la ligne à tester.</param>
        /// <returns>Indique si la ligne est oui ou non, impactée par une panne locale.</returns>
        [OperationContract]
        bool EstLigneAffecteeParPanneCollective(Identite identite, long cleLigne);

        /// <summary>
        /// Liste les pannes collectives impactant une ligne fixe par clé ligne.
        /// </summary>
        /// <param name="identite">Identité.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe.</param>
        /// <param name="dureeValidite">Durée de validité des données, en minutes.</param>
        /// <returns>Liste des pannes collectives impactant la ligne fixe.</returns>
        [OperationContract]
        PanneCollectivePourLister[] ListerPannesCollectivesParCleLigne(Identite identite, long cleLigne, int dureeValidite);
    }
}