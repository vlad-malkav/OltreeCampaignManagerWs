﻿using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Contrat d'interface du service d'Annuaire Universel.
    /// </summary>
    [ServiceContract]
    public interface IInfosAnnuaireService
    {
        /// <summary>
        /// Obtient les informations relatives à la parution dans l’annuaire universel de la ligne.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la Ligne.</param>
        /// <returns>Informations relatives à la parution dans l’annuaire universel de la ligne.</returns>
        [OperationContract]
        InformationsParutionAnnuaireUniverselPourConsultation ObtenirParutionAnnuaireUniverselDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Définit la parution (ou le refus de parution) à l’annuaire universel.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="informationsParutionAnnuaire">Informations relatives à la parution dans l’annuaire universel.</param>
        /// <returns></returns>
        [OperationContract]
        void EnregistrerParutionAnnuaireUniversel(Identite identite, InformationsParutionAnnuaireUniverselPourEnregistrement informationsParutionAnnuaire);

        /// <summary>
        /// Liste les professions disponibles pour l’annuaire.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <returns>Liste des professions disponibles pour l’annuaire.</returns>
        [OperationContract]
        ProfessionPourLister[] ListerProfessionAnnuaire(Identite identite);
    }
}