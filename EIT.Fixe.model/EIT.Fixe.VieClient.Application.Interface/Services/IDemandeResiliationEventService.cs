﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Events;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Service de réception et traitement des évènements dans le cadre des demandes de résiliation.
    /// </summary>
    [ServiceContract]
    public interface IDemandeResiliationEventService
    {
        /// <summary>
        /// Sur réception de la création d'une demande de retour d'équipement.
        /// </summary>
        /// <param name="eventDemandeRetourEquipementCreee">Evènement.</param>
        /// <remarks>Cet évènement est levé par le domaine Vie Client.</remarks>
        [OperationContract]
        void SurCreationDemandeRetourEquipement(DemandeRetourEquipementCreee eventDemandeRetourEquipementCreee);
    }
}