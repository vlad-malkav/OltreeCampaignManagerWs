﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Systeme.Identification;
using EIT.Fixe.VieClient.Application.Interface.DTO;
using System.Collections.Generic;
using System.ServiceModel;

namespace EIT.Fixe.VieClient.Application.Interface.Services
{
    /// <summary>
    /// Contrat d'interface du service de gestion des lignes fixes.
    /// </summary>
    [ServiceContract]
    public interface ILigneService
    {
        /// <summary>
        /// Récupère les listes des commandes de la ligne.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe pour laquelle récupérer les commandes.</param>
        /// <returns>Commandes de la ligne fixe.</returns>
        [OperationContract]
        CommandePourLister[] ObtenirListeCommandesParCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Obtention de l’ensemble des informations nécessaires à l’affichage de la fiche de synthèse de la ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé technique de la ligne.</param>
        /// <returns>Ensemble des informations de la ligne nécessaires à la fiche de synthèse de la ligne fixe.</returns>
        [OperationContract]
        DetailLignePourFicheSynthese ObtenirInformationsLignePourFicheSyntheseParCle(Identite identite, long cle);

        /// <summary>
        /// Obtention des informations d’un titulaire de ligne fixe en vue de fournir en données sa Vue 360.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé unique du titulaire de la ligne.</param>
        [OperationContract]
        DetailTitulairePourVue360 ObtenirVue360TitulaireParCle(Identite identite, long cle);

        /// <summary>
        /// Obtention de l’ensemble des informations nécessaires à l’affichage de la fiche de synthèse de la ligne fixe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="numero">Numéro de ligne.</param>
        /// <returns>Ensemble des informations de la ligne nécessaires à la fiche de synthèse de la ligne fixe.</returns>
        [OperationContract]
        DetailLignePourFicheSynthese ObtenirInformationsLignePourFicheSyntheseParNumero(Identite identite, string numero);

        /// <summary>
        /// Permet la création d’une ligne et son activation dans la foulée.
        /// </summary>
        /// <remarks>
        /// La ligne n’est techniquement pas créée à l’état EtatLigne.Activee mais le changement d’état a lieu dans la foulée de sa création.
        /// L’historique d’états de la ligne expose donc bien ce changement d’état.
        /// </remarks>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="informationsLigne">Informations de la ligne fixe à créer.</param>
        /// <returns>Clé technique de la ligne créée puis activée.</returns>
        [OperationContract]
        long CreerEtActiverLigne(Identite identite, InformationsLignePourCreationEtActivation informationsLigne);

        /// <summary>
        /// Obtention de la liste de toutes les lignes mobiles associées à un compte client.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé unique du compte client.</param>
        /// <returns>Liste des lignes de ce compte client mobile.</returns>
        [OperationContract]
        LigneCompteClientMobilePourLister[] ListerLignesCompteClientMobileParCle(Identite identite, long cle);

        /// <summary>
        [OperationContract]
        LignePourDetail ObtenirLigneParCle(Identite identite, long cleLigne);

        /// <summary>
        /// Permet de savoir si une ligne existe ou non en fonction de son numéro.
        /// Obtenir le ligne par sa clé.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Ligne correspondant à la clé.</returns>
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="numero">Numero de la ligne.</param>
        /// <returns></returns>
        [OperationContract]
        bool EstLigneExistanteParNumero(Identite identite, string numero);

        /// <summary>
        /// Permet de savoir si une ligne existe ou non en fonction de sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cle">Clé technique de la ligne.</param>
        [OperationContract]
        bool EstLigneExistanteParCle(Identite identite, long cle);

        /// <summary>
        /// Modification du statut de surconsommation d’une ligne existante.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne pour laquelle </param>
        [OperationContract]
        void ModifierStatutSurconsommationLigne(Identite identite, long cleLigne, ProfilSurconsommation statutSurconsommation);

        /// <summary>
        /// Méthode permet d'affecter une promotion à une ligne.
        /// </summary>
        /// <param name="identite">Information d'identite.</param>
        /// <param name="clePromotion">Cle de la promotion.</param>
        /// <param name="cleLigne">Cle de la ligne.</param>
        [OperationContract]
        void AppliquerPromotionSurLigne(Identite identite, int clePromotion, long cleLigne);

        /// <summary>
        /// Méthode permet de Récupère le détail des promotions associées à une ligne ainsi que le numéro de la ligne.
        /// </summary>
        /// <param name="identite">Identite de la personne qui fait l'action.</param>
        /// <param name="cleLigne">Clé de la ligne fixe.</param>
        /// <returns>Détail des promotions associées à une ligne fixe + numéro de ligne.</returns>
        [OperationContract]
        PromotionsLignePourDetail ObtenirPromotionsLignePourDetailParCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Résilie une demande de remise.
        /// </summary>
        /// <param name="identite">Identite de l'agent qui fait l'action.</param>
        /// <param name="cleligne">Clé de la ligne.</param>
        /// <param name="cleDemandeRemisePromotion">Clé de la demande de remise de type promotion.</param>
        [OperationContract]
        void ResilierPromotion(Identite identite, long cleligne, long cleDemandeRemisePromotion);

        /// <summary>
        /// Méthode permet de fournit la liste des promotions éligibles pour la ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent qui fait l'action.</param>
        /// <param name="cleLigne">Clé de la ligne fixe.</param>
        /// <returns>Liste des promotions éligibles.</returns>
        [OperationContract]
        PromotionPourLister[] ObtenirPromotionsEligiblesParCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode permet de retournée toutes les promotions appliquées éligibles à expiration, 
        /// (dans le but de les faire expirer par batch).
        /// </summary>
        /// <param name="identite">Identite de l'agent qui fait l'action.</param>
        /// <returns>La liste des promotions appliquées éligibles à expiration.</returns>
        [OperationContract]
        DemandesRemisesLignePourExpiration[] ListerPromotionsAExpirer(Identite identite);

        /// <summary>
        /// Passe un ensemble de demandes de remise associées à une ligne à l'état "Expirée".
        /// (dans le but de les faire expirer par batch).
        /// </summary>
        /// <param name="identite">Identité de l'agent qui fait l'action.</param>
        /// <param name="demandesRemisesLignePourExpiration">Liste de clés de demandes de remise en place sur une ligne et éligibles à expiration.</param>
        [OperationContract]
        void TraiterExpirationDemandeRemiseParCle(Identite identite, DemandesRemisesLignePourExpiration demandesRemisesLignePourExpiration);

        /// <summary>
        /// Méthode qui permet d'enregistrer les modifications des options de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="clesOptionsAAjouter">Clés des options à ajouter.</param>
        /// <param name="clesOptionsASupprimer">Clés des options à supprimer.</param>
        [OperationContract]
        void EnregistrerOptionsLigne(Identite identite, long cleLigne, int[] clesOptionsAAjouter, int[] clesOptionsASupprimer);

        /// <summary>
        /// Méthode qui permet d'obtenir le détail d'une ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Détail de la ligne avec l'historique des demandes de resiliation.</returns>
        [OperationContract]
        LigneAvecHistoriqueDemandeResiliationPourDetail ObtenirDetailLigneParCle(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet d'obtenir le détail des options de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Détail des options de la ligne.</returns>
        [OperationContract]
        OptionsLignePourDetail ObtenirDetailOptionsLigneParCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet d'obtenir les informations d'une demande de résiliation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'iniative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Informations pour la demande de résiliation.</returns>
        [OperationContract]
        InformationsPourSaisieDemandeResiliation ObtenirInformationsPourSaisieDemandeResiliation(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de créer une demande de résiliation de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne sur laquelle on crée la résiliation.</param>
        /// <param name="informationsDemandeResiliation">Informations de la demande de résiliation.</param>
        [OperationContract]
        void CreerDemandeResiliation(Identite identite, long cleLigne, DTO.DemandeResiliationPourCreation informationsDemandeResiliation);

        /// <summary>
        /// Liste les dossiers GBO créés dans le cadre d'une ligne fixe en fonction de la référence externe de cette dernière.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="nombreResultats">Nombre de résultats maximum à retourner (10 par défaut).</param>
        /// <returns>Dossiers GBO créés dans le cadre de la ligne fixe.</returns>
        [OperationContract]
        Interface.DTO.DossierGboPourLister[] ListerDossiersGboParReferenceExterne(Identite identite, string referenceExterne, int? nombreResultats);

        /// <summary>
        /// Rechercher la clé de la ligne à partir d'une cle ICN.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'initative de l'action.</param>
        /// <param name="cleIcn">Clé de l'ICN lié à la ligne.</param>
        /// <returns>Clé de la ligne</returns>
        [OperationContract]
        long? RechercherCleLigneParCleIcn(Identite identite, long cleIcn);

        /// <summary>
        /// Méthode qui permet de récupérer les informations nécessaires pour l'authentification sur le selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTitulaire">Clé du titulaire</param>
        /// <returns>Informations nécessaires pour l'authentification sur le selfcare</returns>
        [OperationContract]
        InformationsAuthentificationLigne ObtenirInformationsAuthentificationLigne(Identite identite, long cleTitulaire);

        /// <summary>
        /// Méthode qui permet de modifier les informations de contact d'un tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="parametreInformationsContact">Informations de contact à modifier.</param>
        [OperationContract]
        void ModifierInformationsContactTiers(Identite identite, ParametreInformationsContact parametreInformationsContact);

        /// <summary>
        /// Méthode qui permet de récupérer les informations de RIO pour une ligne fixe.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <returns>Informations du RIO.</returns>
        [OperationContract]
        InformationsRioPourDetail ObtenirInformationsRioDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de récupérer les informations de contact pour une ligne fixe. 
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <returns>Informations de contact.</returns>
        [OperationContract]
        InformationsContactPourDetail ObtenirInformationsContactDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de récupérer les informations de contact pour la recherche de documents.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé d'une ligne fixe.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <returns>Informations de la ligne pour la recherche de documents.</returns>
        [OperationContract]
        InformationsLignePourRechercherDocuments ObtenirInformationsLignePourRechercherDocuments(Identite identite, long? cleLigne, string referenceExterne);

        /// <summary>
        /// Méthode qui permet d'envoyer le RIO par mail au client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void EnvoyerRioParMail(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet d'envoyer le RIO par courrier au client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void EnvoyerRioParCourrier(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de réinitialiser le code confidentiel de l'espace client.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <param name="canalEnvoiMotDePasse">Canal de communication du mot de passe.</param>
        /// <param name="canalDemande">Canal de la demande (CRM ou WEB).</param>
        [OperationContract]
        void ReinitialiserCodeConfidentielSelfCare(Identite identite, long cleLigne, CanalCommunication canalEnvoiMotDePasse, string canalDemande);

        /// <summary>
        /// Méthode qui permet de débloquer le compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne pour laquelle il faut débloquer le compte.</param>
        [OperationContract]
        void DebloquerCompteMyPartnerTv(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de lister des réinitialisations de login depuis une clé ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Historiques.</returns>
        [OperationContract]
        HistoriqueReinitialiserLoginPourLister[] ListerHistoriqueReinitialisationLoginDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de suspendre une ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void SuspendreLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Méthode qui permet de remettre en service une ligne.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void RemettreEnServiceLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Obtention d'une ligne par sa clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Reference externe de la ligne.</param>
        /// <returns>Ligne correspondant à la clé.</returns>
        [OperationContract]
        LignePourDetail ObtenirLigneDepuisReferenceExterne(Identite identite, string referenceExterne);

        /// <summary>
        /// Permet de récupérer les informations d'une ligne à partir d'une clé tiers pour le Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Informations de la ligne pour le Selfcare.</returns>
        [OperationContract]
        InformationsLignePourSelfcare ObtenirInformationsLignePourSelfcareDepuisCleTiers(Identite identite, long cleTiers);

        /// <summary>
        /// Permet de récupérer les informations des promotions actives de type Offre d'une ligne pour le Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        /// <returns>Liste des promotions actives pour le Selfcare.</returns>
        [OperationContract]
        List<PromotionPourLister> ObtenirPromotionsOffreActivesDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Envoi d'un SMS au client avec son RIO.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void EnvoyerRioParSms(Identite identite, long cleLigne);

        /// <summary>
        /// Retourne les informations de la ligne à partir de la clé tiers.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleTiers">Clé du tiers.</param>
        /// <returns>Le détail de la ligne.</returns>
        [OperationContract]
        LignePourDetail ObtenirLigneDepuisCleTiers(Identite identite, long cleTiers);

        /// <summary>
        /// Retourne les informations de la ligne pour le SVI RIO à partir du numéro de la ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="numeroLigne">Numéro de la ligne fixe.</param>
        /// <returns>Informations de la ligne pour le SVI RIO.</returns>
        [OperationContract]
        InformationsLignePourSviRio ObtenirInformationsLignePourRioParNumeroLigne(Identite identite, string numeroLigne);

        /// <summary>
        /// Permet de changer le mot de passe d'accès au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login.</param>
        /// <param name="ancienMotDePasse">Ancien mot de passe.</param>
        /// <param name="nouveauMotDePasse">Nouveau mot de passe.</param>
        [OperationContract]
        void ChangerMotDePasseSelfcare(Identite identite, string login, string ancienMotDePasse, string nouveauMotDePasse);

        /// <summary>
        /// Génère un OTP envoyé au client par email.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login sur lequel on doit envoyer un OTP.</param>
        /// <param name="cleLigne">Clé de la ligne.</param>
        [OperationContract]
        void DemanderOtp(Identite identite, string login, long cleLigne);

        /// <summary>
        /// Retourne un booléen pour indiquer s'il s'agit de la première connexion au Selfcare.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="login">Login.</param>
        /// <param name="codeOtp">Code OTP.</param>
        /// <returns>Résultat de la validation.</returns>
        [OperationContract]
        bool ValiderOtp(Identite identite, string login, int codeOtp);

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Fixe.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        [OperationContract]
        void ValiderCguFixe(Identite identite, string login);

        /// <summary>
        /// Permet de valider les conditions générales d'utilisation Mobile.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC.</param>
        [OperationContract]
        void ValiderCguMobile(Identite identite, string login);

        /// <summary>
        /// Permet de valider le parcours de bienvenue sur le Selfcare.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="login">Login SFC</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        [OperationContract]
        void ValiderParcoursBienvenue(Identite identite, string login, string referenceExterne);

        /// <summary>
        /// Permet de modifier le mot de passe du compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        /// <param name="motDePasse">Mot de passe du compte My Partner TV.</param>
        [OperationContract]
        void ModifierMotDePasseMyPartnerTv(Identite identite, string referenceExterne, string motDePasse);

        /// <summary>
        /// Permet de créer un compte MyPartnerTv.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="referenceExterne">Reference Externe de la ligne.</param>
        /// <param name="identifiant">Identifiant du compte My Partner TV.</param>
        [OperationContract]
        void CreerCompteMyPartnerTv(Identite identite, string referenceExterne, string identifiant);

        /// <summary>
        /// Mise à jour des équipements de la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne.</param>
        /// <param name="cleAncienEquipement">Cle technique de l'ancien équipement.</param>
        /// <param name="cleNouvelEquipement">Clé technique du nouvel équipement.</param>
        /// <param name="codeRefComNouvelEquipement">Code refcom du nouvel équipement.</param>
        [OperationContract]
        void DefinirEquipementLigne(Identite identite, string referenceExterne, long cleAncienEquipement, long cleNouvelEquipement, string codeRefComNouvelEquipement);

        /// <summary>
        /// Obtention de l'ensemble des informations décrivant les équipements associés à la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="cleLigne">Clé technique de la ligne fixe.</param>
        /// <returns>Ensemble des informations décrivant les équipements associés à la ligne.</returns>
        [OperationContract]
        InformationsEquipementsLigne ObtenirInformationsEquipementsLigneDepuisCleLigne(Identite identite, long cleLigne);

        /// <summary>
        /// Obtention de la liste des équipements présents sur la ligne.
        /// </summary>
        /// <param name="identite">Identification de l'appelant.</param>
        /// <param name="referenceExterne">Référence externe de la ligne fixe.</param>
        /// <returns>Liste des équipements présents sur la ligne fixe.</returns>
        [OperationContract]
        EquipementLignePourLister[] ListerEquipementsDepuisReferenceExterne(Identite identite, string referenceExterne);

        /// <summary>
        /// Obtention de la référence externe depuis le numéro de contrat opérateur.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        /// <returns>La référence externe.</returns>
        [OperationContract]
        string ObtenirReferenceExterneDepuisCleContratOperateur(Identite identite, string numeroContratOperateur);

        /// <summary>
        /// Permet de creér une demande de rétractation.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'origine de l'action;</param>
        /// <param name="cleLigne">Clé de la ligne concernée.</param>
        /// <param name="informationsDemandeRetractation">Informations nécessaire à la création d'une demande de rétractation.</param>
        [OperationContract]
        void CreerDemandeRetractation(Identite identite, long cleLigne, Interface.DTO.DemandeRetractationPourCreation informationsDemandeRetractation);

        /// <summary>
        /// Obtention d'une liste de lignes par un tableau de clé technique.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="clesLignes">Clés des lignes fixes.</param>
        /// <returns>Tableau de lignes.</returns>
        [OperationContract]
        LignePourDetail[] ListerLignesDepuisClesLignes(Identite identite, long[] clesLignes);

        /// <summary>
        /// Création d'une qualification d'appel, avec ou sans création de dossier GBO.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Référence externe.</param>
        /// <param name="informationsDossierGBO">Informations du dossier GBO à créer. Facultatif.</param>
        /// <param name="informationsHistorique">Informations de l'historique à créer. Requis.</param>
        /// <returns>Clés des éléments créés.</returns>
        /// <remarks>L'historique est créé dans tous les cas, le dossier GBO uniquement si le paramètre entrant n'est pas nul.</remarks>
        [OperationContract]
        ReponseCreationQualificationAppel CreerQualificationAppel(Identite identite, string referenceExterne,
            DossierGBOPourCreation informationsDossierGBO, Interface.DTO.HistoriquePourCreation informationsHistorique);

        /// <summary>
        /// Recherche d'une ligne par sa référence externe.
        /// </summary>
        /// <param name="identite">Informations d’identification de l’appelant.</param>
        /// <param name="referenceExterne">Reference externe de la ligne.</param>
        /// <returns>Clé de la ligne, si elle existe.</returns>
        [OperationContract]
        long? RechercherCleLigneDepuisReferenceExterne(Identite identite, string referenceExterne);

        /// <summary>
        /// Méthode qui permet d'obtenir une liste de documents ligne.
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <returns>Liste de documents de ligne.</returns>
        [OperationContract]
        DocumentPourLister[] ObtenirDocumentsLigne(Identite identite);

        /// <summary>
        /// Obtention de la référence externe depuis le numéro de contrat opérateur.
        /// </summary>
        /// <param name="identite">Identite de l'agent à l'origine de l'action.</param>
        /// <param name="numeroContratOperateur">Numéro de contrat opérateur.</param>
        /// <returns>Référence externe associée au numéro de contrat opérateur.</returns>
        /// <remarks>Ne lève pas d'exception en cas de valeur nulle.</remarks>
        [OperationContract]
        string RechercherReferenceExterneParCleContratOperateur(Identite identite, string numeroContratOperateur);

        /// <summary>
        /// Web méthode permettant de récupérer les infos détaillées d'un dossier GBO
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="cleDossier">La clé du dossier GBO pour laquelle il faut récupérer les informations.</param>
        /// <returns>Les informations détaillées du dossier GBO</returns>
        [OperationContract]
        InfoDossierGboPourDetail RechercherInfoDossierGboParCleDossier(Identite identite,int cleDossier);

        /// <summary>
        /// Web méthode permettant de récupérer les infos pour lister les dossiers GBO
        /// </summary>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <param name="clesDossiers">La liste des clés dossiers GBO qu'il faut lister</param>
        /// <returns>Les informations de listing des dossiers GBO passés en paramètres</returns>
        [OperationContract]
        List<InfoDossierGboPourListe> RechercherInfoDossierGboParListeCleDossier(Identite identite,List<int> clesDossiers);

        /// <summary>
        /// Obtenir la ligne qui correspond 
        /// </summary>
        /// <param name="cleGestionnaireOptions"></param>
        /// <param name="identite">Identité de l'agent à l'initiative de l'action.</param>
        /// <returns>Ligne</returns>
        [OperationContract]
        InformationLigne ObtenirLigneDepuisCleGestionnaireOptions(Identite identite, string cleGestionnaireOptions);
    }
}