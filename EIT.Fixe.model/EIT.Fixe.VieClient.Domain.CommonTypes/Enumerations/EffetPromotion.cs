﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumerations des effets promotions (objet de présentation de service externe).
    /// </summary>
    public enum EffetPromotion
    {
        /// <summary>
        /// Non defini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Sur offre.
        /// </summary>
        SurOffre = 10,

        /// <summary>
        /// Sur prestation.
        /// </summary>
        SurPrestation = 20
    }
}
