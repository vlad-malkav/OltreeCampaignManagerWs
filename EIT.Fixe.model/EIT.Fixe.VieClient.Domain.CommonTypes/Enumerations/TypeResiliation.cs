﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des types de résiliation.
    /// </summary>
    public enum TypeResiliation
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Avec frais.
        /// </summary>
        AvecFrais = 10,

        /// <summary>
        /// Sans frais.
        /// </summary>
        SansFrais = 20
    }
}
