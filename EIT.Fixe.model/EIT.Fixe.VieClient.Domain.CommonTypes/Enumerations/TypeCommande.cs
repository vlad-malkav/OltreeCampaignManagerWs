﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Types de commande que peut gérer le domaine Vie Client.
    /// </summary>
    /// <remarks>
    /// Cette énumération est une énumération de rendu et n'est jamais stockée ni utilisée dans un objet métier.
    /// Comme cette énumération n'est consommée que par des objets de présentation et n'est jamais stockée au sein de
    /// la bdd Vie Client, elle n'a pas besoin de valeurs entières.
    /// </remarks>
    public enum TypeCommande
    {
        /// <summary>
        /// Non Defini.
        /// </summary>
        NonDefini,

        /// <summary>
        /// Commande de souscription.
        /// </summary>
        Souscription 
    }
}