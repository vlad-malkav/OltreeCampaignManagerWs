﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    using System.ComponentModel;

    /// <summary>
    /// Liste des états possibles pour une ligne mobile.
    /// </summary>
    /// <remarks>
    /// Cette énumération est une énumération de rendu et n'est jamais stockée ni utilisée dans un objet métier.
    /// Comme cette énumération n'est consommée que par des objets de présentation et n'est jamais stockée au sein de
    /// la bdd Vie Client, elle n'a pas besoin de valeurs entières.
    /// </remarks>
    public enum EtatLigneMobile
    {
        /// <summary>
        /// Non Défini.
        /// </summary>
        [Description("Indéfini")]
        NonDefini,

        [Description("En cours de création")]
        EnCoursDeCreation,

        [Description("Validée")]
        Validee,

        [Description("Annulée")]
        Annulee,

        [Description("Active")]
        Active,

        [Description("Resiliée")]
        Resiliee,

        [Description("Impayée")]
        Impayee,

        [Description("Contentieux")]
        Contentieux,

        [Description("Suspendue")]
        Suspendue,

        [Description("Pré-activée")]
        PreActivee,

        [Description("En cours de souscription")]
        EnCoursDeSouscription,
    }
}