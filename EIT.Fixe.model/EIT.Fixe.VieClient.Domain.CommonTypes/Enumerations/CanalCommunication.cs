﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des canaux de communication.
    /// </summary>
    public enum CanalCommunication
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Contact par SMS.
        /// </summary>
        Sms = 1,

        /// <summary>
        /// Contact par Email.
        /// </summary>
        Email = 2
    }
}
