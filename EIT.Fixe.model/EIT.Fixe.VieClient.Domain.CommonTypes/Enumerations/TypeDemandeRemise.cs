﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumerations des type de demande remise.
    /// </summary>
    public enum TypeDemandeRemise
    {
        /// <summary>
        /// Non defini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Remise sur forfait.
        /// </summary>
        RemiseSurForfait = 10,

        /// <summary>
        /// Remise promotion sur offre.
        /// </summary>
        RemisePromotionSurOffre = 20,

        /// <summary>
        /// Remise promotion sur frais.
        /// </summary>
        RemisePromotionSurFrais = 30
    }
}
