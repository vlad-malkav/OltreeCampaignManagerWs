﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des types d'envoi.
    /// </summary>
    public enum TypeEnvoi
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Envoi par La Poste.
        /// </summary>
        EnvoiParLaPoste = 10,

        /// <summary>
        /// Dépôt en agence.
        /// </summary>
        DepotEnAgence = 20
    }
}
