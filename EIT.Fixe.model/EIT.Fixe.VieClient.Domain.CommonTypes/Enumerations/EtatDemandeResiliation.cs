﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des états d'une demande de résiliation.
    /// </summary>
    public enum EtatDemandeResiliation
    {
        /// <summary>
        /// Etat non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Etat en cours.
        /// </summary>
        EnCours = 10,

        /// <summary>
        /// Etat traitée.
        /// </summary>
        Traitee = 20,

        /// <summary>
        /// Etat annulée.
        /// </summary>
        Annulee = 30
    }
}
