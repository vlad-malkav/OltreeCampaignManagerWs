﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des états d'une option.
    /// </summary>
    public enum EtatOption
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Activation en cours.
        /// </summary>
        ActivationEnCours = 10,

        /// <summary>
        /// Activée.
        /// </summary>
        Activee = 20,

        /// <summary>
        /// Désactivation en cours.
        /// </summary>
        DesactivationEnCours = 30,

        /// <summary>
        /// Désactivée.
        /// </summary>
        Desactivee= 40
    }
}
