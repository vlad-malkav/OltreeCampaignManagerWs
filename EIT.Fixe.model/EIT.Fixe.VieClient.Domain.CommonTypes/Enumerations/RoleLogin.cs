﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Liste des rôles possibles pour un login mobile.
    /// </summary>
    public enum RoleLogin
    {
        /// <summary>
        /// Accès restreint.
        /// </summary>
        Restreint = 0,

        /// <summary>
        /// Accès non restreint.
        /// </summary>
        NonRestreint = 1,

        /// <summary>
        /// Accès en tant que gestionnaire du compte.
        /// </summary>
        GestionnaireCompteClient = 2,

        /// <summary>
        /// Accès en tant que titulaire du compte.
        /// </summary>
        Titulaire = 3
    }
}