﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des modes de facturation.
    /// </summary>
    public enum ModeFacturation
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Récurrent.
        /// </summary>
        Recurrent = 10,

        /// <summary>
        /// Ponctuel.
        /// </summary>
        Ponctuel = 20
    }
}
