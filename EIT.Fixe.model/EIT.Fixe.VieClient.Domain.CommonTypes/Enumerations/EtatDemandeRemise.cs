﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumeration des etats de la demande de remise 
    /// </summary>
    public enum EtatDemandeRemise
    {
        /// <summary>
        /// Non defini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Activée
        /// </summary>
        Activee = 10,

        /// <summary>
        /// Expirée
        /// </summary>
        Expiree = 20,

        /// <summary>
        /// Resiliée
        /// </summary>
        Resiliee = 30
    }
}
