﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Représente le type d'équiment.
    /// </summary>
    public enum TypeEquipement
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Box.
        /// </summary>
        Box = 10,

        /// <summary>
        /// Disque dur.
        /// </summary>
        DisqueDur = 20,

        /// <summary>
        /// Modem.
        /// </summary>
        Modem = 30
       
    }
}