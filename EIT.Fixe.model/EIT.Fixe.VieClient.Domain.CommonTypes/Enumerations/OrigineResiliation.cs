﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des origines de résiliation.
    /// </summary>
    public enum OrigineResiliation
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Client.
        /// </summary>
        Client = 10,

        /// <summary>
        /// EI Telecom.
        /// </summary>
        EIT = 20
    }
}
