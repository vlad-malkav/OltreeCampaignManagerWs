﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Enumération des types de prise en charge.
    /// </summary>
    public enum TypePriseEnCharge
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Client.
        /// </summary>
        Client = 10,

        /// <summary>
        /// EI Telecom.
        /// </summary>
        EIT= 20
    }
}
