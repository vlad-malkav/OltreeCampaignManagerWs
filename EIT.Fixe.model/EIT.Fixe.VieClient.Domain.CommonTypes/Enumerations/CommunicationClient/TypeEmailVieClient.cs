﻿using EIT.Fixe.Domain.CommunicationClient;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations.CommunicationClient
{
    /// <summary>
    /// Classe Type Email.
    /// </summary>
    public class TypeEmailVieClient : TypeEmail
    {

        #region Email

        /// <summary>
        /// Email d'annulation de la résiliation.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_ANNULRESIL_MAIL.
        /// </remarks>
        public static TypeEmail AnnulerResiliation
        {
            get
            {
                return new TypeEmailVieClient(1300, "Annulation de la demande de résiliation");
            }
        }

        /// <summary>
        /// Email de confirmation de résiliation avec étiquette.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMRESILAVECCETIQ_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmerResiliationAvecEtiquette
        {
            get
            {
                return new TypeEmailVieClient(1273, "Envoi d'un email de confirmation de résiliation avec étiquette");
            }
        }

        /// <summary>
        /// Email de confirmation de résiliation sans étiquette.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENTCOM_CONFIRMRESILSANSCETIQ_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmerResiliationSansEtiquette
        {
            get
            {
                return new TypeEmailVieClient(1338, "Envoi d'un email de confirmation de résiliation sans étiquette");
            }
        }

        /// <summary>
        /// Email de confirmation de changement d'email.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMCHGTEMAIL_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmerChangementEmail
        {
            get
            {
                return new TypeEmailVieClient(1269, "Envoi d'un e-mail de confirmation du changement d'e-mail titulaire");
            }
        }

        /// <summary>
        /// Email de confirmation de changement d'email.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMECHGTTEL_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmerChangementTelephone
        {
            get
            {
                return new TypeEmailVieClient(1298, "Envoi d'un e-mail de confirmation du changement de téléphone titulaire");
            }
        }

        /// <summary>
        /// Email de confirmation de changement des options.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMCHGTOPTIONS_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmerChangementOptions
        {
            get
            {
                return new TypeEmailVieClient(1272, "Envoi d'un e-mail de confirmation du changement d'options(s)");
            }
        }

        /// <summary>
        /// Email d'envoi du RIO.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMRIO_MAIL.
        /// </remarks>
        public static TypeEmail EnvoiRio
        {
            get
            {
                return new TypeEmailVieClient(1271, "Envoi d'un e-mail avec le RIO.");
            }
        }

        /// <summary>
        /// Email de validation de demande de résiliation.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_VALIDRESIL_MAIL.
        /// </remarks>
        public static TypeEmail ConfirmationDemandeResiliation
        {
            get
            {
                return new TypeEmailVieClient(1301, "Envoi d'un email de confirmation de demande de resiliation");
            }
        }

        /// <summary>
        /// Email de réinitialisation du code selfcare.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMREINITCODESFC_MAIL.
        /// </remarks>
        public static TypeEmail ReinitialiserCodeSelfcare
        {
            get
            {
                return new TypeEmailVieClient(1270, "Mail de réinitialisation du code confidentiel du SFC");
            }
        }

        #endregion Email

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="cle">Clé du l'email.</param>
        /// <param name="libelle">Libellé de l'email.</param>
        public TypeEmailVieClient(int cle, string libelle) : base(cle, libelle)
        {
        }

        #endregion Constructeurs

    }
}
