﻿using EIT.Fixe.Domain.CommunicationClient;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations.CommunicationClient
{
    public class TypeSmsVieClient : TypeSms
    {
        #region Constructeur

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="cle">Clé du SMS.</param>
        /// <param name="libelle">Libellé du SMS.</param>
        public TypeSmsVieClient(int cle, string libelle) : base(cle, libelle)
        {
        }

        #endregion Constructeur

        #region SMS

        /// <summary>
        /// Sms de confirmation pour la réinitialisation du code du SelfCare.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_HISTO_COM_CONFIRMREINITCODESFC_SMS.
        /// </remarks>
        public static TypeSms ConfirmationReinitialisationCodeSelfcare
        {
            get
            {
                return new TypeSmsVieClient(488, "Confirmation de la réinitialisation du code Selfcare.");
            }
        }

        /// <summary>
        /// Sms de confirmation du RIO.
        /// </summary>
        /// <remarks>
        /// Correspond dans la STD à la mention VIECLIENT_HISTO_COM_CONFIRMRIO_SMS.
        /// </remarks>
        public static TypeSms ConfirmationRio
        {
            get
            {
                return new TypeSmsVieClient(511, "Confirmation du RIO.");
            }
        }

        /// <summary>
        /// Sms de confirmation pour la remise en service.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_HISTO_COM_REMISEENSERVICE_SMS.
        /// </remarks>
        public static TypeSms RemiseEnService
        {
            get
            {
                return new TypeSmsVieClient(514, "Confirmation de remise en service.");
            }
        }

        #endregion SMS
    }
}
