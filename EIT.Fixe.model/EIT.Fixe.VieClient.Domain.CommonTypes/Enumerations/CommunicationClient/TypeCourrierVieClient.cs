﻿using EIT.Fixe.Domain.CommunicationClient;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations.CommunicationClient
{
    /// <summary>
    /// Classe Type Courrier.
    /// </summary>
    public class TypeCourrierVieClient : TypeCourrier
    {

        #region Courriers

        /// <summary>
        /// Courrier de confirmation de la résiliation sans étiquette.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMRESILSANSETIQ_COURRIER.
        /// </remarks>
        public static TypeCourrier ConfirmerResiliationSansEtiquette
        {
            get
            {
                // TODO : En attente EIT pour numéro de modèle.
                string numeroModele = "0";
                return new TypeCourrierVieClient(numeroModele, "Courrier de confirmation de la résilitation sans étiquette");
            }
        }

        /// <summary>
        /// Courrier d'envoi du RIO.
        /// </summary>
        /// <remarks>
        /// Correspond dans les SFD à la mention VIECLIENT_COM_CONFIRMRIO_COURRIER.
        /// </remarks>
        public static TypeCourrier ConfirmerRio
        {
            get
            {
                return new TypeCourrierVieClient("EITIB003", "Courrier d'envoi du RIO");
            }
        }

        #endregion Courrier

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="reference">Référence du courrier.</param>
        /// <param name="libelle">Libellé du courrier.</param>
        public TypeCourrierVieClient(string reference, string libelle) : base(reference, libelle)
        {
        }

        #endregion Constructeurs

    }
}
