﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations
{
    /// <summary>
    /// Types de la valeur de la remise.
    /// </summary>
    public enum TypeValeurRemise
    {
        /// <summary>
        /// Non défini.
        /// </summary>
        NA = 0,

        /// <summary>
        /// Remise en montant.
        /// </summary>
        EnMontant = 10,

        /// <summary>
        /// Remise en pourcentage.
        /// </summary>
        EnPourcentage = 20
    }
}