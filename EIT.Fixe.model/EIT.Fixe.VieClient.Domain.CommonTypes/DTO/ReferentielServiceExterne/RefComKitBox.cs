﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Détails de la reférence commerciale du kit box.
    /// </summary>
    public class RefComKitBox
    {
        /// <summary>
        /// Clé unique du kit box.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Libellé.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Description du kit box.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Montant du dépôt de garantie.
        /// </summary>
        public decimal MontantDepotGarantie { get; set; }
    }
}
