﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Détails de la référence commerciale sérialisée.
    /// </summary>
    public class RefComSerialisee
    {
        /// <summary>
        /// Clé unique de la référence commerciale sérialisée.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de l'équipement.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Type de l'équipement.
        /// </summary>
        public TypeRefCom Type { get; set; }
    }
}
