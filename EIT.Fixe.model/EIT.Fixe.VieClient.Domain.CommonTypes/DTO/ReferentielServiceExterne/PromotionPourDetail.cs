﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne
{
    /// <summary>
    /// Objet de présentation (de service externe) de la liste des promotions.
    /// </summary>
    public class PromotionPourDetail
    {
        /// <summary>
        /// Clé unique de la promotion.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Code de promotion.
        /// </summary>
        public string CodePromo { get; set; }

        /// <summary>
        /// Texte informatif.
        /// </summary>
        public string Descriptif { get; set; }

        /// <summary>
        /// Montant HT.
        /// </summary>
        public decimal MontantHT { get; set; }

        /// <summary>
        /// Montant TTC.
        /// </summary>
        public decimal MontantTtc { get; set; }

        /// <summary>
        /// Enumeration d'effet promotion.
        /// </summary>
        public EffetPromotion EffetPromotion { get; set; }

        /// <summary>
        /// Ordre d'affichage.
        /// </summary>
        public int OrdreAffichage { get; set; }

        /// <summary>
        /// Date d'ouverture.
        /// </summary>
        public DateTime DateOuverture { get; set; }

        /// <summary>
        /// Date de fermeture.
        /// </summary>
        public DateTime? DateFermeture { get; set; }

        /// <summary>
        /// Durée en mois.
        /// </summary>
        public int? Duree { get; set; }

        /// <summary>
        /// Tableau de booléen.
        /// </summary>
        public bool? EstAutomatique { get; set; }
    }
}
