﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne
{
    /// <summary>
    /// Détail des informations de l'offre.
    /// </summary>
    public class OffrePourDetail
    {
        /// <summary>
        /// Clé de l'offre.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Nom de l'offre.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Texte informatif.
        /// </summary>
        public string Descriptif { get; set; }

        /// <summary>
        /// Prix TTC pour l'affichage commercial.
        /// </summary>
        public decimal PrixCommercialisationTtc { get; set; }

        /// <summary>
        /// Calculé à partir du prix commercial de l'offre et de la somme des montants des promotions illimitées.
        /// </summary>
        public decimal MontantPromosIllimitees { get; set; }

        /// <summary>
        /// Calculé à partir du prix commercial de l'offre et de la somme des montants des promotions limitées.
        /// </summary>
        public decimal MontantPromosLimitees { get; set; }

        /// <summary>
        /// Calculé à partir du montant HT de la remise appliquée automatiquement sur l'offre.
        /// </summary>
        public decimal? MontantRemiseAutoTtc { get; set; }

        /// <summary>
        /// libellé remise automatique.
        /// </summary>
        public string LibelleRemiseAuto { get; set; }

        /// <summary>
        /// Montant de la remise hors taxe.
        /// </summary>
        public decimal? MontantRemiseAutoHt { get; set; }
    }
}