﻿using EIT.Fixe.Infrastructure.Extensions;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations principales d'une ligne mobile, en vue de les lister.
    /// </summary>
    public class LigneMobilePourLister
    {
        /// <summary>
        /// Clé technique de la ligne.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Civilité du titulaire de la ligne.
        /// </summary>
        public TiersPourDetail Tiers { get; set; }

        /// <summary>
        /// Libellé de l'offre.
        /// </summary>
        public string LibelleOffre { get; set; }

        /// <summary>
        /// Code opérateur.
        /// </summary>
        public string CodeOperateur { get; set; }

        /// <summary>
        /// Indique s'il s'agit d'un réseau full ou light.
        /// </summary>
        public bool EstReseauFull { get; set; }

        /// <summary>
        /// ScoreChurn.
        /// </summary>
        public int ScoreChurn { get; set; }

        /// <summary>
        /// Statut de la ligne mobile.
        /// </summary>
        public EtatLigneMobile Statut { get; set; }

        /// <summary>
        /// Libellé de l'état de la ligne mobile.
        /// </summary>
        public string LibelleStatut
        {
            get
            {
                return EnumExtension.GetEnumDescription(this.Statut);
            }
        }

        /// <summary>
        /// Seuil de surconsommation téléphonie.
        /// </summary>
        public decimal SeuilSurconsommationTelephonie { get; set; }

        /// <summary>
        /// Seuil de surconsommation VOD.
        /// </summary>
        public decimal SeuilSurconsommationVod { get; set; }
    }
}