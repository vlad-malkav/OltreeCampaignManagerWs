﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ValorisationServiceExterne
{
    /// <summary>
    /// Objet de présentation des informations de la demande de remise pour la brique Valorisation.
    /// </summary>
    public class RemisePourValorisation
    {
        /// <summary>
        /// Code promotion.
        /// </summary>
        public string ReferenceRemise { get; set; }

        /// <summary>
        /// Montant de la remise en euro hors taxe.
        /// </summary>
        public decimal MontantHT { get; set; }

        /// <summary>
        /// Pourcentage à appliquer (exemple 0.10).
        /// </summary>
        public decimal Pourcentage { get; set; }

        /// <summary>
        /// Type de la valeur de la remise.
        /// </summary>
        public TypeValeurRemise TypeValeur { get; set; }

        /// <summary>
        /// Date de debut de la remise ou DateTime.Minvalue pour une application immédiate (borne incluse).
        /// </summary>
        public DateTime DateDebut { get; set; }

        /// <summary>
        /// Date de fin de la remise ou DateTime.Maxvalue pour une durée illimitée (borne exclue).
        /// </summary>
        public DateTime DateFin { get; set; }
    }
}
