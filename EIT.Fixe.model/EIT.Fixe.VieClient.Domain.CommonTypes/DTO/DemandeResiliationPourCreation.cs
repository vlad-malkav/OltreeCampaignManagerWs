﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres DemandeResiliationPourCreation.
    /// </summary>
    public class DemandeResiliationPourCreation
    {
        /// <summary>
        /// Clé du motif de résiliation.
        /// </summary>
        public long CleMotifResiliation { get; set; }

        /// <summary>
        /// Clé du mode de retour équipement.
        /// </summary>
        public long CleModeRetourEquipement { get; set; }

        /// <summary>
        /// Date de réception du courrier avec accusé de réception.
        /// </summary>
        public DateTime DateReceptionCourrierAr { get; set; }

        /// <summary>
        /// Date de résiliation programmée.
        /// </summary>
        public DateTime? DateResiliationProgrammee { get; set; }

        /// <summary>
        /// Adresse email du titulaire.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// True si une nouvelle adresse a été saisie. Sinon false.
        /// </summary>
        public bool EstNouveauTiersEnvoiBonRetour { get; set; }

        /// <summary>
        /// Tiers pour l'envoi du bon de retour. Renseigné si EstNouveauTiersEnvoiBonRetour est à true.
        /// </summary>
        public TiersPourEnvoiBonRetour TiersEnvoiBonRetour { get; set; }
    }
}
