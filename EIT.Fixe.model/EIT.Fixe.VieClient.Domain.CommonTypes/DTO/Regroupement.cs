﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Regroupement.
    /// </summary>
    public class Regroupement
    {
        /// <summary>
        /// Clé du regroupement.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du regroupement.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Type d'exclusion pour le regroupement.
        /// </summary>
        public TypeExclusion TypeExclusion { get; set; }

        /// <summary>
        /// Clé de la catégorie à laquelle appartient le regroupement.
        /// </summary>
        public int CleCategorie { get; set; }

        /// <summary>
        /// Ordre pour l'affichage du regroupement.
        /// </summary>
        public int Ordre { get; set; }
    }
}
