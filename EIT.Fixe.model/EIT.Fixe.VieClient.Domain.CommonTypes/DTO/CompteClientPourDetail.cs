﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Détail d'un compte client.
    /// </summary>
    public class CompteClientPourDetail
    {
        /// <summary>
        /// Clé du compte client.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Numéro du compte client.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Titulaire du compte client.
        /// </summary>
        public TiersPourDetail Titulaire { get; set; }

        /// <summary>
        /// Liste des lignes mobiles de ce compte client.
        /// </summary>
        public List<LigneMobilePourLister> ListeLignes { get; set; }
    }
}