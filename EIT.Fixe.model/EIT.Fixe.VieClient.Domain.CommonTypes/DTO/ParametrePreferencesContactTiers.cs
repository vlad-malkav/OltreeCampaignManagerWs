﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Classe de paramètres pour les préférences de contact d'un tiers.
    /// </summary>
    public class ParametrePreferencesContactTiers
    {
        /// <summary>
        /// Clé du tiers.
        /// </summary>
        public long CleTiers { get; set; }

        /// <summary>
        /// Choix du client pour le contact par mailing.
        /// </summary>
        public bool ContactCourrier { get; set; }

        /// <summary>
        /// Choix du client pour le contact par télévente.
        /// </summary>
        public bool ContactTelevente { get; set; }

        /// <summary>
        /// Choix du client pour le contact par emailing.
        /// </summary>
        public bool ContactEmail { get; set; }

        /// <summary>
        /// Choix du client pour le contact par sms.
        /// </summary>
        public bool ContactSms { get; set; }

        /// <summary>
        /// Choix du client pour le contact par message vocal.
        /// </summary>
        public bool ContactMessageVocal { get; set; }

    }
}
