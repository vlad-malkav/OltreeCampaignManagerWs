﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres DemandeRetourEquipement.
    /// </summary>
    public class DemandeRetourEquipement
    {
        /// <summary>
        /// Clé de la demande de retour équipement.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de la demande de retour équipement.
        /// </summary>
        public string Numero { get; set; }
    }
}
