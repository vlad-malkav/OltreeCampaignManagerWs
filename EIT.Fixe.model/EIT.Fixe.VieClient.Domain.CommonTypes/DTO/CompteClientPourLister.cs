﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations principales d'un compte client.
    /// </summary>
    public class CompteClientPourLister
    {
        /// <summary>
        /// Clé technique du compte client.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Numero
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Titulaire
        /// </summary>
        public TiersPourDetail Titulaire { get; set; }
    }
}