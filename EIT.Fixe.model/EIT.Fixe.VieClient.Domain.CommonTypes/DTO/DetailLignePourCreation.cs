﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Parametres;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations ligne pour création et activation.
    /// </summary>
    public class DetailLignePourCreation
    {
        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Clé marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Clé de l’offre souscrite.
        /// </summary>
        public int CleOffre { get; set; }

        /// <summary>
        /// Clé du tiers ayant souscrit l’offre.
        /// </summary>
        public long CleTiers { get; set; }

        /// <summary>
        /// Clé de la technologie de la ligne.
        /// </summary>
        public int CleTechnologie { get; set; }

        /// <summary>
        /// Clé de la commande d'expédition.
        /// </summary>
        public long CleCommandeExpedition { get; set; }

        /// <summary>
        /// Référence externe (identifiant THD).
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Clé du compte de facturation de la ligne.
        /// </summary>
        public long CleCompteFacturation { get; set; }

        /// <summary>
        ///Clé du gestionnaire des options.
        /// </summary>
        public string CleGestionnaireOptions { get; set; }

        /// <summary>
        /// Numéro de contrat fourni par l’opérateur.
        /// </summary>
        public string NumeroContratOperateur { get; set; }

        /// <summary>
        /// Clé adresse installation.
        /// </summary>
        public long CleAdresseInstallation { get; set; }

        /// <summary>
        /// Date de fin d'engagement.
        /// </summary>
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Numéro RIO sortant de la ligne.
        /// </summary>
        public string Rio { get; set; }

        /// <summary>
        /// Clé ICN.
        /// </summary>
        public int? CleIcn { get; set; }

        /// <summary>
        /// Identifiant de transaction chez l'opérateur.
        /// </summary>
        public int IdentifiantTransactionOperateur { get; set; }

        /// <summary>
        /// Liste des informations des demandes de remises.
        /// </summary>
        public IList<DemandeRemisePourCreation> ListeDemandeRemisePourCreation { get; set; }

        /// <summary>
        /// Clé kit box.
        /// </summary>
        public long CleKitBox { get; set; }
    }
}