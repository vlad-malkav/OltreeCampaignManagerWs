﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Option.
    /// </summary>
    public class Option
    {
        /// <summary>
        /// Clé de l'option.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé de l'option.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Texte descriptif au format HTML.
        /// </summary>
        public string Descriptif { get; set; }

        /// <summary>
        /// Clé du regroupement auquel appartient l'option.
        /// </summary>
        public int CleRegroupement { get; set; }

        /// <summary>
        /// Coût de l'option.
        /// </summary>
        public Cout Cout { get; set; }

        /// <summary>
        /// Mode de facturation de l'option.
        /// </summary>
        public ModeFacturation ModeFacturation { get; set; }

        /// <summary>
        /// Indique si l'option est modifiable.
        /// </summary>
        public bool EstModifiable { get; set; }

        /// <summary>
        /// Indique si l'option est souscrite.
        /// </summary>
        public bool EstSouscrite { get; set; }

        /// <summary>
        /// Indique si l'option fait l'objet d'une facturation pour compte de tiers (non valorisée)
        /// </summary>
        public bool EstFct { get; set; }

        /// <summary>
        /// Dernière modification sur l'option.
        /// </summary>
        public Modification DerniereModification { get; set; }

        /// <summary>
        /// Ordre pour l'affichage des options.
        /// </summary>
        public int Ordre { get; set; }
    }
}
