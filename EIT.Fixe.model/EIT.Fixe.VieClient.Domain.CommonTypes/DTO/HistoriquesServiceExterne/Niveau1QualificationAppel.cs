﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne
{
    /// <summary>
    /// Niveau 1 de qualification d'appel.
    /// </summary>
    public class Niveau1QualificationAppel
    {
        /// <summary>
        /// Clé unique du "Niveau1".
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du "Niveau1".
        /// </summary>
        public string Libelle { get; set; }
    }
}
