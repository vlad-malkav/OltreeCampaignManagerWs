﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne
{
    /// <summary>
    /// Qualification précise d'un historique.
    /// </summary>
    public class MediaHistorique
    {
        /// <summary>
        /// Identifiant technique.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du canal métier concerné.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Libellé court du canal métier concerné.
        /// </summary>
        public string LibelleCourt { get; set; }
    }
}
