﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations principales d'un historique d'appel.
    /// </summary>
    public class HistoriqueAppelPourLister
    {
        /// <summary>
        /// Clé de l'historique.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Commentaire de l'historique.
        /// </summary>
        public string Commentaire { get; set; }

        /// <summary>
        /// Qualification de l'appel, niveau 1.
        /// </summary>
        public Niveau1QualificationAppel QualificationAppelNiveau1 { get; set; }

        /// <summary>
        /// Qualification de l'appel, niveau 2.
        /// </summary>
        public Niveau2QualificationAppel QualificationAppelNiveau2 { get; set; }


        /// <summary>
        /// Clé du type métier de niveau 1.
        /// </summary>
        public int CleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Libellé du type métier de niveau 1.
        /// </summary>
        public string LibelleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Clé du type métier de niveau 2.
        /// </summary>
        public int CleTypeMetierNiveau2 { get; set; }

        /// <summary>
        /// Libellé du type métier de niveau 2.
        /// </summary>
        public string LibelleTypeMetierNiveau2 { get; set; }
                
    }
}