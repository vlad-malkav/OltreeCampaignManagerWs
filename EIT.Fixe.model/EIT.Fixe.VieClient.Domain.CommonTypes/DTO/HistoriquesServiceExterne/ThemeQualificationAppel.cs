﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne
{
    /// <summary>
    /// Thème pour le transfert des appels.
    /// </summary>
    public class ThemeQualificationAppel
    {
        /// <summary>
        /// Clé unique du thème.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du thème.
        /// </summary>
        public string Libelle { get; set; }
    }
}
