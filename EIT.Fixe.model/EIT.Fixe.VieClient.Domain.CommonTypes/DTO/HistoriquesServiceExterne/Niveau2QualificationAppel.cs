﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.HistoriquesServiceExterne
{
    /// <summary>
    /// Niveau 1 de qualification d'appel.
    /// </summary>
    public class Niveau2QualificationAppel
    {
        /// <summary>
        /// Clé unique du "Niveau2".
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé du "Niveau2".
        /// </summary>
        public string Libelle { get; set; }
    }
}
