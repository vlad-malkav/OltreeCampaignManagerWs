﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    public class AdresseInstallationPourDetail
    {
        /// <summary>
        /// Clé unique de l'adresse.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de l'habitation.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Nom de la rue.
        /// </summary>
        public string Rue { get; set; }

        /// <summary>
        /// Code Postal.
        /// </summary>
        public string CodePostal { get; set; }

        /// <summary>
        /// Ville.
        /// </summary>
        public string Ville { get; set; }

        /// <summary>
        /// Complément.
        /// </summary>
        public string Complement { get; set; }
        
        /// <summary>
        /// Batiment.
        /// </summary>
        public string Batiment { get; set; }

        /// <summary>
        /// Etage.
        /// </summary>
        public string Etage { get; set; }

        /// <summary>
        /// Appartement.
        /// </summary>
        public string Appartement { get; set; }

        /// <summary>
        /// Escalier.
        /// </summary>
        public string Escalier { get; set; }
    }
}
