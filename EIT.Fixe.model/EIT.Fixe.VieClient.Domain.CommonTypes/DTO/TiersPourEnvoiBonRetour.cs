﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres TiersPourEnvoiBonRetour.
    /// </summary>
    public class TiersPourEnvoiBonRetour
    {
        /// <summary>
        /// Civilité du tiers pour l'envoi du bon de retour.
        /// </summary>
        public Civilite Civilite { get; set; }

        /// <summary>
        /// Prénom du tiers pour l'envoi du bon de retour.
        /// </summary>
        public string Prenom { get; set; }

        /// <summary>
        /// Nom du tiers pour l'envoi du bon de retour.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Adresse du tiers pour l'envoi du bon de retour.
        /// </summary>
        public AdressePourSaisie Adresse { get; set; }

        /// <summary>
        /// Email du tiers.
        /// </summary>
        public string EmailTiers { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du tiers.
        /// </summary>
        public string TelephoneMobileTiers { get; set; }
    }
}
