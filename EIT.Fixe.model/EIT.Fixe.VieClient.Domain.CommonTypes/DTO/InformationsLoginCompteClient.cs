﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations de login d'un compte client.
    /// </summary>
    public class InformationsLoginCompteClient
    {
        /// <summary>
        /// Login gestionnaire.
        /// </summary>
        public string LoginGestionnaire { get; set; }

        /// <summary>
        /// AAcces Specifique Espace Client Mobile.
        /// </summary>
        public bool AAccesSpecifiqueEspaceClientMobile { get; set; }
    }
}