﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Modification.
    /// </summary>
    public class Modification
    {
        /// <summary>
        /// Date de la modification.
        /// </summary>
        public DateTime? DateTraitement { get; set; }

        /// <summary>
        /// Date de la création.
        /// </summary>
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Utilisateur à l'origine de la modification.
        /// </summary>
        public string Utilisateur { get; set; }

        /// <summary>
        /// Canal par lequel la modification a été demandée.
        /// </summary>
        public string Canal { get; set; }

        /// <summary>
        /// Indique si la modification est en cours de traitement.
        /// </summary>
        public bool EstEnCours { get; set; }
    }
}
