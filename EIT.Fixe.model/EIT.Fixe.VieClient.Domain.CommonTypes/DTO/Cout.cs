﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Cout.
    /// </summary>
    public class Cout
    {
        /// <summary>
        /// Montant TTC en euros.
        /// </summary>
        public decimal? MontantTtc { get; set; }

        /// <summary>
        /// Montant HT en euros.
        /// </summary>
        public decimal MontantHt { get; set; }

        /// <summary>
        /// Taux TVA en pourcentage.
        /// </summary>
        public decimal TauxTva { get; set; }
    }
}
