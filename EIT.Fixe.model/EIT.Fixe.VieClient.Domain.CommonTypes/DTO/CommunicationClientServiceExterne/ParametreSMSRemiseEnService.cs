﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour le SMS de remise en service.
    /// </summary>
    public class ParametreSmsRemiseEnService
    {
        /// <summary>
        /// Référence externe.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du contact.
        /// </summary>
        public string TelephoneMobileContact { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Libelle de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }

        /// <summary>
        /// Numero de telephone de la ligne fixe.
        /// </summary>
        public string TelephoneFixeLigne { get; set; }
    }
}
