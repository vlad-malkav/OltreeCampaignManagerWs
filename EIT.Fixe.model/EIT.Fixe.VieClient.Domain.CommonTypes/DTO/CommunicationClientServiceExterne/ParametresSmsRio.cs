﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour le SMS d'envoi du RIO.
    /// </summary>
    public class ParametresSmsRio : ParametresRio
    {
        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }
    }
}
