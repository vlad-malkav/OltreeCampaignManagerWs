﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour l'email de confirmation de résiliation avec étiquette.
    /// </summary>
    public class ParametresEmailConfirmerResiliationAvecEtiquette : ParametresResiliation
    {
        /// <summary>
        /// Email de contact.
        /// </summary>
        public string EmailContact { get; set; }
        
        /// <summary>
        /// Libellé de l'offre.
        /// </summary>
        public string LibelleOffre { get; set; }

        /// <summary>
        /// Date de résiliation effective.
        /// </summary>
        public string DateResiliationEffective { get; set; }
        
        /// <summary>
        /// Délai pour l'envoi du matériel suite à une résiliation.
        /// </summary>
        public string DelaiEnvoiMaterielSuiteResiliation { get; set; }

        /// <summary>
        /// Le numéro du retour colis.
        /// </summary>
        public string NumeroRetourColis { get; set; }

        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }
    }
}
