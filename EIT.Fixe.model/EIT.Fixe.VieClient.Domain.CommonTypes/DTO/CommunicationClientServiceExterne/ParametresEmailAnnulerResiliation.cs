﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour l'email d'annulation de résiliation.
    /// </summary>
    public class ParametresEmailAnnulerResiliation : ParametresResiliation
    {
        /// <summary>
        /// Email de contact.
        /// </summary>
        public string EmailContact { get; set; }

        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }

    }
}
