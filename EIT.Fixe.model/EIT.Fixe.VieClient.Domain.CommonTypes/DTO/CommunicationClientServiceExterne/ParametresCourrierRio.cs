﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètre pour le courrier d'envoi du RIO.
    /// </summary>
    public class ParametresCourrierRio : ParametresRio
    {
        /// <summary>
        /// Civilité du tiers.
        /// </summary>
        public string CiviliteTiers { get; set; }

        /// <summary>
        /// Prénom du tiers.
        /// </summary>
        public string PrenomTiers { get; set; }

        /// <summary>
        /// Nom du tiers.
        /// </summary>
        public string NomTiers { get; set; }

        /// <summary>
        /// Adresse du tiers, ligne 1.
        /// </summary>
        public string AdresseTiers1 { get; set; }

        /// <summary>
        /// Adresse du tiers, ligne 2.
        /// </summary>
        public string AdresseTiers2 { get; set; }

        /// <summary>
        /// Code postal du tiers.
        /// </summary>
        public string CodePostalTiers { get; set; }

        /// <summary>
        /// Ville du tiers.
        /// </summary>
        public string VilleTiers { get; set; }
        
        /// <summary>
        /// Numéro de téléphone fixe du contact.
        /// </summary>
        public string TelephoneFixeContact { get; set; }
                
        /// <summary>
        /// Numéro de téléphone mobile du service client.
        /// </summary>
        public string TelephoneMobileSc { get; set; }

        /// <summary>
        /// Numéro de téléphone fixe du service client.
        /// </summary>
        public string TelephoneFixeSc { get; set; }

        /// <summary>
        /// Heure d'ouverture du service client.
        /// </summary>
        public string HeureOuvertureSc { get; set; }

        /// <summary>
        /// Heure de fermeture du service client.
        /// </summary>
        public string HeureFermetureSc { get; set; }

        /// <summary>
        /// URL de l'assistance box.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }

        /// <summary>
        /// Mentions légales de la marque.
        /// </summary>
        public string MentionsLegalesMarque { get; set; }

        /// <summary>
        /// Complément d'identification.
        /// </summary>
        public string ComplementIdentification { get; set; }
    }
}
