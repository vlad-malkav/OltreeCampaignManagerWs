﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour l'email de confirmation de changement de téléphone.
    /// </summary>
    public class ParametresEmailConfirmerChangementTelephone : ParametresChangement
    {
        /// <summary>
        /// Téléphone fixe du contact.
        /// </summary>
        public string TelephoneFixeContact { get; set; }
    }
}
