﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    public class ParametresRio
    {
        /// <summary>
        /// Référence externe.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du contact.
        /// </summary>
        public string TelephoneMobileContact { get; set; }

        /// <summary>
        /// Date de fin d'engagement.
        /// </summary>
        public DateTime DateFinEngagement { get; set; }

        /// <summary>
        /// Rio.
        /// </summary>
        public string Rio { get; set; }
    }
}
