﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    public class ParametresResiliationCommun
    {
        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Référence externe de la commande.
        /// </summary>
        public string ReferenceExterne { get; set; }
        
        /// <summary>
        /// Téléphone mobile du contact.
        /// </summary>
        public string TelephoneMobileContact { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Téléphone fixe support client.
        /// </summary>
        public string TelephoneFixeSC { get; set; }

        /// <summary>
        /// Téléphone mobile support client.
        /// </summary>
        public string TelephoneMobileSC { get; set; }

        /// <summary>
        /// Heure ouverture support client.
        /// </summary>
        public string HeureOuvertureSC { get; set; }

        /// <summary>
        /// Heure fermeture support client.
        /// </summary>
        public string HeureFermetureSC { get; set; }

        /// <summary>
        /// URL d'assistance.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }
    }
}
