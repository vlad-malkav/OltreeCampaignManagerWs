﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    public class ParametreEmailCommun
    {
        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }
    }
}
