﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Classe pour l'email de RIO.
    /// </summary>
    public class ParametresEmailRio : ParametresRio
    {
        /// <summary>
        /// Email du contact.
        /// </summary>
        public string EmailContact { get; set; }
        
        /// <summary>
        /// Numéro de téléphone fixe du contact.
        /// </summary>
        public string TelephoneFixeContact { get; set; }
        
        /// <summary>
        /// Numéro de téléphone mobile du service client.
        /// </summary>
        public string TelephoneMobileSc { get; set; }

        /// <summary>
        /// Numéro de téléphone fixe du service client.
        /// </summary>
        public string TelephoneFixeSc { get; set; }

        /// <summary>
        /// Heure d'ouverture du service client.
        /// </summary>
        public string HeureOuvertureSc { get; set; }

        /// <summary>
        /// Heure de fermeture du service client.
        /// </summary>
        public string HeureFermetureSc { get; set; }

        /// <summary>
        /// URL de l'assistance box.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }

        /// <summary>
        /// Mentions légales de la marque.
        /// </summary>
        public string MentionsLegalesMarque { get; set; }

        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }
    }
}
