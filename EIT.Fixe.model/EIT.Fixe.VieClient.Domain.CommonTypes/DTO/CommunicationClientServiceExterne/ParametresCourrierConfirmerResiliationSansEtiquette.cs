﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour le courrier de confirmation de résiliation sans étiquette.
    /// </summary>
    public class ParametresCourrierConfirmerResiliationSansEtiquette : ParametresResiliation
    {

        /// <summary>
        /// Refdoc du courrier.
        /// </summary>
        public string Refdoc { get; set; }

        /// <summary>
        /// Adresse postale du client.
        /// </summary>
        public AdresseCourrier AdresseCourrier { get; set; }
        
        /// <summary>
        /// Libellé de l'offre.
        /// </summary>
        public string LibelleOffre { get; set; }

        /// <summary>
        /// Date de résiliation effective.
        /// </summary>
        public string DateResiliationEffective { get; set; }

        /// <summary>
        /// Délai pour l'envoi du matériel suite à une résiliation.
        /// </summary>
        public string DelaiEnvoiMaterielSuiteResiliation { get; set; }

        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }
    }
}
