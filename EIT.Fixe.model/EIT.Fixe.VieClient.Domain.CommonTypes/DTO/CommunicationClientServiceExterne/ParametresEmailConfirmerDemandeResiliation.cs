﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour m'email de confirmation de demande de résiliation.
    /// </summary>
    public class ParametresEmailConfirmerDemandeResiliation : ParametresResiliation
    {
        /// <summary>
        /// Date de la demande de résiliation.
        /// </summary>
        public DateTime DateDemandeResiliation { get; set; }
        
        /// <summary>
        /// Date de la résiliation effective.
        /// </summary>
        public DateTime DateResiliationEffective { get; set; }
        
        /// <summary>
        /// Email du destinataire.
        /// </summary>
        public string EmailDestinataire { get; set; }

        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }
    }
}
