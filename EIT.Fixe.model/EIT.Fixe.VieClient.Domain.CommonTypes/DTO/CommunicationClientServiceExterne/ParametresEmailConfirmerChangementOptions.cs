﻿using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour l'email de confirmation de changement d'option(s).
    /// </summary>
    public class ParametresEmailConfirmerChangementOptions : ParametresChangement
    {
        /// <summary>
        /// Noms des options soucrites.
        /// </summary>
        public List<string> NomsOptionsSouscrites { get; set; }

        /// <summary>
        /// Tarifs mensuel des options.
        /// </summary>
        public List<string> TarifsMensuelOptions { get; set; }

        /// <summary>
        /// Noms des options résiliées.
        /// </summary>
        public List<string> NomsOptionsResiliees { get; set; }
    }
}
