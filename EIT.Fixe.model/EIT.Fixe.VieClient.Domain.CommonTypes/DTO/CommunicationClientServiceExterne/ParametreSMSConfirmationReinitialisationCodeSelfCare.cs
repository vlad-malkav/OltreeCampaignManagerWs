﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètres pour le SMS de confirmation de réinitialisation du code SelfCare.
    /// </summary>
    public class ParametreSMSConfirmationReinitialisationCodeSelfCare
    {
        /// <summary>
        /// Référence externe.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du contact.
        /// </summary>
        public string TelephoneMobileContact { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Mot de passe temporaire du SelfCare.
        /// </summary>
        public string MotDePasseTemporaire { get; set; }
    }
}
