﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    /// <summary>
    /// Paramètre du mail de confirmation de la réinitialisation du code du SelfCare.
    /// </summary>
    public class ParametreEmailConfirmationReinitialisationCodeSelfCare : ParametreEmailCommun
    {

        /// <summary>
        /// Référence externe.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Email du contact.
        /// </summary>
        public string EmailContact { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Mot de passe temporaire du SelfCare.
        /// </summary>
        public string MotDePasseTemporaire { get; set; }

        /// <summary>
        /// Numéro de téléphone mobile du service client.
        /// </summary>
        public string TelephoneMobileSc { get; set; }

        /// <summary>
        /// Numéro de téléphone fixe du service client.
        /// </summary>
        public string TelephoneFixeSc { get; set; }

        /// <summary>
        /// Heure d'ouverture du service client.
        /// </summary>
        public string HeureOuvertureSc { get; set; }

        /// <summary>
        /// Heure de fermeture du service client.
        /// </summary>
        public string HeureFermetureSc { get; set; }

        /// <summary>
        /// URL de l'assistance box.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }

        /// <summary>
        /// Mentions légales de la marque.
        /// </summary>
        public string MentionsLegalesMarque { get; set; }
    }
}
