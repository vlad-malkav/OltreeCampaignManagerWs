﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.CommunicationClientServiceExterne
{
    public class ParametresChangementCommun
    {
        /// <summary>
        /// Civilite du Titulaire.
        /// </summary>
        public string CiviliteTitulaire { get; set; }

        /// <summary>
        /// Nom du titulaire
        /// </summary>
        public string NomTitulaire { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Référence externe de la commande.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Email de contact.
        /// </summary>
        public string EmailContact { get; set; }

        /// <summary>
        /// Téléphone mobile du contact.
        /// </summary>
        public string TelephoneMobileContact { get; set; }

        /// <summary>
        /// Numéro de la ligne.
        /// </summary>
        public string NumeroLigne { get; set; }

        /// <summary>
        /// Téléphone fixe support client.
        /// </summary>
        public string TelephoneFixeSC { get; set; }

        /// <summary>
        /// Téléphone mobile support client.
        /// </summary>
        public string TelephoneMobileSC { get; set; }

        /// <summary>
        /// Heure ouverture support client.
        /// </summary>
        public string HeureOuvertureSC { get; set; }

        /// <summary>
        /// Heure fermeture support client.
        /// </summary>
        public string HeureFermetureSC { get; set; }

        /// <summary>
        /// URL d'assistance.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string LibelleMarque { get; set; }
    }
}
