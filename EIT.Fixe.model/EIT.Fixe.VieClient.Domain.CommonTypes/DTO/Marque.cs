﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Classe de paramètres pour une marque.
    /// </summary>
    public class Marque
    {
        /// <summary>
        /// Libellé de la marque.
        /// </summary>
        public string Libelle { get; set; }
        
        /// <summary>
        /// Téléphone mobile SC de la marque.
        /// </summary>
        public string TelephoneMobileSc { get; set; }

        /// <summary>
        /// Téléphone fixe SC de la marque.
        /// </summary>
        public string TelephoneFixeSc { get; set; }

        /// <summary>
        /// Heure d'ouverture du SC de la marque.
        /// </summary>
        public string HeureOuvertureSc { get; set; }

        /// <summary>
        /// Heure de fermeture du SC de la marque.
        /// </summary>
        public string HeureFermetureSc { get; set; }
        
        /// <summary>
        /// URL d'assistance de la marque.
        /// </summary>
        public string UrlAssistance { get; set; }

        /// <summary>
        /// Site Web de la marque.
        /// </summary>
        public string SiteWeb { get; set; }

        /// <summary>
        /// Clé pour imprimer le courrier de retour résiliation de la marque.
        /// </summary>
        public int CleImprimeCourrierResiliationRetourColis { get; set; }

        /// <summary>
        /// Mentions légales.
        /// </summary>
        public string MentionLegales { get; set; }
        
    }
}
