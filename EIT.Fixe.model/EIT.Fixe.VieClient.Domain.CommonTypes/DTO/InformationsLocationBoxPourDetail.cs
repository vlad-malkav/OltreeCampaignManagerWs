﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations tarifaires d'une location de box.
    /// </summary>
    public class InformationsLocationBoxPourDetail
    {
        /// <summary>
        /// Clé de l'option.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// En Euro. Prix TTC de la location de la box.
        /// </summary>
        public decimal MontantTtc { get; set; }
    }
}