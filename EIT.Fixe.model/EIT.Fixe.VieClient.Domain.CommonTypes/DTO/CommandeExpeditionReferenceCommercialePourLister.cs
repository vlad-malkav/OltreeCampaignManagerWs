﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètre CommandeExpeditionReferenceCommercialePourLister.
    /// </summary>
    public sealed class CommandeExpeditionReferenceCommercialePourLister
    {
        /// <summary>
        /// Code de la référence commerciale.
        /// </summary>
        public string CodeRefCom { get; set; }

        /// <summary>
        /// Clé de l'équipement.
        /// </summary>
        public long? CleEquipement { get; set; }
    }
}