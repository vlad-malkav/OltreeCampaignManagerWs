﻿using EIT.Fixe.Domain.CommonTypes;
using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne
{
    /// <summary>
    /// Ensemble des informations d'un tiers.
    /// </summary>
    public class TiersPourDetail
    {
        /// <summary>
        /// Clé technique du tiers.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Référence bancaire du tiers.
        /// </summary>
        public List<string> ListeReferenceBancaire { get; set; }

        /// <summary>
        /// La civilité du tiers sous forme d'enum
        /// </summary>
        public Civilite CiviliteEnum { get; set; }

        /// <summary>
        /// Civilité.
        /// </summary>
        public Civilite Civilite { get; set; }

        /// <summary>
        /// Nom.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Nom de naissance.
        /// </summary>
        public string NomNaissance { get; set; }

        /// <summary>
        /// Prénom.
        /// </summary>
        public string Prenom { get; set; }

        /// <summary>
        /// Ville de naissance.
        /// </summary>
        public string VilleNaissance { get; set; }

        /// <summary>
        /// Numéro du département de naissance.
        /// </summary>
        public string NumeroDepartementNaissance { get; set; }

        /// <summary>
        /// Date de naissance.
        /// </summary>
        public DateTime DateNaissance { get; set; }

        /// <summary>
        /// Permet de contacter le client par Email.
        /// </summary>
        public bool EstContactEmailPossible { get; set; }
        
        /// <summary>
        /// Permet de contacter le client par télévente;
        /// </summary>
        public bool EstContactTeleventePossible { get; set; }

        /// <summary>
        /// Permet de contacter le client par courrier.
        /// </summary>
        public bool EstContactCourrierPossible { get; set; }

        /// <summary>
        /// Permet de contacter le client par SMS.
        /// </summary>
        public bool EstContactSmsPossible { get; set; }

        /// <summary>
        /// Permet de contacter le client par message vocal.
        /// </summary>
        public bool EstContactMessageVocalPossible { get; set; }

        /// <summary>
        /// Numéro mobile du tiers.
        /// </summary>
        public string NumeroMobileDeContact { get; set; }

        /// <summary>
        /// Numéro fixe du tiers.
        /// </summary>
        public string NumeroFixeDeContact { get; set; }

        /// <summary>
        /// Email du tiers.
        /// </summary>
        public string EmailContact { get; set; }
        
        /// <summary>
        /// Numéro du tiers bancaire.
        /// </summary>
        public string NumeroTiersBancaire { get; set; }

        /// <summary>
        /// Adresses du tiers.
        /// </summary>
        public List<AdresseTiers> ListeAdresses { get; set; }
    }
}