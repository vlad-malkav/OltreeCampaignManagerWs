﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne
{
    /// <summary>
    /// Informations d'une adresse d'un tiers.
    /// </summary>
    public class AdresseTiers
    {
        /// <summary>
        /// Clé technique de l'adresse.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Complément d'identification de l'adresse.
        /// </summary>
        public string ComplementIdentification { get; set; }
        
        /// <summary>
        /// Complément du point remise de l'adresse.
        /// </summary>
        public string ComplementPointRemise { get; set; }

        /// <summary>
        /// Voie de l'adresse.
        /// </summary>
        public string Voie { get; set; }

        /// <summary>
        /// Service correspondant pour l'adresse spécifiée dans le cas d'un tiers moral par exemple.
        /// </summary>
        public string ServiceParticulier { get; set; }

        /// <summary>
        /// Code postal de l'adresse.
        /// </summary>
        public string CodePostal { get; set; }

        /// <summary>
        /// Ville de l'adresse.
        /// </summary>
        public string Ville { get; set; }

        /// <summary>
        /// Vérifie si l'adresse est l'adresse principale.
        /// </summary>
        public bool EstPrincipale { get; set; }
    }
}