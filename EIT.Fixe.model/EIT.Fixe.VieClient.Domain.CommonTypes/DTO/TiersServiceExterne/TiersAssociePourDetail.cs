﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne
{
    /// <summary>
    /// Informations d'un tiers associé.
    /// </summary>
    public class TiersAssociePourDetail
    {
        /// <summary>
        /// Identifiant technique du tiers au sein du SI.
        /// </summary>
        public int CleTiers { get; set; }

        /// <summary>
        /// Indique si un tiers est associé à la CleTiers.
        /// </summary>
        public bool EstAssocie { get; set; }
    }
}