﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations d'un dossier GBO pour sa création.
    /// </summary>
    public class DossierGboPourCreation
    {
        /// <summary>
        /// Commentaire à associer au dossier.
        /// </summary>
        public string Commentaire { get; set; }

        /// <summary>
        /// Identifiant unique de l'agaent qui doit traiter le dossier.
        /// </summary>
        public string AgentProprietaire { get; set; }

        /// <summary>
        /// Clé de l'activité à laquelle est associé le dossier.
        /// </summary>
        public int CleActivite { get; set; }

        /// <summary>
        /// Délai d'échéance du dossier (en jours).
        /// </summary>
        public int Delai { get; set; }

        /// <summary>
        /// Le dossier est-il confidentiel ou non.
        /// </summary>
        public bool EstConfidentiel { get; set; }
    }
}