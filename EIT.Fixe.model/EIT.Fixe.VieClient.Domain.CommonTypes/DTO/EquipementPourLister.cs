﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres EquipementPourLister.
    /// </summary>
    public class EquipementPourLister
    {
        /// <summary>
        /// Type de l'équipement.
        /// </summary>
        public TypeEquipement Type { get; set; }

        /// <summary>
        /// Numéro de série de l'équipement.
        /// </summary>
        public string NumeroSerie { get; set; }
    }
}
