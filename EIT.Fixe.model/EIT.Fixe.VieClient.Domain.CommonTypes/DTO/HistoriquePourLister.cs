﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Iformations principales des historiques provenant de la brique externe Historique, 
    /// en vue des les afficher dans une liste.
    /// </summary>
    public class HistoriquePourLister
    {
        /// <summary>
        /// Identitfiant technique de l'historique au sein de la brique externe.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Date de création de l'historique.
        /// </summary>
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Type historique.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Historique.
        /// </summary>
        public string Historique { get; set; }

        /// <summary>
        /// Canal à l'origine de l'historique.
        /// </summary>
        public string Canal { get; set; }

        /// <summary>
        /// Agent.
        /// </summary>
        public string Agent { get; set; }
    }
}