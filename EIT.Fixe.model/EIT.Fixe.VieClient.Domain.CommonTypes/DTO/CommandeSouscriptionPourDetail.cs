﻿using EIT.Fixe.Souscription.Domain.CommonTypes.Enumerations;
using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Détail d'une commande de souscription.
    /// </summary>
    public class CommandeSouscriptionPourDetail
    {
        /// <summary>
        /// Clé unique de la commande de souscription.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de la commande de souscription.
        /// </summary>
        public string Numero { get; set; }

        /// <summary>
        /// Date de création de la commande de souscription.
        /// </summary>
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Etat de la commande de souscription.
        /// </summary>
        public EtatCommande Etat { get; set; }

        /// <summary>
        /// Date de confirmation.
        /// </summary>
        public DateTime? DateConfirmation { get; set; }
        /// <summary>
        /// Clé tiers de la commande de souscription.
        /// </summary>
        public long CleTiers { get; set; }
    }
}