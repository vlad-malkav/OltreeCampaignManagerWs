﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Détails d'un équipements.
    /// </summary>
    public class Equipement
    {
        /// <summary>
        /// Clé unique de l'équipement.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Numéro de série.
        /// </summary>
        public string NumeroSerie{ get; set; }

        /// <summary>
        /// Adresse MAC.
        /// </summary>
        public string AdresseMac { get; set; }

        /// <summary>
        /// Numéro de carte TV (optionnel).
        /// </summary>
        public string NumeroCarteTv { get; set; }

        /// <summary>
        /// Etat.
        /// </summary>
        public EtatEquipement Etat { get; set; }
    }
}
