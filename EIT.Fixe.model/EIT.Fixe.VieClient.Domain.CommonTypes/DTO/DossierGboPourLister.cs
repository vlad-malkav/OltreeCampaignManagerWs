﻿using EIT.Fixe.Domain.CommonTypes.Enumerations;
using EIT.Fixe.Infrastructure.Extensions;
using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations principales d'un dossier GBO.
    /// </summary>
    public sealed class DossierGboPourLister
    {
        /// <summary>
        /// Clé du dossier GBO.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Date de création.
        /// </summary>
        public DateTime DateCreation { get; set; }

        /// <summary>
        /// Date d'écheance du dossier.
        /// </summary>
        public DateTime DateEcheance { get; set; }

        /// <summary>
        /// Etat du dossier GBO.
        /// </summary>
        public EtatDossierGbo Etat { get; set; }

        /// <summary>
        /// Libellé de l'état du dossier.
        /// </summary>
        public string LibelleEtat
        {
            get
            {
                return EnumExtension.GetEnumDescription(this.Etat);
            }
        }

        /// <summary>
        /// commentaire.
        /// </summary>
        public string Commentaire { get; set; }

        /// <summary>
        /// Clé d'activité.
        /// </summary>
        public int CleActivite { get; set; }

        /// <summary>
        /// Nom de l'activité.
        /// </summary>
        public string NomActivite { get; set; }

        /// <summary>
        /// Prénom du propriétaire.
        /// </summary>
        public string PrenomAgentProprietaire { get; set; }

        /// <summary>
        /// Nom du propriétaire.
        /// </summary>
        public string NomAgentProprietaire { get; set; }

        /// <summary>
        /// Clé de l'agent propriétaire.
        /// </summary>
        public int CleAgentProprietaire { get; set; }

        /// <summary>
        /// MémoId de l'agent propriétaire.
        /// </summary>
        public string MemoIdAgentProprietaire { get; set; }

        /// <summary>
        /// Clé du type métier niveau 1.
        /// </summary>
        public int CleTypeMetierNiveau1 { get; set; }

        /// <summary>
        /// Libellé du type métier niveau 1.
        /// </summary>
        public string LibelleTypeMetierNiveau1 { get; set; }
    }
}