﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres pour la création d'un historique d'appel.
    /// </summary>
    public class HistoriqueAppelPourCreation
    {
        /// <summary>
        /// Informations de l'historique fonctionnel.
        /// </summary>
        public HistoriqueFonctionnelPourCreation HistoriqueFonctionnel { get; set; }

        /// <summary>
        /// Nom du tiers.
        /// </summary>
        public string NomTiers { get; set; }

        /// <summary>
        /// Prénom du tiers.
        /// </summary>
        public string PrenomTiers { get; set; }

        /// <summary>
        /// Numéro de téléphone de l'appelant.
        /// </summary>
        public string NumeroTelephoneAppelant { get; set; }

        /// <summary>
        /// Numéro de téléphone de l'appelé.
        /// </summary>
        public string NumeroTelephoneAppele { get; set; }

        /// <summary>
        /// Date de l'appel.
        /// </summary>
        public DateTime DateAppel { get; set; }

        /// <summary>
        /// Durée de l'appel.
        /// </summary>
        public int DureeAppel { get; set; }

        /// <summary>
        /// Clé du canal média.
        /// </summary>
        public int CleCanalMedia { get; set; }

        /// <summary>
        /// Clé de qualification d'appel de niveau 1.
        /// </summary>
        public int CleQualificationAppelNiveau1 { get; set; }

        /// <summary>
        /// Clé de qualification d'appel de niveau 2.
        /// </summary>
        public int CleQualificationAppelNiveau2 { get; set; }

        /// <summary>
        /// Point de vente CMI.
        /// </summary>
        public string PointDeVenteCmi { get; set; }
    }
}