﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres des informations de l'annuaire universel, service externe souscription.
    /// </summary>
    public class InformationsAnnuaireUniversel
    {
        /// <summary>
        /// Clé du tiers associé à l’annuaire.
        /// </summary>
        public long CleTiers { get; set; }

        /// <summary>
        /// Référence externe de la commande associée au tiers.
        /// </summary>
        public string ReferenceExterne { get; set; }

        /// <summary>
        /// Numéro de téléphone du tiers.
        /// </summary>
        public string NumeroTelephone { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte la diffusion à l’annuaire universel.
        /// </summary>
        public bool DiffusionAnnuaireUniversel { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte la diffusion de son prénom dans l’annuaire universel.
        /// </summary>
        public bool DiffusionPrenom { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte la diffusion de sa profession dans l’annuaire universel.
        /// </summary>
        public bool DiffusionProfession { get; set; }

        /// <summary>
        /// Profession du titulaire.
        /// </summary>
        public ParamProfession Profession { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte la diffusion de son email dans l’annuaire universel.
        /// </summary>
        public bool DiffusionEmail { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte l’inscription à l’annuaire inversé.
        /// </summary>
        public bool InscriptionAnnuaireInverse { get; set; }

        /// <summary>
        /// Indique si le titulaire veut limiter la diffusion de son adresse à la ville.
        /// </summary>
        public bool LimiterDiffusionAdresseVille { get; set; }

        /// <summary>
        /// Indique si le titulaire accepte l’utilisation marketing de ses données.
        /// </summary>
        public bool UtilisationMarketing { get; set; }
    }
}
