﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Profession, du service externe Souscription.
    /// </summary>
    public class ParamProfession
    {
        /// <summary>
        /// Clé technique de la profession.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Libellé de la Profession.
        /// </summary>
        public string Libelle { get; set; }
    }
}
