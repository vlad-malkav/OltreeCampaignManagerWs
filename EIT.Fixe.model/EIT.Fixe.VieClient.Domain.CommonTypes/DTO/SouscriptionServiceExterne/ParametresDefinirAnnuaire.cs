﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres utilisé pour la définition de l'annuaire, service externe Souscription.
    /// </summary>
    public class ParametresDefinirAnnuaire
    {

        /// <summary>
        /// Clé technique du tiers.
        /// </summary>
        public long CleTiers { get; set; }

        /// <summary>
        /// Diffusion du prénom.
        /// </summary>
        public bool DiffusionPrenom { get; set; }

        /// <summary>
        /// Diffusion de la profession.
        /// </summary>
        public bool DiffusionProfession { get; set; }

        /// <summary>
        /// Profession du tiers.
        /// </summary>
        public ParamProfession Profession { get; set; }

        /// <summary>
        /// Diffusion de l'email.
        /// </summary>
        public bool DiffusionEmail { get; set; }

        /// <summary>
        /// Inscription à l’annuaire inversé.
        /// </summary>
        public bool InscriptionAnnuaireInverse { get; set; }

        /// <summary>
        /// Limiter la diffusion de l’adresse à la ville.
        /// </summary>
        public bool LimiterDiffusionAdresseVille { get; set; }

        /// <summary>
        /// Utilisation marketing des données.
        /// </summary>
        public bool UtilisationMarketing { get; set; }
    }
}
