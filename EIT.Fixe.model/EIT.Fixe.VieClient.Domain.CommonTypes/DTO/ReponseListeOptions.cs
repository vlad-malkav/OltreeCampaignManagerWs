﻿using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres ReponseListeOptions.
    /// </summary>
    public class ReponseListeOptions
    {
        /// <summary>
        /// Liste des options.
        /// </summary>
        public List<Option> Options { get; set; }

        /// <summary>
        /// Liste des regroupements.
        /// </summary>
        public List<Regroupement> Regroupements { get; set; }

        /// <summary>
        /// Liste des catégories.
        /// </summary>
        public List<Categorie> Categories { get; set; }
    }
}
