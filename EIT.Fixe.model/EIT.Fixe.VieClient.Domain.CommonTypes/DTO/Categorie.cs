﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres Categorie.
    /// </summary>
    public class Categorie
    {
        /// <summary>
        /// Clé de la catégorie.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé de la catégorie.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Ordre pour l'affichage de la catégorie.
        /// </summary>
        public int Ordre { get; set; }
    }
}
