﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres CommandeRetourEquipementPourCreation.
    /// </summary>
    public class CommandeRetourEquipementPourCreation
    {
        /// <summary>
        /// Tiers pour l'envoi du bon de retour.
        /// </summary>
        public TiersPourEnvoiBonRetour Tiers { get; set; }

        /// <summary>
        /// Clé de la marque.
        /// </summary>
        public int CleMarque { get; set; }

        /// <summary>
        /// Libellé de l'offre associée à la ligne.
        /// </summary>
        public string LibelleOffre { get; set; }

        /// <summary>
        /// Numéro de la demande de retour équipement.
        /// </summary>
        public string NumeroRetourEquipement { get; set; }

        /// <summary>
        /// Date de la résiliation.
        /// </summary>
        public DateTime DateResiliation { get; set; }

        /// <summary>
        /// Numéro de téléphone fixe SC défini dans le référentiel.
        /// </summary>
        public string TelephoneFixeSc { get; set; }

        /// <summary>
        /// Clé de l'imprimé courrier de résiliation/retour colis.
        /// </summary>
        public int CleImprimeCourrierResiliationRetourColis { get; set; }

        /// <summary>
        /// Code article pour le courrier de résiliation/retour colis.
        /// </summary>
        public string CodeArticleCourrierResiliationRetourColis { get; set; }
    }
}