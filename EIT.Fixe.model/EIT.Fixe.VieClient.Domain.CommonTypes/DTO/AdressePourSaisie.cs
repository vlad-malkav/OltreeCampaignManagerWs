﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Objet de paramètres AdressePourSaisie.
    /// </summary>
    public class AdressePourSaisie
    {
        /// <summary>
        /// Voie.
        /// </summary>
        public string Voie { get; set; }

        /// <summary>
        /// Complément.
        /// </summary>
        public string Complement { get; set; }

        /// <summary>
        /// Code postal.
        /// </summary>
        public string CodePostal { get; set; }

        /// <summary>
        /// Ville.
        /// </summary>
        public string Ville { get; set; }
    }
}
