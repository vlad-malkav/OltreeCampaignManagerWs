﻿using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Classe de paramètres pour la création d'un historique de réinitialisation de login.
    /// </summary>
    public class ParametreHistoriqueReinitialiserLoginPourCreation
    {
        /// <summary>
        /// Clé primaire.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        public long CleLigne { get; set; }

        /// <summary>
        /// Identifiant du titulaire de la ligne.
        /// </summary>
        public string Identifiant { get; set; }

        /// <summary>
        /// Mode d'envoi de la réinitialisation.
        /// </summary>
        public CanalCommunication ModeEnvoi { get; set; }

        /// <summary>
        /// Destinataire de la réinitialisation.
        /// </summary>
        public string Destinataire { get; set; }

        /// <summary>
        /// Canal de la demande.
        /// </summary>
        public string CanalDemande { get; set; }

    }
}
