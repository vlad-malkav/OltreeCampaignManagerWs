﻿using System;
using System.Collections.Generic;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Classe de paramètres pour la création d'un profil Ptf.
    /// </summary>
    public class ParametreProfilPtfPourCreation
    {
        /// <summary>
        /// Clé primaire.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Code du profil.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Libellé du profil.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Description du profil.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Ressource SAS associée.
        /// </summary>
        public string RessourceSas { get; set; }

        /// <summary>
        /// Indique si le profil est actif.
        /// </summary>
        public bool EstActif { get; set; }
        
        /// <summary>
        /// Date d'import du profil.
        /// </summary>
        public DateTime SuiviDateCreation { get; set; }
    }
}
