﻿using EIT.Fixe.Domain.Historique;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations d'un historique pour sa création.
    /// </summary>
    public class HistoriqueFonctionnelPourCreation
    {
        /// <summary>
        /// Type de l'historique métier de niveau 1.
        /// </summary>
        public TypeHistoriqueMetierNiveau1 CleMetier1 { get; set; }

        /// <summary>
        /// Type de l'historique métier de niveau 2.
        /// </summary>
        public TypeHistoriqueMetierNiveau2 CleMetier2 { get; set; }

        /// <summary>
        /// Commentaire de l'historique.
        /// </summary>
        public string Commentaire { get; set; }

        /// <summary>
        /// Clé origine de l'historique.
        /// </summary>
        public int? CleOrigine { get; set; }

        /// <summary>
        /// Référence externe (identifiant THD).
        /// </summary>
        public string ReferenceExterne { get; set; }
    }
}