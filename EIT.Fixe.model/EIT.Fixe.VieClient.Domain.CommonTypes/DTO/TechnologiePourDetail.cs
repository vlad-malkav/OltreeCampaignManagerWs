﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations d'une technologie de ligne.
    /// </summary>
    public class TechnologiePourDetail
    {
        /// <summary>
        /// Clé unique de la technologie.
        /// </summary>
        public int Cle { get; set; }

        /// <summary>
        /// Libellé de la technologie.
        /// </summary>
        public string Libelle { get; set; }
    }
}