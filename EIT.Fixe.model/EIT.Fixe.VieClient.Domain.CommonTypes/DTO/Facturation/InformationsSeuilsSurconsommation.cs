﻿using EIT.Fixe.Domain.CommonTypes;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Informations des seuils de surconsommation.
    /// </summary>
    public class InformationsSeuilsSurconsommation
    {
        /// <summary>
        /// Seuil de surconsommation téléphonie.
        /// </summary>
        public decimal SeuilSurconsommationTelephonie { get; set; }

        /// <summary>
        /// Seuil de surconsommation VOD.
        /// </summary>
        public decimal SeuilSurconsommationVod { get; set; }        
        
    }
}
