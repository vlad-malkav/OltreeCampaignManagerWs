﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.DTO
{
    /// <summary>
    /// Classe de paramètres pour la création d'une fonctionnalité.
    /// </summary>
    public class ParametreFonctionnalitePourCreation
    {
        /// <summary>
        /// Clé primaire.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Code du groupe de fonctionnalités.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Description du groupe de fonctionnalités.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Indique si le groupe de fonctionnalités est actif.
        /// </summary>
        public bool EstActif { get; set; }

        /// <summary>
        /// Date d'import du groupe de fonctionnalités.
        /// </summary>
        public DateTime SuiviDateCreation { get; set; }
    }
}
