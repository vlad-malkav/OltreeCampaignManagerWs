﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Objet de paramètres pour la réponse de validation de l'OTP.
    /// </summary>
    public class ReponseValidationOtp
    {
        /// <summary>
        /// Message d'erreur.
        /// </summary>
        public string MessageErreur { get; set; }

        /// <summary>
        /// Indique si l'OTP est valide.
        /// </summary>
        public bool EstValide { get; set; }
    }
}

