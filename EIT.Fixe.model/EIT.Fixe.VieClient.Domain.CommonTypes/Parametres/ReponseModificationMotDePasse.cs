﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Objet de paramètres pour la réponse de modification de mot de passe.
    /// </summary>
    public class ReponseModificationMotDePasse
    {
        /// <summary>
        /// Code de l'erreur.
        /// </summary>
        public int CodeErreur { get; set; }
        /// <summary>
        /// Message d'erreur.
        /// </summary>
        public string MessageErreur { get; set; }

        /// <summary>le mot de passe Selfcare a été modifié.
        /// </summary>
        public bool EstModifie { get; set; }
    }
}
