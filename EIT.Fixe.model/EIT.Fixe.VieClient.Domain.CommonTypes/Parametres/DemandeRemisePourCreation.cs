﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.ReferentielServiceExterne;
using EIT.Fixe.VieClient.Domain.CommonTypes.Enumerations;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Classe de paramétre pour la creation d'une demande de remise.
    /// </summary>
    public class DemandeRemisePourCreation
    {
        /// <summary>
        /// Type de demande de remise à créer.
        /// </summary>
        public TypeDemandeRemise TypeDemandeRemise { get; set; }

        /// <summary>
        /// Informations de creation d'une demande de remise de type forfait.
        /// </summary>
        public DemandeRemiseForfaitPourCreation DetailRemiseForfaitPourCreation { get; set; }

        /// <summary>
        /// Informations de creation d'une demande de remise de type promotion.
        /// </summary>
        public PromotionPourDetail PromotionPourDetail { get; set; }
    }
}