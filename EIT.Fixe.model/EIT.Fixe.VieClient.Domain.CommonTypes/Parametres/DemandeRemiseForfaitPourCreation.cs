﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Classe de paramétres pour la création d'une demande de remise par forfait.
    /// </summary>
    public class DemandeRemiseForfaitPourCreation
    {
        /// <summary>
        /// Montant HT.
        /// </summary>
        public decimal MontantHT { get; set; }
    }
}