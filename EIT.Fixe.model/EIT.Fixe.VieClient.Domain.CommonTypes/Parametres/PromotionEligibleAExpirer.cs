﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Classe d'une promotion éligible a expirer.
    /// </summary>
    public class PromotionEligibleAExpirer
    {
        /// <summary>
        /// Clé de la ligne.
        /// </summary>
        public long CleLigne { get; set; }

        /// <summary>
        /// Clé de la promotion.
        /// </summary>
        public long ClePromotion { get; set; }
    }
}