﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Informations supplémentaires d'un Formulaire de niveau 2 de demande d'intervention pour sa création.
    /// </summary>
    public class InformationsSupplementairesCN2DiPourCreation
    {
        /// <summary>
        /// Numéro commande client.
        /// </summary>
        public string NumeroCommandeClient { get; set; }

        /// <summary>
        /// Date approximative d'appel du service client.
        /// </summary>
        public virtual DateTime DateApproxAppelServiceClient { get; set; }

        /// <summary>
        /// Raisons du dysfonctionnement.
        /// </summary>
        public virtual string RaisonsDysfonctionnement { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        public virtual string DemandeClient { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        public virtual string SolutionsDejaApportees { get; set; }
    }
}