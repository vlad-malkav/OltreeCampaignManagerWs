﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Informations d’un Client pour création (Formulaire GBO).
    /// </summary>
    public class InformationsClientPourCreation
    {


        /// <summary>
        /// Nom client.
        /// </summary>
        public string NomClient { get; set; }

        /// <summary>
        /// Prénom client.
        /// </summary>
        public string PrenomClient { get; set; }
    }
}