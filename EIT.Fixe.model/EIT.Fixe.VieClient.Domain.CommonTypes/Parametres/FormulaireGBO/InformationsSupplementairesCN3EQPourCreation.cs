﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Informations supplémentaires d'un Formulaire de niveau 3 d'engagement qualité pour sa création.
    /// </summary>
    public class InformationsSupplementairesCN3EqPourCreation
    {

        /// <summary>
        /// Numero de suivi du dossier concerné.
        /// </summary>
        public virtual string NumeroSuiviDossier { get; set; }

        /// <summary>
        /// Date de réponse cellule N2.
        /// </summary>
        public virtual DateTime DateReponseCelluleN2 { get; set; }

        /// <summary>
        /// Raison de la contestation.
        /// </summary>
        public virtual string RaisonContestation { get; set; }

        /// <summary>
        /// Demande du client.
        /// </summary>
        public virtual string DemandeClient { get; set; }

        /// <summary>
        /// Solutions déjà apportées.
        /// </summary>
        public virtual string SolutionsDejaApportees { get; set; }
    }
}