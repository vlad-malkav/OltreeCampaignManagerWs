﻿namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Informations d’un CDC pour création (Formulaire GBO).
    /// </summary>
    public class InformationsCdcPourCreation
    {
        /// <summary>
        /// Adresse mail du Chargé de Clientèle.
        /// </summary>
        public virtual string CdcAdresseMail { get; set; }

        /// <summary>
        /// Code banque du Chargé de Clientèle.
        /// </summary>
        public virtual string CdcCodeBanque { get; set; }

        /// <summary>
        /// Code branche du Chargé de Clientèle.
        /// </summary>
        public virtual string CdcCodeBranche { get; set; }

        /// <summary>
        /// Ligne directe du Chargé de Clientèle.
        /// </summary>
        public virtual string CdcLigneDirecte { get; set; }

        /// <summary>
        /// Nom et prenom concaténés du Chargé de Clientèle.
        /// </summary>
        public virtual string CdcNomPrenom { get; set; }
    }
}