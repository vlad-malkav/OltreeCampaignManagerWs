﻿using System;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Parametres
{
    /// <summary>
    /// Informations d’une panne collective pour sa création.
    /// </summary>
    public struct InformationsPanneCollectivePourCreation
    {
        /// <summary>
        /// Clé unique de la panne collective.
        /// </summary>
        public long Cle { get; set; }

        /// <summary>
        /// Clé unique de la ligne.
        /// </summary>
        public long CleLigne { get; set; }

        /// <summary>
        /// Date de début de la panne.
        /// </summary>
        public DateTime DateDebut { get; set; }
    }
}