﻿using EIT.Domain;
using System;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Events
{
    /// <summary>
    /// Evénement ResiliationEffectuee.
    /// </summary>
    public class ResiliationEffectuee : Event
    {
        /// <summary>
        /// Date de l'événement.
        /// </summary>
        [DataMember]
        public DateTime Date { get; set; }

        /// <summary>
        /// Référence externe de la ligne.
        /// </summary>
        [DataMember]
        public string ReferenceExterne { get; set; }
    }
}