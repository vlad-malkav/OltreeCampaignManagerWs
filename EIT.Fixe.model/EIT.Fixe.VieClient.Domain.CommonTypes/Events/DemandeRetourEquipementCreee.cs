﻿using EIT.Domain;
using System.Runtime.Serialization;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Events
{
    /// <summary>
    /// Evènement levé lorsqu'une demande de retour d'équipement a été créée.
    /// </summary>
    public class DemandeRetourEquipementCreee : Event
    {
        /// <summary>
        /// Numéro de retour.
        /// </summary>
        [DataMember]
        public string NumeroRetour { get; set; }

        /// <summary>
        /// Clé de la demande de retour.
        /// </summary>
        [DataMember]
        public long CleDemandeRetour { get; set; }

        /// <summary>
        /// Clé de la demande de résiliation.
        /// </summary>
        [DataMember]
        public long CleDemandeResiliation { get; set; }
    }
}