﻿using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Tiers.Application.Adresse;

namespace EIT.Fixe.VieClient.Domain.CommonTypes.Mappers.TiersMapper
{
    /// <summary>
    /// Méthodes génériques de conversion d'adresse d'un tiers.
    /// </summary>
    internal static class AdresseTiersMapper
    {
        /// <summary>
        /// Conversion d'adresse.
        /// </summary>
        /// <param name="adresseAConvertir">Adresse à convertir.</param>
        /// <returns>Informations de l'adresse d'un tiers.</returns>
        internal static AdresseTiers Convertir(Adresse adresseAConvertir)
        {
            if (adresseAConvertir == null)
            {
                return null;
            }

            return new AdresseTiers()
            {
                Cle = adresseAConvertir.Cle,
                CodePostal = adresseAConvertir.CodePostal,
                ComplementIdentification = adresseAConvertir.ComplementIdentification,
                ComplementPointRemise = adresseAConvertir.ComplementPtRemise,
                ServiceParticulier = adresseAConvertir.ServiceParticulier,
                Ville = adresseAConvertir.Ville,
                Voie = adresseAConvertir.Voie,
                EstPrincipale = adresseAConvertir.EstPrincipale
            };
        }
    }
}