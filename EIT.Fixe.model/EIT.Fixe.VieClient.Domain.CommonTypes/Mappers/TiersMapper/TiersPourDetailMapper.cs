﻿using EIT.Fixe.Domain.CommonTypes;
using EIT.Fixe.VieClient.Domain.CommonTypes.DTO.TiersServiceExterne;
using EIT.Tiers.Application;
using EIT.Tiers.Application.Tiers;
using System;
using System.Collections.Generic;
using System.Linq;


namespace EIT.Fixe.VieClient.Domain.CommonTypes.Mappers.TiersMapper
{
    /// <summary>
    /// Méthodes génériques de conversion de tiers.
    /// </summary>
    public static class TiersPourDetailMapper
    {
        /// <summary>
        /// Conversion du Tiers récupéré de la brique Tiers vers TiersPourDetail du domaine VieClient.
        /// </summary>
        /// <param name="tiers">TiersPhysique récupéré de la brique tiers.</param>
        /// <returns>Objet de présentation TiersPourDetail.</returns>
        public static TiersPourDetail Convertir(TiersPhysique tiersAConvertir)
        {
            if (tiersAConvertir == null)
            {
                return null;
            }

            TiersPourDetail tiersARetourner = new TiersPourDetail()
            {
                Civilite = Convertir(tiersAConvertir.Civilite),
                CiviliteEnum = (Civilite)Enum.Parse(typeof(TypeCivilite), tiersAConvertir.Civilite.ToString()),
                Cle = tiersAConvertir.Tiers.Cle,
                DateNaissance = tiersAConvertir.DateNaissance,
                EmailContact = tiersAConvertir.Tiers.Email,
                EstContactCourrierPossible = tiersAConvertir.Tiers.PreferenceDeContactCourrier,
                EstContactEmailPossible = tiersAConvertir.Tiers.PreferenceDeContactEmail,
                EstContactMessageVocalPossible = tiersAConvertir.Tiers.PreferenceDeContactVocal,
                EstContactSmsPossible = tiersAConvertir.Tiers.PreferenceDeContactSMS,
                EstContactTeleventePossible = tiersAConvertir.Tiers.PreferenceDeContactTelevente,
                ListeReferenceBancaire = tiersAConvertir.Tiers.ListeRefBan.ToList(),
                Nom = tiersAConvertir.Nom,
                NomNaissance = tiersAConvertir.NomNaissance,
                NumeroMobileDeContact = tiersAConvertir.Tiers.TelPortable,
                NumeroDepartementNaissance = tiersAConvertir.DptNaissance,
                NumeroFixeDeContact = tiersAConvertir.Tiers.TelFixe,
                NumeroTiersBancaire = tiersAConvertir.Tiers.NumeroTiersBancaire,
                Prenom = tiersAConvertir.Prenom,
                VilleNaissance = tiersAConvertir.VilleNaissance
            };

            List<AdresseTiers> listeAdresses = new List<AdresseTiers>();
            foreach (var adresse in tiersAConvertir.Tiers.ListeAdresses)
            {
                listeAdresses.Add(AdresseTiersMapper.Convertir(adresse));
            }

            tiersARetourner.ListeAdresses = listeAdresses;

            return tiersARetourner;
        }

        /// <summary>
        /// Conversion de la civilité de la brique tiers en civilité Fixe.
        /// </summary>
        /// <param name="civilite">Civilité à convertir.</param>
        /// <returns>Valeur de la civilité au sein du SI Fixe.</returns>
        internal static Fixe.Domain.CommonTypes.Civilite Convertir(Tiers.Application.TypeCivilite civilite)
        {
            switch (civilite)
            {
                case Tiers.Application.TypeCivilite.Madame:
                    return Fixe.Domain.CommonTypes.Civilite.Mme;
                case Tiers.Application.TypeCivilite.Mademoiselle:
                    return Fixe.Domain.CommonTypes.Civilite.Melle;
                case Tiers.Application.TypeCivilite.Monsieur:
                    return Fixe.Domain.CommonTypes.Civilite.M;
                case Tiers.Application.TypeCivilite.NonDefini:
                default:
                    return Fixe.Domain.CommonTypes.Civilite.NA;
            }
        }
    }
}